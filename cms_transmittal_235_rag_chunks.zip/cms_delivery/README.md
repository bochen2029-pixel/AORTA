# CMS Transmittal 235 — Pre-Chunked RAG Package

**Source:** `r235soma.pdf` (State Operations Manual Appendix A - Hospitals & Psychiatric Hospitals)
**Published:** January 16, 2026
**Processed:** February 19, 2026

## What's In This Package

| File/Dir | Purpose |
|----------|---------|
| `chunks_final.jsonl` | **Primary RAG ingest file.** One JSON object per line. Load directly into ChromaDB, LanceDB, FAISS, or any vector store. |
| `chunks_final.json` | Same data as pretty-printed JSON array. Good for inspection and debugging. |
| `chunks_final_txt/` | Individual `.txt` files per chunk with metadata headers. For manual review or file-based ingestion. |
| `CHUNK_INDEX_FINAL.md` | Summary index of all chunks with token counts and metadata. |
| `raw_extracted_text.txt` | Full extracted text from the PDF (for reference/re-processing). |
| `chunk_cms_transmittal.py` | The chunking script (reusable for other CMS transmittals). |
| `postprocess_chunks.py` | Post-processor for size normalization. |
| `r235soma.pdf` | Original source PDF. |

## Chunk Stats

- **Total chunks:** 172
- **Total tokens (est):** ~114,600
- **Token range:** 105 – 1,818
- **Target max:** 1,800 tokens/chunk (3 chunks slightly over)
- **Median:** ~475 tokens

## Chunk Structure (JSONL fields)

```json
{
  "chunk_id": "CMS-T235-A-0263-interpretive_guidance",
  "chunk_type": "regulatory_section",
  "a_tag": "A-0263",
  "cfr_section": "§482.21",
  "cfr_title": "Quality Assessment and Performance Improvement Program",
  "change_type": "R",
  "effective_date": "2026-01-16",
  "transmittal": "235",
  "source_document": "r235soma.pdf",
  "content": "... the actual text ...",
  "token_estimate": 2382,
  "topic_keywords": ["QAPI", "governing_body"],
  "page_range": null
}
```

## How to Use with LM Studio / Local RAG

### Option 1: Direct file loading
Many LM Studio RAG setups accept a folder of `.txt` files. Point it at `chunks_final_txt/`.

### Option 2: Vector store ingestion (Python)
```python
import json

# Load chunks
chunks = []
with open('chunks_final.jsonl') as f:
    for line in f:
        chunks.append(json.loads(line))

# For ChromaDB:
import chromadb
client = chromadb.Client()
collection = client.create_collection("cms_t235")
collection.add(
    ids=[c['chunk_id'] for c in chunks],
    documents=[c['content'] for c in chunks],
    metadatas=[{k: v for k, v in c.items() 
                if k not in ('content', 'token_estimate') and v is not None}
               for c in chunks]
)

# Query example:
results = collection.query(
    query_texts=["QAPI data collection requirements"],
    n_results=5,
    where={"change_type": "R"}  # only revised sections
)
```

### Option 3: LanceDB (recommended for local)
```python
import lancedb
import json

db = lancedb.connect("./cms_lance")
chunks = [json.loads(line) for line in open('chunks_final.jsonl')]
table = db.create_table("cms_t235", chunks)

# Full-text search + metadata filter
results = table.search("infection control antibiotic").where("change_type = 'N'").limit(5).to_list()
```

## Metadata Filtering Cheat Sheet

| Query Pattern | Filter |
|--------------|--------|
| "What's new in this transmittal?" | `change_type == "N"` |
| "What was deleted?" | `change_type == "D"` |
| "Show me infection control sections" | `topic_keywords contains "infection_control"` |
| "QAPI requirements" | `topic_keywords contains "QAPI"` |
| "Psychiatric hospital specific" | `topic_keywords contains "psychiatric"` |
| "Everything about §482.42" | `cfr_section == "§482.42"` |
| "Discharge planning" | `topic_keywords contains "discharge_planning"` |

## Chunking Strategy

1. **Primary split:** By A-tag (A-0020, A-0144, etc.) — each is a self-contained regulatory concept
2. **Secondary split:** Within large A-tags, split at "Interpretive Guidelines" and "Survey Procedures" boundaries
3. **Tertiary split:** Paragraph-level splitting for chunks still >1,800 tokens
4. **Front-matter:** Transmittal summary, Task 1, and Task 6 are separate chunks
5. **Tiny stubs (<80 tokens):** Discarded (just revision headers with no content)

## Reprocessing

To re-run on a different CMS transmittal PDF:
```bash
python3 chunk_cms_transmittal.py <your_pdf.pdf> output
python3 postprocess_chunks.py
```
You'll need to update the A-tag regex patterns if the document structure differs significantly.
