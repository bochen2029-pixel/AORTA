# CMS Transmittal 235 — Final Chunk Index

**Source:** r235soma.pdf
**Effective Date:** January 16, 2026
**Total Chunks:** 172
**Total Tokens (est):** 114,623
**Max chunk tokens:** 1,800 target

## Token Distribution

- Min: 105
- Max: 1,818
- Median: 545
- Mean: 666
- Chunks still >1800: 3

## Change Types

- N: 19
- N/A: 5
- R: 148

## All Chunks

| # | Chunk ID | A-Tag | CFR | Change | Tokens | Topics |
|---|---|---|---|---|---|---|
| 1 | TRANSMITTAL-235-SUMMARY-part1 | — | — | — | 1,308 | transmittal_summary, change_table |
| 2 | TRANSMITTAL-235-SUMMARY-part2 | — | — | — | 1,402 | transmittal_summary, change_table |
| 3 | TRANSMITTAL-235-SUMMARY-part3 | — | — | — | 1,673 | transmittal_summary, change_table |
| 4 | TRANSMITTAL-235-SUMMARY-part4 | — | — | — | 1,537 | transmittal_summary, change_table |
| 5 | TRANSMITTAL-235-SUMMARY-part5 | — | — | — | 890 | transmittal_summary, change_table |
| 6 | SURVEY-PROTOCOL-TASK-6-part1 | — | — | R | 1,415 | survey_protocol, post_survey, plan_of_correction |
| 7 | SURVEY-PROTOCOL-TASK-6-part2 | — | — | R | 1,627 | survey_protocol, post_survey, plan_of_correction |
| 8 | SURVEY-PROTOCOL-TASK-6-part3 | — | — | R | 1,518 | survey_protocol, post_survey, plan_of_correction |
| 9 | SURVEY-PROTOCOL-TASK-6-part4 | — | — | R | 1,772 | survey_protocol, post_survey, plan_of_correction |
| 10 | SURVEY-PROTOCOL-TASK-6-part5 | — | — | R | 1,804 | survey_protocol, post_survey, plan_of_correction |
| 11 | CMS-T235-A-0020 | A-0020 | §482.11 | R | 508 | compliance, medical_records, observation_notice |
| 12 | CMS-T235-A-0144-interpretive_guidance | A-0144 | §482.13 | R | 1,427 | infection_control, patient_rights, psychiatric |
| 13 | CMS-T235-A-0144-survey_procedures | A-0144 | §482.13 | R | 685 | infection_control, patient_rights, psychiatric |
| 14 | CMS-T235-A-0213 | A-0213 | §482.13 | R | 1,686 | death_reporting, medical_records, restraint_seclusion |
| 15 | CMS-T235-A-0214-part1 | A-0214 | §482.13 | R | 1,765 | death_reporting, medical_records, rehabilitation |
| 16 | CMS-T235-A-0214-part2 | A-0214 | §482.13 | R | 184 | death_reporting, medical_records, rehabilitation |
| 17 | CMS-T235-A-0263-regulation | A-0263 | §482.21 | R | 198 | QAPI, governing_body, infection_control |
| 18 | CMS-T235-A-0263-interpretive_guidance-part1 | A-0263 | §482.21 | R | 1,685 | QAPI, governing_body, infection_control |
| 19 | CMS-T235-A-0263-interpretive_guidance-part2 | A-0263 | §482.21 | R | 689 | QAPI, governing_body, infection_control |
| 20 | CMS-T235-A-0273 | A-0273 | §482.21 | R | 1,744 | governing_body |
| 21 | CMS-T235-A-0283 | A-0283 | §482.21 | R | 1,088 | QAPI, governing_body, infection_control |
| 22 | CMS-T235-A-0286-regulation | A-0286 | §482.21 | R | 289 | QAPI, governing_body, infection_control |
| 23 | CMS-T235-A-0286-interpretive_guidance | A-0286 | §482.21 | R | 1,444 | QAPI, governing_body, infection_control |
| 24 | CMS-T235-A-0286-survey_procedures | A-0286 | §482.21 | R | 375 | QAPI, governing_body, infection_control |
| 25 | CMS-T235-A-0297 | A-0297 | §482.21 | R | 1,349 | QAPI, governing_body, patient_rights |
| 26 | CMS-T235-A-0309-regulation | A-0309 | §482.21 | R | 221 | QAPI, emergency_services, governing_body |
| 27 | CMS-T235-A-0309-interpretive_guidance | A-0309 | §482.21 | R | 1,429 | QAPI, emergency_services, governing_body |
| 28 | CMS-T235-A-0309-survey_procedures | A-0309 | §482.21 | R | 380 | QAPI, emergency_services, governing_body |
| 29 | CMS-T235-A-0315 | A-0315 | §482.21 | R | 790 | governing_body, medical_staff |
| 30 | CMS-T235-A-0320 | A-0320 | §482.21 | R | 484 | governing_body |
| 31 | CMS-T235-A-0321 | A-0321 | §482.21 | R | 263 |  |
| 32 | CMS-T235-A-0322 | A-0322 | §482.21 | R | 316 |  |
| 33 | CMS-T235-A-0360 | A-0360 | §482.22 | R | 697 | medical_records, medical_staff, surgical_services |
| 34 | CMS-T235-A-0361 | A-0361 | §482.22 | R | 371 | medical_staff |
| 35 | CMS-T235-A-0362 | A-0362 | §482.22 | R | 736 | governing_body, medical_records, medical_staff |
| 36 | CMS-T235-A-0399 | A-0399 | §482.23 | R | 822 | nursing_services, patient_rights |
| 37 | CMS-T235-A-0458 | A-0458 | §482.24 | R | 812 | medical_records, medical_staff, surgical_services |
| 38 | CMS-T235-A-0461 | A-0461 | §482.24 | R | 1,074 | medical_records, medical_staff, surgical_services |
| 39 | CMS-T235-A-0462 | A-0462 | §482.24 | R | 650 | medical_records, medical_staff, surgical_services |
| 40 | CMS-T235-A-0470 | A-0470 | §482.24 | N | 933 | medical_records |
| 41 | CMS-T235-A-0471 | A-0471 | §482.24 | N | 458 | medical_records |
| 42 | CMS-T235-A-0700 | A-0700 | §482.41 | R | 333 | physical_environment |
| 43 | CMS-T235-A-0701 | A-0701 | §482.41 | R | 1,353 | nursing_services, patient_rights, physical_environment |
| 44 | CMS-T235-A-0702 | A-0702 | §482.41 | R | 288 | physical_environment |
| 45 | CMS-T235-A-0710 | A-0710 | §482.41 | R | 1,338 | physical_environment |
| 46 | CMS-T235-A-0713 | A-0713 | §482.41 | R | 299 |  |
| 47 | CMS-T235-A-0714 | A-0714 | §482.41 | R | 197 | physical_environment |
| 48 | CMS-T235-A-0715 | A-0715 | §482.41 | R | 120 | physical_environment |
| 49 | CMS-T235-A-0716 | A-0716 | §482.41 | R | 684 | infection_control |
| 50 | CMS-T235-A-0717 | A-0717 | §482.41 | R | 460 | physical_environment |
| 51 | CMS-T235-A-0718 | A-0718 | §482.41 | R | 413 |  |
| 52 | CMS-T235-A-0720 | A-0720 | §482.41 | R | 653 | physical_environment |
| 53 | CMS-T235-A-0722 | A-0722 | §482.41 | R | 249 |  |
| 54 | CMS-T235-A-0723 | A-0723 | §482.41 | R | 213 |  |
| 55 | CMS-T235-A-0724-interpretive_guidance-part1 | A-0724 | §482.41 | R | 1,814 | patient_rights, physical_environment |
| 56 | CMS-T235-A-0724-interpretive_guidance-part2 | A-0724 | §482.41 | R | 1,659 | patient_rights, physical_environment |
| 57 | CMS-T235-A-0724-interpretive_guidance-part3 | A-0724 | §482.41 | R | 1,759 | patient_rights, physical_environment |
| 58 | CMS-T235-A-0724-interpretive_guidance-part4 | A-0724 | §482.41 | R | 202 | patient_rights, physical_environment |
| 59 | CMS-T235-A-0724-survey_procedures | A-0724 | §482.41 | R | 1,117 | patient_rights, physical_environment |
| 60 | CMS-T235-A-0725 | A-0725 | §482.41 | R | 183 |  |
| 61 | CMS-T235-A-0726 | A-0726 | §482.41 | R | 963 | compliance |
| 62 | CMS-T235-A-0747 | A-0747 | §482.42 | R | 752 | QAPI, antibiotic_stewardship, infection_control |
| 63 | CMS-T235-A-0748 | A-0748 | §482.42 | R | 929 | governing_body, infection_control, medical_staff |
| 64 | CMS-T235-A-0749 | A-0749 | §482.42 | R | 778 | infection_control |
| 65 | CMS-T235-A-0750 | A-0750 | §482.42 | R | 1,340 | infection_control |
| 66 | CMS-T235-A-0751 | A-0751 | §482.42 | R | 345 | infection_control |
| 67 | CMS-T235-A-0760 | A-0760 | §482.42 | N | 1,184 | antibiotic_stewardship, governing_body, medical_staff |
| 68 | CMS-T235-A-0761 | A-0761 | §482.42 | N | 595 | antibiotic_stewardship, infection_control, medical_staff |
| 69 | CMS-T235-A-0762 | A-0762 | §482.42 | N | 191 | antibiotic_stewardship |
| 70 | CMS-T235-A-0763 | A-0763 | §482.42 | N | 280 | antibiotic_stewardship |
| 71 | CMS-T235-A-0764 | A-0764 | §482.42 | N | 588 | antibiotic_stewardship, patient_rights |
| 72 | CMS-T235-A-0765 | A-0765 | §482.42 | N | 155 | antibiotic_stewardship |
| 73 | CMS-T235-A-0770 | A-0770 | §482.42 | R | 607 | antibiotic_stewardship, governing_body, infection_control |
| 74 | CMS-T235-A-0771 | A-0771 | §482.42 | R | 809 | QAPI, antibiotic_stewardship, governing_body |
| 75 | CMS-T235-A-0772 | A-0772 | §482.42 | R | 450 | infection_control |
| 76 | CMS-T235-A-0773 | A-0773 | §482.42 | R | 339 | infection_control |
| 77 | CMS-T235-A-0774 | A-0774 | §482.42 | R | 269 | infection_control |
| 78 | CMS-T235-A-0775 | A-0775 | §482.42 | R | 361 | infection_control, medical_staff |
| 79 | CMS-T235-A-0776 | A-0776 | §482.42 | R | 245 | infection_control |
| 80 | CMS-T235-A-0777 | A-0777 | §482.42 | R | 230 | antibiotic_stewardship, infection_control |
| 81 | CMS-T235-A-0778 | A-0778 | §482.42 | R | 358 | antibiotic_stewardship, infection_control |
| 82 | CMS-T235-A-0779 | A-0779 | §482.42 | R | 181 | antibiotic_stewardship |
| 83 | CMS-T235-A-0780 | A-0780 | §482.42 | R | 247 | antibiotic_stewardship, infection_control, medical_staff |
| 84 | CMS-T235-A-0781 | A-0781 | §482.42 | R | 313 | antibiotic_stewardship, medical_staff |
| 85 | CMS-T235-A-0785 | A-0785 | §482.42 | R | 545 | antibiotic_stewardship, governing_body, infection_control |
| 86 | CMS-T235-A-0786 | A-0786 | §482.42 | R | 338 | antibiotic_stewardship, infection_control |
| 87 | CMS-T235-A-0787 | A-0787 | §482.42 | R | 294 | antibiotic_stewardship, infection_control |
| 88 | CMS-T235-A-0788 | A-0788 | §482.42 | R | 259 | antibiotic_stewardship, infection_control |
| 89 | CMS-T235-A-0789 | A-0789 | §482.42 | R | 600 | antibiotic_stewardship, governing_body, infection_control |
| 90 | CMS-T235-A-0799 | A-0799 | §482.43 | R | 578 | discharge_planning |
| 91 | CMS-T235-A-0800 | A-0800 | §482.43 | R | 908 | discharge_planning, medical_records |
| 92 | CMS-T235-A-0801 | A-0801 | §482.43 | R | 239 | discharge_planning, medical_records |
| 93 | CMS-T235-A-0802 | A-0802 | §482.43 | R | 364 | discharge_planning, medical_records |
| 94 | CMS-T235-A-0803 | A-0803 | §482.43 | R | 345 | discharge_planning |
| 95 | CMS-T235-A-0804 | A-0804 | §482.43 | R | 698 | discharge_planning, medical_records, rehabilitation |
| 96 | CMS-T235-A-0806 | A-0806 | §482.43 | R | 775 | discharge_planning |
| 97 | CMS-T235-A-0807 | A-0807 | §482.43 | R | 1,039 | discharge_planning, physical_environment, rehabilitation |
| 98 | CMS-T235-A-0808 | A-0808 | §482.43 | R | 701 | discharge_planning, medical_records, rehabilitation |
| 99 | CMS-T235-A-0809 | A-0809 | §482.43 | R | 476 | discharge_planning, nursing_services |
| 100 | CMS-T235-A-0810 | A-0810 | §482.43 | R | 1,167 | discharge_planning, medical_records, psychiatric |
| 101 | CMS-T235-A-0812 | A-0812 | §482.43 | R | 123 |  |
| 102 | CMS-T235-A-0813 | A-0813 | §482.43 | R | 980 | discharge_planning, medical_records |
| 103 | CMS-T235-A-0814 | A-0814 | §482.43 | R | 474 | discharge_planning |
| 104 | CMS-T235-A-0815 | A-0815 | §482.43 | R | 345 | discharge_planning |
| 105 | CMS-T235-A-0826 | A-0826 | §482.43 | N | 162 | transfer_protocol |
| 106 | CMS-T235-A-0953 | A-0953 | §482.51 | R | 633 | medical_records, medical_staff, surgical_services |
| 107 | CMS-T235-A-0954 | A-0954 | §482.51 | R | 651 | medical_records, medical_staff, surgical_services |
| 108 | CMS-T235-A-1114 | A-1114 | §482.55 | N | 105 | emergency_services |
| 109 | CMS-T235-A-1115 | A-1115 | §482.55 | N | 118 |  |
| 110 | CMS-T235-A-1116 | A-1116 | §482.55 | N | 204 | emergency_services |
| 111 | CMS-T235-A-1117 | A-1117 | §482.55 | N | 191 | governing_body |
| 112 | CMS-T235-A-1572-regulation | A-1572 | §482.58 | N | 265 | discharge_planning, medical_records, nursing_services |
| 113 | CMS-T235-A-1572-survey_procedures-part1 | A-1572 | §482.58 | N | 1,818 | discharge_planning, medical_records, nursing_services |
| 114 | CMS-T235-A-1572-survey_procedures-part2 | A-1572 | §482.58 | N | 1,573 | discharge_planning, medical_records, nursing_services |
| 115 | CMS-T235-A-1572-survey_procedures-part3 | A-1572 | §482.58 | N | 770 | discharge_planning, medical_records, nursing_services |
| 116 | CMS-T235-A-1600 | A-1600 | §482.60 | R | 1,156 | discharge_planning, emergency_services, medical_staff |
| 117 | CMS-T235-A-1601 | A-1601 | §482.60 | R | 251 | governing_body, medical_records, medical_staff |
| 118 | CMS-T235-A-1605 | A-1605 | §482.60 | R | 255 | medical_records, psychiatric, swing_bed |
| 119 | CMS-T235-A-1610 | A-1610 | §482.60 | R | 116 | psychiatric |
| 120 | CMS-T235-A-1620 | A-1620 | §482.61 | R | 684 | medical_records, psychiatric |
| 121 | CMS-T235-A-1621 | A-1621 | §482.61 | R | 368 | medical_records, psychiatric |
| 122 | CMS-T235-A-1622 | A-1622 | §482.61 | R | 337 | medical_records, psychiatric |
| 123 | CMS-T235-A-1623 | A-1623 | §482.61 | R | 735 | medical_records, psychiatric |
| 124 | CMS-T235-A-1624 | A-1624 | §482.61 | R | 330 | medical_records |
| 125 | CMS-T235-A-1625 | A-1625 | §482.61 | R | 852 | discharge_planning, medical_records, psychiatric |
| 126 | CMS-T235-A-1626 | A-1626 | §482.61 | R | 538 | medical_records, medical_staff, surgical_services |
| 127 | CMS-T235-A-1630 | A-1630 | §482.61 | R | 283 | medical_records, psychiatric |
| 128 | CMS-T235-A-1631 | A-1631 | §482.61 | R | 126 | psychiatric |
| 129 | CMS-T235-A-1632 | A-1632 | §482.61 | R | 427 | medical_staff, psychiatric |
| 130 | CMS-T235-A-1633 | A-1633 | §482.61 | R | 350 | medical_records, psychiatric |
| 131 | CMS-T235-A-1634 | A-1634 | §482.61 | R | 409 | medical_records, psychiatric |
| 132 | CMS-T235-A-1635 | A-1635 | §482.61 | R | 231 | medical_records, psychiatric |
| 133 | CMS-T235-A-1636 | A-1636 | §482.61 | R | 202 | medical_records, psychiatric |
| 134 | CMS-T235-A-1637 | A-1637 | §482.61 | R | 304 | medical_records, psychiatric |
| 135 | CMS-T235-A-1640 | A-1640 | §482.61 | R | 517 | medical_records, psychiatric |
| 136 | CMS-T235-A-1641 | A-1641 | §482.61 | R | 416 | medical_records, medical_staff, psychiatric |
| 137 | CMS-T235-A-1642 | A-1642 | §482.61 | R | 635 | medical_records |
| 138 | CMS-T235-A-1643 | A-1643 | §482.61 | R | 749 | discharge_planning, psychiatric |
| 139 | CMS-T235-A-1644 | A-1644 | §482.61 | R | 372 | medical_records |
| 140 | CMS-T235-A-1645 | A-1645 | §482.61 | R | 376 | medical_records, psychiatric, rehabilitation |
| 141 | CMS-T235-A-1650 | A-1650 | §482.61 | R | 773 | medical_records, patient_rights |
| 142 | CMS-T235-A-1655 | A-1655 | §482.61 | R | 695 | medical_records, rehabilitation |
| 143 | CMS-T235-A-1660 | A-1660 | §482.61 | R | 398 | medical_records, restraint_seclusion |
| 144 | CMS-T235-A-1661 | A-1661 | §482.61 | R | 329 | medical_records |
| 145 | CMS-T235-A-1662 | A-1662 | §482.61 | R | 268 | medical_records |
| 146 | CMS-T235-A-1670 | A-1670 | §482.61 | R | 691 | discharge_planning, medical_records, medical_staff |
| 147 | CMS-T235-A-1671 | A-1671 | §482.61 | R | 757 | discharge_planning, medical_records, psychiatric |
| 148 | CMS-T235-A-1672 | A-1672 | §482.61 | R | 173 | medical_records |
| 149 | CMS-T235-A-1673 | A-1673 | §482.61 | N | 952 | medical_records, psychiatric |
| 150 | CMS-T235-A-1674 | A-1674 | §482.61 | N | 460 | medical_records, psychiatric |
| 151 | CMS-T235-A-1680 | A-1680 | §482.62 | R | 869 | discharge_planning, medical_records, nursing_services |
| 152 | CMS-T235-A-1685 | A-1685 | §482.62 | R | 410 | medical_records |
| 153 | CMS-T235-A-1686 | A-1686 | §482.62 | R | 524 | medical_records |
| 154 | CMS-T235-A-1687 | A-1687 | §482.62 | R | 673 | medical_records |
| 155 | CMS-T235-A-1688 | A-1688 | §482.62 | R | 742 | discharge_planning, medical_records, psychiatric |
| 156 | CMS-T235-A-1690 | A-1690 | §482.62 | R | 638 | medical_staff, psychiatric |
| 157 | CMS-T235-A-1691 | A-1691 | §482.62 | R | 479 | medical_records |
| 158 | CMS-T235-A-1692 | A-1692 | §482.62 | R | 407 |  |
| 159 | CMS-T235-A-1693 | A-1693 | §482.62 | R | 900 | QAPI, governing_body, medical_records |
| 160 | CMS-T235-A-1695 | A-1695 | §482.62 | R | 826 | medical_records, psychiatric, surgical_services |
| 161 | CMS-T235-A-1700 | A-1700 | §482.62 | R | 637 | medical_records, nursing_services, psychiatric |
| 162 | CMS-T235-A-1701 | A-1701 | §482.62 | R | 442 | nursing_services, psychiatric |
| 163 | CMS-T235-A-1702 | A-1702 | §482.62 | R | 721 | nursing_services, psychiatric |
| 164 | CMS-T235-A-1703 | A-1703 | §482.62 | R | 394 | medical_records, nursing_services |
| 165 | CMS-T235-A-1704 | A-1704 | §482.62 | R | 870 | medical_records, nursing_services, psychiatric |
| 166 | CMS-T235-A-1710 | A-1710 | §482.62 | R | 520 | psychiatric |
| 167 | CMS-T235-A-1715 | A-1715 | §482.62 | R | 990 | discharge_planning, medical_records, psychiatric |
| 168 | CMS-T235-A-1716 | A-1716 | §482.62 | R | 456 |  |
| 169 | CMS-T235-A-1717 | A-1717 | §482.62 | R | 889 | discharge_planning, medical_records, psychiatric |
| 170 | CMS-T235-A-1720 | A-1720 | §482.62 | R | 602 |  |
| 171 | CMS-T235-A-1725 | A-1725 | §482.62 | R | 364 | rehabilitation |
| 172 | CMS-T235-A-1726 | A-1726 | §482.62 | R | 676 | medical_records, psychiatric |
