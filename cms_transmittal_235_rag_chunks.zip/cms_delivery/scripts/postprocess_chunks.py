#!/usr/bin/env python3
"""
Post-processor: fix oversized chunks and merge/discard tiny stubs.
Reads chunks.jsonl, outputs chunks_final.jsonl and updated files.
"""

import json
import os
import re
from pathlib import Path


def load_chunks(path):
    chunks = []
    with open(path) as f:
        for line in f:
            chunks.append(json.loads(line))
    return chunks


def estimate_tokens(text):
    return len(text) // 4


def split_by_paragraphs(text, max_tokens=1800, min_tokens=100):
    """Split text at double-newline paragraph boundaries, grouping to stay under max_tokens."""
    paragraphs = re.split(r'\n\s*\n', text)
    parts = []
    current = []
    current_len = 0

    for para in paragraphs:
        para_tokens = estimate_tokens(para)
        if current_len + para_tokens > max_tokens and current:
            parts.append('\n\n'.join(current))
            current = [para]
            current_len = para_tokens
        else:
            current.append(para)
            current_len += para_tokens

    if current:
        parts.append('\n\n'.join(current))

    # Merge tiny trailing parts back
    if len(parts) > 1 and estimate_tokens(parts[-1]) < min_tokens:
        parts[-2] = parts[-2] + '\n\n' + parts[-1]
        parts.pop()

    return parts


def postprocess(chunks, max_tokens=1800):
    result = []

    for chunk in chunks:
        tokens = chunk['token_estimate']

        # Filter out tiny stubs (<80 tokens) that are just header fragments
        if tokens < 80:
            # Try to find sibling chunk to merge into
            # For now just skip these — they're revision headers with no content
            continue

        if tokens <= max_tokens:
            result.append(chunk)
            continue

        # Split oversized chunks
        text = chunk['content']
        parts = split_by_paragraphs(text, max_tokens=max_tokens)

        if len(parts) <= 1:
            result.append(chunk)
            continue

        for i, part in enumerate(parts):
            new_chunk = dict(chunk)
            new_chunk['chunk_id'] = f"{chunk['chunk_id']}-part{i+1}"
            new_chunk['content'] = part
            new_chunk['token_estimate'] = estimate_tokens(part)
            result.append(new_chunk)

    return result


def write_all_outputs(chunks, output_dir):
    os.makedirs(output_dir, exist_ok=True)

    # JSONL
    with open(os.path.join(output_dir, 'chunks_final.jsonl'), 'w') as f:
        for c in chunks:
            f.write(json.dumps(c, ensure_ascii=False) + '\n')

    # Pretty JSON
    with open(os.path.join(output_dir, 'chunks_final.json'), 'w') as f:
        json.dump(chunks, f, indent=2, ensure_ascii=False)

    # Text files
    txt_dir = os.path.join(output_dir, 'chunks_final_txt')
    os.makedirs(txt_dir, exist_ok=True)
    for chunk in chunks:
        fname = f"{chunk['chunk_id']}.txt"
        with open(os.path.join(txt_dir, fname), 'w') as f:
            f.write(f"CHUNK_ID: {chunk['chunk_id']}\n")
            f.write(f"TYPE: {chunk['chunk_type']}\n")
            if chunk.get('a_tag'):
                f.write(f"A_TAG: {chunk['a_tag']}\n")
            if chunk.get('cfr_section'):
                f.write(f"CFR_SECTION: {chunk['cfr_section']}\n")
            if chunk.get('cfr_title'):
                f.write(f"CFR_TITLE: {chunk['cfr_title']}\n")
            if chunk.get('change_type'):
                f.write(f"CHANGE_TYPE: {chunk['change_type']}\n")
            f.write(f"EFFECTIVE_DATE: {chunk['effective_date']}\n")
            f.write(f"TOKENS_EST: {chunk['token_estimate']}\n")
            if chunk.get('topic_keywords'):
                f.write(f"TOPICS: {', '.join(chunk['topic_keywords'])}\n")
            f.write(f"{'='*72}\n\n")
            f.write(chunk['content'])

    # Index
    with open(os.path.join(output_dir, 'CHUNK_INDEX_FINAL.md'), 'w') as f:
        f.write("# CMS Transmittal 235 — Final Chunk Index\n\n")
        f.write(f"**Source:** r235soma.pdf\n")
        f.write(f"**Effective Date:** January 16, 2026\n")
        f.write(f"**Total Chunks:** {len(chunks)}\n")
        total_tokens = sum(c['token_estimate'] for c in chunks)
        f.write(f"**Total Tokens (est):** {total_tokens:,}\n")
        f.write(f"**Max chunk tokens:** 1,800 target\n\n")

        token_counts = [c['token_estimate'] for c in chunks]
        f.write("## Token Distribution\n\n")
        f.write(f"- Min: {min(token_counts):,}\n")
        f.write(f"- Max: {max(token_counts):,}\n")
        f.write(f"- Median: {sorted(token_counts)[len(token_counts)//2]:,}\n")
        f.write(f"- Mean: {sum(token_counts)//len(token_counts):,}\n")
        over = sum(1 for t in token_counts if t > 1800)
        f.write(f"- Chunks still >1800: {over}\n\n")

        by_change = {}
        for c in chunks:
            ct = c.get('change_type') or 'N/A'
            by_change[ct] = by_change.get(ct, 0) + 1
        f.write("## Change Types\n\n")
        for ct, count in sorted(by_change.items()):
            f.write(f"- {ct}: {count}\n")

        f.write("\n## All Chunks\n\n")
        f.write("| # | Chunk ID | A-Tag | CFR | Change | Tokens | Topics |\n")
        f.write("|---|---|---|---|---|---|---|\n")
        for i, c in enumerate(chunks, 1):
            topics = ', '.join((c.get('topic_keywords') or [])[:3])
            f.write(
                f"| {i} | {c['chunk_id']} | "
                f"{c.get('a_tag') or '—'} | {c.get('cfr_section') or '—'} | "
                f"{c.get('change_type') or '—'} | {c['token_estimate']:,} | "
                f"{topics} |\n"
            )


def main():
    input_path = 'output/chunks.jsonl'
    output_dir = 'output'

    print("Loading chunks...")
    chunks = load_chunks(input_path)
    print(f"  Loaded {len(chunks)} chunks")

    print("Post-processing...")
    final = postprocess(chunks, max_tokens=1800)
    print(f"  Final chunk count: {len(final)}")
    print(f"  Total tokens: {sum(c['token_estimate'] for c in final):,}")

    tokens = sorted(c['token_estimate'] for c in final)
    print(f"  Token range: {tokens[0]} — {tokens[-1]}")
    over = sum(1 for t in tokens if t > 1800)
    print(f"  Chunks still >1800: {over}")

    print("Writing final outputs...")
    write_all_outputs(final, output_dir)

    print("Done.")


if __name__ == '__main__':
    main()
