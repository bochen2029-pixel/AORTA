#!/usr/bin/env python3
"""
CMS Transmittal 235 (r235soma.pdf) — RAG Chunking Pipeline
=============================================================
Extracts, chunks, and enriches the State Operations Manual Appendix A
revisions into structured JSON suitable for vector store ingestion
(ChromaDB, LanceDB, FAISS, LM Studio, etc.)

Chunking strategy:
  - Front-matter (transmittal summary, change table) → 1 chunk
  - Survey Protocol sections (Task 1, Task 6) → 1 chunk each
  - Each A-tag section (A-0020, A-0144, ...) → 1 chunk containing
    regulation text + interpretive guidelines + survey procedures
  - Metadata per chunk: a_tag, cfr_section, cfr_title, change_type,
    effective_date, transmittal, topic_keywords, token_estimate

Output:
  - chunks.jsonl          — one JSON object per line (primary RAG ingest format)
  - chunks_pretty.json    — human-readable JSON array
  - chunks_txt/           — individual .txt files per chunk (for manual review)
  - chunk_index.md        — summary index of all chunks
"""

import json
import re
import os
import sys
from pathlib import Path
from dataclasses import dataclass, field, asdict
from typing import Optional

# ── PDF Text Extraction ──────────────────────────────────────────────

def extract_text_from_pdf(pdf_path: str) -> str:
    """Extract full text from PDF using PyMuPDF."""
    import fitz  # PyMuPDF
    doc = fitz.open(pdf_path)
    pages = []
    for page_num in range(len(doc)):
        page = doc[page_num]
        text = page.get_text("text")
        pages.append(text)
    doc.close()
    return "\n".join(pages)


# ── Data Structures ──────────────────────────────────────────────────

@dataclass
class Chunk:
    chunk_id: str
    chunk_type: str               # front_matter | survey_protocol | regulatory_section
    a_tag: Optional[str]          # e.g., "A-0263"
    cfr_section: Optional[str]    # e.g., "§482.21"
    cfr_title: Optional[str]      # e.g., "Quality Assessment and Performance Improvement Program"
    change_type: Optional[str]    # R=Revised, N=New, D=Deleted
    effective_date: str           # "2026-01-16"
    transmittal: str              # "235"
    source_document: str          # "r235soma.pdf"
    content: str                  # The actual text
    token_estimate: int           # Rough token count (~4 chars/token)
    topic_keywords: list = field(default_factory=list)
    page_range: Optional[str] = None


# ── Change Table Parser ──────────────────────────────────────────────

def parse_change_table(text: str) -> dict:
    """
    Parse the R/N/D change table from the front-matter.
    Returns dict mapping A-tag -> change_type (R/N/D).
    """
    changes = {}
    # Pattern: R or N or D followed by section reference containing A-XXXX
    # The table has lines like:
    #   R Appendix A/A-0020/§482.11 ...
    #   N Appendix A/A-0470//§482.24(d)(1-4) ...
    #   D Appendix A/A-0823/§482.43(d)(6) ...
    pattern = re.compile(
        r'^([RND])\s+.*?(?:Appendix\s*A[/\\])?A-(\d{4})',
        re.MULTILINE
    )
    for match in pattern.finditer(text):
        change_type = match.group(1)
        a_num = match.group(2)
        a_tag = f"A-{a_num}"
        changes[a_tag] = change_type
    return changes


# ── CFR Section Extractor ────────────────────────────────────────────

def extract_cfr_section(text: str) -> Optional[str]:
    """Extract the primary CFR section reference (e.g., §482.21)."""
    match = re.search(r'§\s*(\d+\.\d+)', text)
    if match:
        return f"§{match.group(1)}"
    return None


def extract_cfr_title(text: str) -> Optional[str]:
    """Extract the CoP title from the section header."""
    # Look for "Condition of Participation: <title>" pattern
    match = re.search(
        r'Condition of Participation:\s*(.+?)(?:\n|\.)',
        text
    )
    if match:
        return match.group(1).strip().rstrip('.')
    # Look for "Standard: <title>" pattern
    match = re.search(
        r'Standard:\s*(.+?)(?:\n|\.)',
        text
    )
    if match:
        title = match.group(1).strip().rstrip('.')
        if len(title) < 120:
            return title
    return None


# ── Topic Keyword Extraction ─────────────────────────────────────────

# Known topic domains for tagging
TOPIC_PATTERNS = {
    "QAPI": r'quality\s+assessment|performance\s+improvement|QAPI',
    "patient_rights": r'patient.s?\s+right|patient\s+safety',
    "restraint_seclusion": r'restraint|seclusion',
    "death_reporting": r'death\s+report|death\s+associated',
    "infection_control": r'infection\s+prevention|infection\s+control|HAI',
    "antibiotic_stewardship": r'antibiotic\s+stewardship',
    "discharge_planning": r'discharge\s+plan',
    "medical_records": r'medical\s+record|electronic\s+notification',
    "medical_staff": r'medical\s+staff|bylaws|history\s+and\s+physical|H&P',
    "nursing_services": r'nursing\s+service|registered\s+nurse|outpatient\s+department',
    "physical_environment": r'physical\s+environment|building\s+safety|sprinkler|fire',
    "surgical_services": r'surgical\s+service|prior\s+to\s+surgery|anesthesia',
    "emergency_services": r'emergency\s+service|emergency\s+readiness',
    "psychiatric": r'psychiatric\s+hospital|psychiatric\s+evaluation|mental\s+health',
    "organ_procurement": r'organ.*procurement|tissue.*eye|OPO',
    "governing_body": r'governing\s+body|executive\s+responsibilit',
    "survey_protocol": r'survey\s+protocol|off-site\s+preparation|post-survey',
    "transfer_protocol": r'transfer\s+protocol|transferring\s+patient',
    "rehabilitation": r'rehabilitat',
    "swing_bed": r'swing.bed',
    "observation_notice": r'MOON|observation\s+notice|observation\s+services',
    "compliance": r'compliance\s+with\s+federal|compliance\s+with\s+state',
}


def extract_topics(text: str) -> list:
    """Tag chunk with topic keywords based on content."""
    topics = []
    text_lower = text.lower()
    for topic, pattern in TOPIC_PATTERNS.items():
        if re.search(pattern, text_lower):
            topics.append(topic)
    return sorted(topics)


# ── Main Chunking Logic ─────────────────────────────────────────────

def estimate_tokens(text: str) -> int:
    """Rough token estimate: ~4 chars per token for English regulatory text."""
    return len(text) // 4


def chunk_document(full_text: str) -> list:
    """
    Split the full extracted text into structured chunks.
    Primary split: by A-tag boundaries.
    Secondary: front-matter and survey protocol sections.
    """
    chunks = []
    change_table = parse_change_table(full_text)

    # ── 1. Find all A-tag positions ──────────────────────────────────
    # Pattern matches section headers like:
    #   A-0020
    #   (Rev. 235; Issued: ...)
    a_tag_pattern = re.compile(
        r'\n(A-\d{4})\s*\n',
        re.MULTILINE
    )
    matches = list(a_tag_pattern.finditer(full_text))

    if not matches:
        # Fallback: try without strict newline boundaries
        a_tag_pattern = re.compile(r'(A-\d{4})\s*\n\s*\(Rev\.\s*235', re.MULTILINE)
        matches = list(a_tag_pattern.finditer(full_text))

    if not matches:
        print("WARNING: No A-tag sections found. Trying broader pattern...")
        a_tag_pattern = re.compile(r'(A-\d{4})', re.MULTILINE)
        matches = list(a_tag_pattern.finditer(full_text))

    print(f"Found {len(matches)} A-tag boundary markers")

    # ── 2. Extract front-matter (everything before first A-tag) ──────
    if matches:
        front_matter_end = matches[0].start()
        front_matter_text = full_text[:front_matter_end].strip()

        # Split front-matter into transmittal summary and survey protocol
        # Look for Task 1 and Task 6 boundaries
        task1_match = re.search(
            r'(Task\s+1\s*[-–—]\s*Off[- ]Site\s+Survey\s+Preparation)',
            front_matter_text, re.IGNORECASE
        )
        task6_match = re.search(
            r'(Task\s+6\s*[-–—]\s*Post[- ]Survey\s+Activities)',
            front_matter_text, re.IGNORECASE
        )

        # Transmittal summary chunk
        summary_end = task1_match.start() if task1_match else len(front_matter_text)
        summary_text = front_matter_text[:summary_end].strip()
        if summary_text and len(summary_text) > 100:
            chunks.append(Chunk(
                chunk_id="TRANSMITTAL-235-SUMMARY",
                chunk_type="front_matter",
                a_tag=None,
                cfr_section=None,
                cfr_title="Transmittal 235 Summary and Change Table",
                change_type=None,
                effective_date="2026-01-16",
                transmittal="235",
                source_document="r235soma.pdf",
                content=summary_text,
                token_estimate=estimate_tokens(summary_text),
                topic_keywords=["transmittal_summary", "change_table"],
            ))

        # Task 1 chunk
        if task1_match:
            task1_start = task1_match.start()
            task1_end = task6_match.start() if task6_match else len(front_matter_text)
            task1_text = front_matter_text[task1_start:task1_end].strip()
            if task1_text and len(task1_text) > 100:
                chunks.append(Chunk(
                    chunk_id="SURVEY-PROTOCOL-TASK-1",
                    chunk_type="survey_protocol",
                    a_tag=None,
                    cfr_section=None,
                    cfr_title="Task 1 - Off-Site Survey Preparation",
                    change_type="R",
                    effective_date="2026-01-16",
                    transmittal="235",
                    source_document="r235soma.pdf",
                    content=task1_text,
                    token_estimate=estimate_tokens(task1_text),
                    topic_keywords=["survey_protocol", "off_site_preparation"],
                ))

        # Task 6 chunk
        if task6_match:
            task6_text = front_matter_text[task6_match.start():].strip()
            if task6_text and len(task6_text) > 100:
                chunks.append(Chunk(
                    chunk_id="SURVEY-PROTOCOL-TASK-6",
                    chunk_type="survey_protocol",
                    a_tag=None,
                    cfr_section=None,
                    cfr_title="Task 6 - Post-Survey Activities",
                    change_type="R",
                    effective_date="2026-01-16",
                    transmittal="235",
                    source_document="r235soma.pdf",
                    content=task6_text,
                    token_estimate=estimate_tokens(task6_text),
                    topic_keywords=["survey_protocol", "post_survey", "plan_of_correction"],
                ))

    # ── 3. Extract A-tag sections ────────────────────────────────────
    # Deduplicate matches by A-tag (keep first occurrence as section start)
    seen_tags = {}
    unique_matches = []
    for m in matches:
        tag = m.group(1)
        if tag not in seen_tags:
            seen_tags[tag] = m
            unique_matches.append(m)

    print(f"Found {len(unique_matches)} unique A-tag sections")

    for i, match in enumerate(unique_matches):
        a_tag = match.group(1)
        start = match.start()

        # End at next A-tag or end of document
        if i + 1 < len(unique_matches):
            end = unique_matches[i + 1].start()
        else:
            end = len(full_text)

        section_text = full_text[start:end].strip()

        # Skip tiny fragments (likely table-of-contents references)
        if len(section_text) < 200:
            continue

        # Extract metadata
        cfr_section = extract_cfr_section(section_text)
        cfr_title = extract_cfr_title(section_text)
        change_type = change_table.get(a_tag, "R")  # default to R if not in table
        topics = extract_topics(section_text)

        chunks.append(Chunk(
            chunk_id=f"CMS-T235-{a_tag}",
            chunk_type="regulatory_section",
            a_tag=a_tag,
            cfr_section=cfr_section,
            cfr_title=cfr_title,
            change_type=change_type,
            effective_date="2026-01-16",
            transmittal="235",
            source_document="r235soma.pdf",
            content=section_text,
            token_estimate=estimate_tokens(section_text),
            topic_keywords=topics,
        ))

    return chunks


# ── Oversized Chunk Splitter ─────────────────────────────────────────

def split_oversized_chunks(chunks: list, max_tokens: int = 2000) -> list:
    """
    If any chunk exceeds max_tokens, split it at natural boundaries
    (Interpretive Guidelines / Survey Procedures headers).
    Preserves metadata inheritance.
    """
    result = []
    for chunk in chunks:
        if chunk.token_estimate <= max_tokens:
            result.append(chunk)
            continue

        # Try to split at "Interpretive Guidelines" and "Survey Procedures" boundaries
        text = chunk.content
        parts = []

        # Find split points
        ig_match = re.search(r'\n(Interpretive\s+Guid(?:elines|ance))', text, re.IGNORECASE)
        sp_match = re.search(r'\n(Survey\s+Procedure)', text, re.IGNORECASE)

        if ig_match and sp_match and ig_match.start() < sp_match.start():
            # Three-way split: regulation | interpretive guidelines | survey procedures
            reg_text = text[:ig_match.start()].strip()
            ig_text = text[ig_match.start():sp_match.start()].strip()
            sp_text = text[sp_match.start():].strip()

            if reg_text and len(reg_text) > 50:
                parts.append(("regulation", reg_text))
            if ig_text and len(ig_text) > 50:
                parts.append(("interpretive_guidance", ig_text))
            if sp_text and len(sp_text) > 50:
                parts.append(("survey_procedures", sp_text))
        elif ig_match:
            reg_text = text[:ig_match.start()].strip()
            ig_text = text[ig_match.start():].strip()
            if reg_text and len(reg_text) > 50:
                parts.append(("regulation", reg_text))
            if ig_text and len(ig_text) > 50:
                parts.append(("interpretive_guidance", ig_text))
        else:
            # Can't split meaningfully — keep as-is
            result.append(chunk)
            continue

        if len(parts) <= 1:
            result.append(chunk)
            continue

        for j, (sub_type, sub_text) in enumerate(parts):
            sub_chunk = Chunk(
                chunk_id=f"{chunk.chunk_id}-{sub_type}",
                chunk_type=chunk.chunk_type,
                a_tag=chunk.a_tag,
                cfr_section=chunk.cfr_section,
                cfr_title=chunk.cfr_title,
                change_type=chunk.change_type,
                effective_date=chunk.effective_date,
                transmittal=chunk.transmittal,
                source_document=chunk.source_document,
                content=sub_text,
                token_estimate=estimate_tokens(sub_text),
                topic_keywords=chunk.topic_keywords,
            )
            result.append(sub_chunk)

    return result


# ── Output Writers ───────────────────────────────────────────────────

def write_jsonl(chunks: list, output_path: str):
    """Write chunks as JSONL (one JSON object per line)."""
    with open(output_path, 'w', encoding='utf-8') as f:
        for chunk in chunks:
            f.write(json.dumps(asdict(chunk), ensure_ascii=False) + '\n')


def write_pretty_json(chunks: list, output_path: str):
    """Write chunks as pretty-printed JSON array."""
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump([asdict(c) for c in chunks], f, indent=2, ensure_ascii=False)


def write_text_files(chunks: list, output_dir: str):
    """Write individual .txt files per chunk for manual review."""
    os.makedirs(output_dir, exist_ok=True)
    for chunk in chunks:
        filename = f"{chunk.chunk_id}.txt"
        filepath = os.path.join(output_dir, filename)
        with open(filepath, 'w', encoding='utf-8') as f:
            # Write metadata header
            f.write(f"CHUNK_ID: {chunk.chunk_id}\n")
            f.write(f"TYPE: {chunk.chunk_type}\n")
            if chunk.a_tag:
                f.write(f"A_TAG: {chunk.a_tag}\n")
            if chunk.cfr_section:
                f.write(f"CFR_SECTION: {chunk.cfr_section}\n")
            if chunk.cfr_title:
                f.write(f"CFR_TITLE: {chunk.cfr_title}\n")
            if chunk.change_type:
                f.write(f"CHANGE_TYPE: {chunk.change_type}\n")
            f.write(f"EFFECTIVE_DATE: {chunk.effective_date}\n")
            f.write(f"TOKENS_EST: {chunk.token_estimate}\n")
            if chunk.topic_keywords:
                f.write(f"TOPICS: {', '.join(chunk.topic_keywords)}\n")
            f.write(f"{'='*72}\n\n")
            f.write(chunk.content)


def write_index(chunks: list, output_path: str):
    """Write a markdown index summarizing all chunks."""
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write("# CMS Transmittal 235 — Chunk Index\n\n")
        f.write(f"**Source:** r235soma.pdf (State Operations Manual Appendix A)\n")
        f.write(f"**Effective Date:** January 16, 2026\n")
        f.write(f"**Total Chunks:** {len(chunks)}\n")
        f.write(f"**Total Tokens (est):** {sum(c.token_estimate for c in chunks):,}\n\n")

        # Stats
        by_type = {}
        by_change = {}
        for c in chunks:
            by_type[c.chunk_type] = by_type.get(c.chunk_type, 0) + 1
            if c.change_type:
                by_change[c.change_type] = by_change.get(c.change_type, 0) + 1

        f.write("## Chunk Statistics\n\n")
        f.write("| Chunk Type | Count |\n|---|---|\n")
        for t, count in sorted(by_type.items()):
            f.write(f"| {t} | {count} |\n")

        f.write("\n| Change Type | Count |\n|---|---|\n")
        change_labels = {"R": "Revised", "N": "New", "D": "Deleted"}
        for t, count in sorted(by_change.items()):
            f.write(f"| {t} ({change_labels.get(t, t)}) | {count} |\n")

        # Token distribution
        token_counts = [c.token_estimate for c in chunks]
        f.write(f"\n## Token Distribution\n\n")
        f.write(f"- **Min:** {min(token_counts):,}\n")
        f.write(f"- **Max:** {max(token_counts):,}\n")
        f.write(f"- **Avg:** {sum(token_counts)//len(token_counts):,}\n")
        f.write(f"- **Median:** {sorted(token_counts)[len(token_counts)//2]:,}\n")

        oversized = [c for c in chunks if c.token_estimate > 2000]
        if oversized:
            f.write(f"- **Chunks > 2000 tokens:** {len(oversized)}\n")

        f.write("\n## Chunk Detail\n\n")
        f.write("| Chunk ID | Type | A-Tag | CFR § | Change | Tokens | Topics |\n")
        f.write("|---|---|---|---|---|---|---|\n")
        for c in chunks:
            topics_str = ", ".join(c.topic_keywords[:3])
            if len(c.topic_keywords) > 3:
                topics_str += f" +{len(c.topic_keywords)-3}"
            f.write(
                f"| {c.chunk_id} | {c.chunk_type} | "
                f"{c.a_tag or '—'} | {c.cfr_section or '—'} | "
                f"{c.change_type or '—'} | {c.token_estimate:,} | "
                f"{topics_str} |\n"
            )


# ── Main ─────────────────────────────────────────────────────────────

def main():
    pdf_path = sys.argv[1] if len(sys.argv) > 1 else "r235soma.pdf"
    output_dir = sys.argv[2] if len(sys.argv) > 2 else "output"

    print(f"[1/6] Extracting text from {pdf_path}...")
    full_text = extract_text_from_pdf(pdf_path)
    print(f"       Extracted {len(full_text):,} characters")

    # Save raw extracted text for reference
    os.makedirs(output_dir, exist_ok=True)
    raw_path = os.path.join(output_dir, "raw_extracted_text.txt")
    with open(raw_path, 'w', encoding='utf-8') as f:
        f.write(full_text)
    print(f"       Saved raw text to {raw_path}")

    print(f"[2/6] Parsing change table...")
    change_table = parse_change_table(full_text)
    print(f"       Found {len(change_table)} entries in change table")

    print(f"[3/6] Chunking document...")
    chunks = chunk_document(full_text)
    print(f"       Created {len(chunks)} initial chunks")

    print(f"[4/6] Splitting oversized chunks (>2000 tokens)...")
    chunks = split_oversized_chunks(chunks, max_tokens=2000)
    print(f"       Final chunk count: {len(chunks)}")

    print(f"[5/6] Writing output files...")
    write_jsonl(chunks, os.path.join(output_dir, "chunks.jsonl"))
    write_pretty_json(chunks, os.path.join(output_dir, "chunks.json"))
    write_text_files(chunks, os.path.join(output_dir, "chunks_txt"))
    write_index(chunks, os.path.join(output_dir, "CHUNK_INDEX.md"))

    print(f"[6/6] Summary:")
    print(f"       Chunks: {len(chunks)}")
    print(f"       Total tokens (est): {sum(c.token_estimate for c in chunks):,}")
    print(f"       Output dir: {output_dir}/")
    print(f"       Files:")
    print(f"         chunks.jsonl          — JSONL for RAG ingestion")
    print(f"         chunks.json           — Pretty JSON for inspection")
    print(f"         chunks_txt/           — Individual .txt per chunk")
    print(f"         CHUNK_INDEX.md        — Summary index")
    print(f"         raw_extracted_text.txt — Full extracted text")
    print(f"       Done.")


if __name__ == "__main__":
    main()
