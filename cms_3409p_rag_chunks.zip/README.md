# CMS-3409-P Proposed Rule — RAG Chunk Package

## Document
**Title:** Medicare and Medicaid Programs; Organ Procurement Organizations Conditions for Coverage: Revisions to the Conditions for Coverage
**Rule ID:** CMS-3409-P (RIN 0938-AU54)
**Published:** January 30, 2026 — Federal Register Vol. 91, No. 20 (pp. 4190–4251)
**Comment Deadline:** March 31, 2026
**CFR Part:** 42 CFR Part 486, Subpart G
**Source:** https://www.govinfo.gov/content/pkg/FR-2026-01-30/pdf/2026-01833.pdf

## What This Rule Does
This proposed rule revises OPO Conditions for Coverage:
- **Definitions** (§486.302): Revises "adverse event," "donor," "organ," adds "medically complex" definitions
- **Certification** (§486.303): Clarifies OPO certification requirements
- **DSA Designation** (§486.308): Clarifies when a service area is open for competition
- **Multi-DSA Designation** (§486.309): NEW — allows OPOs to be designated to multiple DSAs; **each DSA evaluated separately on outcome measures** (critical for merger strategies)
- **Non-Renewal / De-Certification** (§486.311/312): Establishes enforcement procedures
- **Appeals** (§486.314): Updates appeal process
- **Re-Certification & Competition** (§486.316): Clarifies competition procedures and successor OPO selection factors
- **Outcome Measures** (§486.318): Maintains donation rate + transplant rate tier system
- **QAPI** (§486.344/348): New requirements for medically complex organs/donors
- **Comment Solicitation**: Conflicts of interest, AOOS, automated electronic referrals

## STA/OPO Relevance
**CRITICAL for any OPO facing recertification decisions.** Key provisions:
- §486.309: Separate DSA Evaluation — merged OPOs evaluated per-DSA, not combined
- §486.316: Competition procedures — how CMS selects successor OPOs
- §486.311/312: Decertification triggers and enforcement timeline
- §486.348: New QAPI requirements that apply immediately upon finalization

## Package Contents

### Primary RAG Files
- `chunks_final.jsonl` — One JSON object per line (ChromaDB/LanceDB/FAISS ingest)
- `chunks_final.json` — Pretty-printed JSON array
- `chunks_txt/` — 121 individual .txt files with metadata headers (LM Studio file-based RAG)
- `CHUNK_INDEX.md` — Full index with token counts, topics, structure

### Supporting Files
- `raw_text.txt` — Full extracted text
- `scripts/chunk_3409p.py` — Chunking script (reusable for other Federal Register rules)
- `cms_3409p.pdf` — Source PDF

## Chunk Schema
```json
{
  "chunk_id": "CMS3409P-III.C-part1",
  "chunk_type": "proposed_rule_section",
  "section_path": "III.C",
  "cfr_section": "§486.308",
  "section_title": "Designation of One OPO for Each Service Area",
  "document_type": "proposed_rule",
  "rule_id": "CMS-3409-P",
  "publication_date": "2026-01-30",
  "comment_deadline": "2026-03-31",
  "fr_volume": "91 FR 4190",
  "source_document": "cms_3409p.pdf",
  "content": "...",
  "token_estimate": 1694,
  "topic_keywords": ["competition", "designation", "DSA", "tier_system"],
  "cfr_part": "42 CFR Part 486"
}
```

## Usage

### LM Studio — File-Based RAG
Point at the `chunks_txt/` directory. Each file includes metadata headers.

### Vector Store Ingestion (ChromaDB)
```python
import chromadb, json

client = chromadb.PersistentClient(path="./chroma_db")
collection = client.get_or_create_collection("cms_3409p")

with open("chunks_final.jsonl") as f:
    for line in f:
        chunk = json.loads(line)
        collection.add(
            ids=[chunk["chunk_id"]],
            documents=[chunk["content"]],
            metadatas=[{
                "section_path": chunk["section_path"],
                "cfr_section": chunk.get("cfr_section") or "",
                "section_title": chunk["section_title"],
                "rule_id": chunk["rule_id"],
                "publication_date": chunk["publication_date"],
                "comment_deadline": chunk["comment_deadline"],
                "topic_keywords": ",".join(chunk.get("topic_keywords", [])),
                "token_estimate": chunk["token_estimate"],
            }]
        )
```

### Metadata Filters
```python
# DSA designation rules (critical for merger analysis)
collection.query(query_texts=["service area designation merger"], 
                 where={"cfr_section": "§486.308"})

# Decertification procedures
collection.query(query_texts=["decertification tier 3"],
                 where={"topic_keywords": {"$contains": "decertification"}})

# Competition and successor OPO selection
collection.query(query_texts=["competition successor OPO factors"],
                 where={"cfr_section": "§486.316"})

# QAPI requirements
collection.query(query_texts=["QAPI medically complex"],
                 where={"topic_keywords": {"$contains": "QAPI"}})

# All proposed regulatory text changes
collection.query(query_texts=["proposed regulation text"],
                 where={"section_path": "REGTEXT"})
```

## Unified RAG with Transmittal 235
This package uses the same metadata schema as the CMS Transmittal 235 chunk package.
To build a unified OPO regulatory knowledge base, ingest both into the same collection
and filter by `rule_id` or `document_type`:

```python
# Query across both documents
collection.query(query_texts=["organ procurement requirements"])

# Filter to just the proposed rule
collection.query(query_texts=["organ procurement"],
                 where={"rule_id": "CMS-3409-P"})

# Filter to just the survey guidelines
collection.query(query_texts=["survey protocol"],
                 where={"rule_id": {"$ne": "CMS-3409-P"}})
```

## Topic Taxonomy
22 auto-tagged topics:
- **Structural:** tier_system, recertification, decertification, competition, designation, DSA
- **Measures:** outcome_measures, donor_potential, data_reporting
- **Operations:** QAPI, medically_complex, organ_allocation, human_resources, information_management
- **Relationships:** hospital_OPO, OPTN, conflict_of_interest, electronic_referral
- **Process:** appeals, definitions, comment_solicitation, severability
- **Impact:** cost_impact

## Stats
- **121 chunks**
- **110,860 total tokens**
- **Range:** 65 – 1,815 tokens per chunk
- **99.2% of chunks ≤1,800 tokens** (1 chunk at 1,815)
