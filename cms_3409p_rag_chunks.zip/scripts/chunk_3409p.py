#!/usr/bin/env python3
"""
CMS-3409-P Federal Register Proposed Rule — RAG Chunking Pipeline
====================================================================
Chunks the OPO Conditions for Coverage proposed rule (Jan 30, 2026)
into structured JSON for vector store / local RAG ingestion.

Structure: Federal Register documents use Roman numeral major sections
and lettered subsections. We chunk at the lettered subsection level,
with oversized chunks split at paragraph boundaries.

Output matches the same format as the Transmittal 235 chunker for
unified RAG ingestion.
"""

import json
import re
import os
import sys
from dataclasses import dataclass, field, asdict
from typing import Optional


# ── PDF Text Extraction ──────────────────────────────────────────────

def extract_text_from_pdf(pdf_path: str) -> str:
    import fitz
    doc = fitz.open(pdf_path)
    pages = []
    for page_num in range(len(doc)):
        pages.append(doc[page_num].get_text("text"))
    doc.close()
    return "\n".join(pages)


# ── Data Structures ──────────────────────────────────────────────────

@dataclass
class Chunk:
    chunk_id: str
    chunk_type: str
    section_path: str             # e.g., "III.A" or "VII.B"
    cfr_section: Optional[str]    # e.g., "§486.302"
    section_title: Optional[str]
    document_type: str            # "proposed_rule"
    rule_id: str                  # "CMS-3409-P"
    publication_date: str         # "2026-01-30"
    comment_deadline: str         # "2026-03-31"
    fr_volume: str                # "91 FR 4190"
    source_document: str
    content: str
    token_estimate: int
    topic_keywords: list = field(default_factory=list)
    cfr_part: str = "42 CFR Part 486"


def estimate_tokens(text: str) -> int:
    return len(text) // 4


# ── Section Structure Definition ─────────────────────────────────────

# Define the expected document structure with section boundaries
# Each entry: (section_id, search_pattern, title, cfr_ref)
SECTION_DEFS = [
    # Front matter
    ("PREAMBLE", r"DEPARTMENT OF HEALTH AND\s*\nHUMAN SERVICES", "Preamble and Summary", None),

    # I. Executive Summary
    ("I", r"\nI\.\s+Executive Summary and Severability", "Executive Summary and Severability", None),
    ("I.A", r"\nA\.\s+Executive Summary", "Executive Summary", None),
    ("I.B", r"\nB\.\s+Severability", "Severability", None),

    # II. Background
    ("II", r"\nII\.\s+Organ Procurement Organizations", "Organ Procurement Organizations", None),
    ("II.A", r"\nA\.\s+Background", "Background", None),
    ("II.B", r"\nB\.\s+Regulatory History", "Regulatory History", None),
    ("II.C", r"\nC\.\s+Statutory and Regulatory Provisions", "Statutory and Regulatory Provisions", None),

    # III. Provisions (the meat of the rule)
    ("III", r"\nIII\.\s+Provisions of the Proposed", "Provisions of the Proposed Regulations", None),
    ("III.A", r"\nA\.\s+Definitions\s*\(§\s*486\.302\)", "Definitions", "§486.302"),
    ("III.B", r"\nB\.\s+Requirements for Certification", "Requirements for Certification", "§486.303"),
    ("III.C", r"\nC\.\s+Designation of One OPO for Each", "Designation of One OPO for Each Service Area", "§486.308"),
    ("III.D", r"\nD\.\s+Designation of an OPO to More Than", "Designation of an OPO to More Than One Service Area", "§486.309"),
    ("III.E", r"\nE\.\s+Non-Renewal of Agreement", "Non-Renewal of Agreement and De-Certification", "§486.311"),
    ("III.F", r"\nF\.\s+Appeals\s*\(§\s*486\.314\)", "Appeals", "§486.314"),
    ("III.G", r"\nG\.\s+Re-Certification and Competition", "Re-Certification and Competition", "§486.316"),
    ("III.H", r"\nH\.\s+Outcome Measures", "Outcome Measures", "§486.318"),
    ("III.I", r"\nI\.\s+Human Resources\s*\(§\s*486\.326\)", "Human Resources", "§486.326"),
    ("III.J", r"\nJ\.\s+Information Management", "Information Management", "§486.330"),
    ("III.K", r"\nK\.\s+Quality Assessment and Performance", "Quality Assessment and Performance Improvement", "§486.344"),
    ("III.L", r"\nL\.\s+Proposed Conforming Changes", "Proposed Conforming Changes", None),

    # IV. Comment Solicitation
    ("IV", r"\nIV\.\s+Comment Solicitation", "Comment Solicitation and Requests for Information", None),
    ("IV.A", r"\nA\.\s+Conflicts of Interest", "Conflicts of Interest", None),
    ("IV.B", r"\nB\.\s+Allocation Out of Sequence", "Allocation Out of Sequence (AOOS)", None),
    ("IV.C", r"\nC\.\s+Automated Electronic Referrals", "Automated Electronic Referrals", None),

    # V-VII
    ("V", r"\nV\.\s+Collection of Information", "Collection of Information Requirements", None),
    ("V.A", r"\nA\.\s+ICRs Regarding Information", "ICRs Regarding Information Management", None),
    ("V.B", r"\nB\.\s+ICRs Regarding Quality Assessment", "ICRs Regarding QAPI", None),
    ("VI", r"\nVI\.\s+Response to Comments", "Response to Comments", None),
    ("VII", r"\nVII\.\s+Regulatory Impact Analysis", "Regulatory Impact Analysis", None),
    ("VII.A", r"\nA\.\s+Statement of Need", "Statement of Need", None),
    ("VII.B", r"\nB\.\s+Overall Impact", "Overall Impact", None),
    ("VII.C", r"\nC\.\s+Alternatives Considered", "Alternatives Considered", None),
    ("VII.D", r"\nD\.\s+Regulatory Review Cost", "Regulatory Review Cost Estimation", None),
    ("VII.E", r"\nE\.\s+Accounting Statement", "Accounting Statement", None),
    ("VII.F", r"\nF\.\s+Regulatory Flexibility Act", "Regulatory Flexibility Act", None),
    ("VII.G", r"\nG\.\s+Unfunded Mandates", "Unfunded Mandates Reform Act", None),
    ("VII.H", r"\nH\.\s+Federalism", "Federalism", None),
    ("VII.I", r"\nI\.\s+E\.O\.\s+14192", "Executive Orders", None),

    # Regulatory text (the actual proposed CFR changes)
    ("REGTEXT", r"List of Subjects in 42 CFR Part 486", "Proposed Regulatory Text", "42 CFR 486"),
]


# ── Topic Keyword Extraction ─────────────────────────────────────────

TOPIC_PATTERNS = {
    "tier_system": r'tier\s*[123]|tiered?\s+(?:approach|system|structure)',
    "recertification": r're-?certification|recertif',
    "decertification": r'de-?certification|decertif',
    "competition": r'competition|compete|competitor|competing\s+OPO',
    "DSA": r'designated?\s+service\s+area|DSA[s\b]',
    "outcome_measures": r'outcome\s+measure|donation\s+rate|transplant(?:ation)?\s+rate',
    "QAPI": r'quality\s+assess|performance\s+improve|QAPI',
    "medically_complex": r'medically\s+complex|complex\s+(?:organ|donor)',
    "definitions": r'(?:we\s+)?propos(?:e|ing)\s+to\s+(?:revise|define|add)',
    "appeals": r'appeal|hearing|reconsideration',
    "designation": r'designat(?:ion|e|ing)|successor\s+OPO',
    "donor_potential": r'donor\s+potential|MCOD|death\s+certificate|eligible\s+death',
    "cost_impact": r'(?:regulatory\s+)?impact|cost\s+estimate|burden|economic',
    "OPTN": r'OPTN|Organ\s+Procurement\s+and\s+Transplantation\s+Network',
    "data_reporting": r'data\s+(?:report|submis)|SRTR|Scientific\s+Registry',
    "organ_allocation": r'allocat(?:ion|e|ing)|organ\s+(?:distribut|placement|offer)',
    "conflict_of_interest": r'conflict\s+of\s+interest',
    "electronic_referral": r'electronic\s+(?:referral|notification)|automated\s+referral',
    "human_resources": r'human\s+resources|staffing|personnel|workforce',
    "information_management": r'information\s+management|record\s+keeping|data\s+system',
    "hospital_OPO": r'hospital.*OPO|OPO.*hospital|donor\s+hospital|agreement\s+with',
    "severability": r'severabilit',
    "comment_solicitation": r'comment\s+(?:solicitation|period)|request\s+for\s+(?:information|comment)',
}


def extract_topics(text: str) -> list:
    topics = []
    text_lower = text.lower()
    for topic, pattern in TOPIC_PATTERNS.items():
        if re.search(pattern, text_lower):
            topics.append(topic)
    return sorted(topics)


def extract_cfr_refs(text: str) -> list:
    """Extract all §486.xxx references from text."""
    refs = set()
    for m in re.finditer(r'§\s*486\.(\d+)', text):
        refs.add(f"§486.{m.group(1)}")
    return sorted(refs)


# ── Chunking Logic ───────────────────────────────────────────────────

def find_section_positions(text: str) -> list:
    """Find positions of each section in the text."""
    positions = []
    for sec_id, pattern, title, cfr_ref in SECTION_DEFS:
        match = re.search(pattern, text)
        if match:
            positions.append((match.start(), sec_id, title, cfr_ref))

    # Sort by position
    positions.sort(key=lambda x: x[0])
    return positions


def chunk_document(full_text: str) -> list:
    chunks = []
    positions = find_section_positions(full_text)

    print(f"Found {len(positions)} section boundaries")

    for i, (start, sec_id, title, cfr_ref) in enumerate(positions):
        # End at next section or end of document
        if i + 1 < len(positions):
            end = positions[i + 1][0]
        else:
            end = len(full_text)

        section_text = full_text[start:end].strip()

        # Skip tiny sections (just headers with no content)
        if len(section_text) < 100:
            continue

        # Clean up Federal Register page headers/footers
        section_text = re.sub(
            r'\n\d{4}\s*\nFederal Register\s*/\s*Vol\.\s*\d+.*?Proposed Rules\s*\n',
            '\n',
            section_text
        )
        # Clean up "VerDate" lines
        section_text = re.sub(r'VerDate.*?\n', '', section_text)
        section_text = re.sub(r'Jkt \d+.*?\n', '', section_text)
        section_text = re.sub(r'PO \d+.*?\n', '', section_text)
        section_text = re.sub(r'Fmt \d+.*?\n', '', section_text)
        section_text = re.sub(r'Sfmt \d+.*?\n', '', section_text)
        section_text = re.sub(r'E:\\FR\\FM\\.*?\n', '', section_text)
        section_text = re.sub(r'lotter on DSK.*?\n', '', section_text)
        # Clean up "(printed page XXXX)" references
        section_text = re.sub(r'\(\s*printed\s+page\s+\d+\s*\)', '', section_text)
        # Collapse multiple blank lines
        section_text = re.sub(r'\n{3,}', '\n\n', section_text)

        # Extract CFR references from content if not defined
        cfr = cfr_ref
        if not cfr:
            refs = extract_cfr_refs(section_text)
            if refs:
                cfr = refs[0]  # Primary reference

        topics = extract_topics(section_text)

        chunk = Chunk(
            chunk_id=f"CMS3409P-{sec_id}",
            chunk_type="proposed_rule_section",
            section_path=sec_id,
            cfr_section=cfr,
            section_title=title,
            document_type="proposed_rule",
            rule_id="CMS-3409-P",
            publication_date="2026-01-30",
            comment_deadline="2026-03-31",
            fr_volume="91 FR 4190",
            source_document="cms_3409p.pdf",
            content=section_text,
            token_estimate=estimate_tokens(section_text),
            topic_keywords=topics,
        )
        chunks.append(chunk)

    return chunks


# ── Oversized Chunk Splitter ─────────────────────────────────────────

def split_at_numbered_subsections(text: str, max_tokens: int = 1800) -> list:
    """Split at numbered subsection boundaries (1., 2., 3.) or paragraph breaks."""
    # Try numbered subsections first
    parts = re.split(r'\n(?=\d+\.\s+)', text)
    if len(parts) > 1 and all(estimate_tokens(p) <= max_tokens for p in parts):
        return [p.strip() for p in parts if p.strip()]

    # Fall back to paragraph splitting
    paragraphs = re.split(r'\n\s*\n', text)
    result = []
    current = []
    current_len = 0

    for para in paragraphs:
        para_tokens = estimate_tokens(para)
        if current_len + para_tokens > max_tokens and current:
            result.append('\n\n'.join(current))
            current = [para]
            current_len = para_tokens
        else:
            current.append(para)
            current_len += para_tokens

    if current:
        result.append('\n\n'.join(current))

    # Merge tiny trailing parts
    if len(result) > 1 and estimate_tokens(result[-1]) < 100:
        result[-2] = result[-2] + '\n\n' + result[-1]
        result.pop()

    return result


def split_oversized_chunks(chunks: list, max_tokens: int = 1800) -> list:
    result = []
    for chunk in chunks:
        if chunk.token_estimate <= max_tokens:
            result.append(chunk)
            continue

        parts = split_at_numbered_subsections(chunk.content, max_tokens)

        if len(parts) <= 1:
            # Can't split further — keep as-is (will be oversized)
            result.append(chunk)
            continue

        for i, part in enumerate(parts):
            new_chunk = Chunk(
                chunk_id=f"{chunk.chunk_id}-part{i+1}",
                chunk_type=chunk.chunk_type,
                section_path=chunk.section_path,
                cfr_section=chunk.cfr_section,
                section_title=chunk.section_title,
                document_type=chunk.document_type,
                rule_id=chunk.rule_id,
                publication_date=chunk.publication_date,
                comment_deadline=chunk.comment_deadline,
                fr_volume=chunk.fr_volume,
                source_document=chunk.source_document,
                content=part,
                token_estimate=estimate_tokens(part),
                topic_keywords=chunk.topic_keywords,
                cfr_part=chunk.cfr_part,
            )
            result.append(new_chunk)

    return result


# ── Output Writers ───────────────────────────────────────────────────

def write_all_outputs(chunks: list, output_dir: str):
    os.makedirs(output_dir, exist_ok=True)

    # JSONL
    with open(os.path.join(output_dir, 'chunks_final.jsonl'), 'w', encoding='utf-8') as f:
        for c in chunks:
            f.write(json.dumps(asdict(c), ensure_ascii=False) + '\n')

    # Pretty JSON
    with open(os.path.join(output_dir, 'chunks_final.json'), 'w', encoding='utf-8') as f:
        json.dump([asdict(c) for c in chunks], f, indent=2, ensure_ascii=False)

    # Text files
    txt_dir = os.path.join(output_dir, 'chunks_txt')
    os.makedirs(txt_dir, exist_ok=True)
    for chunk in chunks:
        fname = f"{chunk.chunk_id}.txt"
        with open(os.path.join(txt_dir, fname), 'w', encoding='utf-8') as f:
            f.write(f"CHUNK_ID: {chunk.chunk_id}\n")
            f.write(f"SECTION: {chunk.section_path}\n")
            f.write(f"TITLE: {chunk.section_title}\n")
            if chunk.cfr_section:
                f.write(f"CFR: {chunk.cfr_section}\n")
            f.write(f"RULE: {chunk.rule_id}\n")
            f.write(f"PUBLISHED: {chunk.publication_date}\n")
            f.write(f"COMMENT_DEADLINE: {chunk.comment_deadline}\n")
            f.write(f"TOKENS_EST: {chunk.token_estimate}\n")
            if chunk.topic_keywords:
                f.write(f"TOPICS: {', '.join(chunk.topic_keywords)}\n")
            f.write(f"{'='*72}\n\n")
            f.write(chunk.content)

    # Index
    with open(os.path.join(output_dir, 'CHUNK_INDEX.md'), 'w', encoding='utf-8') as f:
        f.write("# CMS-3409-P Proposed Rule — Chunk Index\n\n")
        f.write("**Document:** Medicare and Medicaid Programs; OPO Conditions for Coverage: Revisions\n")
        f.write("**Rule ID:** CMS-3409-P\n")
        f.write("**Published:** January 30, 2026 (91 FR 4190-4251)\n")
        f.write("**Comment Deadline:** March 31, 2026\n")
        f.write(f"**Total Chunks:** {len(chunks)}\n")
        total_tokens = sum(c.token_estimate for c in chunks)
        f.write(f"**Total Tokens (est):** {total_tokens:,}\n\n")

        token_counts = [c.token_estimate for c in chunks]
        f.write("## Token Distribution\n\n")
        f.write(f"- Min: {min(token_counts):,}\n")
        f.write(f"- Max: {max(token_counts):,}\n")
        f.write(f"- Median: {sorted(token_counts)[len(token_counts)//2]:,}\n")
        f.write(f"- Mean: {sum(token_counts)//len(token_counts):,}\n\n")

        f.write("## Document Structure\n\n")
        f.write("| Section | Title | CFR | Chunks | Tokens |\n")
        f.write("|---|---|---|---|---|\n")

        # Group by base section
        from collections import defaultdict
        by_section = defaultdict(list)
        for c in chunks:
            base = c.section_path.split('-')[0]
            by_section[base].append(c)

        for base in sorted(by_section.keys(), key=lambda x: chunks.index(by_section[x][0])):
            group = by_section[base]
            total = sum(c.token_estimate for c in group)
            cfr = group[0].cfr_section or "—"
            title = group[0].section_title
            f.write(f"| {base} | {title} | {cfr} | {len(group)} | {total:,} |\n")

        f.write("\n## All Chunks\n\n")
        f.write("| # | Chunk ID | Section | CFR | Tokens | Topics |\n")
        f.write("|---|---|---|---|---|---|\n")
        for i, c in enumerate(chunks, 1):
            topics = ', '.join((c.topic_keywords or [])[:3])
            if len(c.topic_keywords) > 3:
                topics += f" +{len(c.topic_keywords)-3}"
            f.write(
                f"| {i} | {c.chunk_id} | {c.section_path} | "
                f"{c.cfr_section or '—'} | {c.token_estimate:,} | {topics} |\n"
            )


# ── Main ─────────────────────────────────────────────────────────────

def main():
    pdf_path = sys.argv[1] if len(sys.argv) > 1 else "cms_3409p.pdf"
    output_dir = sys.argv[2] if len(sys.argv) > 2 else "output"

    print(f"[1/5] Extracting text from {pdf_path}...")
    full_text = extract_text_from_pdf(pdf_path)
    print(f"       {len(full_text):,} characters extracted")

    os.makedirs(output_dir, exist_ok=True)
    with open(os.path.join(output_dir, 'raw_text.txt'), 'w') as f:
        f.write(full_text)

    print(f"[2/5] Chunking by section structure...")
    chunks = chunk_document(full_text)
    print(f"       {len(chunks)} initial chunks")

    print(f"[3/5] Splitting oversized chunks (>1800 tokens)...")
    chunks = split_oversized_chunks(chunks, max_tokens=1800)
    print(f"       {len(chunks)} final chunks")

    print(f"[4/5] Writing outputs...")
    write_all_outputs(chunks, output_dir)

    print(f"[5/5] Summary:")
    tokens = [c.token_estimate for c in chunks]
    print(f"       Chunks: {len(chunks)}")
    print(f"       Total tokens: {sum(tokens):,}")
    print(f"       Token range: {min(tokens)} — {max(tokens)}")
    over = sum(1 for t in tokens if t > 1800)
    print(f"       Chunks >1800: {over}")
    print(f"       Done.")


if __name__ == "__main__":
    main()
