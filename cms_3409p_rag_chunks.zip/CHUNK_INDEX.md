# CMS-3409-P Proposed Rule — Chunk Index

**Document:** Medicare and Medicaid Programs; OPO Conditions for Coverage: Revisions to the Conditions for Coverage
**Rule ID:** CMS-3409-P (RIN 0938-AU54)
**Published:** January 30, 2026 (91 FR 4190–4251)
**Comment Deadline:** March 31, 2026
**CFR Part:** 42 CFR Part 486, Subpart G

**Total Chunks:** 121
**Total Tokens (est):** 110,860

## Token Distribution

- Min: 65
- Max: 1815
- Median: 816
- Mean: 916

| Range | Count |
|---|---|
| 0–200 | 16 ████████████████ |
| 200–500 | 36 ████████████████████████████████████ |
| 500–1000 | 17 █████████████████ |
| 1000–1500 | 10 ██████████ |
| 1500–1800 | 41 █████████████████████████████████████████ |
| 1800–2500 | 1 █ |
| **Total** | **121** |

## Document Structure

| Section | Title | CFR | Chunks | Tokens |
|---|---|---|---|---|
| PREAMBLE | Preamble and Summary | — | 1 | 998 |
| I.A | Executive Summary | §486.302 | 6 | 4,946 |
| I.B | Severability | — | 1 | 170 |
| II.A | Background | — | 1 | 569 |
| II.B | Regulatory History | §486.314 | 10 | 9,466 |
| II.C | Statutory and Regulatory Provisions | §486.303 | 1 | 1,595 |
| III | Provisions of the Proposed Regulations | — | 1 | 179 |
| III.A | Definitions | §486.302 | 8 | 8,738 |
| III.B | Requirements for Certification | §486.303 | 2 | 1,954 |
| III.C | Designation of One OPO for Each Service Area | §486.308 | 4 | 2,802 |
| III.D | Designation of an OPO to More Than One Service Area | §486.309 | 4 | 3,312 |
| III.E | Non-Renewal of Agreement and De-Certification | §486.311 | 3 | 3,551 |
| III.F | Appeals | §486.314 | 6 | 5,024 |
| III.G | Re-Certification and Competition | §486.316 | 6 | 5,084 |
| III.H | Outcome Measures | §486.318 | 2 | 2,467 |
| III.I | Human Resources | §486.326 | 2 | 1,806 |
| III.J | Information Management | §486.330 | 1 | 428 |
| III.K | Quality Assessment and Performance Improvement | §486.344 | 4 | 4,359 |
| III.L | Proposed Conforming Changes | §486.322 | 1 | 713 |
| IV.A | Conflicts of Interest | §486.322 | 6 | 5,901 |
| IV.B | Allocation Out of Sequence (AOOS) | §486.320 | 8 | 8,279 |
| IV.C | Automated Electronic Referrals | §486.322 | 1 | 1,188 |
| V | Collection of Information Requirements | — | 1 | 740 |
| V.A | ICRs Regarding Information Management | §486.330 | 1 | 1,149 |
| V.B | ICRs Regarding QAPI | §486.348 | 1 | 1,598 |
| VI | Response to Comments | — | 1 | 105 |
| VII.A | Statement of Need | — | 1 | 386 |
| VII.B | Overall Impact | §486.302 | 16 | 15,449 |
| VII.C | Alternatives Considered | §486.308 | 6 | 3,963 |
| VII.D | Regulatory Review Cost Estimation | — | 1 | 293 |
| VII.E | Accounting Statement | — | 1 | 390 |
| VII.F | Regulatory Flexibility Act | — | 1 | 1,001 |
| VII.G | Unfunded Mandates Reform Act | — | 1 | 432 |
| VII.H | Federalism | — | 1 | 449 |
| VII.I | Executive Orders | — | 1 | 920 |
| REGTEXT | Proposed Regulatory Text | 42 CFR 486 | 9 | 10,456 |

## All Chunks (Detailed)

| # | Chunk ID | Section | CFR | Tokens | Key Topics |
|---|---|---|---|---|---|
| 1 | CMS3409P-PREAMBLE | PREAMBLE | — | 998 | QAPI, appeals, comment_solicitation, competition +5 |
| 2 | CMS3409P-I.A-part1 | I.A | §486.302 | 675 | QAPI, appeals, competition, cost_impact +11 |
| 3 | CMS3409P-I.A-part2.1 | I.A | §486.302 | 1,721 | QAPI, appeals, competition, cost_impact +11 |
| 4 | CMS3409P-I.A-part2.2 | I.A | §486.302 | 201 | QAPI, appeals, competition, cost_impact +11 |
| 5 | CMS3409P-I.A-part3.1 | I.A | §486.302 | 1,648 | QAPI, appeals, competition, cost_impact +11 |
| 6 | CMS3409P-I.A-part3.2 | I.A | §486.302 | 211 | QAPI, appeals, competition, cost_impact +11 |
| 7 | CMS3409P-I.A-part4 | I.A | §486.302 | 490 | QAPI, appeals, competition, cost_impact +11 |
| 8 | CMS3409P-I.B | I.B | — | 170 | severability |
| 9 | CMS3409P-II.A | II.A | — | 569 | QAPI, cost_impact, outcome_measures |
| 10 | CMS3409P-II.B-part1 | II.B | §486.314 | 589 | QAPI, appeals, comment_solicitation, competition +12 |
| 11 | CMS3409P-II.B-part2.1 | II.B | §486.314 | 1,609 | QAPI, appeals, comment_solicitation, competition +12 |
| 12 | CMS3409P-II.B-part2.2 | II.B | §486.314 | 353 | QAPI, appeals, comment_solicitation, competition +12 |
| 13 | CMS3409P-II.B-part3.1 | II.B | §486.314 | 1,700 | QAPI, appeals, comment_solicitation, competition +12 |
| 14 | CMS3409P-II.B-part3.2 | II.B | §486.314 | 229 | QAPI, appeals, comment_solicitation, competition +12 |
| 15 | CMS3409P-II.B-part4.1 | II.B | §486.314 | 1,691 | QAPI, appeals, comment_solicitation, competition +12 |
| 16 | CMS3409P-II.B-part4.2 | II.B | §486.314 | 212 | QAPI, appeals, comment_solicitation, competition +12 |
| 17 | CMS3409P-II.B-part5.1 | II.B | §486.314 | 1,690 | QAPI, appeals, comment_solicitation, competition +12 |
| 18 | CMS3409P-II.B-part5.2 | II.B | §486.314 | 260 | QAPI, appeals, comment_solicitation, competition +12 |
| 19 | CMS3409P-II.B-part6 | II.B | §486.314 | 1,133 | QAPI, appeals, comment_solicitation, competition +12 |
| 20 | CMS3409P-II.C | II.C | §486.303 | 1,595 | competition, designation, donor_potential, outcome_measures +1 |
| 21 | CMS3409P-III | III | — | 179 | recertification |
| 22 | CMS3409P-III.A-part1 | III.A | §486.302 | 975 | cost_impact, data_reporting, definitions, designation +6 |
| 23 | CMS3409P-III.A-part2.1 | III.A | §486.302 | 1,705 | cost_impact, data_reporting, definitions, designation +6 |
| 24 | CMS3409P-III.A-part2.2 | III.A | §486.302 | 328 | cost_impact, data_reporting, definitions, designation +6 |
| 25 | CMS3409P-III.A-part3.1 | III.A | §486.302 | 1,687 | cost_impact, data_reporting, definitions, designation +6 |
| 26 | CMS3409P-III.A-part3.2 | III.A | §486.302 | 317 | cost_impact, data_reporting, definitions, designation +6 |
| 27 | CMS3409P-III.A-part4.1 | III.A | §486.302 | 1,698 | cost_impact, data_reporting, definitions, designation +6 |
| 28 | CMS3409P-III.A-part4.2 | III.A | §486.302 | 263 | cost_impact, data_reporting, definitions, designation +6 |
| 29 | CMS3409P-III.A-part5 | III.A | §486.302 | 1,765 | cost_impact, data_reporting, definitions, designation +6 |
| 30 | CMS3409P-III.B-part1 | III.B | §486.303 | 264 | competition, decertification, designation, donor_potential +2 |
| 31 | CMS3409P-III.B-part2 | III.B | §486.303 | 1,690 | competition, decertification, designation, donor_potential +2 |
| 32 | CMS3409P-III.C-part1 | III.C | §486.308 | 137 | appeals, competition, decertification, definitions +5 |
| 33 | CMS3409P-III.C-part2.1 | III.C | §486.308 | 1,686 | appeals, competition, decertification, definitions +5 |
| 34 | CMS3409P-III.C-part2.2 | III.C | §486.308 | 239 | appeals, competition, decertification, definitions +5 |
| 35 | CMS3409P-III.C-part3 | III.C | §486.308 | 740 | appeals, competition, decertification, definitions +5 |
| 36 | CMS3409P-III.D-part1 | III.D | §486.309 | 1,158 | appeals, competition, decertification, definitions +6 |
| 37 | CMS3409P-III.D-part2.1 | III.D | §486.309 | 1,694 | appeals, competition, decertification, definitions +6 |
| 38 | CMS3409P-III.D-part2.2 | III.D | §486.309 | 222 | appeals, competition, decertification, definitions +6 |
| 39 | CMS3409P-III.D-part3 | III.D | §486.309 | 238 | appeals, competition, decertification, definitions +6 |
| 40 | CMS3409P-III.E-part1 | III.E | §486.311 | 1,694 | appeals, competition, cost_impact, decertification +6 |
| 41 | CMS3409P-III.E-part2.1 | III.E | §486.311 | 1,717 | appeals, competition, cost_impact, decertification +6 |
| 42 | CMS3409P-III.E-part2.2 | III.E | §486.311 | 140 | appeals, competition, cost_impact, decertification +6 |
| 43 | CMS3409P-III.F-part1 | III.F | §486.314 | 65 | appeals, competition, cost_impact, decertification +6 |
| 44 | CMS3409P-III.F-part2.1 | III.F | §486.314 | 1,674 | appeals, competition, cost_impact, decertification +6 |
| 45 | CMS3409P-III.F-part2.2 | III.F | §486.314 | 330 | appeals, competition, cost_impact, decertification +6 |
| 46 | CMS3409P-III.F-part3.1 | III.F | §486.314 | 1,696 | appeals, competition, cost_impact, decertification +6 |
| 47 | CMS3409P-III.F-part3.2 | III.F | §486.314 | 297 | appeals, competition, cost_impact, decertification +6 |
| 48 | CMS3409P-III.F-part4 | III.F | §486.314 | 962 | appeals, competition, cost_impact, decertification +6 |
| 49 | CMS3409P-III.G-part1 | III.G | §486.316 | 944 | appeals, competition, cost_impact, decertification +6 |
| 50 | CMS3409P-III.G-part2.1 | III.G | §486.316 | 1,685 | appeals, competition, cost_impact, decertification +6 |
| 51 | CMS3409P-III.G-part2.2 | III.G | §486.316 | 252 | appeals, competition, cost_impact, decertification +6 |
| 52 | CMS3409P-III.G-part3.1 | III.G | §486.316 | 1,681 | appeals, competition, cost_impact, decertification +6 |
| 53 | CMS3409P-III.G-part3.2 | III.G | §486.316 | 192 | appeals, competition, cost_impact, decertification +6 |
| 54 | CMS3409P-III.G-part4 | III.G | §486.316 | 330 | appeals, competition, cost_impact, decertification +6 |
| 55 | CMS3409P-III.H-part1 | III.H | §486.318 | 1,574 | competition, cost_impact, definitions, designation +3 |
| 56 | CMS3409P-III.H-part2 | III.H | §486.318 | 893 | competition, cost_impact, definitions, designation +3 |
| 57 | CMS3409P-III.I-part1 | III.I | §486.326 | 1,038 | cost_impact, definitions, designation, hospital_OPO +1 |
| 58 | CMS3409P-III.I-part2 | III.I | §486.326 | 768 | cost_impact, definitions, designation, hospital_OPO +1 |
| 59 | CMS3409P-III.J | III.J | §486.330 | 428 | data_reporting, information_management, outcome_measures |
| 60 | CMS3409P-III.K-part1 | III.K | §486.344 | 819 | QAPI, appeals, data_reporting, definitions +4 |
| 61 | CMS3409P-III.K-part2.1 | III.K | §486.344 | 1,703 | QAPI, appeals, data_reporting, definitions +4 |
| 62 | CMS3409P-III.K-part2.2 | III.K | §486.344 | 283 | QAPI, appeals, data_reporting, definitions +4 |
| 63 | CMS3409P-III.K-part3 | III.K | §486.344 | 1,554 | QAPI, appeals, data_reporting, definitions +4 |
| 64 | CMS3409P-III.L | III.L | §486.322 | 713 | definitions, designation, hospital_OPO, recertification |
| 65 | CMS3409P-IV.A-part1 | IV.A | §486.322 | 1,622 | competition, conflict_of_interest, cost_impact, donor_potential +4 |
| 66 | CMS3409P-IV.A-part2.1 | IV.A | §486.322 | 1,700 | competition, conflict_of_interest, cost_impact, donor_potential +4 |
| 67 | CMS3409P-IV.A-part2.2 | IV.A | §486.322 | 257 | competition, conflict_of_interest, cost_impact, donor_potential +4 |
| 68 | CMS3409P-IV.A-part3.1 | IV.A | §486.322 | 1,693 | competition, conflict_of_interest, cost_impact, donor_potential +4 |
| 69 | CMS3409P-IV.A-part3.2 | IV.A | §486.322 | 301 | competition, conflict_of_interest, cost_impact, donor_potential +4 |
| 70 | CMS3409P-IV.A-part4 | IV.A | §486.322 | 328 | competition, conflict_of_interest, cost_impact, donor_potential +4 |
| 71 | CMS3409P-IV.B-part1 | IV.B | §486.320 | 1,618 | conflict_of_interest, cost_impact, hospital_OPO, human_resources +3 |
| 72 | CMS3409P-IV.B-part2.1 | IV.B | §486.320 | 1,676 | conflict_of_interest, cost_impact, hospital_OPO, human_resources +3 |
| 73 | CMS3409P-IV.B-part2.2 | IV.B | §486.320 | 427 | conflict_of_interest, cost_impact, hospital_OPO, human_resources +3 |
| 74 | CMS3409P-IV.B-part3.1 | IV.B | §486.320 | 1,694 | conflict_of_interest, cost_impact, hospital_OPO, human_resources +3 |
| 75 | CMS3409P-IV.B-part3.2 | IV.B | §486.320 | 430 | conflict_of_interest, cost_impact, hospital_OPO, human_resources +3 |
| 76 | CMS3409P-IV.B-part4.1 | IV.B | §486.320 | 1,652 | conflict_of_interest, cost_impact, hospital_OPO, human_resources +3 |
| 77 | CMS3409P-IV.B-part4.2 | IV.B | §486.320 | 428 | conflict_of_interest, cost_impact, hospital_OPO, human_resources +3 |
| 78 | CMS3409P-IV.B-part5 | IV.B | §486.320 | 354 | conflict_of_interest, cost_impact, hospital_OPO, human_resources +3 |
| 79 | CMS3409P-IV.C | IV.C | §486.322 | 1,188 | comment_solicitation, designation, electronic_referral, hospital_OPO |
| 80 | CMS3409P-V | V | — | 740 | cost_impact |
| 81 | CMS3409P-V.A | V.A | §486.330 | 1,149 | cost_impact, information_management |
| 82 | CMS3409P-V.B | V.B | §486.348 | 1,598 | QAPI, cost_impact, medically_complex |
| 83 | CMS3409P-VI | VI | — | 105 |  |
| 84 | CMS3409P-VII.A | VII.A | — | 386 | appeals, competition, cost_impact |
| 85 | CMS3409P-VII.B-part1 | VII.B | §486.302 | 1,420 | DSA, QAPI, appeals, competition +10 |
| 86 | CMS3409P-VII.B-part2.1 | VII.B | §486.302 | 1,697 | DSA, QAPI, appeals, competition +10 |
| 87 | CMS3409P-VII.B-part2.2 | VII.B | §486.302 | 191 | DSA, QAPI, appeals, competition +10 |
| 88 | CMS3409P-VII.B-part3 | VII.B | §486.302 | 486 | DSA, QAPI, appeals, competition +10 |
| 89 | CMS3409P-VII.B-part4.1 | VII.B | §486.302 | 1,714 | DSA, QAPI, appeals, competition +10 |
| 90 | CMS3409P-VII.B-part4.2 | VII.B | §486.302 | 171 | DSA, QAPI, appeals, competition +10 |
| 91 | CMS3409P-VII.B-part5.1 | VII.B | §486.302 | 1,632 | DSA, QAPI, appeals, competition +10 |
| 92 | CMS3409P-VII.B-part5.2 | VII.B | §486.302 | 213 | DSA, QAPI, appeals, competition +10 |
| 93 | CMS3409P-VII.B-part6.1 | VII.B | §486.302 | 1,653 | DSA, QAPI, appeals, competition +10 |
| 94 | CMS3409P-VII.B-part6.2 | VII.B | §486.302 | 193 | DSA, QAPI, appeals, competition +10 |
| 95 | CMS3409P-VII.B-part7.1 | VII.B | §486.302 | 1,677 | DSA, QAPI, appeals, competition +10 |
| 96 | CMS3409P-VII.B-part7.2 | VII.B | §486.302 | 179 | DSA, QAPI, appeals, competition +10 |
| 97 | CMS3409P-VII.B-part8 | VII.B | §486.302 | 1,486 | DSA, QAPI, appeals, competition +10 |
| 98 | CMS3409P-VII.B-part9.1 | VII.B | §486.302 | 1,712 | DSA, QAPI, appeals, competition +10 |
| 99 | CMS3409P-VII.B-part9.2 | VII.B | §486.302 | 209 | DSA, QAPI, appeals, competition +10 |
| 100 | CMS3409P-VII.B-part10 | VII.B | §486.302 | 816 | DSA, QAPI, appeals, competition +10 |
| 101 | CMS3409P-VII.C-part1 | VII.C | §486.308 | 176 | QAPI, appeals, competition, cost_impact +6 |
| 102 | CMS3409P-VII.C-part2 | VII.C | §486.308 | 188 | QAPI, appeals, competition, cost_impact +6 |
| 103 | CMS3409P-VII.C-part3 | VII.C | §486.308 | 1,448 | QAPI, appeals, competition, cost_impact +6 |
| 104 | CMS3409P-VII.C-part4 | VII.C | §486.308 | 799 | QAPI, appeals, competition, cost_impact +6 |
| 105 | CMS3409P-VII.C-part5 | VII.C | §486.308 | 960 | QAPI, appeals, competition, cost_impact +6 |
| 106 | CMS3409P-VII.C-part6 | VII.C | §486.308 | 392 | QAPI, appeals, competition, cost_impact +6 |
| 107 | CMS3409P-VII.D | VII.D | — | 293 |  |
| 108 | CMS3409P-VII.E | VII.E | — | 390 | cost_impact |
| 109 | CMS3409P-VII.F | VII.F | — | 1,001 | cost_impact |
| 110 | CMS3409P-VII.G | VII.G | — | 432 |  |
| 111 | CMS3409P-VII.H | VII.H | — | 449 | DSA, designation |
| 112 | CMS3409P-VII.I | VII.I | — | 920 | appeals, competition, cost_impact, decertification +1 |
| 113 | CMS3409P-REGTEXT-part1 | REGTEXT | 42 CFR 486 | 1,725 | QAPI, appeals, competition, cost_impact +11 |
| 114 | CMS3409P-REGTEXT-part2.1 | REGTEXT | 42 CFR 486 | 1,704 | QAPI, appeals, competition, cost_impact +11 |
| 115 | CMS3409P-REGTEXT-part2.2 | REGTEXT | 42 CFR 486 | 161 | QAPI, appeals, competition, cost_impact +11 |
| 116 | CMS3409P-REGTEXT-part3 | REGTEXT | 42 CFR 486 | 1,815 | QAPI, appeals, competition, cost_impact +11 |
| 117 | CMS3409P-REGTEXT-part4.1 | REGTEXT | 42 CFR 486 | 1,728 | QAPI, appeals, competition, cost_impact +11 |
| 118 | CMS3409P-REGTEXT-part4.2 | REGTEXT | 42 CFR 486 | 147 | QAPI, appeals, competition, cost_impact +11 |
| 119 | CMS3409P-REGTEXT-part5.1 | REGTEXT | 42 CFR 486 | 1,706 | QAPI, appeals, competition, cost_impact +11 |
| 120 | CMS3409P-REGTEXT-part5.2 | REGTEXT | 42 CFR 486 | 106 | QAPI, appeals, competition, cost_impact +11 |
| 121 | CMS3409P-REGTEXT-part6 | REGTEXT | 42 CFR 486 | 1,364 | QAPI, appeals, competition, cost_impact +11 |

## Topic Coverage

| Topic | Chunks |
|---|---|
| outcome_measures | 104 |
| cost_impact | 96 |
| designation | 89 |
| recertification | 86 |
| competition | 84 |
| hospital_OPO | 82 |
| appeals | 77 |
| tier_system | 75 |
| decertification | 67 |
| medically_complex | 63 |
| human_resources | 60 |
| QAPI | 54 |
| organ_allocation | 51 |
| information_management | 47 |
| definitions | 46 |
| donor_potential | 46 |
| data_reporting | 23 |
| DSA | 17 |
| conflict_of_interest | 14 |
| comment_solicitation | 12 |
| severability | 1 |
| electronic_referral | 1 |
