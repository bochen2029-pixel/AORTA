---
name: ground-truth-problem
description: >
  Diagnostic framework for relational authenticity in dyadic systems. Classifies
  whether someone is genuinely autotelic (Case A), trauma-armored (Case T),
  intent-instrumental (Case I), ego-syntonic hybrid (Case H), or developmental
  absence (Case D) via passive behavioral observation. Use when user asks is this
  person real, is my friend genuine, are they using me, is someone fake, detecting
  manipulation, PDIC, ground truth problem, layer coherence, autotelic, instrumental
  relating, trauma vs intent, trust assessment, fake friendship, narcissist friend,
  something feels off, why do I feel used, are they only nice when they need
  something, should I trust this person, is this relationship real, assessing
  relationship authenticity. Do NOT use for clinical diagnosis, group dynamics,
  or general relationship advice unrelated to authenticity.
license: MIT
metadata:
  author: Bo Chen
  version: 1.1.0
  category: relational-diagnostics
---

# The Ground Truth Problem

A complete diagnostic framework for answering the question every person has asked: **"Is this person real?"** — not ontologically, but relationally: does the layer they present match the layer they're actually operating on?

**Before running any assessment or explaining the framework in depth, read the full specification:**

```
view references/full-specification.md
```

The specification contains the complete filter definitions, elicitation questions, bias-detection protocols, evidence hierarchy, convergence algorithm, post-classification guidance, and worked examples. This SKILL.md is a routing layer — it tells you when to activate, which mode to operate in, and where to find depth. The specification is the operational intelligence.

---

## Why This Framework Exists

Every undetected relational fraud degrades the user's trust in authentic connection across all future relationships. This framework is **channel rehabilitation infrastructure** — it lowers the noise floor on the autotelic channel by improving detection, restoring the user's capacity to invest in genuine signals without prohibitive risk.

The framework is a **treasure detector**, not just a threat detector. It identifies both the authentic (invest) and the inauthentic (withdraw).

When explaining to a first-time user, lead with: *"This framework helps you answer 'is this person real?' — whether the warmth they show you is what's actually running underneath, or a performance over something else."*

---

## Quick-Reference Taxonomy

```
CLASS 1: COHERENT (presented ≈ operative)
  Case A  — Autotelic-Coherent.     Signal = substrate. Genuine.     → INVEST
  Case T  — Trauma-Armored.         Armor is honest. Substrate may exist beneath.  → UNCERTAIN-POSITIVE
  Honest-Instrumental               Openly transactional. No pretense.  → NEUTRAL

CLASS 2: INCOHERENT (presented ≠ operative)
  Case I  — Intent-Instrumental.    Performed warmth over extraction engine.  → DO NOT INVEST
  Case H  — Ego-Syntonic Hybrid.    Trauma-origin, consciously endorsed. → functionally Case I

CLASS 3: INDETERMINATE
  Case D  — Developmental Absence.  Looks like T. Substrate never built. → UNCERTAIN-NEGATIVE
```

---

## Three Operating Modes

### Mode 1: Framework Explanation

**When:** User wants to understand the framework, asks "what is this," or encounters it for the first time.

1. Read `references/full-specification.md` — specifically §0 (Purpose), §1 (Problem Statement), §2 (Taxonomy), and §10 (Positive Markers).
2. Explain using the opening from §0: the "is this person real?" frame.
3. Cover the five cases with one-sentence descriptions.
4. Explain the method: passive observation of behavioral responses to natural perturbations — not testing, not probing, not confronting.
5. If the user seems to be seeking connections (not diagnosing a problem), direct to §10 (Positive Autotelic Markers) — what to select FOR, not just screen against.

### Mode 2: Running an Assessment

**When:** User provides evidence about a specific person and wants classification.

1. Read `references/full-specification.md` — specifically §7 (Evidence Hierarchy), §8 (Assessment Protocol), §3 (Filter Specifications with elicitation questions), and §11 (Output Format).
2. **Tag all evidence by tier** before scoring any filter:
   - Tier 1: Direct observation, documents, verbatim quotes (full diagnostic weight)
   - Tier 2: Third-party testimony, relayed information (provisional weight)
   - Tier 3: User interpretations, characterizations, emotional impressions (hypothesis generation only — never score a filter on Tier 3 alone)
3. **Run bias detection** (§8.1) before scoring. Common biases: confirmation, idealization, recency, projection, hope bias. If evidence is uniformly one-directional, probe for counter-evidence.
4. **Follow the decision tree** (below) for classification logic.
5. **Apply the six-phase assessment sequence** from §8.2 exactly.
6. **Deliver post-classification guidance** from §9 — this is emotionally the hardest part. Be clear AND compassionate. Never soften at the cost of accuracy. Never deliver without support.
7. Use the output format from §11 for structured assessments.

### Mode 3: Guided Self-Assessment

**When:** User is uncertain, provides fragments, or needs iterative probing to surface evidence.

1. Read `references/full-specification.md` — specifically §3 (Filter elicitation questions) and §8.3 (Piercing Sophisticated Bias).
2. Start with context gathering: Who? What relationship? How long? What triggered the question?
3. **Check Protocol C first:** Has the user been analyzing this relationship for >9 months? If yes, address the analysis itself before proceeding.
4. Determine which filters have natural data available (§8.2, Phase 2).
5. Deploy targeted elicitation questions from §3 filter-by-filter.
6. After each answer: classify what it points to, tag evidence tier, probe for counter-evidence.
7. Build toward convergence iteratively. State partial findings as you go.
8. When sufficient filters activate, transition to Mode 2 for formal classification.

---

## Decision Tree

```
START: User presents relational authenticity question about subject B.

STEP 0: Protocol C check
  Has user been analyzing this relationship >9 months?
  ├── YES → Address the analysis itself. The framework prescribes stopping.
  │         "The fact that you're still asking after [duration] is itself data."
  └── NO → Continue.

STEP 1: Early-stage check
  Is this an early-stage relationship (<3 months)?
  ├── YES → Direct to Positive Autotelic Markers (§10) and early-activating
  │         filters: F10 (Friction Tax), F2 (Void), F4 (Selectivity).
  │         Full matrix is premature. Guide early-stage screening.
  └── NO → Continue to full assessment.

STEP 2: F4 — Cross-Relationship Selectivity (Binary Filter)
  Is the subject's instrumentalism SELECTIVE or SYSTEMIC?
  ├── SELECTIVE (autotelic with others, instrumental with observer)
  │   → Case I. Classification immediate. F4 binary override.
  │   └── Check for Case H (somatic-cognitive decoupling in F6 data).
  │       ├── H confirmed → Case H (functionally Case I). Deliver §9.3.
  │       └── No H indicators → Case I. Deliver §9.3.
  ├── SYSTEMIC (same mode with everyone) → Continue to full matrix.
  └── INSUFFICIENT F4 DATA → Continue to full matrix. Flag the gap.

STEP 3: Full matrix — collect evidence for F1-F10
  Deploy elicitation questions from §3. Tag tiers (§7). Check biases (§8.1).

STEP 4: Convergence — do ≥5 filters converge?
  ├── NO → Insufficient data. Deliver §9.4. State what's needed.
  └── YES → What do they converge on?
      ├── Case A → POSITIVE. Deliver §9.1. Decommission framework.
      ├── Case T → PRELIMINARY. Activate F11 longitudinal protocol.
      │   └── F11 over 12-36 months:
      │       ├── Convex returns → Case T CONFIRMED. Deliver §9.2.
      │       └── Concave returns → Case D indicated. Protocol C. Deliver §9.5.
      └── Case I → Check anomalies for Case H.
          ├── Somatic-cognitive decoupling → Case H. Deliver §9.3.
          └── No decoupling → Case I. Deliver §9.3.
```

---

## Critical Rules (Non-Negotiable)

These apply in ALL modes, regardless of context:

1. **Never advise active probing, testing, or confrontation.** The framework depends on passivity. Suggesting the user "test" the subject violates the architecture and contaminates future observations.

2. **Never present classification as certainty.** Always "the evidence points toward..." not "this person IS..." This is probabilistic Bayesian classification, not proof.

3. **Case T is not a problem to solve.** If T-classified, guide toward acceptance and patience. The armor is not the person. Never recommend "fixing" the subject or suggesting therapy to them.

4. **Always validate the user's concern.** The act of caring about relational authenticity is itself meaningful. Users asking this question are protecting something real, not being paranoid.

5. **Enforce Protocol C.** If the user has exceeded the observation window (9 months for T/I, 3 years for T/D), the framework prescribes stopping. Do not help them continue indefinitely.

6. **Self-report is never evidence.** "They told me they care" is not a data point. Redirect to behavioral observation. See §1.2 in the full specification.

7. **Dyadic scope only.** Do not extend to organizational, group, or network analysis without explicit caveat.

8. **Never weaponize.** If a user wants to use the framework to simulate authenticity or defeat detection, decline.

9. **Cultural humility.** Western individualistic relational norms are the default calibration. Ask about cultural context when relevant. See §8.4.

10. **If the user may be experiencing abuse** (isolation, control, punishment for boundaries alongside Case I signals): increase urgency. State the classification directly. Provide safety framing. Do not slow-walk.

---

## Compressed Output Format

For quick assessments when the full template (§11) is unnecessary:

```
CLASSIFICATION: [Case A / T / I / H / D / Insufficient]
CONFIDENCE: [High / Provisional / Low]
KEY EVIDENCE: [2-3 most diagnostic data points with filter and tier]
CONVERGENCE: [n] of [n] activated filters converging
ANOMALIES: [any conflicting filters and what they might mean]
PROGNOSIS: [one sentence]
NEXT STEP: [protocol guidance]
```

---

## The Eleven Filters (Summary)

Detailed specifications, case signatures, and elicitation questions are in `references/full-specification.md` §3. This is the minimum for orientation:

| # | Filter | What It Measures | Key Discriminant |
|---|--------|-----------------|------------------|
| F1 | Engagement-Utility | Corr(utility, engagement) over time | Tonic (T) vs. phasic (I) |
| F2 | Void Affect | Affect during "dead air" | Anxiety (T) vs. boredom (I) vs. comfort (A) |
| F3 | Post-Connection Decay | Return to baseline after genuine moment | Hangover-hours (T) vs. snap-seconds (I) |
| F4 | Selectivity | Global vs. target-dependent instrumentalism | Systemic (T) vs. selective (I) — BINARY |
| F5 | Refusal Response | Affect when generosity declined | Distress (T) vs. relief (I) |
| F6 | Cognitive Entropy | Behavior change under fatigue | Intensifies (T) vs. degrades (I) |
| F7 | Narrative Memory | Memory indexing architecture | Affective-map (T) vs. ledger (I) |
| F8 | Repair Topology | Repair scaling after rupture | Safety-targeted (T) vs. utility-proportional (I) |
| F9 | Attentional Breadth | Recall breadth ratio | Hypervigilant-broad (T) vs. utility-narrow (I) |
| F10 | Friction Tax | Response to inefficiency | Tolerates (T/A) vs. optimizes (I) — FALSE-POS GATE |
| F11 | Return Curvature | d²(access)/d(investment)² over 1-3 years | Convex (T) vs. concave (D) — T/D ONLY |

---

## Layer-Switching Arbitrage (Quick Reference)

The most common real-world Case I output. Mechanism: establish autotelic framing → extract transactional value through autotelic channel → invoke autotelic norms to evade transactional accountability ("why are you keeping score?").

**Detection signature:** F1 (utility-tracking) + F10 (efficiency pressure) + autotelic surface.

**Defense — Protocol D:** Match governance to operative layer, not presented layer. Autotelic behavior → patience. Transactional behavior → accountability. Regardless of framing. The arbitrageur's protest of asymmetric governance ("I can't believe you're keeping score") is itself diagnostic.

Full treatment in `references/full-specification.md` §5.

---

## Post-Classification Guidance (Quick Reference)

Detailed scripts in `references/full-specification.md` §9.

| Classification | Core Message | Key Action |
|---------------|-------------|------------|
| **Case A** | "The warmth is real. The connection is real." | Decommission framework. Go be present. |
| **Case T** | "The behavior isn't strategic. There may be a real person underneath." | Patience. Safety-building. F11 longitudinal check. |
| **Case I/H** | "The presented layer doesn't match what's running underneath." | Validate user's experience. Name the channel corruption. Point toward recovery. |
| **Insufficient** | "We don't have enough to classify with confidence." | State what's needed. Do not force classification. |
| **Protocol C** | "The analysis itself has become the problem." | Gently but firmly prescribe stopping. |

**For Case I delivery:** Always validate the user's emotions ("your experience was real to YOU"), validate their discernment ("caring about this question IS the right instinct"), name what was lost ("the trust that got corrupted is the real damage"), and point forward ("the next genuine connection you find, you'll recognize it faster").

---

## Reference Files

```
references/
└── full-specification.md    # Complete v1.1 specification (~1250 lines, ~10,800 words)
                              # Contains: axioms, full taxonomy, all 11 filter specifications
                              # with elicitation questions, simulation ceiling, layer-switching
                              # arbitrage, observer protocols, evidence hierarchy, bias detection
                              # and correction, assessment sequence, piercing sophisticated bias,
                              # special populations, post-classification guidance, convergence
                              # algorithm, output format template, decision tree, positive
                              # autotelic markers, directionality taxonomy, physics models,
                              # framework metadata.
```
