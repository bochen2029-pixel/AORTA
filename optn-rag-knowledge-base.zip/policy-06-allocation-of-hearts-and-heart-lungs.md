# OPTN Policy 6: Allocation of Hearts and Heart-Lungs

**Source:** OPTN Policies | **Effective:** 12/10/2025 | **Category:** Heart Allocation
**Confidence:** HIGH — Official OPTN policy language

---

## 6.1 — Adult Status Assignments and Update Requirements

<!-- Policy: 6 | Section: 6.1 | Category: Heart Allocation -->

Each adult heart transplant candidate at least 18 years old at the time of registration is assigned a status 
that reflects the candidate’s medical urgency for transplant. The candidate’s transplant program must 
submit a heart status justification form to the OPTN to assign a candidate the status for which the 
candidate qualifies. Transplant programs must assign candidates on the waiting list that are not 
currently suitable for transplant to the inactive status.  
 
If a candidate’s transplant program does not submit a heart status justification form or the status 
expires and the transplant program does not submit a new heart status justification form, the candidate 
is assigned to status 6, or status 5 if the candidate is registered for another organ.  
 
When registering a candidate, the transplant program must submit to the OPTN all of the following 
clinical data: 
 
• 
Hemodynamic assessment results 
• 
Functional status or exercise testing results 
• 
Heart failure severity or end organ function indicators  
• 
Heart failure therapies 
• 
Mechanical support  
• 
Sensitization risk, including CPRA, peak PRA, and number of prior sternotomies 
• 
Current diagnosis 
 
These clinical data must be submitted every time the transplant program submits a justification form 
unless a test needed to obtain the data has not been performed since the last justification form was 
submitted. The transplant program must maintain source documentation for all laboratory values 
reported to the OPTN.

---

## 6.1.A — Adult Heart Status 1 Requirements

<!-- Policy: 6 | Section: 6.1.A | Category: Heart Allocation -->

To assign a candidate adult status 1, the candidate’s transplant program must submit a Heart 
Status 1 Justification Form to the OPTN. A candidate is not assigned adult status 1 until this form 
is submitted. 
 

 
 
 
If the candidate is at least 18 years old at the time of registration, then the candidate’s 
transplant program may assign the candidate adult status 1 if the candidate has at least one of 
the following conditions: 
 
• 
Is supported by veno-arterial extracorporeal membrane oxygenation (VA ECMO), according 
to OPTN Policy 6.1.A.i below. 
• 
Is supported by a non-dischargeable, surgically implanted, non-endovascular biventricular 
support device according to Policy 6.1.A.ii below. 
• 
Is supported by a mechanical circulatory support device (MCSD) and has a life-threatening 
ventricular arrhythmia according to Policy 6.1.A.iii below.  
 
6.1.A.i Veno-Arterial Extracorporeal Membrane Oxygenation (VA ECMO)  
A candidate’s transplant program may assign a candidate to adult status 1 if the 
candidate is admitted to the transplant hospital that registered the candidate on the 
waiting list, and is supported by VA ECMO for cardiogenic shock as evidenced by 
either of the following: 
 
• 
Within 7 days prior to VA ECMO support, all of the following are true within one 
24 hour period: 
a. Systolic blood pressure less than 90 mmHg 
b. Cardiac index less than 1.8 L/min/m2 if the candidate is not supported by 
inotropes or less than 2.0 L/min/m2 if the candidate is supported by at least 
one inotrope 
c. Pulmonary capillary wedge pressure greater than 15 mmHg 
• 
If hemodynamic measurements could not be obtained within 7 days prior to VA 
ECMO support, at least one of the following is true within 24 hours prior to VA 
ECMO support: 
o CPR was performed on the candidate 
o Systolic blood pressure less than 70 mmHg 
o Arterial lactate greater than 4 mmol/L 
o Aspartate transaminase (AST) or alanine transaminase (ALT) greater than 
1,000 U/L 
 
Candidates that meet either of the criteria above will remain in this status for up to 
7 days from submission of the Heart Status 1 Justification Form.  
 
Every 7 days, the transplant program may apply to the regional review board (RRB) 
to extend the candidate at this status if the candidate remains hospitalized and is 
supported by VA ECMO. The transplant program must provide to the RRB objective 
evidence of both of the following: 
 
1. The candidate demonstrated a contraindication to being supported by a durable 
device 
2. Within 48 hours prior to the status expiring, the transplant program failed at 
weaning the candidate from VA ECMO as evidenced by at least one of the 
following:  
• 
Mean arterial pressure (MAP) less than 60 mmHg 

 
 
 
• 
Cardiac index less than 2.0 L/min/m2  
• 
Pulmonary capillary wedge pressure greater than 15 mmHg 
• 
SvO2 less than 50 percent measured by central venous catheter 
 
The RRB will retrospectively review extension requests. If the candidate is still supported 
by VA ECMO after 7 days and either the extension request is not granted or the 
transplant program does not request an extension, then the transplant program may 
assign the candidate to status 3.  
 
6.1.A.ii 
Non-dischargeable, Surgically Implanted, Non-Endovascular 
Biventricular Support Device  
A candidate’s transplant program may assign a candidate to adult status 1 if the 
candidate is admitted to the transplant hospital that registered the candidate on the 
waiting list, is supported by a surgically implanted, non-endovascular biventricular 
support device and must remain hospitalized because the device is not FDA-approved 
for out of hospital use. This status is valid for up to 7 days from submission of the Heart 
Status 1 Justification Form.  
 
A candidate’s transplant program may extend the candidate’s status every 7 days if the 
candidate continues to meet the above criteria and the transplant program submits 
another Heart Status 1 Justification Form. 
 
6.1.A.iii 
Mechanical Circulatory Support Device (MCSD) with Life 
Threatening Ventricular Arrhythmia 
A candidate’s transplant program may assign a candidate to adult status 1 if the 
candidate is admitted to the transplant hospital that registered the candidate on the 
waiting list, is supported by an MCSD, and is experiencing recurrent or sustained 
ventricular tachycardia or ventricular fibrillation as evidenced by at least one of the 
following:  
 
• 
Placement of a biventricular mechanical circulatory support device for the 
treatment of sustained ventricular arrhythmias 
• 
That the patient was not considered a candidate for other treatment alternatives, 
such as ablation, by an electrophysiologist, and has experienced three or more 
episodes of ventricular fibrillation or ventricular tachycardia separated by at least an 
hour, over the previous 7 days that both: 
1. Occurred in the setting of normal serum magnesium and potassium levels 
2. Required electrical cardioversion despite receiving continuous intravenous 
antiarrhythmic therapies 
 
This status is valid for up to 7 days from submission of the Heart Status 1 Justification 
Form. This status can be extended by the transplant program every 7 days by 
submission of another Heart Status 1 Justification Form if the candidate remains 
hospitalized on continuous intravenous antiarrhythmic therapy. 
 

 
 
 
After 7 days, if the candidate remains hospitalized and the transplant program does not 
request an extension, then the transplant program may assign the candidate to status 3.

---

## 6.1.B — Adult Heart Status 2 Requirements (Part 1)

<!-- Policy: 6 | Section: 6.1.B | Category: Heart Allocation -->

To assign a candidate adult status 2, the candidate’s transplant program must submit a Heart 
Status 2 Justification Form to the OPTN. A candidate is not assigned adult status 2 until this form 
is submitted. 

If the candidate is at least 18 years old at the time of registration then the candidate’s transplant 
program may assign the candidate to adult status 2 if the candidate has at least one of the 
following conditions:  

• 
Is supported by a non-dischargeable, surgically implanted, non-endovascular left ventricular 
assist device (LVAD), according to OPTN Policy 6.1.B.i below. 
• 
Is supported by a total artificial heart (TAH), biventricular assist device (BiVAD), right 
ventricular assist device (RVAD), or ventricular assist device (VAD) for single ventricle 
patients, according to OPTN Policy 6.1.B.ii below. 
• 
Is supported by a mechanical circulatory support device (MCSD) that is malfunctioning, 
according to OPTN Policy 6.1.B.iii below.  
• 
Is supported by a percutaneous endovascular mechanical circulatory support device, 
according to OPTN Policy 6.1.B.iv below. 
• 
Is supported by an intra-aortic balloon pump (IABP), according to OPTN Policy 6.1.B.v below.  
• 
Is experiencing recurrent or sustained ventricular tachycardia or ventricular fibrillation 
according to OPTN Policy 6.1.B.vi below. 

6.1.B.i 
Non-Dischargeable, Surgically Implanted, Non-Endovascular Left 
Ventricular Assist Device (LVAD)  
A candidate’s transplant program may assign a candidate to adult status 2 if the 
candidate is admitted to the transplant hospital that registered the candidate on the 
waiting list, is supported by a surgically implanted, non-endovascular LVAD, and must 
remain hospitalized because the device is not FDA-approved for out of hospital use. 

Candidates that meet the criteria above will remain in this status for up to 14 days from 
submission of the Heart Status 2 Justification Form. Every 14 days, the transplant 
program may apply to the RRB to extend the candidate’s registration if the candidate 
remains supported by the non-dischargeable surgically implanted, non-endovascular 
LVAD. The transplant program must provide to the RRB objective evidence of both of 
the following: 

1. The candidate demonstrated a contraindication to being supported by a durable 
device 
2. Within 48 hours prior to the status expiring, the transplant program failed at 
weaning the candidate from the non-dischargeable surgically implanted, non-
endovascular LVAD as evidenced by at least one of the following: 
• 
Mean arterial pressure (MAP) less than 60 mmHg  
• 
Cardiac index less than 2.0 L/min/m2  

• 
Pulmonary capillary wedge pressure greater than15 
• 
SvO2 less than 50 percent measured by central venous catheter 

The RRB will retrospectively review extension requests. If the candidate is still supported 
by the non-dischargeable surgically implanted, non-endovascular LVAD after 14 days 
and either the extension request is not granted or the transplant program does not 
request an extension, then the transplant program may assign the candidate to status 3.  

6.1.B.ii 
Total Artificial Heart (TAH), BiVAD, Right Ventricular Assist Device 
(RVAD), or Ventricular Assist Device (VAD) for Single Ventricle 
Patients 
A candidate’s transplant program may assign a candidate to adult status 2 if the 
candidate is supported by any of the following:  

• 
A TAH 
• 
An RVAD alone 
• 
A BiVAD  
• 
A VAD, for single ventricle patients only 

This status is valid for up to 14 days from submission of the Heart Status 2 Justification 
Form. This status can be extended by the transplant program every 14 days by 
submission of another Heart Status 2 Justification Form. 

6.1.B.iii 
Mechanical Circulatory Support Device (MCSD) with Malfunction  
A candidate’s transplant program may assign a candidate to adult status 2 if the 
candidate is admitted to the transplant hospital that registered the candidate on the 
waiting list and is supported by an MCSD that is experiencing device malfunction as 
evidenced by all of the following: 

1. Malfunction of at least one of the components of the MCSD 
2. Malfunction cannot be fixed without an entire device replacement 
3. Malfunction is currently causing inadequate mechanical circulatory support or 
places the candidate at imminent risk of device stoppage 

This status is valid for up to 14 days from submission of the Heart Status 2 Justification 
Form. This status can be extended by the transplant program every 14 days by 
submission of another Heart Status 2 Justification Form. 

6.1.B.iv 
Percutaneous Endovascular Mechanical Circulatory Support Device 
A candidate’s transplant program may assign a candidate to adult status 2 if the 
candidate is admitted to the transplant hospital that registered the candidate on the 
waiting list, and is supported by a percutaneous endovascular mechanical circulatory 
support device without an oxygenator for cardiogenic shock as evidenced by either of 
the following:

---

## 6.1.B — Adult Heart Status 2 Requirements (Part 2)

<!-- Policy: 6 | Section: 6.1.B | Category: Heart Allocation -->

• 
Within 7 days prior to percutaneous endovascular mechanical circulatory 
support, both of the following are true:  
1. All of the following hemodynamic measurements were 
obtained for the candidate within one 24-hour period, and: 
a. Systolic blood pressure of less than 90 mmHg 
b. Cardiac index of less than 2.0 L/min/m2 
c. Pulmonary capillary wedge pressure of greater than 15 
mmHg 
2. The candidate either: 
a. Was being supported by inotropic therapy according to 
either of the following qualifying doses, or 
▪ 
A continuous infusion of at least one high-dose 
intravenous inotrope, or: 
▪ 
Dobutamine greater than or equal to 
7.5 mcg/kg/min 
▪ 
Milrinone greater than or equal to 0.50 
mcg/kg/min 
▪ 
Epinephrine greater than or equal to 
0.02 mcg/kg/min 
▪ 
A continuous infusion of at least two 
intravenous inotropes: 
▪ 
Dobutamine greater than or equal to 3 
mcg/kg/min 
▪ 
Milrinone greater than or equal to 0.25 
mcg/kg/min 
▪ 
Epinephrine greater than or equal to 
0.01 mcg/kg/min 
▪ 
Dopamine greater than or equal to 3 
mcg/kg/min 
b. Developed ventricular tachycardia lasting at least 30 
seconds or required cardioversion, defibrillation, or 
antitachycardia pacing after inotropic therapy was 
initiated in an attempt to reach the qualifying doses 
• 
If hemodynamic measurements could not be obtained within 7 days prior to 
percutaneous endovascular mechanical circulatory support, at least one of the 
following was true within 24 hours prior to percutaneous endovascular 
mechanical circulatory support:  
o CPR was performed on the candidate 
o Systolic blood pressure less than 70 mmHg 
o Arterial lactate greater than 4 mmol/L 
o Aspartate transaminase (AST) or alanine transaminase (ALT) greater 
than 1,000 U/L 
Candidates that meet the criteria above will remain in this status for up to 14 days from 
submission of the Heart Status 2 Justification Form. Every 14 days, the transplant 
program may apply to the RRB to extend the candidate’s status if the candidate remains 
supported by the percutaneous endovascular mechanical circulatory support device. 

The transplant program must provide to the RRB objective evidence of both of the 
following: 

1. The candidate demonstrated a contraindication to being supported by a durable 
device, and 
2. Either 
a. Within 48 hours prior to the status expiring, the transplant program 
demonstrated a failure to wean the candidate from the percutaneous 
endovascular mechanical circulatory support device evidenced by at least one of 
the following while being supported by inotropic therapy at a qualifying dose, 
or:  
▪ 
Mean arterial pressure (MAP) less than 60 mmHg 
▪ 
Cardiac index less than 2.0 L/min/m2 
▪ 
Pulmonary capillary wedge pressure greater than 15 mmHg 
▪ 
SvO₂ less than 50 percent measured by central venous catheter 
b. The candidate had qualified for status 2 after requiring a percutaneous 
endovascular mechanical circulatory support device due to failure to be 
supported on inotropes related to ventricular tachycardia lasting at least 30 
seconds, or requiring cardioversion, defibrillation, or antitachycardia pacing. 
The RRB will retrospectively review extension requests. If the candidate is still supported by 
the percutaneous endovascular mechanical circulatory support device after 14 days and 
either the extension request is not granted or the transplant program does not request an 
extension, then the transplant program may assign the candidate to status 3. 

6.1.B.v  
Intra-Aortic Balloon Pump (IABP) 
A candidate’s transplant program may assign a candidate to adult status 2 if the 
candidate is admitted to the transplant hospital that registered the candidate on the 
waiting list, and is supported by an IABP for cardiogenic shock as evidenced by either of 
the following: 
• 
Within 7 days prior to IABP support, both of the following are true: 
1. All of the following hemodynamic measurements were obtained for 
the candidate within one 24-hour period, and: 
a. Systolic blood pressure of less than 90 mmHg 
b. Cardiac index of less than 2.0 L/min/m2 
c. Pulmonary capillary wedge pressure of greater than 15 
mmHg 
2. The candidate either: 
a. Was being supported by inotropic therapy according to 
either of the following qualifying doses, or 
▪ 
A continuous infusion of at least one high-dose 
intravenous inotrope, or: 
▪ 
Dobutamine greater than or equal to 
7.5 mcg/kg/min 
▪ 
Milrinone greater than or equal to 0.50 
mcg/kg/min 

▪ 
Epinephrine greater than or equal to 
0.02 mcg/kg/min 
▪ 
A continuous infusion of at least two 
intravenous inotropes: 
▪ 
Dobutamine greater than or equal to 3 
mcg/kg/min 
▪ 
Milrinone greater than or equal to 0.25 
mcg/kg/min 
▪ 
Epinephrine greater than or equal to 
0.01 mcg/kg/min 
▪ 
Dopamine greater than or equal to 3 
mcg/kg/min 
b. Developed ventricular tachycardia lasting at least 30 
seconds or required cardioversion, defibrillation, or 
antitachycardia pacing after inotropic therapy was 
initiated in an attempt to reach the qualifying doses 
• 
If hemodynamic measurements could not be obtained within 7 days prior to IABP 
support, at least one of the following was true within 24 hours prior to IABP 
support: 
o CPR was performed on the candidate 
o Systolic blood pressure less than 70 mmHg 
o Arterial lactate greater than 4 mmol/L 
o AST or ALT greater than 1,000 U/L 

Candidates that meet the criteria above will remain in this status for up to 14 days from 
submission of the Heart Status 2 Justification Form. Every 14 days, the transplant 
program may apply to the RRB to extend the candidate’s status if the candidate remains 
supported by the IABP. The transplant program must provide to the RRB objective 
evidence of both of the following:

---

## 6.1.B — Adult Heart Status 2 Requirements (Part 3)

<!-- Policy: 6 | Section: 6.1.B | Category: Heart Allocation -->

1. The candidate demonstrated a contraindication to being supported by a durable 
device, and 
2. Either 
a. Within 48 hours prior to the status expiring, the transplant program 
demonstrated a failure to wean the candidate from the IABP evidenced by at 
least one of the following, while being supported by inotropic therapy at a 
qualifying dose, or:  
▪ 
Mean arterial pressure (MAP) less than 60 mmHg 
▪ 
Cardiac index less than 2.0 L/min/m2 
▪ 
Pulmonary capillary wedge pressure greater than 15 mmHg 
▪ 
SvO₂ less than 50 percent measured by central venous catheter 
b. The candidate had qualified for status 2 after requiring the IABP due to failure to 
be supported on inotropes related to ventricular tachycardia lasting at least 30 
seconds, or requiring cardioversion, defibrillation, or antitachycardia pacing. 

The RRB will retrospectively review extension requests. If the candidate is still supported by the 
IABP after 14 days and either the extension request is not granted or the transplant program 
does not request an extension, then the transplant program may assign the candidate to status 
3. 

6.1.B.vi 
Ventricular Tachycardia (VT) or Ventricular Fibrillation (VF) 
A candidate’s transplant program may assign a candidate to adult status 2 if the 
candidate is admitted to the transplant hospital that registered the candidate on the 
waiting list, is not considered a candidate for other treatment alternatives, such as 
ablation, by an electrophysiologist, and is experiencing recurrent or sustained VT or VF 
with at least three episodes separated by at least one hour within a period of 14 days. 
The VT or VF episodes must have both of the following: 

1. Occurred in the setting of normal serum magnesium and potassium levels 
2. Required electrical cardioversion despite receiving intravenous antiarrhythmic 
therapies  

This status is valid for up to 14 days from submission of the Heart Status 2 Justification 
Form. This status can be extended by the transplant program every 14 days by 
submission of another Heart Status 2 Justification Form.

---

## 6.1.C — Adult Heart Status 3 Requirements (Part 1)

<!-- Policy: 6 | Section: 6.1.C | Category: Heart Allocation -->

To assign a candidate to adult status 3, the candidate’s transplant program must submit a Heart 
Status 3 Justification Form to the OPTN. A candidate is not assigned adult status 3 until this form 
is submitted.  

If the candidate is at least 18 years old at the time of registration, then the candidate’s 
transplant program may assign the candidate adult status 3 if the candidate has at least one of 
the following conditions: 

• 
Is supported by a dischargeable left ventricular assist device and is exercising 30 days of 
discretionary time, according to OPTN Policy 6.1.C.i below. 
• 
Is supported by multiple inotropes or a single high dose inotrope and has hemodynamic 
monitoring, according to OPTN Policy 6.1.C.ii below. 
• 
Is supported by a mechanical circulatory support device (MCSD) with hemolysis, according 
to OPTN Policy 6.1.C.iii below. 
• 
Is supported by an MCSD with pump thrombosis, according to OPTN Policy 6.1.C.iv below. 
• 
Is supported by an MCSD and has right heart failure, according to OPTN Policy 6.1.C.v below. 
• 
Is supported by an MCSD and has a device infection, according to OPTN Policy 6.1.C.vi 
below. 
• 
Is supported by an MCSD and has bleeding, according to OPTN Policy 6.1.C.vii below. 
• 
Is supported by an MCSD and has aortic insufficiency, according to OPTN Policy 6.1.C.viii 
below. 
• 
Is supported by veno-arterial extracorporeal membrane oxygenation (VA ECMO) after 7 
days, according to OPTN Policy 6.1.C.ix below. 

• 
Is supported by a non-dischargeable, surgically implanted, non-endovascular left ventricular 
assist device (LVAD) after 14 days, according to OPTN Policy 6.1.C.x below. 
• 
Is supported by a percutaneous endovascular mechanical circulatory support device after 14 
days, according to OPTN Policy 6.1.C.xi below. 
• 
Is supported by an intra-aortic balloon pump (IABP) after 14 days, according to OPTN Policy 
6.1.C.xii below. 
• 
Is supported by a MCSD and has life threatening ventricular arrhythmia after 7 days, 
according to OPTN Policy 6.1.C.xiii below. 

6.1.C.i 
Dischargeable Left Ventricular Assist Device (LVAD) for 
Discretionary 30 Days 
A candidate’s transplant program may assign a candidate to adult status 3 if the 
candidate is supported by a dischargeable LVAD. The OPTN maintains a list of OPTN-
approved, qualifying devices.  

The candidate may be registered as status 3 for 30 days at any point after being 
implanted with the dischargeable LVAD and once the attending physician 
determines the candidate is medically stable. Regardless of whether the candidate 
has a single transplant program registration or multiple transplant program 
registrations, the candidate receives a total of 30 days discretionary time for each 
dischargeable LVAD implanted across all registrations. Each day used by any of the 
transplant programs counts towards the cumulative 30 days. 

The 30 days do not have to be consecutive and if the candidate undergoes a 
procedure to receive another replacement dischargeable LVAD, then the candidate 
qualifies for a new term of 30 days. When a candidate receives a replacement 
device, the 30 day period begins again, and the candidate cannot use any time 
remaining from the previous period. 

6.1.C.ii 
Multiple Inotropes or a Single High Dose Inotrope and 
Hemodynamic Monitoring  
A candidate’s transplant program may assign a candidate to adult status 3 if the 
candidate is admitted to the hospital that registered the candidate on the waiting 
list, and within 7 days prior to inotrope administration or while on inotropes meets 
all of the following: 

1. Has one of the following: 
• 
Invasive pulmonary artery catheter  
• 
Daily hemodynamic monitoring to measure cardiac output and left 
ventricular filling pressures  
2. Is in cardiogenic shock, as evidenced by all of the following within one 24 hour 
period: 
a. Systolic blood pressure less than 90 mmHg 
b. Pulmonary Capillary Wedge Pressure greater than 15 mmHg  
c. Cardiac index of either: 

o Less than 1.8 L/min/m2 for candidates without inotropic or mechanical 
support within 7 days prior to inotrope administration 
o Less than 2.2 L/min/m2 for candidates with inotropic or mechanical 
support 
3. Is supported by one of the following:  
• 
A continuous infusion of at least one high-dose intravenous inotrope: 
o Dobutamine greater than or equal to 7.5 mcg/kg/min 
o Milrinone greater than or equal to 0.50 mcg/kg/min 
o Epinephrine greater than or equal to 0.02 mcg/kg/min  
• 
A continuous infusion of at least two intravenous inotropes: 
o Dobutamine greater than or equal to 3 mcg/kg/min 
o Milrinone greater than or equal to 0.25 mcg/kg/min 
o Epinephrine greater than or equal to 0.01 mcg/kg/min 
o Dopamine greater than or equal to 3 mcg/kg/min 

This status is valid for up to 14 days from submission of the Heart Status 3 
Justification Form. After the initial 14 days, this status can be extended by the 
transplant program every 14 days by submission of another Heart Status 3 
Justification Form if the candidate remains admitted to the hospital that registered 
the candidate on the waiting list, and the candidate remains supported by ongoing 
use of a qualifying inotrope therapy and meets all of the following: 

1. One of the following hemodynamic monitoring: 
• 
Invasive pulmonary artery catheter  
• 
Daily hemodynamic monitoring to measure cardiac output and left 
ventricular filling pressures 
2. Within 48 hours prior to the status expiring, must meet either of the following: 
• 
Cardiac index less than 2.2 L/min/m2 on the current medical regimen  
• 
Failed attempt to wean the inotrope support documented by at least one of 
the following: 
o Cardiac index less than 2.2 L/min/m2 during dose reduction 
o Increase in serum creatinine by 20 percent over the value immediately 
prior to, and within 24 hours of, inotrope dose reduction 
o Increase in arterial lactate to greater than 2.5 mmol/L 
o SvO2 less than 50 percent measured by central venous catheter

---

## 6.1.C — Adult Heart Status 3 Requirements (Part 2)

<!-- Policy: 6 | Section: 6.1.C | Category: Heart Allocation -->

6.1.C.iii 
Mechanical Circulatory Support Device (MCSD) with Hemolysis 
A candidate’s transplant program may assign a candidate to adult status 3 if the 
candidate is supported by an MCSD and is not experiencing device malfunction, but 
is experiencing hemolysis, as evidenced by both of the following: 

1. Two separate samples collected within 48 hours of each other confirming 
markers of active hemolysis as evidenced by at least two of the following 
criteria:  
• 
Blood lactate dehydrogenase (LDH) at least 2.5 times the upper limit of 
normal at the laboratory reference range  
• 
Plasma free hemoglobin greater than 20 mg/dL 
• 
Hemoglobinuria  
2. Documentation of at least one attempt to treat the condition using an 
intravenous anticoagulant, intravenous anti-platelet agent, or thrombolytic, 
with persistent or recurrent hemolysis  

This status is valid for up to 14 days from submission of the Heart Status 3 
Justification Form. After the initial 14 days, this status can be extended by the 
transplant program every 14 days by submission of another Heart Status 3 
Justification Form. 

6.1.C.iv 
Mechanical Circulatory Support Device (MCSD) with Pump 
Thrombosis 
A candidate’s transplant program may assign a candidate to adult status 3 if the 
candidate is admitted to the transplant hospital that registered the candidate on the 

waiting list, is supported by MCSD and the transplant program has identified a 
suspected pump thrombosis in either an implanted LVAD or a discharged 
paracorporeal device and both of the following criteria are met:  

• 
The candidate has one of the following conditions: 
o Transient Ischemic Attack (TIA) lasting less than 24 hours or Reversible 
Ischemic Neurologic Deficit (RIND) lasting less than 72 hours (as 
observed by symptoms such as, but not limited to unilateral facial 
weakness, vision problems, and/or slurred speech), Cerebrovascular 
Accident (CVA), or a peripheral thromboembolic event in the absence of 
intracardiac thrombus or significant carotid artery disease, 
o A condition that requires inotropic support and presence of left-sided 
heart failure not explained by structural heart disease such as Aortic 
Insufficiency (AI) [as defined Policy 6.1.C.vii: MCSD with Mucosal 
Bleeding], as demonstrated by 
▪ 
Pulmonary Capillary Wedge Pressure (PCWP) greater than 15, 
and 
▪ 
Mean Arterial Pressure (MAP) less than 90 
o Abnormal pump parameters, such as significant and persistent increase 
in pump power and low flow despite good blood pressure control 
o Visually detected thrombus in a paracorporeal ventricular device (VAD) 
• 
The candidate is supported by one of the following treatments in the hospital: 
o Intravenous anticoagulation (e.g. heparin) 
o Intravenous thrombolytics (e.g. tPA) 
o Intravenous antiplatelet therapy (e.g. eptifibatide or tirofiban) 

This status is valid for up to 30 days from submission of the Heart Status 3 
Justification Form.  

After the initial 30 days, a candidate’s transplant program may extend the 
candidate’s status every 90 days if the candidate continues to meet the above 
criteria and the transplant program submits another Heart Status 3 Justification 
Form. 

6.1.C.v 
Mechanical Circulatory Support Device (MCSD) with Right Heart 
Failure 
A candidate’s transplant program may assign a candidate to adult status 3 if the 
candidate is supported by an MCSD and has at least moderate right ventricular 
malfunction in the absence of left ventricular assist device (LVAD) malfunction, and 
both of the following: 

1. Has been treated with at least one of the following therapies for at least 14 
consecutive days, and requires ongoing treatment with at least one of the 
following therapies:  
• 
Dobutamine greater than or equal to 5 mcg/kg/min  
• 
Dopamine greater than or equal to 4 mcg/kg/min  
• 
Epinephrine greater than or equal to 0.05 mcg/kg/min 

• 
Inhaled nitric oxide  
• 
Intravenous prostacyclin  
• 
Milrinone greater than or equal to 0.35 mcg/kg/min  
2. Has, within 7 days prior to initiation of any of the therapies above, pulmonary 
capillary wedge pressure less than 20 mmHg and central venous pressure 
greater than 18 mmHg within one 24 hour period. 

This status is valid for up to 14 days from submission of the Heart Status 3 
Justification Form.  
After the initial 14 days, a candidate’s transplant program may extend the 
candidate’s status every 90 days if the candidate continues to meet the above 
criteria and the transplant program submits another Heart Status 3 Justification 
Form. 

6.1.C.vi 
Mechanical Circulatory Support Device (MCSD) with Device 
Infection 
A candidate’s transplant program may assign a candidate to adult status 3 if the 
candidate is supported by an MCSD and is experiencing a pump-related local or 
systemic infection, with at least one of the symptoms according to Table 6-1: 
Evidence of Device Infection below.

---

## 6.1.C — Adult Heart Status 3 Requirements (Part 3)

<!-- Policy: 6 | Section: 6.1.C | Category: Heart Allocation -->

Table 6-1: Evidence of Device Infection 
If the candidate has evidence of: 
Then this status is valid for up to: 
Erythema and pain along the driveline, 
requiring IV antibiotics and either:  
• 
Positive bacterial or fungal cultures 
from the driveline exit site within 
the last 14 days  
• 
A culture-positive fluid collection 
between the driveline exit site and 
the device 
14 days from submission of the Heart 
Status 3 Justification Form. 
Debridement of the driveline with 
positive cultures from sites between 
the driveline exit site and the device 
requiring IV antibiotics 
14 days from submission of the Heart 
Status 3 Justification Form. 
Recurrent debridement 
90 days from submission of the Heart 
Status 3 Justification Form. 
Positive culture of material from the 
pump pocket of an implanted device 
90 days from submission of the Heart 
Status 3 Justification Form. 
Bacteremia treated with antibiotics 
42 days from submission of the Heart 
Status 3 Justification Form. 
Recurrent bacteremia that recurs from 
the same organism within four weeks 
 90 days from submission of the Heart 
Status 3 Justification Form. 

If the candidate has evidence of: 
Then this status is valid for up to: 
of completing antibiotic treatment to 
which the bacteria is susceptible 

After the initial qualifying time period, a candidate’s transplant program may extend 
the candidate’s stay according to the time periods established in Table 6-1: Evidence 
of Device Infection if the candidate continues to meet the above criteria or the 
candidate continues to require intravenous (IV) antibiotics, and the transplant 
program submits another Heart Status 3 Justification Form. 

6.1.C.vii 
Mechanical Circulatory Support Device (MCSD) with Mucosal 
Bleeding 
A candidate’s transplant program may assign a candidate to adult status 3 if the 
candidate is admitted to the transplant hospital that registered the candidate on the 
waiting list, is supported by an MCSD, has been hospitalized for mucosal bleeding at 
least two times within the past six months, excluding the candidate’s hospitalization 
for implantation of the MCSD, and meets the requirements according to Table 6-2: 
Evidence of Mucosal Bleeding below:  

Table 6-2: Evidence of Mucosal Bleeding 

If all of the following occurred: 
Then this status is valid for either 
1. The candidate received blood 
transfusions of at least two units 
of packed red blood cells per 
hospitalization during at least two 
hospitalizations for mucosal 
bleeding 
2. The candidate’s international 
normalized ratio (INR) was less 
than 3.0 at the time of at least one 
of the bleeds 
3. The candidate’s hematocrit upon 
admission is less than or equal to 
0.20 or decreased by 20 percent or 
more relative to the last measured 
value at any time during the 
bleeding episode 
• Up to 14 days from submission of the Heart 
Status 3 Justification Form, if the candidate 
has been hospitalized for mucosal bleeding 
at least two times within the past six 
months 
• Up to 90 days from submission of the Heart 
Status 3 Justification Form, if the candidate 
has been hospitalized for mucosal bleeding 
at least three times within the past six 
months 

After the initial qualifying time period, this status can be extended by the transplant 
program by submission of another Heart Status 3 Justification Form. 

6.1.C.viii Mechanical Circulatory Support Device (MCSD) with Aortic 
Insufficiency (AI) 
A candidate’s transplant program may assign a candidate to adult status 3 if the 
candidate is supported by an MCSD and is not exhibiting evidence of device 
malfunction, but is experiencing AI, with all of the following: 

1. At least moderate AI by any imaging modality in the setting of the mean arterial 
pressure (MAP) less than or equal to 80 mmHg  
2. Pulmonary capillary wedge pressure greater than 20 mmHg 
3. New York Heart Association (NYHA) Class III-IV symptoms  

This status is valid for up to 90 days from submission of the Heart Status 3 
Justification Form. After the initial 90 days, this status can be extended by the 
transplant program every 90 days by submission of another Heart Status 3 
Justification Form. 

6.1.C.ix 
VA ECMO after 7 Days 
A candidate’s transplant program may assign a candidate to adult status 3 if the 
candidate is admitted to the transplant hospital that registered the candidate on the 
waiting list, is supported by VA ECMO, and has already been assigned to status 1 
according to OPTN Policy 6.1.A.i: Veno-Arterial Extracorporeal Membrane 
Oxygenation (VA ECMO) for 7 days. 

This status is valid for up to 7 days from submission of the Heart Status 3 
Justification Form. After the initial 7 days, this status can be extended by the 
transplant program every 7 days by submission of another Heart Status 3 
Justification Form. 

6.1.C.x 
Non-Dischargeable, Surgically Implanted, Non-Endovascular Left 
Ventricular Assist Device (LVAD) after 14 Days 
A candidate’s transplant program may assign a candidate to adult status 3 if the 
candidate is admitted to the transplant hospital that registered the candidate on the 
waiting list, is supported by a non-dischargeable, surgically implanted, non-
endovascular left ventricular assist device (LVAD) and has already been assigned to 
status 2 according to OPTN Policy 6.1.B.i: Non-Dischargeable, Surgically Implanted, 
Non-Endovascular Left Ventricular Assist Device (LVAD) for 14 days.  

This status is valid for up to 14 days from submission of the Heart Status 3 
Justification Form. After the initial 14 days, this status can be extended by the 
transplant program every 14 days by submission of another Heart Status 3 
Justification Form.

---

## 6.1.C — Adult Heart Status 3 Requirements (Part 4)

<!-- Policy: 6 | Section: 6.1.C | Category: Heart Allocation -->

6.1.C.xi 
Percutaneous Endovascular Mechanical Circulatory Support 
Device after 14 Days 
A candidate’s transplant program may assign a candidate to adult status 3 if the 
candidate is admitted to the transplant hospital that registered the candidate on the 
waiting list, is supported by a percutaneous endovascular mechanical circulatory 
support device and has already been assigned to status 2 according to OPTN Policy 
6.1.B.iv: Percutaneous Endovascular Mechanical Circulatory Support Device for 14 
days.  

This status is valid for up to 14 days from submission of the Heart Status 3 
Justification Form. After the initial 14 days, this status can be extended by the 
transplant program every 14 days by submission of another Heart Status 3 
Justification Form. 

6.1.C.xii 
Intra-Aortic Balloon Pump (IABP) after 14 Days 
A candidate’s transplant program may assign a candidate to adult status 3 if the 
candidate is admitted to the transplant hospital that registered the candidate on the 
waiting list, is supported by an IABP, and has already been assigned to status 2 
according to OPTN Policy 6.1.B.v: Intra-Aortic Balloon Pump (IABP) for 14 days.  

This status is valid for up to 14 days from submission of the Heart Status 3 
Justification Form. After the initial 14 days, this status can be extended by the 
transplant program every 14 days by submission of another Heart Status 3 
Justification Form. 

6.1.C.xiii Mechanical Circulatory Support Device (MCSD) with Life 
Threatening Ventricular Arrhythmia After 7 Days 
A candidate’s transplant program may assign a candidate to adult status 3 if the 
candidate is admitted to the transplant hospital that registered the candidate on the 
waiting list, is supported by placement of a biventricular mechanical circulatory 
support device for the treatment of sustained ventricular arrhythmias or receiving 
continuous intravenous antiarrhythmic therapy, and has already been assigned to 
status 1 according to OPTN Policy 6.1.A.iii: Mechanical Circulatory Support Device 
(MCSD) with Life Threatening Ventricular Arrhythmia for 7 days. This status is valid 
for up to 7 days from the submission of the Heart Status 3 Justification Form. 

A candidate’s transplant program may extend the candidate’s status every 7 days if 
the candidate continues to meet the above criteria and the transplant program 
submits another Heart Status 3 Justification Form.

---

## 6.1.D — Adult Heart Status 4 Requirements

<!-- Policy: 6 | Section: 6.1.D | Category: Heart Allocation -->

To assign a candidate adult status 4, the candidate’s transplant program must submit a Heart 
Status 4 Justification Form to the OPTN. A candidate is not assigned adult status 4 until this form 
is submitted.  

 
 
 
 
If the candidate is at least 18 years old at the time of registration then the candidate’s transplant 
program may assign the candidate adult status 4 if the candidate has at least one of the 
following conditions: 
 
• 
Is supported by a dischargeable left ventricular assist device (LVAD), according to OPTN 
Policy 6.1.D.i below. 
• 
Is supported by inotropes without continuous hemodynamic monitoring, according to OPTN 
Policy 6.1.D.ii below. 
• 
Is diagnosed with congenital heart disease, according to OPTN Policy 6.1.D.iii below. 
• 
Is diagnosed with ischemic heart disease with intractable angina, according to OPTN Policy 
6.1.D.iv below. 
• 
Is diagnosed with amyloidosis, hypertrophic cardiomyopathy or restrictive cardiomyopathy, 
according to OPTN Policy 6.1.D.v below. 
• 
Is a re-transplant, according to OPTN Policy 6.1.D.vi below. 
 
6.1.D.i  
Dischargeable Left Ventricular Assist Device (LVAD) without 
Discretionary 30 Days 
A candidate’s transplant program may assign a candidate to adult status 4 if the 
candidate is supported by a dischargeable LVAD. The OPTN maintains a list of OPTN-
approved, qualifying devices.  
 
This status is valid for up to 90 days from submission of the Heart Status 4 
Justification Form. After the initial 90 days, this status can be extended by the 
transplant program every 90 days by submission of another Heart Status 4 
Justification Form. 
 
6.1.D.ii 
Inotropes without Hemodynamic Monitoring 
A candidate’s transplant program may assign a candidate to adult status 4 if the 
candidate is supported by a continuous infusion of a positive inotropic agent, and 
meets all of the following:  
 
1. Cardiac index of less than 2.2 L/min/m2 within 7 days prior to inotropic 
administration or while on inotrope infusion as specified below  
2. Pulmonary Capillary Wedge Pressure greater than 15 mmHg 
3. Requires at least one of the following intravenous inotropes:  
o Dobutamine greater than or equal to 3 mcg/kg/min 
o Milrinone greater than or equal to 0.25 mcg/kg/min 
o Epinephrine greater than or equal to 0.01 mcg/kg/min 
o Dopamine greater than or equal to 3 mcg/kg/min 
 
This status is valid for up to 180 days from submission of the Heart Status 4 
Justification Form. After the initial 180 days, this status can be extended by the 
transplant program every 180 days by submission of another Heart Status 4 
Justification Form. 
 

 
 
 
6.1.D.iii 
Congenital Heart Disease 
A candidate’s transplant program may assign a candidate to adult status 4 if the 
candidate is diagnosed with a hemodynamically significant congenital heart disease. 
The OPTN maintains a list of OPTN-approved qualifying congenital heart disease 
diagnoses.  
 
This status is valid for up to 90 days from submission of the Heart Status 4 
Justification Form. After the initial 90 days, this status can be extended by the 
transplant program every 90 days by submission of another Heart Status 4 
Justification Form. 
 
6.1.D.iv 
Ischemic Heart Disease with Intractable Angina 
A candidate’s transplant program may assign a candidate to adult status 4 if the 
candidate is diagnosed with ischemic heart disease and has intractable angina, with 
all of the following: 
 
1. Coronary artery disease 
2. Canadian Cardiovascular Society Grade IV angina pectoris that cannot be 
treated by a combination of medical therapy, and percutaneous or surgical 
revascularization  
3. Myocardial ischemia shown by imaging 
 
This status is valid for up to 90 days from submission of the Heart Status 4 
Justification Form. After the initial 90 days, this status can be extended by the 
transplant program every 90 days by submission of another Heart Status 4 
Justification Form. 
 
6.1.D.v 
Amyloidosis, or Hypertrophic or Restrictive Cardiomyopathy 
A candidate’s transplant program may assign a candidate to adult status 4 if the 
candidate is diagnosed with amyloidosis, hypertrophic cardiomyopathy or restrictive 
cardiomyopathy, with at least one of the following: 
 
• 
Canadian Cardiovascular Society Grade IV angina pectoris that cannot be 
controlled by medical therapy 
• 
New York Heart Association (NYHA) Class III-IV symptoms with either:  
o Cardiac index less than 2.2 L/min/m2 
o Left or right atrial pressure, left or right ventricular end-diastolic pressure, 
or pulmonary capillary wedge pressure greater than 20 mmHg 
• 
Ventricular tachycardia lasting at least 30 seconds 
• 
Ventricular fibrillation 
• 
Ventricular arrhythmia requiring electrical cardioversion 
• 
Sudden cardiac death 
 
This status is valid for up to 90 days from submission of the Heart Status 4 
Justification Form. After the initial 90 days, this status can be extended by the 

 
 
 
transplant program every 90 days by submission of another Heart Status 4 
Justification Form. 
 
6.1.D.vi 
Re-transplant 
A candidate’s transplant program may assign a candidate to adult status 4 if the 
candidate has a previous heart transplant, and there is evidence of International 
Society of Heart and Lung Transplantation (ISHLT) coronary allograft vasculopathy 
(CAV) grade 2-3, or New York Heart Association (NYHA) Class III-IV heart failure 
symptoms.  
 
This status is valid for up to 90 days from submission of the Heart Status 4 
Justification Form. After the initial 90 days, this status can be extended by the 
transplant program every 90 days by submission of another Heart Status 4 
Justification Form.

---

## 6.1.E — Adult Heart Status 5 Requirements

<!-- Policy: 6 | Section: 6.1.E | Category: Heart Allocation -->

If the candidate is at least 18 years old at the time of registration then the candidate’s transplant 
program may assign the candidate to adult status 5 if the candidate is registered on the heart 
waiting list and is also registered on the waiting list for at least one other organ at the same 
hospital.  
 
This status is valid for up to 180 days from submission of the Heart Status 5 Justification Form as 
long as the candidate is registered for another organ at the same hospital. After the initial 180 
days, this status can be extended by the transplant program every 180 days by submission of 
another Heart Status 5 Justification Form as long as the candidate is registered for another 
organ at the same hospital.

---

## 6.1.F — Adult Heart Status 6 Requirements

<!-- Policy: 6 | Section: 6.1.F | Category: Heart Allocation -->

If the candidate is at least 18 years old at the time of registration and is suitable for transplant, 
then the transplant program may assign the candidate to adult status 6. 
 
This status is valid for up to 180 days from submission of the Heart Status 6 Justification Form as 
long as the candidate remains suitable for transplant. After the initial 180 days, this status can 
be extended by the transplant program every 180 days by submission of another Heart Status 6 
Justification Form as long as the candidate remains suitable for transplant.

---

## 6.2 — Pediatric Status Assignments and Update Requirements

<!-- Policy: 6 | Section: 6.2 | Category: Heart Allocation -->

Heart candidates less than 18 years old at the time of registration may be assigned any of the following: 
 
• 
Pediatric status 1A 
• 
Pediatric status 1B 
• 
Pediatric status 2 
• 
Inactive status 
 
 

 
 
 
A candidate registered on the waiting list before turning 18 years old remains eligible for pediatric status 
until the candidate has been removed from the waiting list.

---

## 6.2.A — Pediatric Heart Status 1A Requirements

<!-- Policy: 6 | Section: 6.2.A | Category: Heart Allocation -->

To register a candidate as pediatric status 1A, the candidate’s transplant program must submit a 
Heart Status 1A Justification Form to the OPTN. A candidate is not classified as pediatric status 
1A until this form is submitted. 
 
The candidate’s transplant program may assign the candidate pediatric status 1A if the 
candidate is less than 18 years old at the time of registration and meets at least one of the 
following criteria: 
 
1. Requires continuous mechanical ventilation and is admitted to the hospital that registered 
the candidate. 
2. Requires assistance of an intra-aortic balloon pump and is admitted to the hospital that 
registered the candidate. 
3. Has ductal dependent pulmonary or systemic circulation, with ductal patency maintained by 
stent or prostaglandin infusion, and is admitted to the transplant hospital that registered 
the candidate. 
4. Has a hemodynamically significant congenital heart disease diagnosis, requires infusion of 
multiple intravenous inotropes or a high dose of a single intravenous inotrope, and is 
admitted to the transplant hospital that registered the candidate. The OPTN maintains a list 
of OPTN-approved congenital heart disease diagnoses and qualifying inotropes and doses 
that qualify a candidate for pediatric status 1A.  
5. Requires assistance of a mechanical circulatory support device. 
 
Pediatric status 1A is valid for 14 days from the date of the candidate’s initial registration as 
pediatric status 1A. After the initial 14 days, status 1A must be recertified by the transplant 
program every 14 days to extend the status 1A registration.  
 
When a candidate’s pediatric status 1A expires, the candidate will be assigned pediatric status 
1B. Within 24 hours of the status change, the transplant program must report to the OPTN the 
criterion that qualifies the candidate to be registered as status 1B. The transplant program must 
classify the candidate as pediatric status 2 or inactive status if the candidate's medical condition 
does not qualify for pediatric status 1B.

---

## 6.2.B — Pediatric Heart Status 1B Requirements

<!-- Policy: 6 | Section: 6.2.B | Category: Heart Allocation -->

To assign a candidate pediatric heart status 1B, the candidate’s transplant program must submit 
a Heart Status 1B Justification Form to the OPTN. A candidate is not assigned pediatric status 1B 
until this form is submitted.  
 
The candidate’s transplant program may assign the candidate pediatric status 1B if the 
candidate is less than 18 years old at the time of registration and meets at least one of the 
following criteria: 

 
 
 
 
1. Requires infusion of one or more inotropic agents but does not qualify for pediatric status 
1A. The OPTN maintains a list of the OPTN-approved status 1B inotropic agents and doses. 
2. Is less than one year old at the time of the candidate’s initial registration and has a diagnosis 
of hypertrophic or restrictive cardiomyopathy. 
The candidate may retain pediatric status 1B for an unlimited period and this status does not 
require any recertification, unless the candidate’s medical condition changes and the criteria 
used to justify that candidate’s status are no longer accurate as described in Policy 6.2.

---

## 6.2.C — Pediatric Heart Status 2 Requirements

<!-- Policy: 6 | Section: 6.2.C | Category: Heart Allocation -->

If the candidate is less than 18 years old at the time of registration and does not meet the 
criteria for pediatric status 1A or 1B but is suitable for transplant, then the candidate may be 
assigned pediatric status 2. 
 
A candidate’s pediatric status 2 does not require any recertification.

---

## 6.2.D — Inactive Adult and Pediatric Candidates

<!-- Policy: 6 | Section: 6.2.D | Category: Heart Allocation -->

If an adult or pediatric candidate is temporarily unsuitable for transplant, then the candidate’s 
transplant program may assign the candidate inactive status and the candidate will not receive 
any heart offers.

---

## 6.3 — Status Updates

<!-- Policy: 6 | Section: 6.3 | Category: Heart Allocation -->

If a candidate’s medical condition changes and the criteria used to justify that candidate’s status is no 
longer accurate, then the candidate’s transplant program must update the candidate’s status and report 
the updated information to the OPTN within 24 hours of the change in medical condition.

---

## 6.4 — Adult and Pediatric Status Exceptions

<!-- Policy: 6 | Section: 6.4 | Category: Heart Allocation -->

A heart candidate can receive a status by qualifying for an exception according to Table 6-3 below. 
 
Table 6-3: Exception Qualification and Periods 
Requested Status: 
Qualification: 
Initial Review 
Duration: 
Extensions: 
Adult status 1 
1. Candidate is admitted to 
the transplant hospital that 
registered the candidate on 
the waiting list 
2. Transplant physician 
believes, using acceptable 
medical criteria, that a 
heart candidate has an 
urgency and potential for 
benefit comparable to that 
of other candidates at the 
requested status 
RRBs 
retrospectively 
review requests 
for status 1 
exceptions 
14 days 
• Require RRB 
approval for each 
successive 14 day 
period 
• RRB will review 
and decide 
extension 
requests 
retrospectively 

 
 
 
Requested Status: 
Qualification: 
Initial Review 
Duration: 
Extensions: 
Adult status 2 
1. Candidate is admitted to 
the transplant hospital that 
registered the candidate on 
the waiting list 
2. Transplant physician 
believes, using acceptable 
medical criteria, that a 
heart candidate has an 
urgency and potential for 
benefit comparable to that 
of other candidates at the 
requested status 
RRBs 
retrospectively 
review requests 
for status 2 
exceptions 
14 days 
• Require RRB 
approval for each 
successive 14 day 
period 
• RRB will review 
and decide 
extension 
requests 
retrospectively 
Adult status 3 
1. Candidate is admitted to 
the transplant hospital that 
registered the candidate on 
the waiting list 
2. Transplant physician 
believes, using acceptable 
medical criteria, that a 
heart candidate has an 
urgency and potential for 
benefit comparable to that 
of other candidates at the 
requested status 
RRBs 
retrospectively 
review requests 
for status 3 
exceptions 
14 days 
• Require RRB 
approval for each 
successive 14 day 
period 
• RRB will review 
and decide 
extension 
requests 
retrospectively 

 
 
 
Requested Status: 
Qualification: 
Initial Review 
Duration: 
Extensions: 
Adult status 1, 2, or 
3 
1. Candidate’s implanted 
mechanical circulatory 
support device, or an 
implanted component 
within, has a U.S. Food and 
Drug Administration recall 
that the transplant 
physician determines is a 
risk to patient safety that 
cannot be sufficiently 
mitigated without 
replacement of the device 
or the component, and 
2. Transplant physician 
believes, using acceptable 
medical criteria, that the 
heart candidate has an 
urgency and potential for 
benefit comparable to that 
of other candidates at the 
requested status 
RRBs 
retrospectively 
review requests 
for exceptions 
associated with 
a heart device 
recall 
14 days 
• Require RRB 
approval for each 
successive 14 day 
period 
• RRB will review 
and decide 
extension 
requests 
retrospectively 
Adult status 4 
Transplant physician believes, 
using acceptable medical 
criteria, that a heart 
candidate has an urgency and 
potential for benefit 
comparable to that of other 
candidates at the requested 
status 
RRBs 
retrospectively 
review requests 
for status 4 
exceptions 
90 days 
• Require RRB 
approval for each 
successive 90 day 
period 
• RRB will review 
and decide 
extension 
requests 
retrospectively 

 
 
 
Requested Status: 
Qualification: 
Initial Review 
Duration: 
Extensions: 
Pediatric status 1A 
a. Candidate is admitted to 
the transplant hospital that 
registered the candidate on 
the waiting list 
b. Transplant physician 
believes, using acceptable 
medical criteria, that a heart 
candidate has an urgency 
and potential for benefit 
comparable to that of other 
candidates at the requested 
status 
The National 
Heart Review 
Board (NHRB) 
retrospectively 
reviews 
requests for 
Status 1A-
exceptions 
14 days 
• Require the NHRB 
approval for each 
successive 14 day 
period 
• The NHRB will 
review and decide 
extension 
requests 
retrospectively  
• If no extension 
request is 
submitted, the 
candidate will be 
assigned pediatric 
status 1B 
Pediatric status 1B 
Transplant physician believes, 
using acceptable medical 
criteria, that a heart 
candidate has an urgency and 
potential for benefit 
comparable to that of other 
candidates at the requested 
status 
The NHRB 
retrospectively 
review requests 
for Status 1B 
exceptions 
Indefinite 
• Not required as 
long as 
candidate’s 
medical condition 
remains the same 
 
The candidate’s transplant physician must submit a justification form with the requested status and the 
rationale for granting the status exception.

---

## 6.4.A — Review Board and Committee Review of Status Exceptions

<!-- Policy: 6 | Section: 6.4.A | Category: Heart Allocation -->

The heart RRB reviews applications for adult status exceptions and extensions retrospectively. 
The national heart review board (NHRB) reviews applications for pediatric status exceptions and 
extensions retrospectively. 
 
If the candidate is transplanted and the relevant review board does not approve the initial 
exception or extension request or any appeal, then the case will be referred to the Heart 
Transplantation Committee. If the Heart Transplantation Committee agrees with the review 
board’s decision, then the Heart Transplantation Committee may refer the case to Membership 
& Professional Standards Committee (MPSC) for review according to Appendix L of the OPTN 
Management and Membership Policies. 
 
6.4.A.i. Review Board Appeals 
If the review board denies an exception or extension request, the candidate’s 
transplant program must either appeal to the relevant review board within 1 day of 
receiving notification of the review board denial or assign the candidate to the 

 
 
 
status for which the candidate qualifies within 1 day of receiving notification of the 
review board denial.  
 
6.4.A.ii Committee Appeals 
If the review board denies the appeal, the candidate’s transplant program must 
within 1 day of receiving notification of the denied appeal either appeal to the Heart 
Transplantation Committee or assign the candidate to the status for which the 
candidate qualifies. If the Heart Transplantation Committee agrees with the review 
board’s decision, the candidate’s transplant program must assign the candidate to 
the status for which the candidate qualifies within 1 day of receiving notification of 
the denied Committee appeal. If the transplant program does not assign the 
candidate to the status for which the candidate qualifies within 1 day of receiving 
notification of the denied Committee appeal, then the Committee will refer the case 
to the MPSC.

---

## 6.5 — Waiting Time

<!-- Policy: 6 | Section: 6.5 | Category: Heart Allocation -->

Waiting time for heart candidates begins when the candidate is first registered as an active heart 
candidate on the waiting list and is calculated within each heart status. 
 
If a candidate’s status is upgraded, waiting time accrued while assigned to a lower status is not 
transferred to the higher status. Conversely, waiting time accrued while assigned at a higher status is 
transferred to a lower status if the candidate is assigned to a lower status. 
 
Waiting time does not accrue while the candidate is inactive.

---

## 6.6.A — Blood Type Matching Priority for Heart Offers

<!-- Policy: 6 | Section: 6.6.A | Category: Heart Allocation -->

Hearts are prioritized according to the blood type matching requirements in Table 6-4: Blood 
Type Matching Prioritization for Heart Allocation. Pediatric candidates who are eligible for 
intended incompatible blood type offers are prioritized according to OPTN Policy 6.6.B.ii: Blood 
Type Prioritization for Intended Incompatible Offers. 
Table 6-4: Blood Type Matching Prioritization for Heart Allocation 
Hearts from Deceased 
Donors with: 
Are Allocated to Primary 
Candidates defined as: 
Then to Secondary 
Candidates, defined as: 
Blood Type O 
Blood type O or blood type 
B 
Blood type A or blood type 
AB 
Blood Type A 
Blood type A or blood type 
AB 
Not applicable 
Blood Type B 
Blood type B or blood type 
AB 
Not applicable 
Blood Type AB 
Blood type AB 
Not applicable

---

## 6.6.B — Intended Incompatible Blood Type Heart Offers Eligibility and Prioritization

<!-- Policy: 6 | Section: 6.6.B | Category: Heart Allocation | Cross-ref: Policy 5 -->

6.6.B.i 
Eligibility for Intended Incompatible Blood Type Heart Offers 
Pediatric heart and pediatric heart-lung candidates are eligible for an intended 
incompatible blood type heart offer if all of the following conditions are met: 
• 
The transplant program specifies the candidate is willing to accept an intended 
incompatible blood type heart according to OPTN Policy 5.3.E: Pediatric Heart 
Acceptance Criteria to Receive Intended Incompatible Blood Type Heart, and 
reports isohemagglutinin titer(s) information according to Table 6-5: 
Isohemagglutinin Titer(s) Reporting Requirements for Pediatric Candidates 
Willing to Receive an Intended Incompatible Blood Type Heart 
• 
The transplant program reports updated isohemagglutinin titer information 
every 30 days 
• 
And the candidate meets one of the following conditions: 
o Is less than one year old at the time of the match run 
o Is at least one year old at the time of the match run, and has titers less 
than or equal to 1:16, and has not received treatments that may have 
reduced isohemagglutinin titers to 1:16 or less within 30 days of when 
this blood sample was collected. 
 
Table 6-5: Isohemagglutinin Titer Reporting Requirements for a Candidate Who is Willing to Receive 
an Intended Incompatible Blood Type Heart 
If the candidate’s blood 
type is: 
Then the transplant program must report the following 
isohemagglutinin titers to the OPTN: 
A 
Anti-B 
B 
Anti-A 
O 
Anti-A and Anti-B 
 
6.6.B.ii 
Blood Type Matching Priority for Intended Incompatible Blood 
Type Heart Offers 
An eligible pediatric candidate who is less than one year old at the time of the 
match run is classified as a primary blood type match candidate. 
 
An eligible pediatric candidate who is at least one year old at the time of the match 
run is classified as a secondary blood type match candidate, unless they are a 
primary blood type match candidate according to Table 6-4. 
 
6.6.B.iii 
Reporting Requirements for Recipients of Intended Incompatible 
Blood Type Hearts 
Isohemagglutinin titers must be reported for recipients of an intended incompatible 
blood type heart, according to Table 6-6, as follows: 
 
1. At transplant from a blood sample taken within 24 hours prior to transplant.  

 
 
 
2. If graft loss occurs within one year after transplant from the most recent blood 
sample, if available. 
3. If recipient death occurs within one year after transplant from the most recent 
blood sample, if available. 
Table 6-6: Isohemagglutinin Titer Reporting Requirements for a Recipient of an Intended 
Incompatible Blood Type Heart 
Deceased donor’s blood 
type: 
Recipient’s blood type: 
Isohemagglutinin titer 
reporting requirement: 
A 
B or O 
Anti-A  
B 
A or O 
Anti-B  
AB 
A 
Anti-B  
AB 
B 
Anti-A  
AB 
O 
Anti-A and Anti-B  
 
If a laboratory provides more than one isohemagglutinin titer value for a tested 
blood sample, the transplant program must report to the OPTN the highest titer 
value.

---

## 6.6.C — Sorting Within Each Classification

<!-- Policy: 6 | Section: 6.6.C | Category: Heart Allocation -->

Candidates are sorted within each classification by the total amount of waiting time that the 
candidate has accumulated at that status, according to OPTN Policy 6.5: Waiting Time.

---

## 6.6.D — Allocation of Hearts from Donors at Least 18 years Old (Part 1)

<!-- Policy: 6 | Section: 6.6.D | Category: Heart Allocation -->

Hearts from deceased donors at least 18 years old are allocated to candidates according to 
Table 6-7 below. 

Table 6-7: Allocation of Hearts from Deceased Donors At Least 18 Years Old 
Classification 
Candidates that are within the  
And registered at a transplant 
hospital that is at or within this 
distance from the donor hospital 
1 
Adult status 1 or pediatric status 
1A and primary blood type match 
with the donor 
500NM  
2 
Adult status 1 or pediatric status 
1A and secondary blood type 
match with the donor 
500NM  
3 
Adult status 2 and primary blood 
type match with the donor 
500NM  
4 
Adult status 2 and secondary 
blood type match with the donor 
500NM  

Classification 
Candidates that are within the  
And registered at a transplant 
hospital that is at or within this 
distance from the donor hospital 
5 
Adult status 3 or pediatric status 
1B and primary blood type match 
with the donor 
250NM 
6 
Adult status 3 or pediatric status 
1B and secondary blood type 
match with the donor 
250NM 
7 
Adult status 1 or pediatric status 
1A and primary blood type match 
with the donor 
1000NM 
8 
Adult status 1 or pediatric status 
1A and secondary blood type 
match with the donor 
1000NM 
9 
Adult status 2 and primary blood 
type match with the donor 
1000NM 
10 
Adult status 2 and secondary 
blood type match with the donor 
1000NM 
11 
Adult status 4 and primary blood 
type match with the donor 
250NM 
12 
Adult status 4 and secondary 
blood type match with the donor 
250NM 
13 
Adult status 3 or pediatric status 
1B and primary blood type match 
with the donor 
500NM 
14 
Adult status 3 or pediatric status 
1B and secondary blood type 
match with the donor 
500NM 
15 
Adult status 5 and primary blood 
type match with the donor 
250NM 
16 
Adult status 5 and secondary 
blood type match with the donor 
250NM 
17 
Adult status 3 or pediatric status 
1B and primary blood type match 
with the donor 
1000NM 
18 
Adult status 3 or pediatric status 
1B and secondary blood type 
match with the donor 
1000NM 
19 
Adult status 6 or pediatric status 
2 and primary blood type match 
with the donor 
250NM 
20 
Adult status 6 or pediatric status 
2 and secondary blood type 
match with the donor 
250NM 

Classification 
Candidates that are within the  
And registered at a transplant 
hospital that is at or within this 
distance from the donor hospital 
21 
Adult status 1 or pediatric status 
1A and primary blood type match 
with the donor 
1500NM 
22 
Adult status 1 or pediatric status 
1A and secondary blood type 
match with the donor 
1500NM 
23 
Adult status 2 and primary blood 
type match with the donor 
1500NM 
24 
Adult status 2 and secondary 
blood type match with the donor 
1500NM 
25 
Adult status 3 or pediatric status 
1B and primary blood type match 
with the donor 
1500NM 
26 
Adult status 3 or pediatric status 
1B and secondary blood type 
match with the donor 
1500NM 
27 
Adult status 4 and primary blood 
type match with the donor 
500NM 
28 
Adult status 4 and secondary 
blood type match with the donor 
500NM 
29 
Adult status 5 and primary blood 
type match with the donor 
500NM 
30 
Adult status 5 and secondary 
blood type match with the donor 
500NM 
31 
Adult status 6 or pediatric status 
2 and primary blood type match 
with the donor 
500NM 
32 
Adult status 6 or pediatric status 
2 and secondary blood type 
match with the donor 
500NM 
33 
Adult status 1 or pediatric status 
1A and primary blood type match 
with the donor 
2500NM 
34 
Adult status 1 or pediatric status 
1A and secondary blood type 
match with the donor 
2500NM 
35 
Adult status 2 and primary blood 
type match with the donor 
2500NM 
36 
Adult status 2 and secondary 
blood type match with the donor 
2500NM 
37 
Adult status 3 or pediatric status 
1B and primary blood type match 
with the donor 
2500NM 

Classification 
Candidates that are within the  
And registered at a transplant 
hospital that is at or within this 
distance from the donor hospital 
38 
Adult status 3 or pediatric status 
1B and secondary blood type 
match with the donor 
2500NM 
39 
Adult status 4 and primary blood 
type match with the donor 
1000NM 
40 
Adult status 4 and secondary 
blood type match with the donor 
1000NM 
41 
Adult status 5 and primary blood 
type match with the donor 
1000NM 
42 
Adult status 5 and secondary 
blood type match with the donor 
1000NM 
43 
Adult status 6 or pediatric status 
2 and primary blood type match 
with the donor 
1000NM 
44 
Adult status 6 or pediatric status 
2 and secondary blood type 
match with the donor 
1000NM 
45 
Adult status 1 or pediatric status 
1A and primary blood type match 
with the donor 
Nation 
46 
Adult status 1 or pediatric status 
1A and secondary blood type 
match with the donor 
Nation 
47 
Adult status 2 and primary blood 
type match with the donor 
Nation 
48 
Adult status 2 and secondary 
blood type match with the donor 
Nation 
49 
Adult status 3 or pediatric status 
1B and primary blood type match 
with the donor 
Nation 
50 
Adult status 3 or pediatric status 
1B and secondary blood type 
match with the donor 
Nation 
51 
Adult status 4 and primary blood 
type match with the donor 
1500NM 
52 
Adult status 4 and secondary 
blood type match with the donor 
1500NM 
53 
Adult status 5 and primary blood 
type match with the donor 
1500NM 
54 
Adult status 5 and secondary 
blood type match with the donor 
1500NM 
55 
Adult status 6 or pediatric status 
2 and primary blood type match 
with the donor 
1500NM

---

## 6.6.D — Allocation of Hearts from Donors at Least 18 years Old (Part 2)

<!-- Policy: 6 | Section: 6.6.D | Category: Heart Allocation -->

Classification 
Candidates that are within the  
And registered at a transplant 
hospital that is at or within this 
distance from the donor hospital 
56 
Adult status 6 or pediatric status 
2 and secondary blood type 
match with the donor 
1500NM 
57 
Adult status 4 and primary blood 
type match with the donor 
2500NM 
58 
Adult status 4 and secondary 
blood type match with the donor 
2500NM 
59 
Adult status 5 and primary blood 
type match with the donor 
2500NM 
60 
Adult status 5 and secondary 
blood type match with the donor 
2500NM 
61 
Adult status 6 or pediatric status 
2 and primary blood type match 
with the donor 
2500NM 
62 
Adult status 6 or pediatric status 
2 and secondary blood type 
match with the donor 
2500NM 
63 
Adult status 4 and primary blood 
type match with the donor 
Nation 
64 
Adult status 4 and secondary 
blood type match with the donor 
Nation 
65 
Adult status 5 and primary blood 
type match with the donor 
Nation 
66 
Adult status 5 and secondary 
blood type match with the donor 
Nation 
67 
Adult status 6 or pediatric status 
2 and primary blood type match 
with the donor 
Nation 
68 
Adult status 6 or pediatric status 
2 and secondary blood type 
match with the donor 
Nation

---

## 6.6.E — Allocation of Hearts from Donors Less Than 18 Years Old (Part 1)

<!-- Policy: 6 | Section: 6.6.E | Category: Heart Allocation -->

A heart from a pediatric donor will be allocated to a pediatric heart candidate by status and 
geographical location before being allocated to a candidate at least 18 years old according to 
Table 6-8 below. 

Table 6-8: Allocation of Hearts from Donors Less Than 18 Years Old 
Classification 
Candidates that are  
And registered at a transplant 
hospital that is at or within this 
distance from the donor 
hospital 
1 
Pediatric status 1A and primary 
blood type match with the donor 
500NM 
2 
Pediatric status 1A and 
secondary blood type match with 
the donor 
500NM 
3 
Adult status 1 and primary blood 
type match with the donor 
 250NM 
4 
Adult status 1 and secondary 
blood type match with the donor 
 250NM 
5 
Adult status 2 and primary blood 
type match with the donor 
 250NM 
6 
Adult status 2 and secondary 
blood type match with the donor 
 250NM 
7 
Pediatric status 1B and primary 
blood type match with the donor 
 500NM 
8 
Pediatric status 1B and 
secondary blood type match with 
the donor 
 500NM 
9 
Adult status 1 and primary blood 
type match with the donor 
 500NM 
10 
Adult status 1 and secondary 
blood type match with the donor 
 500NM 
11 
Adult status 2 and primary blood 
type match with the donor 
 500NM 
12 
Adult status 2 and secondary 
blood type match with the donor 
 500NM 
13 
Adult status 3 and primary blood 
type match with the donor 
 250NM 
14 
Adult status 3 and secondary 
blood type match with the donor 
 250NM 
15 
Adult status 4 and primary blood 
type match with the donor 
 250NM 

Classification 
Candidates that are  
And registered at a transplant 
hospital that is at or within this 
distance from the donor 
hospital 
16 
Adult status 4 and secondary 
blood type match with the donor 
 250NM 
17 
Adult status 5 and primary blood 
type match with the donor 
 250NM 
18 
Adult status 5 and secondary 
blood type match with the donor 
 250NM 
19 
Adult status 3 and primary blood 
type match with the donor 
 500NM 
20 
Adult status 3 and secondary 
blood type match with the donor 
 500NM 
21 
Adult status 4 and primary blood 
type match with the donor 
 500NM 
22 
Adult status 4 and secondary 
blood type match with the donor 
 500NM 
23 
Adult status 5 and primary blood 
type match with the donor 
 500NM 
24 
Adult Status 5 and secondary 
blood type match with the donor 
 500NM 
25 
Pediatric status 2 and primary 
blood type match with the donor 
 250NM 
26 
Pediatric status 2 and secondary 
blood type match with the donor 
 250NM 
27 
Adult status 6 and primary blood 
type match with the donor 
 250NM 
28 
Adult status 6 and secondary 
blood type match with the donor 
 250NM 
29 
Pediatric status 1A and primary 
blood type match with the donor 
 1000NM 
30 
Pediatric status 1A and 
secondary blood type match with 
the donor 
 1000NM 
31 
Adult status 1 and primary blood 
type match with the donor 
 1000NM 

Classification 
Candidates that are  
And registered at a transplant 
hospital that is at or within this 
distance from the donor 
hospital 
32 
Adult status 1 and secondary 
blood type match with the donor 
 1000NM 
33 
Adult status 2 and primary blood 
type match with the donor 
 1000NM 
34 
Adult status 2 and secondary 
blood type match with the donor 
 1000NM 
35 
Pediatric status 1B and primary 
blood type match with the donor 
 1000NM 
36 
Pediatric status 1B and 
secondary blood type match with 
the donor 
 1000NM 
37 
Adult status 3 and primary blood 
type match with the donor 
 1000NM 
38 
Adult status 3 and secondary 
blood type match with the donor 
 1000NM 
39 
Adult status 4 and primary blood 
type match with the donor 
 1000NM 
40 
Adult status 4 and secondary 
blood type match with the donor 
 1000NM 
41 
Adult status 5 and primary blood 
type match with the donor 
 1000NM 
42 
Adult status 5 and secondary 
blood type match with the donor 
 1000NM 
43 
Pediatric status 2 and primary 
blood type match with the donor 
 500NM 
44 
Pediatric status 2 and secondary 
blood type match with the donor 
 500NM 
45 
Adult status 6 and primary blood 
type match with the donor 
 500NM 
46 
Adult status 6 and secondary 
blood type match with the donor 
 500NM 
47 
Pediatric status 2 and primary 
blood type match with the donor 
 1000NM 

Classification 
Candidates that are  
And registered at a transplant 
hospital that is at or within this 
distance from the donor 
hospital 
48 
Pediatric status 2 and secondary 
blood type match with the donor 
 1000NM 
49 
Adult status 6 and primary blood 
type match with the donor 
 1000NM 
50 
Adult status 6 and secondary 
blood type match with the donor 
 1000NM 
51 
Pediatric status 1A and primary 
blood type match with the donor 
 1500NM 
52 
Pediatric status 1A and 
secondary blood type match with 
the donor 
 1500NM 
53 
Adult status 1 and primary blood 
type match with the donor 
 1500NM 
54 
Adult status 1 and secondary 
blood type match with the donor 
 1500NM 
55 
Adult status 2 and primary blood 
type match with the donor 
 1500NM 
56 
Adult status 2 and secondary 
blood type match with the donor 
 1500NM 
57 
Pediatric status 1B and primary 
blood type match with the donor 
 1500NM 
58 
Pediatric status 1B and 
secondary blood type match with 
the donor 
 1500NM 
59 
Adult status 3 and primary blood 
type match with the donor 
 1500NM 
60 
Adult status 3 and secondary 
blood type match with the donor 
 1500NM 
61 
Adult status 4 and primary blood 
type match with the donor 
 1500NM 
62 
Adult status 4 and secondary 
blood type match with the donor 
 1500NM

---

## 6.6.E — Allocation of Hearts from Donors Less Than 18 Years Old (Part 2)

<!-- Policy: 6 | Section: 6.6.E | Category: Heart Allocation -->

Classification 
Candidates that are  
And registered at a transplant 
hospital that is at or within this 
distance from the donor 
hospital 
63 
Adult status 5 and primary blood 
type match with the donor 
 1500NM 
64 
Adult status 5 and secondary 
blood type match with the donor 
 1500NM 
65 
Pediatric status 2 and primary 
blood type match with the donor 
 1500NM 
66 
Pediatric status 2 and secondary 
blood type match with the donor 
 1500NM 
67 
Adult status 6 and primary blood 
type match with the donor 
 1500NM 
68 
Adult status 6 and secondary 
blood type match with the donor 
 1500NM 
69 
Pediatric status 1A and primary 
blood type match with the donor 
 2500NM 
70 
Pediatric status 1A and 
secondary blood type match with 
the donor 
 2500NM 
71 
Adult status 1 and primary blood 
type match with the donor 
 2500NM 
72 
Adult status 1 and secondary 
blood type match with the donor 
 2500NM 
73 
Adult status 2 and primary blood 
type match with the donor 
 2500NM 
74 
Adult status 2 and secondary 
blood type match with the donor 
 2500NM 
75 
Pediatric status 1B and primary 
blood type match with the donor 
 2500NM 
76 
Pediatric status 1B and 
secondary blood type match with 
the donor 
 2500NM 
77 
Adult status 3 and primary blood 
type match with the donor 
 2500NM 

Classification 
Candidates that are  
And registered at a transplant 
hospital that is at or within this 
distance from the donor 
hospital 
78 
Adult status 3 and secondary 
blood type match with the donor 
 2500NM 
79 
Adult status 4 and primary blood 
type match with the donor 
 2500NM 
80 
Adult status 4 and secondary 
blood type match with the donor 
 2500NM 
81 
Adult status 5 and primary blood 
type match with the donor 
 2500NM 
82 
Adult status 5 and secondary 
blood type match with the donor 
 2500NM 
83 
Pediatric status 2 and primary 
blood type match with the donor 
 2500NM 
84 
Pediatric status 2 and secondary 
blood type match with the donor 
 2500NM 
85 
Adult status 6 and primary blood 
type match with the donor 
 2500NM 
86 
Adult status 6 and secondary 
blood type match with the donor 
 2500NM 
87 
Pediatric status 1A and primary 
blood type match with the donor 
 Nation 
88 
Pediatric status 1A and 
secondary blood type match with 
the donor 
 Nation 
89 
Adult status 1 and primary blood 
type match with the donor 
 Nation 
90 
Adult status 1 and secondary 
blood type match with the donor 
 Nation 
91 
Adult status 2 and primary blood 
type match with the donor 
 Nation 
92 
Adult status 2 and secondary 
blood type match with the donor 
 Nation 
93 
Pediatric status 1B and primary 
blood type match with the donor 
 Nation 

Classification 
Candidates that are  
And registered at a transplant 
hospital that is at or within this 
distance from the donor 
hospital 
94 
Pediatric status 1B and 
secondary blood type match with 
the donor 
 Nation 
95 
Adult status 3 and primary blood 
type match with the donor 
 Nation 
96 
Adult status 3 and secondary 
blood type match with the donor 
 Nation 
97 
Adult status 4 and primary blood 
type match with the donor 
 Nation 
98 
Adult status 4 and secondary 
blood type match with the donor 
 Nation 
99 
Adult status 5 and primary blood 
type match with the donor 
 Nation 
100 
Adult status 5 and secondary 
blood type match with the donor 
 Nation 
101 
Pediatric status 2 and primary 
blood type match with the donor 
 Nation 
102 
Pediatric status 2 and secondary 
blood type match with the donor 
 Nation 
103 
Adult status 6 and primary blood 
type match with the donor 
 Nation 
104 
Adult status 6 and secondary 
blood type match with the donor 
 Nation

---

## 6.6.F — Allocation of Heart-Lungs

<!-- Policy: 6 | Section: 6.6.F | Category: Heart Allocation | Cross-ref: Policy 10, Policy 7 -->

6.6.F.i  
Allocation of Heart-Lungs from Deceased Donors at Least 18 
Years Old 
If a host OPO is offering a heart and lung from the same deceased donor, then the 
host OPO must offer the heart and lung in the following order: 
1. To all heart and heart-lung PTRs in allocation classifications 1 through 4 
according to OPTN Policy 6.6.D: Allocation of Hearts from Donors at Least 18 
Years Old 
2. To all lung and heart-lung PTRs according to OPTN Policy 10.1 Lung Composite 
Allocation Score until offers have been made to all heart-lung PTRs with a lung 
composite allocation score of 25 or higher 
3. To heart and heart-lung PTRs in classifications 5 or later according to OPTN 
Policy 6.6.D: Allocation of Hearts from Donors at Least 18 Years Old. 
 
The host OPO must follow the order on each match run, including heart-lung, heart, 
and lung candidates. 
 
6.6.F.ii 
Allocation of Heart-Lungs from Deceased Donors Less Than 18 
Years Old 
If a host OPO is offering a heart and lung from the same deceased donor, then the 
host OPO must offer: 
1. To all heart and heart-lung PTRs in allocation classifications 1 through 12 
according to OPTN Policy 6.6.E: Allocation of Hearts from Donors Less Than 18 
Years Old 
2. To all lung and heart-lung PTRs according to OPTN Policy 10.1 Lung Composite 
Allocation Score until offers have been made to all heart-lung PTRs with a lung 
composite allocation score of 25 or higher 
3. To heart and heart-lung PTRs in classifications 13 or later according to OPTN 
Policy 6.6.E: Allocation of Hearts from Donors Less Than 18 Years Old 
 
The host OPO must follow the order on each match run, including heart-lung, heart, 
and lung candidates. 
 

 
 
 
 
 
Policy 7: Allocation of Intestines 
7.1 
Status Assignments 
145 
7.2 
Waiting Time 
145 
7.3 
Intestine Allocation Classifications and Rankings 
145

---
