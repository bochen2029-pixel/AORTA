# OPTN Policy 9: Allocation of Livers and Liver-Intestines

**Source:** OPTN Policies | **Effective:** 12/10/2025 | **Category:** Liver Allocation
**Confidence:** HIGH — Official OPTN policy language

---

## 9.1 — Status and Score Assignments

<!-- Policy: 9 | Section: 9.1 | Category: Liver Allocation -->

Each liver transplant candidate is assigned a score that reflects the probability of death within a 3-month 
period as determined by the Model for End-Stage Liver Disease (MELD) scoring system or the Pediatric 
End Stage Liver Disease (PELD) scoring system. Liver candidates can also be assigned a priority status if 
the candidate meets the requirements for that status. 
 
Liver candidates at least 18 years old at the time of registration may be assigned any of the following: 
 
• 
Adult status 1A 
• 
Calculated MELD score 
• 
Exception MELD score 
• 
Inactive status 
 
Liver candidates less than 18 years old at the time of registration may be assigned any of the following: 
 
• 
Pediatric status 1A 
• 
Pediatric status 1B 
• 
Calculated MELD or PELD score 
• 
Exception MELD or PELD score 
• 
Inactive status 
 
Liver candidates less than 18 years old at the time of registration, who remain on the waiting list after 
turning 18 years old, will be classified as a 12 to 17 year old for the purposes of allocation in:  
 
 

 
 
 
• 
OPTN Policy 9.8.F: Allocation of Livers from Non- DCD Deceased Donors 11 to 17 Years Old 
• 
OPTN Policy 9.8.G: Allocation of Livers from Non-DCD Deceased Donors Less than 11 Years Old 
• 
OPTN Policy 9.8.J: Allocation of Liver-Intestines from Non-DCD Donors Less than 11 Years Old 
 
If the candidate is removed from the waiting list at any time and returns to the waiting list after turning 
18 years old, the candidate must then be registered as an adult.

---

## 9.1.A — Adult Status 1A Requirements

<!-- Policy: 9 | Section: 9.1.A | Category: Liver Allocation -->

To assign a candidate adult status 1A, the candidate’s transplant hospital must submit a Liver 
Status 1A Justification Form to the OPTN. A candidate is not registered as status 1A until this 
form is submitted. When reporting laboratory values to the OPTN, transplant hospitals must 
submit the most recent results including the dates of the laboratory tests. 
 
The candidate’s transplant program may assign the candidate adult status 1A if all the following 
conditions are met: 
 
1. The candidate is at least 18 years old at the time of registration 
2. The candidate has a life expectancy without a liver transplant of less than 7 days and has at 
least one of the following conditions: 
 
a. Fulminant liver failure, defined as the onset of hepatic encephalopathy within 56 days of 
the first signs or symptoms of liver disease. In addition, the candidate: 
i. 
Must not have a pre-existing diagnosis of liver disease. For purposes of this 
section, any diagnoses of liver disease that occurred prior to a subsequent liver 
transplant do not constitute pre-existing liver disease. 
ii. 
Must currently be admitted in the intensive care unit 
iii. 
Must meet at least one of the following conditions: 
1. Is ventilator dependent 
2. Requires dialysis, continuous veno-venous hemofiltration (CVVH), or 
continuous veno-venous hemodialysis (CVVHD) 
3. Has an international normalized ratio (INR) greater than 2.0 
 
b. Anhepatic 
 
c. Primary non-function of a transplanted whole liver within 7 days of transplant, with 
aspartate aminotransferase (AST) greater than or equal to 3,000 U/L and at least one of 
the following: 
• 
International normalized ratio (INR) greater than or equal to 2.5 
• 
Arterial pH less than or equal to 7.30 
• 
Venous pH less than or equal to 7.25 
• 
Lactate greater than or equal to 4 mmol/L 
  
All laboratory results reported for the tests required above must be from the same 
blood draw taken 24 hours to 7 days after the transplant. 

 
 
 
d. non-function within 7-days of transplant of a transplanted liver segment from a 
deceased or living donor, evidenced by at least one of the following: 
• 
INR greater than or equal to 2.5 
• 
Arterial pH less than or equal to 7.30 
• 
Venous pH less than or equal to 7.25 
• 
Lactate greater than or equal to 4 mmol/L 
 
e. Hepatic artery thrombosis (HAT) within 7-days of transplant, with AST greater than or 
equal to 3,000 U/L and at least one of the following: 
• 
INR greater than or equal to 2.5 
• 
Arterial pH less than or equal to 7.30 
• 
Venous pH less than or equal to 7.25 
• 
Lactate greater than or equal to 4 mmol/L 
  
All laboratory results reported for the tests required above must be from the same 
blood draw taken 24 hours to 7 days after the transplant. 
 
f. Acute decompensated Wilson’s disease

---

## 9.1.B — Pediatric Status 1A Requirements

<!-- Policy: 9 | Section: 9.1.B | Category: Liver Allocation -->

To assign a candidate pediatric status 1A, the candidate’s transplant hospital must submit a Liver 
Status 1A Justification Form to the OPTN. A candidate is not assigned pediatric status 1A until 
this form is submitted.  
 
The candidate’s transplant program may assign the candidate pediatric status 1A if all the 
following conditions are met: 
 
1. The candidate is less than 18 years old at the time of registration. This includes candidates 
less than 18 years old at the time of registration, who remain on the waiting list after turning 
18 years old, but does not include candidates removed from the waiting list at any time who 
then return to the waiting list after turning 18 years old. 
2. The candidate has at least one of the following conditions:  
 
a. Fulminant liver failure and the candidate:  
i. 
Must not have a pre-existing diagnosis of liver disease. For purposes of this section, 
any diagnoses of liver disease that occurred prior to a subsequent liver transplant 
do not constitute pre-existing liver disease. 
ii. Must meet at least one of the following criteria: 
1. Is ventilator dependent 
2. Requires dialysis, continuous veno-venous hemofiltration (CVVH), or 
continuous veno-venous hemodialysis (CVVHD) 
3. Has an international normalized ratio (INR) greater than or equal to 1.5 and 
less than 2.0 and a diagnosis of hepatic encephalopathy within 56 days of 
the first signs or symptoms of liver disease 
4. Has an INR greater than or equal to 2.0 
 

 
 
 
b. Diagnosis of primary non-function of a transplanted liver within 7 days of transplant, 
evidenced by at least two of the following: 
i. 
Alanine aminotransferase (ALT) greater than or equal to 2,000 U/L 
ii. INR greater than or equal to 2.5 
iii. Total bilirubin greater than or equal to 10 mg/dL 
iv. Acidosis, defined as one of the following: 
• 
Arterial pH less than or equal to 7.30 
• 
Venous pH less than or equal to 7.25 
• 
Lactate greater than or equal to 4 mmol/L 
 
All laboratory results reported for any tests required for the primary non-function of a 
transplanted liver diagnosis above must be from the same blood draw taken between 
24 hours and 7 days after the transplant. 
 
c. Diagnosis of hepatic artery thrombosis (HAT) in a transplanted liver within 14 days of 
transplant 
 
d. Acute decompensated Wilson’s disease

---

## 9.1.C — Pediatric Status 1B Requirements

<!-- Policy: 9 | Section: 9.1.C | Category: Liver Allocation -->

To assign a candidate pediatric status 1B, the candidate’s transplant hospital must submit a Liver 
Status 1B Justification Form to the OPTN. A candidate is not registered as status 1B until this 
form is submitted. 
 
The candidate’s transplant program may assign the candidate pediatric status 1B if all the 
following conditions are met: 
 
1. The candidate is less than 18 years old at the time of registration. This includes candidates 
less than 18 years old at the time of registration, who remain on the waiting list after 
turning 18 years old, but does not include candidates removed from the waiting list at any 
time who then return to the waiting list after turning 18 years old. 
  
2. The candidate has one of the following conditions: 
 
a. The candidate has a biopsy-proven hepatoblastoma without evidence of metastatic 
disease. 
b. The candidate has an organic acidemia or urea cycle defect and an approved MELD or 
PELD exception meeting standard criteria for metabolic disease for at least 30 days. 
c. Chronic liver disease and meets at least one of the following criteria due to 
complications of chronic liver disease: 
i. 
Is on a mechanical ventilator 
ii. 
Has gastrointestinal bleeding requiring red blood cell replacement of at least 30 
mL/kg within the previous 96 hours or 20 mL/kg within the previous 24 hours 
iii. 
Has renal failure or renal insufficiency requiring dialysis, continuous veno-
venous hemofiltration (CVVH), or continuous veno-venous hemodialysis 
(CVVHD) 

 
 
 
d. Chronic liver disease and is a combined liver-intestine candidate and meets at least one 
of the following criteria due to complications of chronic liver disease: 
i. 
Is on a mechanical ventilator 
ii. 
Has gastrointestinal bleeding requiring at least 10 mL/kg of red blood cell 
replacement within the previous 24 hours 
iii. 
Has renal failure or renal insufficiency requiring dialysis, continuous veno-
venous hemofiltration (CVVH), or continuous veno-venous hemodialysis 
(CVVHD)

---

## 9.1.D — MELD Score

<!-- Policy: 9 | Section: 9.1.D | Category: Liver Allocation -->

Candidates who are at least 18 years old at the time of registration receive a MELD score equal 
to:  
 
MELD = 1.33 (if female) + [4.56 x loge(bilirubin)] + [0.82 x (137-sodium)] – [0.24 x (137-sodium) x 
loge(bilirubin)] + [9.09 x loge(INR)] + [11.14 x loge(creatinine)] + [1.85 x (3.5-albumin)] – [1.83 x 
(3.5 – albumin) x loge(creatinine)] + 6 
 
Candidates who are currently at least 12 years old and were less than 18 years old at the time of 
registration receive a MELD score equal to:  
 
MELD = [4.56 x loge(bilirubin)] + [0.82 x (137-sodium)] – [0.24 x (137-sodium) x loge(bilirubin)] + 
[9.09 x loge(INR)] + [11.14 x loge(creatinine)] + [1.85 x (3.5-albumin)] – [1.83 x (3.5 – albumin) x 
loge(creatinine)] + 7.33 
 
Bilirubin, INR, and creatinine values less than 1.0 will be set to 1.0 when calculating a 
candidate’s MELD score.  
 
The following candidates will receive a creatinine value of 3.0 mg/dL when calculating a 
candidate’s MELD score: 
 
• 
Candidates with a creatinine value greater than 3.0 mg/dL 
• 
Candidates who received two or more dialysis treatments within the 7 days prior to the 
serum creatinine test 
• 
Candidates who received 24 hours of continuous veno-venous hemodialysis (CVVHD) within 
the 7 days prior to the serum creatinine test 
 
Sodium values less than 125 mmol/L will be set to 125 mmol/L, and values greater than 137 
mmol/L will be set to 137 mmol/L. 
 
Albumin values less than 1.5 g/dL will be set to 1.5 g/dL, and values greater than 3.5 g/dL will be 
set to 3.5 g/dL.  
 
The minimum MELD score is 6. The maximum MELD score is 40. The MELD score derived from 
this calculation will be rounded to the nearest whole number.

---

## 9.1.E — PELD Score

<!-- Policy: 9 | Section: 9.1.E | Category: Liver Allocation -->

Candidates who are under the age of 12 receive a PELD score equal to: 
 
Table 9-1: PELD Score Calculation 
  
If the value is: 
Then the value’s contribution to PELD is: 
Candidate Age 
(fractional calendar 
year) 
<1 
-0.1967 * 1 
1 to 5.5 
-0.1967 * age at the time of the most recent 
lab reported for use in the PELD score 
> 5.5 and < 12 
-0.1967 * 5.5 
Albumin (g/dL) 
1 to 1.9 
-1.842 * ln(albumin) 
> 1.9 
-1.842 * ln(1.9) 
Total bilirubin 
(mg/dL) 
1 to 4 
0.7854 * ln(bilirubin) + 0.3434 * ln(4) 
> 4 to 40 
0.7854 * ln(4) + 0.3434 * ln(bilirubin) 
> 40 
0.7854 * ln(4) + 0.3434 * ln(40) 
INR 
1 to 2 
1.981 * ln(INR) + 0.7298 * ln(2) 
> 2 to 10 
1.981 * ln(2) + 0.7298 * ln(INR) 
> 10 
1.981 * ln(2) + 0.7298 * In(10) 
Minimum of CDC 
height or weight Z-
score 
< -5.0 
-0.1807 * (-5) 
-5.0 to -2.1 
-0.1807 * (minimum z-score) 
> -2.1 
-0.1807 * (-2.1) 
Creatinine (mg/dL) 
< 0.2 
1.453 * ln(.02) 
0.2 to 1.3 
1.453 * ln(creatinine) 
> 1.3 
1.453 * ln(1.3) 
 
A candidate’s PELD score will then be calculated as follows:  
 
PELD = (sum of all terms as outlined in Table 9-1: PELD Score Calculation + 1.5287) x 10 + 2.82 
 
The minimum of Center for Disease Control and Prevention’s (CDC) height or weight Z-score 
uses the lambda-mu-alpha (LMS) method and is based on the 2000 CDC Growth Charts for the 
United States. The calculation uses the candidate’s birth sex, most recent values submitted for 

 
 
 
height and weight, and the candidate’s age in months at the time the height and weight values 
used in the PELD calculation were measured.  
 
Albumin, bilirubin, and INR values less than 1.0 will be set to 1.0 when calculating a candidate’s 
PELD score. 
 
The following candidates will receive a creatinine value of 1.3 mg/dL when calculating a 
candidate’s PELD score: 
 
• 
Candidates with a creatinine value greater than 1.3 mg/dL  
• 
Candidates who received two or more dialysis treatments within the 7 days prior to the 
serum creatinine test 
• 
Candidates who received 24 hours of continuous veno-venous hemodialysis (CVVHD) 
within the 7 days prior to the serum creatinine test 
 
The minimum PELD score is 6. The PELD score derived from this calculation will be rounded to 
the nearest whole number.

---

## 9.1.F — Liver-Intestine Candidates

<!-- Policy: 9 | Section: 9.1.F | Category: Liver Allocation -->

Liver candidates who are registered on the waiting list after turning 18 years old and are also 
registered and active on the waiting list for an intestine transplant at that transplant hospital 
will automatically receive an additional increase in their MELD or PELD score equivalent to a 10 
percentage point increase in risk of 3-month mortality. Liver candidates who are registered on 
the waiting list before turning 18 years old and are also registered and active on the waiting list 
for an intestine transplant at that transplant hospital will receive 23 additional points to their 
calculated MELD or PELD score. The transplant hospital must document in the candidate’s 
medical record the medical justification for the combined liver-intestine transplant and that the 
transplant was completed.

---

## 9.2 — Status and Laboratory Values Update Schedule

<!-- Policy: 9 | Section: 9.2 | Category: Liver Allocation -->

The OPTN will notify the transplant hospital within 2 days of the deadline for recertification when a 
candidate’s laboratory values need to be updated. Transplant hospitals must recertify a candidate’s 
values according to Table 9-2. 
 
When reporting laboratory values to the OPTN, transplant hospitals must submit the most recent results 
including the dates of the laboratory tests. In order to change a MELD or PELD score voluntarily, all 
laboratory values must be obtained within the same 2 day period. 
 

 
 
 
Table 9-2: Liver Status Update Schedule 
If the candidate is: 
The new laboratory values 
must be reported every: 
And when reported, the new 
laboratory values must be no 
older than : 
Status 1A or 1B 
7 days 
2 days 
MELD 25 or greater (ages 18 
or older) 
7 days 
2 days 
MELD or PELD 25 or greater 
(less than 18 years old) 
14 days 
3 days 
MELD or PELD 19 to 24 
30 days 
7 days 
MELD or PELD 11 to 18 
90 days 
14 days 
MELD or PELD 10 or less 
365 days 
30 days 
 
Status 1B candidates have these further requirements for certification: 
 
• 
Candidates with a gastrointestinal bleed as the reason for the initial status 1B upgrade criteria must 
have had another bleed in the past 7 days immediately before the upgrade in order to recertify as 
status 1B. 
• 
Candidates indicating a metabolic disease or a hepatoblastoma require recertification every 90 days 
with lab values no older than 14 days. 
 
If a candidate is not recertified by the deadline according to Table 9-2, the candidate will be re-assigned 
to their previous lower MELD or PELD score. The candidate may remain at that previous lower score for 
the period allowed based on the recertification schedule for the previous lower score, minus the time 
spent in the uncertified score. 
 
If the candidate remains uncertified past the recertification due date for the previous lower score, the 
candidate will be assigned a MELD or PELD score of 6. If a candidate has no previous lower MELD or 
PELD score, and is not recertified according to the schedule, the candidate will be reassigned to a MELD 
or PELD score of 6.

---

## 9.2.A — Recertification of Status 1A or 1B

<!-- Policy: 9 | Section: 9.2.A | Category: Liver Allocation -->

Transplant hospitals must submit a completed Liver Status 1A or 1B Justification Form to the 
OPTN for each recertification as a status 1A or 1B. A request to continue as status 1A or 1B 
beyond 14 days accumulated time will result in a review of all status 1A or 1B liver candidate 
registrations at the transplant hospital. A review will not occur if the request was for a candidate 
meeting the requirements for hepatoblastoma in OPTN Policy 9.1.C: Pediatric Status 1B 
Requirements or a metabolic disease in OPTN Policy 9.5.F: Requirements for Metabolic Disease 
MELD or PELD Score Exceptions.

---

## 9.2.B — Reporting of Final Laboratory Value at Removal from Waiting List

<!-- Policy: 9 | Section: 9.2.B | Category: Liver Allocation -->

The transplant hospital must report final laboratory values reported for certification to the 
OPTN before removing the candidate from the waiting list as transplanted or deceased.

---

## 9.3 — Status Exceptions

<!-- Policy: 9 | Section: 9.3 | Category: Liver Allocation -->

The Liver and Intestinal Organ Transplantation Committee establishes guidelines for review of status and 
MELD or PELD score exception requests. 
 
If a candidate’s transplant program believes that a candidate’s current status does not appropriately 
reflect the candidate’s medical urgency for transplant, the transplant program may register a candidate 
at an exceptional status. However, the Liver and Intestinal Organ Transplantation Committee will 
retrospectively review all exception candidates registered as status 1A or 1B and may refer these cases 
to the Membership and Professional Standards Committee (MPSC) for review according to Appendix L of 
the OPTN Management and Membership Policies.

---

## 9.4 — MELD or PELD Score Exceptions

<!-- Policy: 9 | Section: 9.4 | Category: Liver Allocation -->

If a candidate’s transplant program believes that a candidate’s current MELD or PELD score does not 
appropriately reflect the candidate’s medical urgency for transplant, the transplant program may submit 
a MELD or PELD score exception request to the National Liver Review Board (NLRB).

---

## 9.4.A — MELD or PELD Score Exception Requests

<!-- Policy: 9 | Section: 9.4.A | Category: Liver Allocation -->

A MELD or PELD score exception request must include: 
 
1. A request for either: 
a. An adjustment of a certain amount of points higher or lower than MMaT or MPaT or 
b. A specific MELD or PELD score of 40 or higher 
2. A justification that outlines how a candidate’s medical condition warrants an exception and 
the specific score being requested. 
 
MELD or PELD exceptions are valid for 90 days from the date the exception is approved or 
assigned.

---

## 9.4.B — NLRB and Committee Review of MELD or PELD Exceptions

<!-- Policy: 9 | Section: 9.4.B | Category: Liver Allocation -->

The NLRB must review exception or extension requests within 21 days of the date the request is 
submitted to the OPTN. If the NLRB fails to make a decision on the initial exception or extension 
request by the end of the 21 day review period, the candidate will be assigned the requested 
MELD or PELD exception score. 
 
 

 
 
 
9.4.B.i  
NLRB Appeals 
If the NLRB denies an exception or extension request, the candidate’s transplant 
program may appeal to the NLRB within 14 days of receiving the denial. 
 
The NLRB must review appeals within 21 days of the date the appeal is submitted to 
the OPTN. If the NLRB fails to make a decision on the appeal by the end of the 21 
day appeal period, the candidate will be assigned the requested MELD or PELD 
exception score. 
 
9.4.B.ii 
Appeals Review Team (ART) Conference 
If the NLRB denies the appeal for an exception or extension request, the candidate’s 
transplant program may further appeal to the Appeals Review Team (ART) within 7 
days of receiving notification of the denial. If the transplant program appeals the 
exception or extension request to the ART, the ART must review the request within 
14 days of the date the appeal is submitted to the OPTN. If the ART fails to make a 
decision on the appealed request by the end of the 14 day ART appeal review 
period, the candidate will be assigned the requested MELD or PELD exception score. 
 
9.4.B.iii 
Committee Appeals 
If the ART denies the appeal for an exception or extension request, the candidate’s 
transplant program may appeal to the Liver and Intestinal Organ Transplantation 
Committee within 7 days of receiving notification of the denial.

---

## 9.4.C — MELD or PELD Exception Extensions

<!-- Policy: 9 | Section: 9.4.C | Category: Liver Allocation -->

9.4.C.i 
Hepatocellular Carcinoma (HCC) MELD or PELD Score Exception 
Extensions 
A candidate with an approved exception for HCC is eligible for automatic approval of 
an extension according to OPTN Policy 9.5.I.vii Extensions of HCC Exceptions, even if 
the initial exception was not a standardized MELD or PELD score exception. 
 
9.4.C.ii  
Other MELD or PELD Score Exception Extensions 
A candidate’s approved or assigned exception will be maintained if the transplant 
program enters a MELD or PELD Exception Score Extension Request before the due 
date, even if the NLRB does not act before the due date. If the extension request is 
denied or if no MELD or PELD Exception Score Extension Request is submitted 
before the due date, then the candidate will be assigned the calculated MELD or 
PELD score based on the most recent reported laboratory values.  
 
Each approved or assigned MELD or PELD exception extension is valid for an 
additional 90 days beginning from the day that the previous exception or extension 
expired.

---

## 9.4.D — Calculation of Median MELD or PELD at Transplant

<!-- Policy: 9 | Section: 9.4.D | Category: Liver Allocation -->

For each donor hospital, the OPTN will calculate the MMaT based on a cohort of recipients 
transplanted at programs at or within 150 nautical miles of the donor hospital in a prior 365 day 
period. If there are either less than two active liver transplant programs or less than 10 
qualifying transplants within 150 nautical miles of the donor hospital, the geographic area used 
to calculate the MMaT will increase in 50 nautical mile increments until two active liver 
transplant programs and 10 qualifying transplants are included in the MMaT cohort. 
 
The MMaT is calculated by using the median of the MELD scores at the time of transplant of all 
recipients within the geographic area defined above that are at least 12 years old at the time of 
transplant. Recipients are excluded who are either of the following: 
 
1. Transplanted with livers from living donors, DCD donors, or donors from donor hospitals 
more than 500 nautical miles away from the recipient’s transplant program or 
2. Status 1A or 1B at the time of transplant. 
 
If a transplant program has not performed at least one transplant included in the MMaT 
calculation, the program is not included in the MMaT cohort. 
 
If there are less than 10 qualifying transplants within 250 nautical miles of a donor hospital in 
Hawaii or Puerto Rico, the MMaT will be calculated based on a total of 730 days. There does not 
need to be two transplant programs within 250 nautical miles of donor hospitals in Hawaii or 
Puerto Rico. 
 
Median PELD at transplant (MPaT) is calculated by using the median of the PELD scores at the 
time of transplant of all recipients less than 12 years old at the time of transplant in the nation. 
Recipients are excluded who are either of the following: 
 
1. Transplanted with livers from living donors, DCD donors, or donors from donor hospitals 
more than 500 nautical miles away from the recipient’s transplant program or 
2. Status 1A or 1B at the time of transplant. 
 
The OPTN will recalculate the MMaT and MPaT twice a year based on an updated cohort. The 
updated cohort will include transplants over a prior 365 day period.

---

## 9.4.E — MELD or PELD Exception Scores Relative to Median MELD or PELD at Transplant

<!-- Policy: 9 | Section: 9.4.E | Category: Liver Allocation -->

A match run will provide MELD exception candidates on the match run a MELD exception score 
relative to the MMaT for the donor hospital. PELD exception candidates are provided a PELD 
exception score relative to the MPaT for the nation. If a candidate’s exception score relative to 
MMaT or MPaT would be lower than 15, the candidate’s exception score will be 15. 
 
The following exception scores are not awarded relative to MMaT or MPaT: 
1.  Exception scores of 40 or higher awarded by the NLRB according to OPTN Policy 9.4.A: MELD 
or PELD Score Exception Requests 
2.  Any exception awarded according to OPTN Policy 9.5.D: Requirements for Hepatic Artery 
Thrombosis (HAT) MELD or PELD Score Exceptions 

 
 
 
3.  Exceptions awarded to candidates less than 18 years old at time of registration according to 
OPTN Policy 9.5.I: Requirements for Hepatocellular Carcinoma (HCC) MELD or PELD Score 
Exceptions

---

## 9.5 — Specific Standardized MELD or PELD Score Exceptions

<!-- Policy: 9 | Section: 9.5 | Category: Liver Allocation -->

Candidates are eligible for MELD or PELD score exceptions or extensions that do not require evaluation 
by the NLRB if they meet any of the following requirements for a specific diagnosis of any of the 
following: 
 
• 
Hilar Cholangiocarcinoma (CCA), according to OPTN Policy 9.5.A: Requirements for Hilar 
Cholangiocarcinoma MELD or PELD Score Exceptions 
• 
Cystic fibrosis, according to OPTN Policy 9.5.B: Requirements for Cystic Fibrosis MELD or PELD Score 
Exceptions 
• 
Familial amyloid polyneuropathy, according to OPTN Policy 9.5.C: Requirements for Familial Amyloid 
Polyneuropathy (FAP) MELD or PELD Score Exceptions 
• 
Hepatic artery thrombosis, according to OPTN Policy 9.5.D: Requirements for Hepatic Artery 
Thrombosis (HAT) MELD Score Exceptions 
• 
Hepatopulmonary syndrome, according to OPTN Policy 9.5.E: Requirements for Hepatopulmonary 
Syndrome (HPS) MELD or PELD Score Exceptions 
• 
Metabolic disease, according to OPTN Policy 9.5.F: Requirements for Metabolic Disease MELD or 
PELD Score Exceptions 
• 
Portopulmonary hypertension, according to OPTN Policy 9.5.G: Requirements for Portopulmonary 
Hypertension MELD or PELD Score Exceptions 
• 
Primary hyperoxaluria, according to OPTN Policy 9.5.H: Requirements for Primary Hyperoxaluria 
MELD or PELD Score Exceptions 
• 
Hepatocellular carcinoma, according to OPTN Policy 9.5.I: Requirements for Hepatocellular 
Carcinoma (HCC) MELD or PELD Score Exception

---

## 9.5.A — Requirements for Hilar Cholangiocarcinoma (CCA) MELD or PELD Score

<!-- Policy: 9 | Section: 9.5.A | Category: Liver Allocation -->

Exceptions 
A candidate will receive a MELD or PELD score exception for Hilar CCA, if the candidate’s 
transplant program meets all the following qualifications: 
 
1. Submits a written protocol for patient care to the Liver and Intestinal Organ Transplantation 
Committee for review and approval. The written protocol must include all of the following: 
i. 
Candidate selection criteria 
ii. 
Administration of neoadjuvant therapy before transplantation 
iii. 
Operative staging to exclude any patient with regional hepatic lymph node metastases, 
intrahepatic metastases, or extrahepatic disease 
iv. 
Any data requested by the Liver and Intestinal Organ Transplantation Committee 
 
2. Documents that the candidate meets the diagnostic criteria for Hilar CCA with a malignant 
appearing stricture on cholangiography and at least one of the following: 
• 
Biopsy or cytology results demonstrating malignancy 
• 
Carbohydrate antigen 19-9 greater than 100 U/mL in absence of cholangitis 

 
 
 
• 
Aneuploidy 
• 
Hilar mass, which is less than 3 cm in radial diameter.  
 
The tumor must be considered un-resectable because of technical considerations or 
underlying liver disease. 
 
3. Submits cross-sectional imaging studies. If cross-sectional imaging studies demonstrate a 
mass, the mass must be single and less than three cm in radial (perpendicular to the duct) 
diameter. The longitudinal extension of the stricture along the bile duct is not considered in 
the measurement of a mass.  
 
4. Documents the exclusion of intrahepatic and extrahepatic metastases by cross-sectional 
imaging studies of the chest and abdomen within 90 days prior to submission of the initial 
exception request. 
 
5. Assesses regional hepatic lymph node involvement and peritoneal metastases by operative 
staging after completion of neoadjuvant therapy and before liver transplantation. 
Endoscopic ultrasound-guided aspiration of regional hepatic lymph nodes may be advisable 
to exclude patients with obvious metastases before neo-adjuvant therapy is initiated. 
 
6. Transperitoneal aspiration or biopsy of the primary tumor (either by endoscopic ultrasound, 
operative or percutaneous approaches) must be avoided because of the high risk of tumor 
seeding associated with these procedures. 
 
A candidate who meets the requirements for a standardized MELD or PELD score exception will 
receive a score according to Table 9-2. 
 
Table 9-2: Hilar CCA Exception Scores 
Age 
Age at registration 
Score  
At least 18 years old 
At least 18 years old 
3 points below MMaT 
At least 12 years old 
Less than 18 years old 
Equal to MMaT 
Less than 12 years old 
Less than 12 years old 
Equal to MPaT 
 
In order to be approved for an extension of this MELD or PELD score exception, transplant 
programs must submit an exception extension request according to OPTN Policy 9.4.C: MELD or 
PELD Exception Extensions, and provide cross-sectional imaging studies of the chest and 
abdomen that exclude intrahepatic and extrahepatic metastases. These required imaging 
studies must have been completed within 30 days prior to the submission of the extension 
request.

---

## 9.5.B — Requirements for Cystic Fibrosis (CF) MELD or PELD Score Exceptions

<!-- Policy: 9 | Section: 9.5.B | Category: Liver Allocation -->

A candidate will receive a MELD or PELD score exception for cystic fibrosis if the candidate’s 
diagnosis has been confirmed by genetic analysis, and the candidate has a forced expiratory 
volume at one second (FEV1) below 40 percent of predicted FEV1 within 30 days prior to 
submission of the initial exception request. 

 
 
 
 
A candidate who meets the requirements for a standardized MELD or PELD score exception will 
receive a score according to Table 9-3. 
 
Table 9-3: Cystic Fibrosis Exception Scores 
Age 
Age at registration 
Score  
At least 18 years old 
At least 18 years old 
3 points below MMaT 
At least 12 years old 
Less than 18 years old 
Equal to MMaT 
Less than 12 years old 
Less than 12 years old 
Equal to MPaT 
 
In order to be approved for an extension of this MELD or PELD score exception, transplant 
programs must submit an exception extension request according to OPTN Policy 9.4.C: MELD or 
PELD Exception Extensions.

---

## 9.5.C — Requirements for Familial Amyloid Polyneuropathy (FAP) MELD or PELD

<!-- Policy: 9 | Section: 9.5.C | Category: Liver Allocation -->

Score Exceptions 
A candidate will receive a MELD or PELD score exception for FAP if the candidate’s transplant 
program submits evidence of all of the following: 
 
1. Either that the candidate is also registered and active on the waiting list for a heart 
transplant at that transplant hospital, or has an echocardiogram performed within 30 days 
prior to submission of the initial exception request showing the candidate has an ejection 
fraction greater than 40 percent. 
2. That the candidate can walk without assistance. 
3. That a transthyretin (TTR) gene mutation has been confirmed. 
4. A biopsy-proven amyloid. 
 
A candidate who meets the requirements for a standardized MELD or PELD score exception will 
receive a score according to Table 9-4. 
 
Table 9-4: FAP Exception Scores 
Age 
Age at registration 
Score  
At least 18 years old 
At least 18 years old 
3 points below MMaT 
At least 12 years old 
Less than 18 years old 
Equal to MMaT 
Less than 12 years old 
Less than 12 years old 
Equal to MPaT 
 
In order to be approved for an extension of this MELD or PELD score exception, transplant 
programs must submit an exception extension request according to OPTN Policy 9.4.C: MELD or 
PELD Exception Extensions and meet one of the following criteria:  
 
1. An echocardiogram that shows that the candidate has an ejection fraction greater than 40 
percent within the last 120 days 
2. Registered and active on the waiting list for a heart transplant at that hospital

---

## 9.5.D — Requirements for Hepatic Artery Thrombosis (HAT) MELD Score Exceptions

<!-- Policy: 9 | Section: 9.5.D | Category: Liver Allocation -->

A candidate will receive a MELD score exception for HAT if the candidate is at least 18 years old 
at registration and has HAT within 14 days of transplant but does not meet criteria for status 1A 
in OPTN Policy 9.1.A: Adult Status 1A Requirements. 
 
Candidates who meet these requirements will receive a MELD score of 40. 
 
In order to be approved for an extension of this MELD score exception, transplant programs 
must submit an exception extension request according to OPTN Policy 9.4.C: MELD or PELD 
Exception Extensions.

---

## 9.5.E — Requirements for Hepatopulmonary Syndrome (HPS) MELD or PELD Score

<!-- Policy: 9 | Section: 9.5.E | Category: Liver Allocation -->

Exceptions 
A candidate will receive a MELD or PELD score exception for HPS if the candidate’s transplant 
program submits evidence of all of the following: 
 
1. Ascites, varices, splenomegaly, or thrombocytopenia. 
2. A shunt, shown by either contrast echocardiogram or lung scan. 
3. PaO2 less than 60 mmHg on room air within 30 days prior to submission of the initial 
exception request. 
4. No clinically significant underlying primary pulmonary disease. 
 
A candidate who meets the requirements for a standardized MELD or PELD exception will 
receive a score according to Table 9-5.  
 
Table 9-5: HPS Exception Scores 
Age 
Age at registration 
Score  
At least 18 years old 
At least 18 years old 
3 points below MMaT 
At least 12 years old 
Less than 18 years old 
Equal to MMaT 
Less than 12 years old 
Less than 12 years old 
Equal to MPaT 
 
In order to be approved for an extension of this MELD or PELD score exception, transplant 
programs must submit an exception extension request according to OPTN Policy 9.4.C: MELD or 
PELD Exception Extensions, with evidence that the candidate’s PaO2 remained at less than 60 
mmHg on room air within the 30 days prior to submission of the extension request.

---

## 9.5.F — Requirements for Metabolic Disease MELD or PELD Score Exceptions

<!-- Policy: 9 | Section: 9.5.F | Category: Liver Allocation -->

A liver candidate less than 18 years old at the time of registration will receive a MELD or PELD 
score exception for metabolic disease if the candidate’s transplant program submits evidence of 
urea cycle disorder or organic acidemia. 
 

 
 
 
A candidate who meets the requirements for a standardized MELD or PELD score exception will 
receive a score according to Table 9-6. 
Table 9-6: Metabolic Disease Exception Scores 
Age 
Age at registration 
Score  
At least 12 years old 
Less than 18 years old 
Equal to MMaT 
Less than 12 years old 
Less than 12 years old 
Equal to MPaT 
 
If the candidate does not receive a transplant within 30 days of being registered with the 
exception score, then the candidate’s transplant physician may register the candidate as a status 
1B. 
 
In order to be approved for an extension of this MELD or PELD score exception, transplant 
programs must submit an exception extension request according to OPTN Policy 9.4.C: MELD or 
PELD Exception Extensions.

---

## 9.5.G — Requirements for Portopulmonary Hypertension MELD or PELD Score

<!-- Policy: 9 | Section: 9.5.G | Category: Liver Allocation -->

Exceptions 
A candidate will receive a MELD or PELD score exception for portopulmonary hypertension if the 
transplant program submits evidence of all of the following: 
 
1. Document via heart catheterization initial mean pulmonary arterial pressure (MPAP) level 
greater than or equal to 35 mmHg and initial pulmonary vascular resistance (PVR) level 
greater than or equal to 240 dynes*sec/cm5 (or greater than or equal to 3 Wood units 
(WU)). These values must be from the same test date. 
2. Other causes of pulmonary hypertension have been assessed and determined to not be a 
significant contributing factor 
3. Initial transpulmonary gradient to correct for volume overload 
4. Documentation of treatment 
5. Document via heart catheterization within 90 days prior to submission of the initial 
exception either of the following: 
• 
Post-treatment MPAP less than 35 mmHg and post-treatment PVR less than 400 
dynes*sec/cm5 (or less than 5 Wood units (WU)). These values must be from the 
same test date. 
• 
Post-treatment MPAP greater than or equal to 35 mmHg and less than 45 mmHg 
and post-treatment PVR less than 240 dynes*sec/cm5 (or less than 3 Wood units 
(WU)). These values must be from the same test date. 
6. Documentation of portal hypertension at the time of initial exception 
 
 

 
 
 
A candidate who meets the requirements for a standardized MELD or PELD score exception will 
receive a score according to Table 9-7.  
 
Table 9-7: Portopulmonary Hypertension Exception Scores 
Age 
Age at registration 
Score  
At least 18 years old 
At least 18 years old 
3 points below MMaT 
At least 12 years old 
Less than 18 years old 
Equal to MMaT 
Less than 12 years old 
Less than 12 years old 
Equal to MPaT 
 
In order to be approved for an extension of this MELD or PELD score exception, transplant 
programs must submit an exception extension request according to OPTN Policy 9.4.C: MELD or 
PELD Exception Extensions with evidence of a heart catheterization since the last exception or 
extension request that confirms either of the following: 
• 
MPAP less than 35 mmHg and PVR less than 400 dynes*sec/cm5 (or less than 5 Wood 
units (WU)). These values must be from the same test date. 
• 
MPAP greater than or equal to 35 mmHg and less than 45 mmHg and PVR less than 
240 dynes*sec/cm5 (or less than 3 Wood units (WU)). These values must be from the 
same test date.

---

## 9.5.H — Requirements for Primary Hyperoxaluria MELD or PELD Score Exceptions

<!-- Policy: 9 | Section: 9.5.H | Category: Liver Allocation -->

A candidate will receive a MELD or PELD score exception for primary hyperoxaluria if the 
candidate’s transplant program submits evidence of all of the following:  
 
1. The liver candidate is registered on the waiting list for a kidney transplant at that transplant 
hospital 
2. Alanine glyoxylate aminotransferase (AGT) deficiency proven by liver biopsy using sample 
analysis or genetic analysis 
3. Glomerular filtration rate (GFR) less than or equal to 25 mL/min on 2 occasions at least 42 
days apart 
 
A candidate who meets the requirements for a standardized MELD or PELD score exception will 
receive an exception score according to Table 9-8. 
 
Table 9-8: Primary Hyperoxaluria Scores 
Age 
Age at registration 
Score  
At least 18 years old 
At least 18 years old 
Equal to MMaT 
At least 12 years old 
Less than 18 years old 
3 points above MMaT 
Less than 12 years old 
Less than 12 years old 
3 points above MPaT 
 
In order to be approved for an extension of this MELD or PELD score exception, transplant 
programs must submit an exception extension request according to OPTN OPTN Policy 9.4.C: 
MELD or PELD Exception Extensions with evidence that the candidate is registered on the 
waiting list for a kidney transplant at that hospital.

---

## 9.5.I — Requirements for Hepatocellular Carcinoma (HCC) MELD or PELD Score (Part 1)

<!-- Policy: 9 | Section: 9.5.I | Category: Liver Allocation -->

Exceptions 
Upon submission of the first exception request, a candidate with hepatocellular carcinoma 
(HCC) will receive a score according to OPTN Policy 9.5.I.vii: Extensions of HCC Exceptions if the 
candidate meets the criteria according to OPTN Policies 9.5.I.i through 9.5.I.vi. 

9.5.I.i 
Initial Assessment and Requirements for HCC Exception 
Requests 
Prior to applying for a standardized MELD or PELD exception, the candidate must 
undergo a thorough assessment that includes all of the following: 

1. An evaluation of the number and size of lesions using multiphase contrast-
enhanced computer tomography (CT) or magnetic resonance imaging (MRI) 
before locoregional therapy.  
2. An evaluation that the lesions meet Class 5 criteria according to Table 9-9 using 
a multiphase contrast-enhanced (CT), (MRI), or ultrasound (CEUS).  
3. A CT of the chest to rule out metastatic disease. This is only required prior to 
applying for an initial exception. A CT of the chest is not required for exception 
extensions. 
4. A CT or MRI to rule out any other sites of extrahepatic spread or macrovascular 
involvement 
5. An indication that the candidate is not eligible for resection 
6. An indication whether the candidate has undergone locoregional therapy 
7. The candidate’s alpha-fetoprotein (AFP) level 

The transplant hospital must maintain documentation of the radiologic images and 
assessments of all OPTN Class 5 lesions in the candidate’s medical record. If growth 
criteria are used to classify a lesion as HCC, the radiology report must contain the 
prior and current dates of imaging, type of imaging, and measurements of the 
lesion. 

For those candidates who receive a liver transplant while receiving additional 
priority under the HCC exception criteria, the transplant hospital must submit the 
Post-Transplant Explant Pathology Form to the OPTN within 60 days of transplant. If 
the Post-Transplant Explant Pathology Form does not show evidence of HCC or liver-
directed therapy for HCC, the transplant program must also submit documentation 
or imaging studies confirming HCC at the time of assignment.  

The Liver and Intestinal Organ Transplantation Committee will review the submitted 
documentation or imaging studies when more than 10 percent of the Post-
Transplant Explant Pathology Forms submitted by a transplant program in a one 
year period do not show evidence of HCC or liver-directed therapy for HCC. 

9.5.I.ii  
Eligible Candidates Definition of T2 Stage 
Candidates with hepatic lesions that meet T2 stage are eligible for a standardized 
MELD or PELD exception if they have an alpha-fetoprotein (AFP) level less than or 
equal to 1000 ng/mL. T2 stage is defined as candidates with either of the following: 

• 
One Class 5 lesion greater than or equal to 2 cm and less than or equal to 5 cm 
in size. 
• 
Two or three Class 5 lesions each greater than or equal to 1 cm and less than or 
equal to 3 cm in size. 

A candidate who has previously had an AFP level greater than 1000 ng/mL at any 
time must qualify for a standardized MELD or PELD exception according to OPTN 
Policy 9.5.I.iv: Candidates with Alpha-fetoprotein (AFP) Levels Greater than 1000. 

9.5.I.iii  
Lesions Eligible for Downstaging Protocols 
Candidates are eligible for a standardized MELD or PELD exception if, before 
completing locoregional therapy, they have lesions that meet one of the following 
criteria: 

• 
One Class 5 lesion greater than 5 cm and less than or equal to 8 cm 
• 
Two or three Class 5 lesions that meet all of the following:  
o 
at least one lesion greater than 3 cm 
o 
each lesion less than or equal to 5 cm, and 
o 
a total diameter of all lesions less than or equal to 8 cm 
• 
Four or five Class 5 lesions each less than 3 cm, and a total diameter of all 
lesions less than or equal to 8 cm 

For candidates who meet the downstaging criteria above and then complete 
locoregional therapy, the viable lesions must subsequently meet the size 
requirements for T2 stage according to OPTN Policy 9.5.I.ii: Eligible Candidates 
Definition of T2 Stage to be eligible for a standardized MELD or PELD exception. 
Downstaging to meet eligibility requirements for T2 stage must be demonstrated by 
multiphase contrast-enhanced CT or MRI performed after locoregional therapy. 
Candidates with lesions that do not initially meet the downstaging protocol 
inclusion criteria who are later downstaged and then meet eligibility for T2 stage are 
not automatically eligible for a standardized MELD or PELD exception and must be 
referred to the NLRB for consideration of a MELD or PELD exception. 

9.5.I.iv 
Candidates with Alpha-fetoprotein (AFP) Levels Greater than 
1000 
Candidates with lesions meeting T2 stage according to OPTN Policy 9.5.I.ii Eligible 
Candidates Definition of T2 Stage but with an alpha-fetoprotein (AFP) level greater 
than 1000 ng/mL may be treated with locoregional therapy. If the candidate’s AFP 
level falls below 500 ng/mL after treatment, the candidate is eligible for a 
standardized MELD or PELD exception as long as the candidate’s AFP level remains 

below 500 ng/mL. Candidates with an AFP level greater than or equal to 500 ng/mL 
following locoregional therapy at any time must be referred to the NLRB for 
consideration of a MELD or PELD exception.

---

## 9.5.I — Requirements for Hepatocellular Carcinoma (HCC) MELD or PELD Score (Part 2)

<!-- Policy: 9 | Section: 9.5.I | Category: Liver Allocation -->

9.5.I.v 
Requirements for Multiphase Contrast-enhanced CT or MRI of 
the Liver 
CT scans or MRIs performed for a HCC MELD or PELD score exception request must 
be interpreted by a radiologist at a transplant hospital. If the lesion cannot be 
categorized due to image degradation or omission, then the lesion will be classified 
as Not categorizable (NC) and imaging must be repeated or completed to receive an 
HCC MELD or PELD exception. If the lesion cannot be fully categorized due to image 
degradation or omission, then imaging must be repeated or completed. Contrast-
enhanced ultrasound (CEUS) can be used to determine class 5 classification, in 
accordance with Table 9-9. 
9.5.I.vi  
Imaging Requirements for Class 5 Lesions 
Lesions found on imaging in candidates at risk for HCC are classified according to 
Table 9-9. The imaging criteria within the table apply only to observations which do 
not represent benign lesions or non-HCC malignancy (i.e. targetoid or LR-M) by 
imaging. 

Table 9-9: Classification System for Lesions 
Seen on Imaging of Livers 
Class 
Description 
NC – Not 
Categorizable 
Incomplete or technically inadequate study due to image 
degradation or omission 
5A 
Must meet all of the following: 
• 
Maximum diameter of at least 1 cm and less than 2 cm, 
as measured on late arterial or portal phase images 
• 
Either of the following: 
o LI-RADS 5 classification on CT, MRI, or CEUS 
o Biopsy 
5B 
Must meet all of the following: 
• 
Maximum diameter of at least 2 cm and less than or 
equal to 5 cm, as measured on late arterial or portal 
phase images 
• 
Either of the following: 
o LI-RADS 5 classification on CT, MRI, or CEUS 
o Biopsy 
5T 
a. Any Class 5A, 5B lesion that was automatically approved 
upon initial request or extension and has subsequently 
been treated by locoregional therapy 

9.5.I.vii 
Extensions of HCC Exceptions 
A candidate with an approved exception for HCC is eligible for automatic approval of 
an extension if the transplant program enters a MELD or PELD Exception Score 
Extension Request that contains the following: 

1. Documentation of the tumor stage using multiphase contrast-enhanced CT or 
MRI 
2. The type of treatment if the number of tumors decreased since the last request 
3. The candidate’s alpha-fetoprotein (AFP) level 

A CT of the chest to rule out metastatic disease is not required after the initial 
exception request. 

The candidate’s exception extension will then be automatically approved unless any 
of the following occurs: 

• 
The candidate’s lesions progress beyond T2 criteria, according to OPTN 9.5.I.ii: 
Eligible Candidates Definition of T2 Stage  
• 
The candidate’s alpha-fetoprotein (AFP) level was less than or equal to 1,000 
ng/mL on the initial request but subsequently rises above 1,000 ng/mL 
• 
The candidate’s AFP level was greater than 1,000 ng/mL, the AFP level falls 
below 500 ng/mL after treatment but before the initial request, then the AFP 
level subsequently rises to greater than or equal to 500 ng/mL 
• 
The candidate’s tumors have been resected since the previous request 
• 
The program requests a score different from the scores assigned in Table 9-10. 

When a transplant program submits either an initial exception request or the first 
extension request for a liver candidate at least 18 years old at the time of 
registration that meets the requirements for a standardized MELD score exception, 
the candidate will appear on the match run according to the calculated MELD score. 

A candidate who meets these requirements for a MELD or PELD score exception for 
HCC will receive a score according to Table 9-10 below. 

Table 9-10: HCC Exception Scores 
Age 
Age at registration Exception Request 
Score  
At least 18 years 
old 
At least 18 years old Initial and first extension 
Calculated MELD 
At least 18 years 
old 
At least 18 years old Any extension after the first 
extension 
3 points below 
MMaT 
At least 12 years 
old 
Less than 18 years 
old 
Any 
40 
Less than 12 
years old 
Less than 12 years 
old 
Any 
40

---

## 9.6.A — Waiting Time for Liver Candidates

<!-- Policy: 9 | Section: 9.6.A | Category: Liver Allocation -->

Liver transplant candidates on the waiting list accrue waiting time within status 1A or 1B or any 
MELD or PELD score. 
 
Status 1A or 1B candidates will receive waiting time points based on their waiting time in that 
status, according to OPTN Policy 9.7.A: Points for Waiting Time. Status 1A candidates begin 
accruing waiting time at status 1A upon submission of the earliest Liver Status 1A or 1B 
Justification Form for the status 1A. Status 1B candidates begin accruing waiting time at status 
1B upon submission of the earliest Liver Status 1A or 1B Justification Form for status 1B. 
 
Candidates with a MELD or PELD score begin accruing waiting time when the candidate is first 
registered as an active liver candidate on the waiting list. 
 
Allocation MELD or PELD score waiting time is accrued as follows: 
• 
If the candidate’s allocation MELD or PELD score is based on a calculated MELD or PELD 
score, then allocation MELD or PELD score waiting time includes all waiting time at current 
or higher calculated MELD or PELD score, including liver-intestine points. Waiting time at 
current or higher calculated MELD or PELD score includes all of the following: 
1. Waiting time at current calculated MELD or PELD score, including liver-intestine 
points 
2. Previous waiting time accrued during an earlier period at current calculated MELD 
or PELD sore, including liver-intestine points 
3. Previous total waiting time accrued at any calculated MELD or PELD score higher 
than the current calculated MELD or PELD score, including liver-intestine points 
4. Previous total waiting time accrued at status 1A and status 1B 
 
• 
If the candidate’s allocation MELD or PELD score is an exception MELD or PELD score, then 
allocation MELD or PELD score waiting time equals time since submission of earliest 
approved or assigned MELD or PELD exception request, including time at an inactive status.

---

## 9.6.B — Waiting Time for Liver-Intestine Candidates

<!-- Policy: 9 | Section: 9.6.B | Category: Liver Allocation -->

Waiting time accrued by a candidate for an isolated intestinal organ transplant while waiting on 
the waiting list may also be applied for a combine liver-intestine transplant, when it is 
determined that the candidate requires both organs.

---

## 9.7 — Liver Allocation Points

<!-- Policy: 9 | Section: 9.7 | Category: Liver Allocation -->

Points are used for sorting liver candidates according to OPTN Policy 9.8.D: Sorting Within Each 
Classification.

---

## 9.7.A — Points for Waiting Time

<!-- Policy: 9 | Section: 9.7.A | Category: Liver Allocation -->

Points are assigned so that the status 1A or 1B candidate with the longest waiting time receives 
the most points as follows: 

 
 
 
 
• 
10 points for the candidate with the greatest total status 1A or status 1B waiting time within 
each classification 
• 
A fraction of 10 points divided up among the remaining status 1A or status 1B candidates 
within each classification, based on the potential recipient's total waiting time

---

## 9.7.B — Points Assigned by Blood Type

<!-- Policy: 9 | Section: 9.7.B | Category: Liver Allocation -->

For status 1A and 1B transplant candidates, those with the same blood type as the deceased 
liver donor will receive 10 points. Candidates with compatible but not identical blood types will 
receive 5 points, and candidates with incompatible types will receive 0 points. Blood type O 
candidates who will accept a liver from a blood type A, non-A1 blood type donor will receive 5 
points for blood type incompatible matching.

---

## 9.7.C — Points Assigned by Diagnosis

<!-- Policy: 9 | Section: 9.7.C | Category: Liver Allocation -->

Status 1B candidates will be assigned points based on diagnosis as follows:  
 
• 
If the candidate’s diagnosis is chronic liver disease, the candidate will receive 15 points. 
• 
If the candidate’s diagnosis is hepatoblastoma, the candidate will receive 5 points.  
• 
If the candidate’s diagnosis is an organic acidemia or urea cycle defect, the candidate will 
receive 0 points.  
• 
If the candidate has any other diagnosis, the candidate will receive 0 points.

---

## 9.8 — Liver Allocation, Classifications, and Rankings

<!-- Policy: 9 | Section: 9.8 | Category: Liver Allocation -->

Unless otherwise stated, all mentions of MELD or PELD in this section reference a candidate’s allocation 
MELD or PELD score.

---

## 9.8.A — Segmental Transplant and Allocation of Liver Segments

<!-- Policy: 9 | Section: 9.8.A | Category: Liver Allocation -->

If a transplant program accepts a liver and performs a segmental transplant, the host OPO must 
make reasonable attempts to offer the remaining segment according to the adult deceased 
donor liver match run. If the remaining segment has not been allocated by the time the 
deceased donor organ procurement has started, the transplant hospital must offer it to 
candidates registered with the transplant program, or any medically appropriate candidate on 
the waiting list.  
 
The match run will identify a donor’s liver as one with the potential to be split if the donor 
meets all the following criteria: 
 
1. Less than 40-years old 
2. On a single vasopressor or less 
3. Transaminases no greater than three times the normal level 
4. Body mass index (BMI) of 28 or less 
The deceased donor liver match run will also indicate if potential transplant recipients are 
willing to accept a segmental liver transplant. 

 
 
 
 
If the potential transplant recipient that receives the primary whole liver offer ultimately 
declines the liver, any subsequent segmental allocation must be relinquished so that the host 
OPO may reallocate the whole liver using the liver match run that corresponds to the deceased 
donor’s age.  
 
The transplant hospital that receives the primary whole liver offer will determine how the liver 
will be split.

---

## 9.8.B — Allocation of Livers for Other Methods of Hepatic Support

<!-- Policy: 9 | Section: 9.8.B | Category: Liver Allocation -->

A liver must be offered first for transplantation according to the match run before it is offered 
for use in other methods of hepatic support. If the liver is not accepted for transplant within 6 
hours of attempted allocation by the OPTN, the OPTN will offer the liver for other methods of 
hepatic support, according to Tables 9-11, 9-12, 9-13, 9-14, 9-15, and 9-16 below.

---

## 9.8.C — Allocation of Livers by Blood Type

<!-- Policy: 9 | Section: 9.8.C | Category: Liver Allocation -->

Livers from blood type O donors must be offered in the following order:  
 
1. Status 1A and 1B candidates, blood type O candidates, and blood type B candidates with a 
MELD or PELD score of at least 30 
2. Blood type B candidates with a MELD or PELD score less than 30 
3. Any remaining blood type compatible candidates 
 
For status 1A or 1B candidates or candidates with a MELD or PELD score ≥ 30, transplant 
hospitals may specify on the waiting list if those candidates will accept a liver from a deceased 
donor of any blood type. Candidates are given points depending on their blood type according 
to OPTN Policy 9.7.B: Points Assigned by Blood Type.

---

## 9.8.D — Sorting Within Each Classification

<!-- Policy: 9 | Section: 9.8.D | Category: Liver Allocation -->

Within each status 1A allocation classification, candidates are sorted in the following order: 
 
1. The sum of waiting time and blood type compatibility points, according to OPTN Policy 9.7: 
Liver Allocation Points (highest to lowest) 
2. Total waiting time at status 1A (highest to lowest) 
 
Within each status 1B allocation classification, candidates are sorted in the following order: 
 
1. The sum of waiting time, blood type compatibility, and diagnosis points according to OPTN 
Policy 9.7: Liver Allocation Points (highest to lowest) 
2. Total waiting time at status 1B (highest to lowest) 
 
Within each MELD or PELD score allocation classification, all candidates are sorted in the 
following order: 
 
1. Allocation MELD or PELD score (highest to lowest) 
2. Blood type compatibility (identical, compatible, then incompatible) 

 
 
 
3. Age at time of registration on the liver waitlist (less than 18 years old followed by 18 years 
or older) 
4. Allocation MELD or PELD score type (calculated, including liver-intestine points, then 
exception) 
5. Allocation MELD or PELD score waiting time (highest to lowest) 
6. Total waiting time (highest to lowest)

---

## 9.8.E — Allocation of Livers from Non-DCD Deceased Donors at Least 18 Years Old

<!-- Policy: 9 | Section: 9.8.E | Category: Liver Allocation -->

and Less than 70 Years Old 
Livers from non-DCD deceased donors at least 18 years old and less than 70 years old are 
allocated to candidates according to Table 9-11 below. 
Table 9-11: Allocation of Livers from Non-DCD Deceased Donors 
at Least 18 Years Old and Less than 70 Years Old 
Classification 
Candidates with a 
MELD or PELD score 
of at least 
And registered at a 
transplant hospital that 
is at or within this 
distance from a donor 
hospital 
Donor 
blood type 
Candidate 
blood type 
1 
Status 1A 
500NM 
Any 
Any 
2 
Status 1B 
500NM 
Any 
Any 
3 
Status 1A 
2,400NM and candidate 
is registered in Hawaii or 
1,100NM and candidate 
is registered in Puerto 
Rico 
Any 
Any 
4 
Status 1B 
2,400NM and candidate 
is registered in Hawaii or 
1,100NM and candidate 
is registered in Puerto 
Rico 
Any 
Any 
5 
37 
150NM 
O 
O or B 
6 
37 
150NM 
Non-O 
Any 
7 
37 
250NM 
O 
O or B 
8 
37 
250NM 
Non-O 
Any 
9 
37 
500NM 
O 
O or B 
10 
37 
500NM 
Non-O 
Any 

 
 
 
Classification 
Candidates with a 
MELD or PELD score 
of at least 
And registered at a 
transplant hospital that 
is at or within this 
distance from a donor 
hospital 
Donor 
blood type 
Candidate 
blood type 
11 
37 
2,400NM and candidate 
is registered in Hawaii or 
1,100NM and candidate 
is registered in Puerto 
Rico 
O 
O or B 
12 
37 
2,400NM and candidate 
is registered in Hawaii or 
1,100NM and candidate 
is registered in Puerto 
Rico 
Non-O 
Any 
13 
33 
150NM 
O 
O or B 
14 
33 
150NM 
Non-O 
Any 
15 
33 
250NM 
O 
O or B 
16 
33 
250NM 
Non-O 
Any 
17 
33 
500NM 
O 
O or B 
18 
33 
500NM 
Non-O 
Any 
19 
30 
150NM 
O 
O or B 
20 
29 
150NM 
O 
O 
21 
29 
150NM 
Non-O 
Any 
22 
30 
250NM 
O 
O or B 
23 
29 
250NM 
O 
O 
24 
29 
250NM 
Non-O 
Any 
25 
30 
500NM 
O 
O or B 
26 
29 
500NM 
O 
O 
27 
29 
500NM 
Non-O 
Any 

 
 
 
Classification 
Candidates with a 
MELD or PELD score 
of at least 
And registered at a 
transplant hospital that 
is at or within this 
distance from a donor 
hospital 
Donor 
blood type 
Candidate 
blood type 
28 
15 
150NM 
O 
O 
29 
15 
150NM 
Non-O 
Any 
30 
15 
250NM 
O 
O 
31 
15 
250NM 
Non-O 
Any 
32 
15 
500NM 
O 
O 
33 
15 
500NM 
Non-O 
Any 
34 
Status 1A 
Nation 
Any 
Any 
35 
Status 1B 
Nation 
Any 
Any 
36 
30 
Nation 
O 
O or B 
37 
15 
Nation 
O 
O 
38 
15 
Nation 
Non-O 
Any 
39 
Any 
150NM 
O 
O 
40 
Any 
150NM 
Non-O 
Any 
41 
Any 
250NM 
O 
O 
42 
Any 
250NM 
Non-O 
Any 
43 
Any 
500NM 
O 
O 
44 
Any 
500NM 
Non-O 
Any 
45 
Any 
Nation 
O 
O 
46 
Any 
Nation 
Non-O 
Any 
47 
29 
150NM 
O 
B 
48 
29 
250NM 
O 
B 

 
 
 
Classification 
Candidates with a 
MELD or PELD score 
of at least 
And registered at a 
transplant hospital that 
is at or within this 
distance from a donor 
hospital 
Donor 
blood type 
Candidate 
blood type 
49 
29 
500NM 
O 
B 
50 
15 
150NM 
O 
B 
51 
15 
250NM 
O 
B 
52 
15 
500NM 
O 
B 
53 
15 
Nation 
O 
B 
54 
Any 
150NM 
O 
B 
55 
Any 
250NM 
O 
B 
56 
Any 
500NM 
O 
B 
57 
Any 
Nation 
O 
B 
58 
37 
150NM 
O 
A or AB 
59 
37 
250NM 
O 
A or AB 
60 
37 
500NM 
O 
A or AB 
61 
33 
150NM 
O 
A or AB 
62 
33 
250NM 
O 
A or AB 
63 
33 
500NM 
O 
A or AB 
64 
29 
150NM 
O 
A or AB 
65 
29 
250NM 
O 
A or AB 
66 
29 
500NM 
O 
A or AB 
67 
15 
150NM 
O 
A or AB 
68 
15 
250NM 
O 
A or AB 
69 
15 
500NM 
O 
A or AB 

 
 
 
Classification 
Candidates with a 
MELD or PELD score 
of at least 
And registered at a 
transplant hospital that 
is at or within this 
distance from a donor 
hospital 
Donor 
blood type 
Candidate 
blood type 
70 
15 
Nation 
O 
A or AB 
71 
Any 
150NM 
O 
A or AB 
72 
Any 
250NM 
O 
A or AB 
73 
Any 
500NM 
O 
A or AB 
74 
Any 
Nation 
O 
A or AB 
75 
Status 1A, for other 
method of hepatic 
support 
Nation 
Any 
Any 
76 
Status 1B, for other 
method of hepatic 
support 
Nation 
Any 
Any 
77 
Any MELD or PELD 
for other method of 
hepatic support 
Nation 
Any 
Any

---

## 9.8.F — Allocation of Livers from Non-DCD Deceased Donors 11 to 17 Years Old

<!-- Policy: 9 | Section: 9.8.F | Category: Liver Allocation -->

Livers from non-DCD deceased donors 11 to 17 years old are allocated to candidates according 
to Table 9-12 below. 
Table 9-12: Allocation of Livers from Non-DCD Deceased Donors 11 to 17 Years Old 
Classification 
Candidates with a 
MELD or PELD score 
of at least 
And registered at a 
transplant hospital that 
is at or within this 
distance from a donor 
hospital 
Donor 
blood type 
Candidate 
blood type 
1 
 
 
 
 
 
 
 
 
 
 
 
 
 
Pediatric Status 1A 
500NM 
Any 
Any 
2 
 
 
 
 
 
 
 
 
 
 
 
Adult Status 1A 
500NM 
Any 
Any 

 
 
 
Classification 
Candidates with a 
MELD or PELD score 
of at least 
And registered at a 
transplant hospital that 
is at or within this 
distance from a donor 
hospital 
Donor 
blood type 
Candidate 
blood type 
3 
 
 
 
 
 
 
 
 
 
Pediatric Status 1B 
500NM 
Any 
Any 
4 
 
 
 
 
 
 
 
 
Pediatric Status 1A 
2,400NM and candidate 
is registered in Hawaii or 
1,100NM and candidate 
is registered in Puerto 
Rico 
Any 
Any 
5 
Adult Status 1A 
2,400NM and candidate 
is registered in Hawaii or 
1,100NM and candidate 
is registered in Puerto 
Rico 
Any 
Any 
6 
Pediatric Status 1B 
2,400NM and candidate 
is registered in Hawaii or 
1,100NM and candidate 
is registered in Puerto 
Rico 
Any 
Any 
7 
PELD of at least 37 
500NM 
O 
O or B 
8 
PELD of at least 37 
500NM 
Non-O 
Any 

 
 
 
Classification 
Candidates with a 
MELD or PELD score 
of at least 
And registered at a 
transplant hospital that 
is at or within this 
distance from a donor 
hospital 
Donor 
blood type 
Candidate 
blood type 
9 
PELD of at least 37 
2,400NM and candidate 
is registered in Hawaii or 
1,100NM and candidate 
is registered in Puerto 
Rico 
O 
O or B 
10 
PELD of at least 37 
2,400NM and candidate 
is registered in Hawaii or 
1,100NM and candidate 
is registered in Puerto 
Rico 
Non-O 
Any 
11 
PELD of at least 30 
500NM 
O 
O or B 
12 
Any PELD 
500NM 
O 
O 
13 
Any PELD 
500NM 
Non-O 
Any 
14 
MELD of at least 37 
and candidate is less 
than 18 years old at 
registration 
500NM 
O 
O or B 
15 
MELD of at least 37 
and candidate is less 
than 18 years old at 
registration 
500NM 
Non-O 
Any 
16 
MELD of at least 37 
and candidate is less 
than 18 years old at 
registration 
2,400NM and candidate 
is registered in Hawaii or 
1,100NM and candidate 
is registered in Puerto 
Rico 
O 
O or B 
17 
MELD of at least 37 
and candidate is less 
than 18 years old at 
registration 
2,400NM and candidate 
is registered in Hawaii or 
1,100NM and candidate 
is registered in Puerto 
Rico 
Non-O 
Any 

 
 
 
Classification 
Candidates with a 
MELD or PELD score 
of at least 
And registered at a 
transplant hospital that 
is at or within this 
distance from a donor 
hospital 
Donor 
blood type 
Candidate 
blood type 
18 
MELD of at least 30 
and candidate is less 
than 18 years old at 
registration 
500NM 
O 
O or B 
19 
Any MELD and 
candidate is less than 
18 years old at 
registration  
500NM 
O 
O 
20 
Any MELD and 
candidate is less than 
18 years old at 
registration  
500NM 
Non-O 
Any 
21 
Pediatric Status 1A 
Nation 
Any 
Any 
22 
Adult Status 1A 
Nation 
Any 
Any 
23 
Pediatric Status 1B 
Nation 
Any 
Any 
24 
PELD score of at least 
30 
Nation 
O 
O or B 
25 
Any PELD 
Nation 
O 
O 
26 
Any PELD 
Nation 
Non-O 
Any 
27 
MELD of at least 30 
and candidate is less 
than 18 years old at 
registration 
Nation 
O 
O or B 
28 
Any MELD and 
candidate is less than 
18 years old at 
registration 
Nation 
O 
O 
29 
Any MELD and 
candidate is less than 
18 years old at 
registration 
Nation 
Non-O 
Any 

 
 
 
Classification 
Candidates with a 
MELD or PELD score 
of at least 
And registered at a 
transplant hospital that 
is at or within this 
distance from a donor 
hospital 
Donor 
blood type 
Candidate 
blood type 
30 
MELD of at least 30 
and candidate is at 
least 18 years old at 
registration 
500NM 
O 
O or B 
31 
Any MELD and 
candidate is at least 
18 years old at 
registration 
500NM 
O 
O 
32 
Any MELD and 
candidate is at least 
18 years old at 
registration 
500NM 
Non-O 
Any 
33 
MELD of at least 30 
and candidate is at 
least 18 years old at 
registration 
Nation 
O 
O or B 
34 
Any MELD and 
candidate is at least 
18 years old at 
registration 
Nation 
O 
O 
35 
Any MELD and 
candidate is at least 
18 years old at 
registration 
Nation 
Non-O 
Any 
36 
Any PELD  
500NM 
O 
B 
37 
Any MELD and 
candidate is less than 
18 years old at 
registration 
500NM 
O 
B 
38 
Any PELD 
Nation 
O 
B 

 
 
 
Classification 
Candidates with a 
MELD or PELD score 
of at least 
And registered at a 
transplant hospital that 
is at or within this 
distance from a donor 
hospital 
Donor 
blood type 
Candidate 
blood type 
39 
Any MELD and 
candidate is less than 
18 years old at 
registration 
Nation 
O 
B 
40 
Any MELD and 
candidate is at least 
18 years old at 
registration 
500NM 
O 
B 
41 
Any MELD and 
candidate is at least 
18 years old at 
registration 
Nation 
O 
B 
42 
Any PELD  
500NM 
O 
A or AB 
43 
Any MELD and 
candidate is less than 
18 years old at 
registration 
500NM 
O 
A or AB 
44 
Any PELD 
Nation 
O 
A or AB 
45 
Any MELD and 
candidate is less than 
18 years old at 
registration 
Nation 
O 
A or AB 
46 
Any MELD and 
candidate is at least 
18 years old at 
registration 
500NM 
O 
A or AB 
47 
Any MELD and 
candidate is at least 
18 years old at 
registration 
Nation 
O 
A or AB 

 
 
 
Classification 
Candidates with a 
MELD or PELD score 
of at least 
And registered at a 
transplant hospital that 
is at or within this 
distance from a donor 
hospital 
Donor 
blood type 
Candidate 
blood type 
48 
Adult or Pediatric 
Status 1A, for other 
method of hepatic 
support 
Nation 
Any 
Any 
49 
Pediatric Status 1B, 
for other method of 
hepatic support 
Nation 
Any 
Any 
50 
Any MELD or PELD 
for other method of 
hepatic support 
Nation 
Any 
Any

---

## 9.8.G — Allocation of Livers from Non-DCD Deceased Donors Less than 11 Years Old

<!-- Policy: 9 | Section: 9.8.G | Category: Liver Allocation -->

Livers from non-DCD donors less than 11 years old are allocated to candidates according to  
Table 9-13 below. 
Table 9-13: Allocation of Livers from Non-DCD Deceased Donors 
Less than 11 Years Old 
Classification 
Candidates with a 
MELD or PELD score 
of at least 
And registered at a 
transplant hospital that 
is at or within this 
distance from a donor 
hospital 
Donor 
blood type 
Candidate 
blood type 
1 
Pediatric Status 1A 
500NM 
Any 
Any 
2 
Pediatric Status 1A 
and candidate is less 
than 12 years old 
Nation 
Any 
Any 
3 
Adult Status 1A 
500NM 
Any 
Any 
4 
Pediatric Status 1B  
500NM 
Any 
Any 
5 
Pediatric Status 1A 
and candidate is at 
least 12 years old  
2,400NM and candidate 
is registered in Hawaii or 
1,100NM and candidate 
is registered in Puerto 
Rico 
Any 
Any 

 
 
 
Classification 
Candidates with a 
MELD or PELD score 
of at least 
And registered at a 
transplant hospital that 
is at or within this 
distance from a donor 
hospital 
Donor 
blood type 
Candidate 
blood type 
6 
Adult Status 1A 
2,400NM and candidate 
is registered in Hawaii or 
1,100NM and candidate 
is registered in Puerto 
Rico 
Any 
Any 
7 
Pediatric Status 1B  
2,400NM and candidate 
is registered in Hawaii or 
1,100NM and candidate 
is registered in Puerto 
Rico 
Any 
Any 
8 
PELD of at least 37 
500NM 
O 
O or B 
9 
PELD of at least 37 
500NM 
Non-O 
Any 
10 
PELD of at least 37 
2,400NM and candidate 
is registered in Hawaii or 
1,100NM and candidate 
is registered in Puerto 
Rico 
O 
O or B 
11 
PELD of at least 37 
2,400NM and candidate 
is registered in Hawaii or 
1,100NM and candidate 
is registered in Puerto 
Rico 
Non-O 
Any 
12 
PELD of at least 30 
500NM 
O 
O or B 
13 
Any PELD 
500NM 
O 
O 
14 
Any PELD 
500NM 
Non-O 
Any 
15 
MELD of at least 37 
and candidate is less 
than 18 years old at 
registration 
500NM 
O 
O or B 

 
 
 
Classification 
Candidates with a 
MELD or PELD score 
of at least 
And registered at a 
transplant hospital that 
is at or within this 
distance from a donor 
hospital 
Donor 
blood type 
Candidate 
blood type 
16 
MELD of at least 37 
and candidate is less 
than 18 years old at 
registration 
500NM 
Non-O 
Any 
17 
MELD of at least 37 
and candidate is less 
than 18 years old at 
registration 
2,400NM and candidate 
is registered in Hawaii or 
1,100NM and candidate 
is registered in Puerto 
Rico 
O 
O or B 
18 
MELD of at least 37 
and candidate is less 
than 18 years old at 
registration 
2,400NM and candidate 
is registered in Hawaii or 
1,100NM and candidate 
is registered in Puerto 
Rico 
Non-O 
Any 
19 
MELD of at least 30 
and candidate is less 
than 18 years old at 
registration 
500NM 
O 
O or B 
20 
Any MELD and 
candidate is less than 
18 years old at 
registration 
500NM 
O 
O 
21 
Any MELD and 
candidate is less than 
18 years old at 
registration 
500NM 
Non-O 
Any 
22 
Pediatric Status 1A 
and candidate is at 
least 12 years old 
Nation 
Any 
Any 
23 
Adult Status 1A 
Nation 
Any 
Any 
24 
Pediatric Status 1B 
Nation 
Any 
Any 
25 
PELD of at least 30 
Nation 
O 
O or B 

 
 
 
Classification 
Candidates with a 
MELD or PELD score 
of at least 
And registered at a 
transplant hospital that 
is at or within this 
distance from a donor 
hospital 
Donor 
blood type 
Candidate 
blood type 
26 
Any PELD 
Nation 
O 
O 
27 
Any PELD 
Nation 
Non-O 
Any 
28 
MELD of at least 30 
and candidate is less 
than 18 years old at 
registration 
Nation 
O 
O or B 
29 
Any MELD and 
candidate is less than 
18 years old at 
registration  
Nation 
O 
O 
30 
Any MELD and less 
than 18 years old at 
registration  
Nation 
Non-O 
Any 
31 
MELD of at least 30 
and candidate is at 
least 18 years old at 
registration 
500NM 
O 
O or B 
32 
Any MELD and 
candidate is at least 
18 years old at 
registration 
500NM 
O 
O 
33 
Any MELD and at 
least 18 years old at 
registration 
500NM 
Non-O 
Any 
34 
MELD of at least 30 
and at least 18 years 
old at registration 
Nation 
O 
O or B 
35 
Any MELD and at 
least 18 years old at 
registration 
Nation 
O 
O 

 
 
 
Classification 
Candidates with a 
MELD or PELD score 
of at least 
And registered at a 
transplant hospital that 
is at or within this 
distance from a donor 
hospital 
Donor 
blood type 
Candidate 
blood type 
36 
Any MELD and at 
least 18 years old at 
registration 
Nation 
Non-O 
Any 
37 
Any PELD 
500NM 
O 
B 
38 
Any MELD and 
candidate is less than 
18 years old at 
registration 
500NM 
O 
B 
39 
Any PELD 
Nation 
O 
B 
40 
Any MELD and 
candidate is less than 
18 years old at 
registration 
Nation 
O 
B 
41 
Any MELD and 
candidate is at least 
18 years old at 
registration 
500NM 
O 
B 
42 
Any MELD and 
candidate is at least 
18 years old at 
registration 
Nation 
O 
B 
43 
Any PELD 
500NM 
O 
A or AB 
44 
Any MELD and 
candidate is less than 
18 years old at 
registration 
500NM 
O 
A or AB 
45 
Any PELD 
Nation 
O 
A or AB 
46 
Any MELD and 
candidate is less than 
18 years old at 
registration 
Nation 
O 
A or AB 

 
 
 
Classification 
Candidates with a 
MELD or PELD score 
of at least 
And registered at a 
transplant hospital that 
is at or within this 
distance from a donor 
hospital 
Donor 
blood type 
Candidate 
blood type 
47 
Any MELD and 
candidate is at least 
18 years old at 
registration 
500NM 
O 
A or AB 
48 
Any MELD and 
candidate is at least 
18 years old at 
registration 
Nation 
O 
A or AB 
49 
Status 1A, for other 
method of hepatic 
support 
Nation 
Any 
Any 
50 
Status 1B, for other 
method of hepatic 
support 
Nation 
Any 
Any 
51 
Any MELD or PELD 
for other method of 
hepatic support 
Nation 
Any 
Any

---

## 9.8.H — Allocation of Livers and Liver-Intestines from DCD Donors or Donors at

<!-- Policy: 9 | Section: 9.8.H | Category: Liver Allocation -->

Least 70 Years Old 
Livers and liver-intestines from DCD donors or donors at least 70 years old are allocated to 
candidates according to Table 9-14. 
 
Table 9-14: Allocation of Livers and Liver-Intestines from DCD Donors or  
Donors at Least 70 Years Old 
Classification 
Candidates with a 
MELD or PELD 
score of at least 
And registered at a transplant 
hospital that is at or within 
this distance from a donor 
hospital 
Donor 
blood 
type 
Candidate 
blood 
type 
1 
Status 1A 
500NM 
Any 
Any 
2 
Status 1B 
500NM 
Any 
Any 
3 
30 
150NM 
O 
O or B 
4 
15 
150NM 
O 
O 
5 
15 
150NM 
Non-O 
Any 
6 
30 
250NM 
O 
O or B 
7 
15 
250NM 
O 
O 
8 
15 
250NM 
Non-O 
Any 
9 
30 
500NM 
O 
O or B 
10 
15 
500NM 
O 
O 
11 
15 
500NM 
Non-O 
Any 
12 
Status 1A 
Nation 
Any 
Any 
13 
Status 1B 
Nation 
Any 
Any 
14 
30 
Nation 
O 
O or B 
15 
15 
Nation 
O 
O 
16 
15 
Nation 
Non-O 
Any 
17 
Any 
150NM 
O 
O 
18 
Any 
150NM 
Non-O 
Any 
19 
Any 
250NM 
O 
O 
20 
Any 
250NM 
Non-O 
Any 
21 
Any 
500NM 
O 
O 
22 
Any 
500NM 
Non-O 
Any 
23 
Any 
Nation 
O 
O 
24 
Any 
Nation 
Non-O 
Any 
25 
15 
150NM 
O 
B 

 
 
 
Classification 
Candidates with a 
MELD or PELD 
score of at least 
And registered at a transplant 
hospital that is at or within 
this distance from a donor 
hospital 
Donor 
blood 
type 
Candidate 
blood 
type 
26 
15 
250NM 
O 
B 
27 
15 
500NM 
O 
B 
28 
15  
Nation 
O 
B 
29 
Any 
150NM 
O 
B 
30 
Any 
250NM 
O 
B 
31 
Any 
500NM 
O 
B 
32 
Any 
Nation 
O 
B 
33 
15  
150NM 
O 
A or AB 
34 
15 
250NM 
O 
A or AB 
35 
15 
500NM 
O 
A or AB 
36 
15  
Nation 
O 
A or AB 
37 
Any 
150NM 
O 
A or AB 
38 
Any 
250NM 
O 
A or AB 
39 
Any  
500NM 
O 
A or AB 
40 
Any  
Nation 
O 
A or AB 
41 
Status 1A, for 
other method of 
hepatic support 
Nation 
Any 
Any 
42 
Status 1B, for 
other method of 
hepatic support 
Nation 
Any 
Any 
43 
Any MELD or PELD 
for other method 
of hepatic support 
Nation 
Any 
Any

---

## 9.8.I — Allocation of Liver-Intestines from Non-DCD Deceased Donors at Least 18

<!-- Policy: 9 | Section: 9.8.I | Category: Liver Allocation -->

Years Old and Less than 70 Years Old 
Livers and intestines from non-DCD deceased donors at least 18 years old and less than 70 years 
old are allocated to candidates according to Table 9-15 below: 
Table 9-15: Allocation of Liver-Intestines from Non-DCD Deceased Donors at Least 18 Years Old 
and Less than 70 Years Old 
Classification 
Candidates with a 
MELD or PELD score 
of at least 
And registered at a 
transplant hospital that 
is at or within this 
distance from a donor 
hospital 
Donor 
blood type 
Candidate 
blood type 
1 
Status 1A 
500NM 
Any 
Any 
2 
Status 1B 
500NM 
Any 
Any 
3 
Status 1A 
2,400NM and candidate 
is registered in Hawaii or 
1,100NM and candidate 
is registered in Puerto 
Rico 
Any 
Any 
4 
Status 1B 
2,400NM and candidate 
is registered in Hawaii or 
1,100NM and candidate 
is registered in Puerto 
Rico 
Any 
Any 
5 
37 
150NM 
O 
O or B 
6 
37 
150NM 
Non-O 
Any 
7 
37 
250NM 
O 
O or B 
8 
37 
250NM 
Non-O 
Any 
9 
37 
500NM 
O 
O or B 
10 
37 
500NM 
Non-O 
Any 
11 
37 
2,400NM and candidate 
is registered in Hawaii or 
1,100NM and candidate 
is registered in Puerto 
Rico 
O 
O or B 

 
 
 
Classification 
Candidates with a 
MELD or PELD score 
of at least 
And registered at a 
transplant hospital that 
is at or within this 
distance from a donor 
hospital 
Donor 
blood type 
Candidate 
blood type 
12 
37 
2,400NM and candidate 
is registered in Hawaii or 
1,100NM and candidate 
is registered in Puerto 
Rico 
Non-O 
Any 
13 
33 
150NM 
O 
O or B 
14 
33 
150NM 
Non-O 
Any 
15 
33 
250NM 
O  
O or B 
16 
33 
250NM 
Non-O 
Any 
17 
33 
500NM 
O 
O or B 
18 
33 
500NM 
Non-O 
Any 
19 
30 
150NM 
O 
O or B 
20 
29 
150NM 
O  
O 
21 
29 
150NM 
Non-O 
Any 
22 
30 
250NM 
O 
O or B 
23 
29 
250NM 
O 
O 
24 
29 
250NM 
Non-O 
Any 
25 
30 
500NM 
O 
O or B 
26 
29 
500NM 
O 
O 
27 
29 
500NM 
Non-O 
Any 
28 
Status 1A and also 
registered for an 
intestine 
Nation 
Any 
Any 

 
 
 
Classification 
Candidates with a 
MELD or PELD score 
of at least 
And registered at a 
transplant hospital that 
is at or within this 
distance from a donor 
hospital 
Donor 
blood type 
Candidate 
blood type 
29 
Status 1B and also 
registered for an 
intestine 
Nation 
Any 
Any 
30 
30 and also 
registered for an 
intestine 
Nation 
O 
O or B 
31 
Any and also 
registered for an 
intestine 
Nation 
O 
O 
32 
Any and also 
registered for an 
intestine 
Nation 
Non-O 
Any 
33 
15 
150NM 
O 
O 
34 
15 
150NM 
Non-O 
Any 
35 
15 
250NM 
O 
O 
36 
15 
250NM 
Non-O 
Any 
37 
15 
500NM 
O 
O 
38 
15 
500NM 
Non-O 
Any 
39 
Status 1A 
Nation 
Any 
Any 
40 
Status 1B 
Nation 
Any 
Any 
41 
30 
Nation 
O 
O or B 
42 
15 
Nation 
O 
O 
43 
15 
Nation 
Non-O 
Any 
44 
Any 
150NM 
O 
O 
45 
Any 
150NM 
Non-O 
Any 

 
 
 
Classification 
Candidates with a 
MELD or PELD score 
of at least 
And registered at a 
transplant hospital that 
is at or within this 
distance from a donor 
hospital 
Donor 
blood type 
Candidate 
blood type 
46 
Any 
250NM 
O 
O 
47 
Any 
250NM 
Non-O 
Any 
48 
Any 
500NM 
O 
O 
49 
Any 
500NM 
Non-O 
Any 
50 
Any 
Nation 
O 
O 
51 
Any 
Nation 
Non-O 
Any 
52 
29 
150NM 
O 
B 
53 
29 
250NM 
O 
B 
54 
29 
500NM 
O 
B 
55 
Any and also 
registered for an 
intestine 
Nation 
O 
B 
56 
15 
150NM 
O 
B 
57 
15 
250NM 
O 
B 
58 
15 
500NM 
O 
B 
59 
15 
Nation 
O 
B 
60 
Any 
150NM 
O 
B 
61 
Any 
250NM 
O 
B 
62 
Any 
500NM 
O 
B 
63 
Any 
Nation 
O 
B 
64 
37 
150NM 
O 
A or AB 
65 
37 
250NM 
O 
A or AB 

 
 
 
Classification 
Candidates with a 
MELD or PELD score 
of at least 
And registered at a 
transplant hospital that 
is at or within this 
distance from a donor 
hospital 
Donor 
blood type 
Candidate 
blood type 
66 
37 
500NM 
O 
A or AB 
67 
33 
150NM 
O 
A or AB 
68 
33 
250NM 
O 
A or AB 
69 
33 
500NM 
O 
A or AB 
70 
29 
150NM 
O 
A or AB 
71 
29 
250NM 
O 
A or AB 
72 
29 
500NM 
O 
A or AB 
73 
Any and also 
registered for an 
intestine 
Nation 
O 
A or AB 
74 
15 
150NM 
O 
A or AB 
75 
15 
250NM 
O 
A or AB 
76 
15 
500NM 
O 
A or AB 
77 
15 
Nation 
O 
A or AB 
78 
Any 
150NM 
O 
A or AB 
79 
Any 
250NM 
O 
A or AB 
80 
Any 
500NM 
O 
A or AB 
81 
Any 
Nation 
O 
A or AB 
82 
Status 1A, for other 
method of hepatic 
support 
Nation 
Any 
Any 
83 
Status 1B, for other 
method of hepatic 
support 
Nation 
Any 
Any 

 
 
 
Classification 
Candidates with a 
MELD or PELD score 
of at least 
And registered at a 
transplant hospital that 
is at or within this 
distance from a donor 
hospital 
Donor 
blood type 
Candidate 
blood type 
84 
Any MELD or PELD 
for other method of 
hepatic support 
Nation 
Any 
Any

---

## 9.8.J — Allocation of Liver-Intestines from Non-DCD Donors 11 to 17 Years Old

<!-- Policy: 9 | Section: 9.8.J | Category: Liver Allocation -->

For combined liver-intestine allocation from non-DCD donors 11 to 17 years old, the liver must 
first be offered as follows: 
  
• 
According to OPTN Policy 9.8.F: Allocation of Livers from Non-DCD Deceased Donors 11 to 17 
Years Old 
• 
Sequentially to each liver candidate, including all MELD and PELD candidates, through 
national status 1A and 1B offers 
  
The liver may then be offered to combined liver-intestine potential recipients sequentially 
according to the intestine match run.

---

## 9.8.K — Allocation of Liver-Intestines from Non-DCD Donors Less than 11 Years Old (Part 1)

<!-- Policy: 9 | Section: 9.8.K | Category: Liver Allocation -->

Livers and intestines from non-DCD donors less than 11 years old are allocated to candidates 
according to Table 9-16. 

Table 9-16: Allocation of Combined Liver-Intestines from Donors 
Less than 11 Years Old 
Classification 
Candidates with a 
MELD or PELD score 
of at least 
And registered at a 
transplant hospital that 
is at or within this 
distance from a donor 
hospital 
Donor 
blood type 
Candidate 
blood type 
1 
Pediatric Status 1A 
500NM 
Any 
Any 
2 
Pediatric Status 1A 
and candidate is less 
than 12 years old 
Nation 
Any 
Any 

Classification 
Candidates with a 
MELD or PELD score 
of at least 
And registered at a 
transplant hospital that 
is at or within this 
distance from a donor 
hospital 
Donor 
blood type 
Candidate 
blood type 
3 
Pediatric Status 1A, 
candidate is at least 
12 years old, and 
candidate is also 
registered for an 
intestine 
Nation 
Any 
Any 
4 
Adult Status 1A 
500NM 
Any 
Any 
5 
Pediatric Status 1B  
500NM 
Any 
Any 
6 
Pediatric Status 1A 
and candidate is at 
least 12 years old 
2,400NM and candidate 
is registered in Hawaii or 
1,100NM and candidate 
is registered in Puerto 
Rico 
Any 
Any 
7 
Adult Status 1A 
2,400NM and candidate 
is registered in Hawaii or 
1,100NM and candidate 
is registered in Puerto 
Rico 
Any 
Any 
8 
Pediatric Status 1B  
2,400NM and candidate 
is registered in Hawaii or 
1,100NM and candidate 
is registered in Puerto 
Rico 
Any 
Any 
9 
PELD of at least 37 
500NM 
O 
O or B 
10 
PELD of at least 37 
500NM 
Non-O 
Any 
11 
PELD of at least 37 
2,400NM and candidate 
is registered in Hawaii or 
1,100NM and candidate 
is registered in Puerto 
Rico 
O 
O or B 

Classification 
Candidates with a 
MELD or PELD score 
of at least 
And registered at a 
transplant hospital that 
is at or within this 
distance from a donor 
hospital 
Donor 
blood type 
Candidate 
blood type 
12 
PELD of at least 37 
2,400NM and candidate 
is registered in Hawaii or 
1,100NM and candidate 
is registered in Puerto 
Rico 
Non-O 
Any 
13 
PELD 30 
500NM 
O 
O or B 
14 
PELD 20 
500NM 
O 
O 
15 
PELD 20 
500NM 
Non-O 
Any 
16 
Pediatric Status 1B, 
and candidate is also 
registered for an 
intestine 
Nation 
Any 
Any 
17 
PELD of at least 30 
and candidate is also 
registered for an 
intestine 
Nation 
O 
O or B 
18 
PELD of at least 20 
and candidate is also 
registered for an 
intestine 
Nation 
O 
O 
19 
PELD of at least 20 
and candidate is also 
registered for an 
intestine 
Nation 
Non-O 
Any 
20 
Any PELD 
500NM 
O 
O 
21 
Any PELD 
500NM 
Non-O 
Any 
22 
MELD of at least 37 
and candidate is less 
than 18 years old at 
registration 
500NM 
O 
O or B 

Classification 
Candidates with a 
MELD or PELD score 
of at least 
And registered at a 
transplant hospital that 
is at or within this 
distance from a donor 
hospital 
Donor 
blood type 
Candidate 
blood type 
23 
MELD of at least 37 
and candidate is less 
than 18 years old at 
registration 
500NM 
Non-O 
Any 
24 
MELD of at least 37 
and candidate is less 
than 18 years old at 
registration 
2,400NM and candidate 
is registered in Hawaii or 
1,100NM and candidate 
is registered in Puerto 
Rico 
O 
O or B 
25 
MELD of at least 37 
and candidate is less 
than 18 years old at 
registration 
2,400NM and candidate 
is registered in Hawaii or 
1,100NM and candidate 
is registered in Puerto 
Rico 
Non-O 
Any 
26 
MELD of at least 30 
and less than 18 
years old at 
registration 
500NM 
O 
O or B 
27 
Any MELD and less 
than 18 years old at 
registration 
500NM 
O 
O 
28 
Any MELD, candidate 
is less than 18 years 
old at registration 
500NM 
Non-O 
Any 
29 
Pediatric Status 1A 
and at least 12 years 
old 
Nation 
Any 
Any 
30 
Adult Status 1A 
Nation 
Any 
Any 
31 
Pediatric Status 1B 
Nation 
Any 
Any 
32 
PELD at least 30 
Nation 
O 
O or B 
33 
Any PELD 
Nation 
O 
O 

Classification 
Candidates with a 
MELD or PELD score 
of at least 
And registered at a 
transplant hospital that 
is at or within this 
distance from a donor 
hospital 
Donor 
blood type 
Candidate 
blood type 
34 
Any PELD 
Nation 
Non-O 
Any 
35 
MELD of at least 30 
and less than 18 
years old at 
registration 
Nation 
O 
O or B 
36 
Any MELD and less 
than 18 years old at 
registration  
Nation 
O 
O 
37 
Any MELD and less 
than 18 years old at 
registration  
Nation 
Non-O 
Any 
38 
MELD of at least 30 
and at least 18 years 
old at registration 
500NM 
O 
O or B 
39 
Any MELD and at 
least 18 years old at 
registration 
500NM 
O 
O 
40 
Any MELD and at 
least 18 years old at 
registration 
500NM 
Non-O 
Any 
41 
MELD of at least 30 
and at least 18 years 
old at registration 
Nation 
O 
O or B 
42 
Any MELD and at 
least 18 years old at 
registration 
Nation 
O 
O 
43 
Any MELD and at 
least 18 years old at 
registration 
Nation 
Non-O 
Any 
44 
PELD 20 
500NM 
O 
B 

Classification 
Candidates with a 
MELD or PELD score 
of at least 
And registered at a 
transplant hospital that 
is at or within this 
distance from a donor 
hospital 
Donor 
blood type 
Candidate 
blood type 
45 
PELD of at least 20 
and candidate is also 
registered for an 
intestine 
Nation 
O 
B 
46 
Any PELD 
500NM 
O 
B 
47 
Any MELD and 
candidate is less than 
18 years old at 
registration 
500NM 
O 
B 
48 
Any PELD 
Nation 
O 
B 
49 
Any MELD and 
candidate is less than 
18 years old at 
registration 
Nation 
O 
B 
50 
Any MELD and 
candidate is at least 
18 years old at 
registration 
500NM 
O 
B 
51 
Any MELD and 
candidate is at least 
18 years old at 
registration 
Nation 
O 
B 
52 
PELD 20 
500NM 
O 
A or AB 
53 
PELD of at least 20 
and candidate is also 
registered for an 
intestine 
Nation 
O 
A or AB 
54 
Any PELD 
500NM 
O 
A or AB 
55 
Any MELD and 
candidate is less than 
18 years old at 
registration 
500NM 
O 
A or AB

---

## 9.8.K — Allocation of Liver-Intestines from Non-DCD Donors Less than 11 Years Old (Part 2)

<!-- Policy: 9 | Section: 9.8.K | Category: Liver Allocation -->

Classification 
Candidates with a 
MELD or PELD score 
of at least 
And registered at a 
transplant hospital that 
is at or within this 
distance from a donor 
hospital 
Donor 
blood type 
Candidate 
blood type 
56 
Any PELD 
Nation 
O 
A or AB 
57 
Any MELD, candidate 
is less than 18 years 
old at registration 
Nation 
O 
A or AB 
58 
Any MELD, candidate 
is at least 18 years 
old at registration 
500NM 
O 
A or AB 
59 
Any MELD, candidate 
is at least 18 years 
old at registration 
Nation 
O 
A or AB 
60 
Adult or Pediatric 
Status 1A, for other 
method of hepatic 
support 
Nation 
Any 
Any 
61 
Pediatric Status 1B, 
for other method of 
hepatic support 
Nation 
Any 
Any 
62 
Any MELD or PELD 
for other method of 
hepatic support 
Nation 
Any 
Any

---

## 9.9 — Liver-Kidney Allocation

<!-- Policy: 9 | Section: 9.9 | Category: Liver Allocation -->

Unless otherwise stated, all mentions of MELD in this section reference a candidate’s allocation MELD 
score. 
 
When an OPO is offering a liver, and a kidney is also available from the same deceased donor, then 
before allocating the kidney to kidney alone candidates, the OPO must offer the kidney to a potential 
transplant recipient (PTR) who is registered for a liver and a kidney at the same transplant hospital, and 
who meets one of the following criteria: 
a) PTR was less than 18 years old when registered on the liver waiting list 
b) PTR is registered at a transplant hospital at or within 150 nautical miles of the donor hospital and 
has a MELD of 15 or greater and meets eligibility criteria according to Table 9-17: Medical Eligibility 
Criteria for Liver-Kidney Allocation 

 
 
 
c) PTR is registered at a transplant hospital at or within 500 nautical miles of the donor hospital and 
has a MELD of 29 or greater and meets eligibility criteria according to Table 9-17: Medical Eligibility 
Criteria for Liver-Kidney Allocation 
d) PTR is registered at a transplant hospital at or within 500 nautical miles of the donor hospital and is 
adult status 1A and meets eligibility criteria according to Table 9-17: Medical Eligibility Criteria for 
Liver-Kidney Allocation 
 
The OPO may then offer the kidney and liver to any PTRs who meet eligibility in Table 9-17: Medical 
Eligibility Criteria for Liver-Kidney Allocation, or offer the liver and the kidney separately according to 
policy.  
 
Table 9-17: Medical Eligibility Criteria for Liver-Kidney Allocation 
If the candidate’s transplant 
nephrologist confirms a diagnosis of:  
Then the transplant program must report to the OPTN and 
document in the candidate’s medical record: 
Chronic kidney disease (CKD) with a 
GFR less than or equal to 60 mL/min 
for greater than 90 consecutive days 
At least one of the following: 
• 
That the candidate has begun regularly administered 
dialysis as an end-stage renal disease (ESRD) patient in a 
hospital based, independent non-hospital based, or 
home setting. 
• 
At the time of registration on the kidney waiting list, that 
the candidate’s most recent GFR or measured or 
estimated creatinine clearance (CrCl) is less than or equal 
to 30 mL/min. 
• 
On a date after registration on the kidney waiting list, 
that the candidate’s GFR or measured or estimated CrCl 
is less than or equal to 30 mL/min. 
Sustained acute kidney injury 
At least one of the following, or a combination of both of the 
following, for the last 6 weeks: 
 
• 
That the candidate has been on dialysis at least once 
every 7 days. 
• 
That the candidate has a GFR or measured or estimated 
CrCl less than or equal to 25 mL/min at least once every 
7 days. 
 
If the candidate’s eligibility is not confirmed at least once 
every seven days for the last 6 weeks, the candidate is not 
eligible to receive a liver and a kidney from the same donor. 
Metabolic disease 
A diagnosis of at least one of the following: 
• 
Hyperoxaluria 
• 
Atypical hemolytic uremic syndrome (HUS) from 
mutations in factor H or factor I 
• 
Familial non-neuropathic systemic amyloidosis 
• 
Methylmalonic aciduria

---

## 9.10.A — Expedited Liver Placement Acceptance Criteria

<!-- Policy: 9 | Section: 9.10.A | Category: Liver Allocation -->

In order for a liver candidate to receive expedited offers as outlined in OPTN Policy 9.10.B: 
Expedited Liver Offers, the transplant hospital must report all of the following information to the 
OPTN: 
1. Agreement to accept a liver recovered by any procurement team 
2. The following liver acceptance criteria:  
o Minimum and maximum age 
o Maximum body mass index (BMI) 
o Maximum distance from the donor hospital 
o Minimum and maximum height 
o Percentage of macrosteatosis 
o Minimum and maximum weight

---

## 9.10.B — Expedited Liver Offers

<!-- Policy: 9 | Section: 9.10.B | Category: Liver Allocation -->

The host OPO or the Organ Center is permitted to make expedited liver offers if both of the 
following conditions are met: 
 
1. The donor has entered the operating room or, in the case of a DCD donor, withdrawal of life 
sustaining medical support has been initiated, whichever occurs first. 
2. The host OPO or Organ Center is notified by the primary transplant hospital that the primary 
potential transplant recipient will no longer accept the liver. 
 
Prior to sending expedited liver offers, the host OPO or Organ Center must report all of the 
following information to the OPTN: 
 
1. Date and time donor entered the operating room or withdrawal of life sustaining medical 
support was initiated, whichever occurs first. 
2. Date and time host OPO was notified by the primary transplant hospital that they will no 
longer accept the liver offer for the primary potential transplant recipient. 
3. Reason for organ offer refusal by the primary potential transplant recipient. 
 
Expedited liver offers will be made to potential transplant recipients on the match run who are 
eligible to receive expedited liver offers as described in OPTN Policy 9.10.A: Expedited Liver 
Placement Acceptance Criteria. 
 
Transplant hospitals must accept an expedited offer within 30 minutes of notification to be 
eligible to receive the liver. Once this time limit has expired, the host OPO or Organ Center must 
place the liver with the potential transplant recipient with the provisional yes that appears 
highest on the match run.

---

## 9.11.A — Registration Accuracy

<!-- Policy: 9 | Section: 9.11.A | Category: Liver Allocation -->

If a member questions the accuracy or appropriateness of a liver allocation or candidate status, 
the member may report it with reasons for the concern to the national liver review board 
(NLRB). The NLRB will retrospectively review the allocation or status. 
 
If the NLRB receives two or more reports about a member within any one year period, the NLRB 
will report it to the Membership and Professional Standards (MPSC) Committee and request an 
on-site review of the member.

---

## 9.11.B — Review of Status 1A and 1B Candidate Registrations

<!-- Policy: 9 | Section: 9.11.B | Category: Liver Allocation -->

If three or more status 1A or 1B candidate registrations at a transplant program are rejected and 
each of the candidates receives a transplant while registered at the rejected status, then the 
OPTN will conduct an on-site review of the transplant program’s status 1A and 1B candidate 
registrations. If the OPTN finds a Policy violation or inappropriate registrations, the transplant 
program will reimburse all necessary and reasonable expenses incurred by the OPTN in 
performing this review.

---

## 9.11.C — Location of Donor Hospitals

<!-- Policy: 9 | Section: 9.11.C | Category: Liver Allocation -->

For the purposes of determining the location of the donor hospital, livers, intestine, and liver-
intestine organs procured in Alaska will be considered procured from the Seattle Tacoma 
Airport, Seattle Washington.

---

## 9.12.A — Open Variance for Segmental Liver Transplantation

<!-- Policy: 9 | Section: 9.12.A | Category: Liver Allocation -->

This variance only applies when a transplant program transplants a right lobe or right tri-
segment of the liver.  
 
Under this variance, a transplant program may offer the remaining left lobe or left-lateral 
segment into a different, medically suitable, potential recipient registered at the same 
transplant hospital or an affiliated pediatric institution instead of offering the remaining 
segment to potential recipients at other transplant programs. The transplant program must 
determine potential recipient for the second segment by using the same match run used to 
allocate the right lobe or tri-segment. Additionally, the transplant program must document all 
refusals of potential transplant recipients that are prioritized ahead of the potential transplant 
recipient that received the second segment. 
 
Each participating region or DSA must meet to review the results of the first ten segmental liver 
transplants performed as a result of this variance, and each ten thereafter. If the re-transplant 
rate for segmental liver transplant recipients at any liver transplant program participating in the 
variance exceeds three within any sequential twenty transplants, the variance at that transplant 
program will be put on hold until the transplant program can review results and surgical 
practices.

---

## 9.12.B — Closed Variance for Allocation of Blood Type O Deceased Donor Livers

<!-- Policy: 9 | Section: 9.12.B | Category: Liver Allocation -->

This is a closed variance that applies only to liver and liver-intestine organs allocated by the 
OPOs in Hawaii and Puerto Rico to potential transplant recipients registered at transplant 
programs in Hawaii and Puerto Rico, respectively due to geographic location. This variance 
supersedes the treatment of blood type O donors according to OPTN Policy 9.8.C Allocation of 
Livers by Blood Type, and instead the OPO will allocate these blood type O organs to potential 
transplant recipients with any blood type within the same classification.

---

## 9.12.C — Closed Variance for Any Segment Liver Transplantation

<!-- Policy: 9 | Section: 9.12.C | Category: Liver Allocation -->

This is a closed variance. The OPTN maintains a list of participating transplant programs. 
 
If a participating transplant program chooses to split an accepted liver, the program will decide 
which segment of the liver to transplant into the intended recipient. The transplant program 
must notify the host OPO of the remaining segment prior to transplanting the remaining 
segment. The OPO must then offer the remaining segment to the following potential transplant 
recipients, using the same match run used to allocate the liver: 
 
• 
Lower-ranked status 1A and 1B potential transplant recipients registered at any transplant 
hospital within 500 nautical miles of the donor hospital 
• 
Lower-ranked potential transplant recipients with a MELD or PELD of 33 or higher that are 
registered at any transplant hospital within 500 nautical miles of the donor hospital 
If the remaining segment is not accepted for any of the potential transplant recipients in the 
bulleted classifications listed above, the OPO must notify the participating transplant program 
that accepted the liver. The participating transplant program may then transplant the remaining 
segment into a different, medically suitable, candidate registered at the same transplant 
hospital or an affiliated transplant program with an active pediatric liver component. If the first 
segment is accepted for a pediatric potential transplant recipient, the participating transplant 
program may transplant the remaining segment into a different, medically suitable, candidate at 
the same transplant hospital or an affiliated transplant program. For purposes of this variance, 
participating transplant programs may only have one affiliated transplant program and must 
identify the program they are affiliated with in their application for the variance. 
 
If the participating transplant program declines the remaining segment, the OPO may offer the 
remaining segment to any lower ranked potential transplant recipients off the same match run 
used to allocate the liver to the recipient of the first segment.

---

## 9.12.D — Closed Variance for Liver Transplantation in Hawaii and Puerto Rico

<!-- Policy: 9 | Section: 9.12.D | Category: Liver Allocation | Cross-ref: Policy 10 -->

This is a closed variance that applies only to liver and liver-intestine candidates registered at 
transplant programs in Hawaii or Puerto Rico, due to geographic location. This variance provides 
for additional classifications in the allocation sequences in OPTN Policies 9.8.E-9.8.J. The 
additional classifications apply to the following: 
• 
Candidates registered at transplant programs in Hawaii when the transplant hospital is at or 
within 2,400 NM of the donor hospital. 

 
 
 
• 
Candidates registered at transplant programs in Puerto Rico when the transplant hospital is 
at or within 1,100 NM of the donor hospital. 
 

 
 
 
Policy 10: Allocation of Lungs  
10.1 Lung Composite Allocation Score 
238 
10.2 Lung Composite Score Exceptions 
245 
10.3 Clinical Values and Update Schedule 
246 
10.4 Eligibility Criteria 
248

---
