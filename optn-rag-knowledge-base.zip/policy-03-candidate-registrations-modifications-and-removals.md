# OPTN Policy 3: Candidate Registrations, Modifications, and Removals

**Source:** OPTN Policies | **Effective:** 12/10/2025 | **Category:** Candidate Registration
**Confidence:** HIGH — Official OPTN policy language

---

## 3.1 — Access to OPTN Computer System

<!-- Policy: 3 | Section: 3.1 | Category: Candidate Registration -->

Transplant hospital, organ procurement organization, and histocompatibility laboratory members are 
provided access to the OPTN Computer System as members of the OPTN for the purposes of facilitating 
organ transplants, quality assurance and performance improvement (QAPI), and fulfilling OPTN 
Obligations, as defined in OPTN Management and Membership Policy Appendix M: Definitions. Business 
members may be granted access to the OPTN Computer System for the purposes of facilitating organ 
transplants and fulfilling OPTN Obligations, as defined in OPTN Management and Membership Policy 
Appendix M: Definitions, on behalf of affiliated transplant hospitals, OPOs, or histocompatibility labs. 
 
Transplant hospital, organ procurement organization, and histocompatibility laboratory members with 
access to the OPTN Computer System may authorize user access to the OPTN Computer System. 
 
Representatives of HRSA, HHS, and other components of the federal government are provided access to 
the OPTN Computer System as requested by the HRSA COR. 
 
Members must ensure that all users meet OPTN training requirements prior to establishing a user’s 
access to the OPTN computer system and yearly thereafter. Members must also ensure that all users 
comply with the OPTN Contractor’s system terms of use for the OPTN Computer System.

---

## 3.1.A — Conditions for Access to and Interconnection with the OPTN Computer

<!-- Policy: 3 | Section: 3.1.A | Category: Candidate Registration -->

System  
Members must have an active OPTN Interconnection Security Agreement (ISA) in order to 
interconnect with the OPTN Computer System, including interconnection via Application 
Programming Interface (API). The ISA must be executed by an individual authorized by the 
member organization within three months of being issued by the OPTN, reviewed annually, and 
renewed every three years. 
 

 
 
The member must execute a new ISA with the OPTN: 
• 
Upon change in any of the information provided by the member 
• 
If additional interconnections are required 
• 
If any of the requirements for interconnections change 
• 
At the request of the OPTN 
 
Members may not use the OPTN Computer System for non-members or allow non-members 
access to the OPTN Computer System. 
 
Transplant hospitals, OPOs, and histocompatibility labs may grant business members 
permissions to their patient-identified data in the OPTN Computer System if all of the following 
requirements are met: 
 
1. The business member is assisting the member with facilitating organ transplants or 
otherwise fulfilling OPTN Obligations, as defined in OPTN Management and Membership 
Policy Appendix M: Definitions. 
2. The business member users are granted access to the OPTN Computer System according to 
OPTN Policy 3.1.C.i: Business Member Users within the OPTN Computer System. 
3. The transplant hospital, OPO, or histocompatibility lab has a DUA with the business member 
with all of the following elements:  
a. Data confidentiality and security requirements 
b. Data rights  
c. Access to patient-identified data 
d. Data use 
e. Procedures for securing data confidentiality 
f. Storage or disposal of data upon completion of contracted task 
g. Procedures to protect patient-identified data in the event of a data breach, inadvertent 
or otherwise 
h. Remedies in the event of a violation of the DUA 
 
The member must maintain copies of all DUAs with business members. 
 
Business members accessing the OPTN Computer System must provide a list of all active OPTN 
members they are contracted with, update this list and report to the OPTN within 7 days of any 
changes, and verify the accuracy of this list upon request by the OPTN. Business members must 
also provide copies of their DUAs with each OPTN member they are contracted with to the 
OPTN upon request. 
 
If the business member is no longer contracted with any active OPTN members they must notify 
the OPTN within 7 days prior to the contract ending and their access to the OPTN Computer 
System will be removed upon contract end. 
 
Transplant hospitals, OPOs, and histocompatibility labs must notify the OPTN within 7 days prior 
to the contract ending when they are no longer contracted with a business member.

---

## 3.1.B — Security Requirements for Systems Accessing the OPTN Computer System

<!-- Policy: 3 | Section: 3.1.B | Category: Candidate Registration -->

Members must provide security for the computing environments and components thereof 
which are used to access the OPTN Computer System and the associated environments used to 
manage the member’s computing environment used to access the OPTN Computer System.  
 
Members must ensure that these environments adhere to a security framework that is either:  
• 
The most recent revision of a National Institute of Standards in Technology (NIST) 
information security framework or  
• 
A security framework with equivalent controls provided by the member and approved 
by the OPTN 
 
Members who authorize access to users must ensure that the user agrees to access the OPTN 
Computer System through computing environments that adhere to either the most recent 
revision of a NIST information security framework or a security framework with equivalent 
controls.  
 
Members must attest to their adherence to their security framework through an OPTN 
attestation. OPTN attestations must be submitted annually and upon request by the OPTN to 
maintain access to the OPTN Computer System. 
 
Adherence to the security framework will be audited at least once every three years. Members 
must also respond to OPTN requests for information within the timeframe stated by the OPTN.

---

## 3.1.C — Site Access Administrators

<!-- Policy: 3 | Section: 3.1.C | Category: Candidate Registration -->

Organ procurement organization and histocompatibility laboratory members with access to the 
OPTN Computer System must designate at least two site access administrators to maintain 
access to the OPTN Computer System. Transplant hospital members with access to the OPTN 
Computer System must designate at least two site access administrators for each of its 
designated transplant programs. 
 
Site access administrators are responsible for maintaining an accurate and current list of users 
and permissions, specific to the role of the user in their performance of duties related to OPTN 
Obligations. Permission levels must be granted according to the NIST principle of least privilege. 
 
Site access administrators must review and update user accounts and permission levels: 
• 
When a user is no longer associated with the member organization, as soon as possible, but 
no later than 24 hours after the user’s last day of employment 
• 
When the user’s roles or responsibilities have changed, such that a different level of 
permission is necessitated, as soon as possible, but no later than 24 hours from the change 
in roles or responsibilities 
• 
As directed by the OPTN, within the timeframe provided by the OPTN 
 
 
 

 
 
3.1.C.i Business Member Users within the OPTN Computer System 
Business member representatives are responsible for maintaining an accurate and 
current list of users. The list must include all organizations for which the user 
requires OPTN Computer System access. Business member representatives must 
review user accounts: 
• 
When a user is no longer associated with the business member 
• 
When a user’s affiliated organizations have changed 
• 
As directed by the OPTN 
Business member representatives must report changes in user accounts to the 
OPTN: 
• 
When a user is no longer associated with the business member, as soon as 
possible, but no later than 24 hours after the user’s last day of employment 
• 
As directed by the OPTN, within the timeframe provided by the OPTN 
Business member users are granted access to the OPTN Computer System by the 
OPTN Contractor. Business member users are granted permissions to data within 
the OPTN Computer System by the site access administrators at each affiliated 
organization according to the NIST principle of least privilege.

---

## 3.1.D — Security Incident and Privacy Incident Management and Reporting

<!-- Policy: 3 | Section: 3.1.D | Category: Candidate Registration -->

Members with access to the OPTN Computer System must develop and comply with an incident 
response plan designed to identify, prioritize, contain and eradicate security incidents and 
privacy incidents. The incident response plan must include all of the following: 
 
• 
Appointment of an information security contact, as detailed in OPTN Policy 3.1.D.i: 
Information Security Contact 
• 
Notification to the OPTN Contractor of security incidents occurring in any environment 
outlined in Policy 3.1.B: Security Requirements for Systems Accessing the OPTN Computer 
System, as soon as possible, but no later than: 
o 24 hours following the member becoming aware of the security 
incident if a member does not disconnect the affected users and any impacted 
systems from the OPTN Computer System 
o 72 hours following the member becoming aware of the security 
incident if the member does disconnect the affected users and any impacted 
systems from the OPTN Computer System 
• 
Notification to the OPTN Contractor of any privacy incident involving data obtained from the 
OPTN Computer System, except for data which a member incorporates into a member’s 
own system for candidate, recipient, or donor medical records. Notification must occur as 
soon as possible, but no later than 48 hours following the member becoming aware of the 
privacy incident. 
• 
Process for acquiring third party validation of proper containment, eradication, and 
successful recovery 
 

 
 
Portions of the incident response plan involving access to the OPTN Computer System must be 
made available to the OPTN on request and will be considered confidential. 
 
In the event of a security incident or privacy incident, members will be required to provide 
status updates to the OPTN on an agreed upon schedule and to meet control and verification 
requirements as provided by the OPTN based on the type of security incident or privacy 
incident. These requirements will be communicated directly to the member through the 
information security contact established in the member’s incident response plan. Members may 
also be required to provide a final incident report. 
 
Members may be required to take specific actions to appropriately ensure risk to the OPTN 
Computer System is managed and balanced with the need to ensure transplants continue. 
Specific actions may include on-site remediation, requiring the member’s access to the OPTN 
Computer System be temporarily removed until the OPTN has determined the risk is mitigated, 
or other containment and recovery actions with oversight by the OPTN. 
 
Any action that temporarily removes the member’s access to the OPTN Computer System must 
be directed by the OPTN or the Secretary of HHS. The OPTN Contractor may take other actions 
necessary to secure the OPTN Computer System on behalf of the OPTN. Any actions taken by 
the OPTN Contractor to secure the OPTN Computer System on behalf of the OPTN must be 
reported to the OPTN within 48 hours. 
 
3.1.D.i  Information Security Contact 
Members with access to the OPTN Computer System must identify an information 
security contact, who is responsible for maintaining and complying with a written 
protocol that includes how an information security contact will: 
 
1. Provide 24/7 capability for incident response and communications 
2. Receive relevant notifications of security incidents and privacy incidents 
from the member’s information security staff 
3. Communicate information regarding security incidents and privacy incidents 
to the OPTN 
4. Facilitate development and fulfillment of OPTN Obligations outlined in OPTN 
Policy 3.1.B: Security Requirements for Systems Accessing the OPTN 
Computer System

---

## 3.2 — Notifying Patients of Their Options

<!-- Policy: 3 | Section: 3.2 | Category: Candidate Registration -->

As part of the evaluation process, transplant programs must inform and provide each patient it 
evaluates with information and written materials explaining all of the following options: 
 
1. Registering at multiple transplant hospitals 
2. Transferring primary waiting time 
3. Transferring their care to a different transplant hospital without losing accrued waiting time 
 
Each transplant program must document that it fulfilled these requirements and maintain this 
documentation. 

 
 
 
Transplant programs must inform the patient before or during the evaluation process if either: 
 
1. The transplant program does not accept candidates with multiple registrations 
2. The transplant program does not allow candidates to transfer waiting time to their program

---

## 3.3 — Candidate Blood Type Determination and Reporting before

<!-- Policy: 3 | Section: 3.3 | Category: Candidate Registration -->

Waiting List Registration   
Transplant programs must develop and comply with a written protocol for blood type determination 
and reporting that includes all of the requirements below.

---

## 3.3.A — Candidate Blood Type Determination

<!-- Policy: 3 | Section: 3.3.A | Category: Candidate Registration -->

The transplant program must ensure that each candidate’s blood type is determined by testing 
at least two candidate blood samples prior to registration on the waiting list. 
 
Candidate blood samples must: 
 
1. Be drawn on two separate occasions 
2. Have different collection times 
3. Be submitted as separate samples 
 
The transplant program must include a process to address conflicting or indeterminate primary 
blood type results in their written protocol. 
 
The transplant program must document that blood type determination was conducted 
according to the program’s protocol and the above requirements.

---

## 3.3.B — Reporting of Candidate Blood Type

<!-- Policy: 3 | Section: 3.3.B | Category: Candidate Registration -->

The candidate is not eligible to appear on a match run until the transplant program completes 
verification and reporting as follows: 
 
1. Two different qualified health care professionals, as defined in the transplant program’s 
protocol, must each make an independent report of the candidate’s blood type to the OPTN 
2. Both qualified health care professionals must use all known available blood type 
determination source documents to verify they: 
a. Contain blood type results for the candidate 
b. Indicate the same blood type on the test results. If the results are conflicting or 
indeterminate, the transplant program must refer to their written protocol as outlined 
in Policy 3.3.A: Candidate Blood Type Determination.  
c. Match the result reported to the OPTN 
 
The transplant program must document that reporting was completed according to the 
program’s protocol and the above requirements.

---

## 3.4.A — Registration Fee

<!-- Policy: 3 | Section: 3.4.A | Category: Candidate Registration -->

The registration fee of $868 for the registration of a transplant candidate is authorized by 42 
C.F.R. § 121.5(c) and OPTN Management and Membership Policy F.2.D: Registration Fee.

---

## 3.4.B — Approved Transplant Program Requirement

<!-- Policy: 3 | Section: 3.4.B | Category: Candidate Registration -->

Members are only permitted to register a candidate on the waiting list for an organ at a 
transplant program if the transplant program has current OPTN transplant program approval for 
that organ type.

---

## 3.4.C — Candidate Registrations

<!-- Policy: 3 | Section: 3.4.C | Category: Candidate Registration -->

Transplant programs must: 
 
1. Register all recipients as candidates on the waiting list prior to transplant at the program 
that performs the organ transplant. 
2. Complete all candidate registrations, modifications, and removals in the waiting list. 
3. Register all multi-organ candidates on the waiting list for each required organ.

---

## 3.4.D — Candidate Human Leukocyte Antigen (HLA) Requirements

<!-- Policy: 3 | Section: 3.4.D | Category: Candidate Registration -->

The candidate’s transplant program must report to the OPTN complete human leukocyte 
antigen (HLA) information (at least 1A, 1B, and 1DR antigen) according to Table 3-1 below: 
 
Table 3-1: HLA Requirements 
If the candidate is registered for a… 
Then, HLA information is… 
Kidney alone 
Required 
Kidney–pancreas 
Required 
Kidney with any other non-renal organ 
Not required 
Pancreas alone 
Required 
Pancreas islet alone 
Required 
 
Transplant programs must report this HLA information using current World Health Organization 
(WHO) nomenclature when the candidate is registered on the waiting list.

---

## 3.4.E — Inactive Status

<!-- Policy: 3 | Section: 3.4.E | Category: Candidate Registration -->

If the candidate is temporarily unsuitable for transplant, then the candidate’s transplant 
program may classify the candidate as inactive and the candidate will not receive any organ 
offers.

---

## 3.4.F — Multiple Transplant Program Registrations

<!-- Policy: 3 | Section: 3.4.F | Category: Candidate Registration -->

Candidates may be registered for an organ at multiple transplant programs within the same 
Donation Service Area (DSA) or different DSAs. A transplant program may choose whether or 
not to accept a candidate seeking multiple registrations for an organ. 
 
Transplant hospitals may access a report from the OPTN that identifies any candidates that have 
multiple registrations for the same organ. This report will not include the identities of the other 
hospitals where the candidates are registered. 
 
 

 
 
3.5 Patient Notification   
Transplant hospitals must notify patients in writing according to Table 3-2 below: 
 
Table 3-2: Transplant Hospital Patient Notification Requirements 
When: 
The transplant hospital must send a notification within 10 
business days with the following information: 
The patient is registered on the 
waiting list 
The date the patient was registered. 
The patient’s evaluation for 
transplant is complete and the 
patient is not registered on the 
waiting list 
That the patient’s evaluation has been completed and the patient 
will not be registered on the waiting list at this time. 
The patient is removed from the 
waiting list for reasons other 
than transplant or death 
That the patient has been removed from the waiting list. 
 
Each written patient notification required in Table 3-2 must also include and refer to the OPTN 
Contractor’s Patient Information Letter, which provides the number for the toll-free Patient Services 
Line. The transplant hospital must document these notifications.

---

## 3.6.A — Waiting Time for Inactive Candidates

<!-- Policy: 3 | Section: 3.6.A | Category: Candidate Registration -->

Candidates accrue waiting time while inactive according to Table 3-3 below. Inactive candidates 
do not receive organ offers. 
 
Table 3-3: Waiting Time for Inactive Candidates 
If the candidate is registered for the 
following organ… 
Then the candidate accrues waiting time 
while inactive as follows… 
Heart 
No time 
Intestine 
Up to 30 cumulative days 
Kidney 
Unlimited time 
Kidney-pancreas 
Unlimited time 
Liver 
No time 
Lung  
Unlimited time 
Pancreas 
Unlimited time 
Pancreas islet 
Unlimited time 
Any covered VCA 
Unlimited time

---

## 3.6.B — Waiting Time Reinstatement for Non-Function of Transplanted Organ

<!-- Policy: 3 | Section: 3.6.B | Category: Candidate Registration -->

The OPTN Contractor will reinstate waiting time to recipients according to the policies below, 
without interruption, when immediate and permanent non-function of any transplanted kidney, 
pancreas, or intestine occurs and the recipient is re-registered on the waiting list as a candidate 
for the same organ. 
 
3.6.B.i Non-function of a Transplanted Kidney  
Immediate and permanent non-function of a transplanted kidney is defined as 
either: 
 
• 
Kidney graft removal within the first 90 days of transplant documented by an 
operative report of the removal of the transplanted kidney. 
• 
Kidney graft failure within the first 90 days of transplant with documentation 
that the candidate is either on dialysis or has a glomerular filtration rate (GFR) 
or measured or estimated creatinine clearance (CrCl) less than or equal to 20 
mL/min within 90 days after the candidate’s kidney transplant.  
 
Kidney waiting time will be reinstated when the OPTN receives a completed Renal 
Waiting Time Reinstatement Form and the supporting documentation required 
above. The Estimated Post Transplant Survival (EPTS) score will also be calculated 
without interruption. The OPTN will send a notice of waiting time reinstatement to 
the transplant hospital involved. 
 
3.6.B.ii  
Non-function of a Transplanted Pancreas  
Immediate and permanent non-function of a transplanted pancreas is defined as 
removal of the transplanted pancreas within 14 days after transplant.  
 
Pancreas waiting time will be reinstated when the OPTN receives a completed 
Pancreas Waiting Time Reinstatement Form and either of the following:  
 
• 
An operative report of the removal of the pancreas. 
• 
A statement of intent from the transplant hospital to remove the transplanted 
pancreas, and a statement that there is documented, radiographic evidence 
indicating that the transplanted pancreas has failed.  
 
The transplant hospital must maintain this documentation. The OPTN will send a 
notice of waiting time reinstatement to the transplant hospital involved. 
 
3.6.B.iii 
Non-function of a Transplanted Intestine  
Immediate and permanent non-function is defined as an intestinal organ graft 
failure resulting in removal of the transplanted organ within the first 7 days 
following transplant.  
 
 

 
 
Intestine waiting time will be reinstated when the OPTN receives a completed 
Intestinal Organ Waiting Time Reinstatement Form and documentation, including 
but not limited to, the recipient’s operative report of removal of the transplanted 
intestine. The OPTN will send a notice of waiting time reinstatement to the 
transplant hospital involved.

---

## 3.6.C — Individual Waiting Time Transfers

<!-- Policy: 3 | Section: 3.6.C | Category: Candidate Registration -->

A candidate may transfer primary waiting time from one transplant program to another if all of 
the following requirements are met: 
 
The candidate must be registered at the new transplant program. 
The candidate must currently be, or have previously been, registered at the earlier transplant program. 
The candidate must sign a Wait Time Transfer Form, requesting transfer of primary waiting time to the 
new transplant program. 
One of the transplant programs must submit a Wait Time Transfer Form to the OPTN. 
 
The OPTN will transfer the primary qualifying date and waiting time accrued from the earlier 
transplant program to the new transplant program. However, time accrued simultaneously at 
more than one program is only counted once. 
 
The OPTN will notify each of the transplant programs involved of the completed transfer of 
waiting time. The new transplant program must notify the candidate of the waiting time transfer 
status within 10 business days of receiving notification from the OPTN and must document that 
this notification was completed. 
 
If the candidate chooses to have multiple registrations, the OPTN will exchange the primary 
qualifying date and waiting time accrued from the earlier transplant to the new transplant 
program. 
 
If the candidate chooses not to have multiple registrations, then the OPTN will do both of the 
following: 
 
1. Transfer the primary qualifying date and accrued waiting time from the earlier transplant 
program to the new transplant program. 
2. Remove the candidate from the waiting list of the earlier transplant program. 
 
If the candidate is removed from the waiting list at the earlier transplant program before being 
registered at the new transplant program, the OPTN will add the waiting time accrued at the 
earlier transplant program to the waiting time accrued at the new program. 
 
The OPTN will not include time between removal at the earlier transplant program and 
registration at the new program in the candidate’s waiting time.

---

## 3.7.A — Applications for Modifications of Waiting Time

<!-- Policy: 3 | Section: 3.7.A | Category: Candidate Registration -->

To apply for a waiting time modification, the candidate’s transplant program must submit an 
application to the OPTN with all of the following information:  
 
1. The requested listing date and documentation showing an intent to register the candidate at 
the requested listing date. 
2. Documentation or a statement showing that the candidate qualified for the waiting time 
according to the organ-specific OPTN Policies 6 through 12. 
3. A corrective action plan, if the application is due to an error. 
4. The name and signature of the candidate’s physician or surgeon. 
5. Signatures indicating agreement from all applicable transplant programs in the OPO. If a 
signature cannot be obtained from a transplant program, the submitting program must 
explain the efforts it made to obtain a signature and include any stated reasons for 
disagreement with the request.  
 
Upon receipt of a complete application and required documentation, the OPTN will forward the 
application, without person-identified data, according to Table 3-4 that follows: 
 
Table 3-4: Waiting Time Modification Application Review 
If the candidate requests a 
waiting time modification for 
the following organ: 
Then the application will be reviewed by the: 
Kidney 
Kidney Waiting Time Modifications Subcommittee 
Liver 
A subcommittee of the Liver and Intestinal Organ 
Transplantation Committee, appointed by the Chair 
of the Liver and Intestinal Organ Transplantation 
Committee 
Heart 
A subcommittee of the Heart Transplantation 
Committee, appointed by the Chair of the Heart 
Transplantation Committee 
Lung 
A subcommittee of the Lung Transplantation 
Committee, appointed by the Chair of the Lung 
Transplantation Committee 
Pancreas 
Kidney or Pancreas Waiting Time Modifications 
Subcommittee 
Intestine 
A subcommittee of the Liver and Intestinal Organ 
Transplantation Committee, appointed by the Chair 
of the Liver and Intestinal Organ Transplantation 
Committee 
 
 
 

 
 
Waiting list modification applications will be reviewed as follows: 
 
1. The reviewer will determine if it is appropriate to modify the candidate’s waiting time as 
requested in the application and will notify the OPTN of the decision. 
2. Upon notice, the OPTN will implement the waiting time modification. 
3. The reviewer will report the modification, without person-identified data, to the relevant 
organ specific Committee. 
4. The Committee will report the modification, without person-identified data, to the Board of 
Directors.

---

## 3.7.B — Required Expedited Modifications of Waiting Time

<!-- Policy: 3 | Section: 3.7.B | Category: Candidate Registration | Cross-ref: Policy 11 -->

An application for waiting time modifications must follow the procedures for expedited 
modifications of waiting time if it meets any of the following criteria according to Table 3-5 
below: 
 
Table 3-5: Applications Requiring Expedited Modifications of Waiting Time 
When: 
And the candidate is 
registered for: 
And the transplant program is 
requesting reinstatement of 
waiting time including: 
An error occurred in 
removing the candidate’s 
waiting list record 
The same organ 
Time accrued under the 
previous registration and any 
time lost by the error. 
An error occurred in 
registering, modifying, or 
renewing the candidate’s 
waiting list record 
Status 1 liver, pediatric status 
1A heart, adult status 1,2, 3, 
or 4 heart, or priority 1 
pediatric lung 
Any time lost by the error. 
The candidate was 
removed from the waiting 
list for medical reasons, 
other than receiving a 
transplant 
The same organ with the 
same diagnosis 
Time accrued under the 
previous registration without 
the time interval when the 
candidate was removed from 
the waiting list. 
An islet recipient has re-
registered on the islet 
waiting list 
An islet infusion 
Any previously accrued 
waiting time according to 
Policy 11.3.C: Islet Waiting 
Time Criteria. 
The candidate needs a 
second organ 
Heart, liver, or lung 
Modified waiting time for the 
second organ that includes the 
waiting time accrued for the 
first organ. 

 
 
When: 
And the candidate is 
registered for: 
And the transplant program is 
requesting reinstatement of 
waiting time including: 
The candidate needs a 
second organ, routine 
alternative therapies are 
not possible, and the 
other transplant programs 
within the OPO and the 
OPO itself agree to the 
modified waiting time 
Kidney, pancreas, or intestine 
Modified waiting time for the 
second organ that includes the 
waiting time for the first 
organ. 
 
Additionally, applications must meet any additional requirements outlined in the organ-specific 
allocation policies. If an application does not comply with the requirements of Policy 3.7: 
Waiting Time Modifications, then the OPTN will not implement the requested waiting time 
modifications or forward the application for review. 
 
Applications eligible for expedited modifications of waiting time must use the following process: 
 
1. Upon receipt of a complete application, including the name and signature of the candidate’s 
physician or surgeon, the OPTN will implement the waiting time modification. 
2. The OPTN will report the modification, without person-identified data, to the relevant 
organ-specific Committee. 
3. The Committee will report the modification, without person-identified data, to the Board of 
Directors.

---

## 3.7.C — Waiting Time Modifications for Heart, Lung, and Heart-Lung Candidates

<!-- Policy: 3 | Section: 3.7.C | Category: Candidate Registration -->

The OPTN may assign heart, lung, and heart-lung candidates waiting time from one waiting list 
to another waiting list according to Table 3-6 below. 
 
Table 3-6: Waiting Time Modifications for Heart, Lung, and Heart-Lung Candidates 
From this registration: 
To this registration: 
Heart 
Heart-lung 
Heart-lung 
Heart 
Heart-lung 
Lung

---

## 3.7.D — Waiting Time Modifications for Kidney Candidates Affected by Race-

<!-- Policy: 3 | Section: 3.7.D | Category: Candidate Registration -->

Inclusive eGFR Calculations 
Transplant hospitals must develop and comply with a written protocol that includes processes 
for meeting the requirements of Policy 3.7.D, including: 
• 
Confirming candidate race 
• 
Fulfilling notification requirements 
• 
Seeking supporting documentation including at a minimum, what sources will be 
reviewed  

 
 
The transplant hospital must document that above processes were completed, including the 
results of the review of sources, in the candidate’s medical record. 
 
3.7.D.i  
Notification Requirement 
 
All designated kidney transplant programs must notify candidates, of the following: 
1. Programs are required to submit eGFR waiting time modifications for 
candidates affected by race inclusive eGFR calculations (education 
notification). 
2. Whether or not candidates are eligible for an eGFR modification (eligibility 
notification). 
3. The outcome of the eGFR modification submission, for applicable 
candidates (outcome notification). 
• 
Programs must notify candidates within 10 business days following the 
program’s receipt of modification outcome from the OPTN. 
 
3.7.D.ii 
 Determination of Eligible Candidates 
 
All designated kidney transplant programs must determine eligibility for a Waiting 
Time Modification for Kidney Candidates affected by Race-Inclusive eGFR 
Calculations for each candidate registered at the transplant program. A candidate is 
eligible for a waiting time modification if the candidate is registered as Black or 
African American in the OPTN Computer System and has documentation 
establishing that the candidate had an eGFR that was over 20 mL/min and would 
have been 20 mL/min or less if a race-neutral calculation had been used. Every 
kidney transplant candidate needs to be assessed for eligibility regardless of waiting 
time criteria or status, including candidates registered for multi-organ transplant. 
 
3.7.D.iii  
Application for Waiting Time Modification 
 
Transplant programs must submit an eGFR waiting time modification for each 
eligible candidate registered at their transplant program. The application for an 
eGFR waiting time modification must include the qualifying eGFR value, as well as: 
1. Documentation of one of the following, and 
• The candidate’s eGFR values for Black and non-Black candidates or 
• The estimation of GFR with a race-inclusive calculation and a re-estimation of     
GFR with a race-neutral calculation. 
2. The name and signature of the candidate’s physician or surgeon. 
Upon receipt of a complete application the OPTN will implement the waiting time 
modification.

---

## 3.8 — Collective Patient Transfers

<!-- Policy: 3 | Section: 3.8 | Category: Candidate Registration -->

The OPTN may collectively transfer patients from transplant programs with a status of long-term 
inactive, withdrawal, or termination, and in other circumstances upon request to one or more transplant 
programs according to Appendix K: Transplant Program Inactivity, Withdrawal, and Termination of the 

 
 
OPTN Management and Membership Policies. Candidates transferred as part of a collective transfer will 
retain waiting time according to Appendix K.6: Transferred Candidates Waiting Time.

---

## 3.9 — Removing Candidates from the Waiting List

<!-- Policy: 3 | Section: 3.9 | Category: Candidate Registration -->

If a candidate receives a transplant or dies while awaiting a transplant then the registering transplant 
hospitals must remove the candidate from the hospital’s organ waiting lists and notify the OPTN within 
24 hours of the event. If the candidate has multiple-registrations for the same organ, each transplant 
hospital where the candidate is registered must meet these requirements. 
 
The OPTN will notify other transplant hospitals when a multiple registered candidate receives a 
transplant or another transplant hospital reports the candidate as deceased. Upon notification, all other 
transplant hospitals involved can investigate and remove the candidate from the transplant hospital’s 
waiting list. 
 
If the transplant recipient re-registers for another organ to replace a transplanted organ, then waiting 
time will begin as of the date and time the candidate re-qualifies. The waiting time from the previous 
registration may be added to the new registration according to Policy 3.6.B: Waiting Time Reinstatement 
for Non-Function of Transplanted Organ.

---

## 3.9.A — Removing Liver Candidates from the Waiting List

<!-- Policy: 3 | Section: 3.9.A | Category: Candidate Registration -->

For a liver candidate, the data necessary to calculate the candidate’s current MELD or PELD 
score is required to remove the candidate from the waiting list.

---

## 3.9.B — Removing Pancreas Islets Candidates from the Waiting List

<!-- Policy: 3 | Section: 3.9.B | Category: Candidate Registration | Cross-ref: Policy 4 -->

The transplant hospital must remove the candidate from the waiting list within 24 hours of the 
candidate receiving each islet infusion. 

 
 
 
Policy 4: Histocompatibility 
4.1 
Requirements for Laboratory Review of Reports 
54 
4.2 
Requirements for Waiting List Data Verification 
54 
4.3 
Requirements for Performing and Reporting HLA Typing 
54 
4.4 
Critical HLA Discrepancies in Candidate, Donor, and Recipient HLA Typing Results 
55 
4.5 
Antibody Screening and Reporting 
56 
4.6  Calculated Panel Reactive Antibody (CPRA) Calculation 
56 
4.7 
Crossmatching 
57 
4.8 
Blood Type Determination 
58 
4.9 
Preservation of Excess Specimens 
58 
4.10 HLA Value Updates 
58 
4.11 Reference Tables of HLA Antigen Values and Split Equivalences 
58

---
