# OPTN Policy 8: Allocation of Kidneys

**Source:** OPTN Policies | **Effective:** 12/10/2025 | **Category:** Kidney Allocation
**Confidence:** HIGH — Official OPTN policy language

---

## 8.1.A — Deceased Donor Kidneys with Discrepant Human Leukocyte Antigen (HLA)

<!-- Policy: 8 | Section: 8.1.A | Category: Kidney Allocation | Cross-ref: Policy 5 -->

Typings  
Allocation of deceased donor kidneys is based on the HLA typing identified by the donor 
histocompatibility laboratory. If the recipient HLA laboratory identifies a different HLA type for 
the deceased donor and the intended recipient cannot be transplanted, the kidney must be 
allocated according to OPTN Policy 5.9: Released Organs. When reallocating the kidney, the OPO 
has the discretion to use either the HLA typing identified by the donor histocompatibility 
laboratory or the recipient HLA laboratory.

---

## 8.2 — Kidney Allocation Score

<!-- Policy: 8 | Section: 8.2 | Category: Kidney Allocation -->

Candidates receive an allocation score according to the total of all points assigned in Table 8-1.  
 
Table 8-1: Kidney Points 
If the candidate is: 
And the following allocation 
sequence is used: 
Then the candidate receives 
this many points: 
Registered for transplant and 
meets the qualifying criteria 
described in Policy 8.3: Waiting 
Time 
8.4.I, 8.4.J, 8.4.K, or 8.4.L 
1/365 points for each day since 
the qualifying criteria in Policy 
8.3: Waiting Time 
Aged 0-10 at time of match and 
a 0-ABDR mismatch with the 
donor  
8.4.I, 8.4.J, or 8.4.K 
4 points 
Aged 11-17 at time of match 
and a 0-ABDR mismatch with 
the donor 
8.4.I, 8.4.J, or 8.4.K 
3 points 
Aged 0-10 at time of match and 
donor has a KDPI score <35% 
8.4.I, 8.4.J 
1 point 

 
 
 
 
*Donors with only one antigen identified at an HLA locus (A, B, and DR) are presumed “homozygous” at 
that locus.  
 
Table 8-2: Points for CPRA 
If the candidate’s CPRA score is: 
Then the candidate receives this many points: 
0 
0.00 
1-9 
0.00 
10-19 
0.00 
20-29 
0.08 
30-39 
0.21 
40-49 
0.34 
50-59 
0.48 
60-69 
0.81 
70-74 
1.09 
75-79 
1.58 
80-84 
2.46 
85-89 
4.05 
90-94 
6.71 
95 
10.82 
96 
12.17 
97 
17.30 
98 
24.40 
99 
50.09 
100 
202.10 
 
 
 
If the candidate is: 
And the following allocation 
sequence is used: 
Then the candidate receives 
this many points: 
A prior living donor  
8.4.I, 8.4.J, or 8.4.K 
4 points 
Sensitized (CPRA at least 20%) 
8.4.I, 8.4.J, or 8.4.K 
See Table 8-2: Points for CPRA 
A single HLA-DR mismatch with 
the donor* 
8.4.I, 8.4.J, or 8.4.K 
1 point 
A zero HLA-DR mismatch with 
the donor* 
8.4.I, 8.4.J, or 8.4.K 
2 points 
Meets the qualifying criteria 
described in Table 8-3: Points 
for Allocation of Kidneys based 
on Proximity to Donor Hospital 
8.4.I, 8.4.J, 8.4.K, or 8.4.L 
See Table 8-3: Points for 
Allocation of Kidneys based on 
Proximity to Donor Hospital 

Table 8-3: Points for Allocation of Kidneys based on Proximity to Donor Hospital 
For purposes of this section, distance is calculated in nautical miles between candidate’s hospital of 
registration and the donor hospital. 
If the candidate is: 
Then the candidate receives this many points: 
Registered at a transplant program that 
is 250 nautical miles or less away from 
the donor hospital 
2 −[(
2
250 −0) × 𝑑𝑖𝑠𝑡𝑎𝑛𝑐𝑒] 
Registered at a transplant program that 
is more than 250 nautical miles away 
from but 2500 nautical miles or less away 
from the donor hospital 
4 −[((
4
2500 −250) × 𝑑𝑖𝑠𝑡𝑎𝑛𝑐𝑒 )
−(4 ×
250
2500 −250)] 
Registered at a transplant program that 
is more than 2500 nautical miles away 
from the donor hospital 
0 
Table 8-4: Points for Released Kidneys based on Proximity to Transplant Hospital that Originally 
Accepted the Organ 
For purposes of this section, distance is calculated in nautical miles between the candidate’s hospital of 
registration and the transplant hospital that released the kidney.  
If the candidate is: 
Then the candidate receives this many points: 
Registered at a transplant hospital that is 250 
nautical miles or less away from the transplant 
hospital that originally accepted the kidney 
2 −[(
2
250 −0) × 𝑑𝑖𝑠𝑡𝑎𝑛𝑐𝑒] 
Registered at a transplant hospital that is more 
than 250 nautical miles but 2,500 nautical miles 
or less away from the transplant hospital that 
originally accepted the kidney 
4 −[((
4
2500 −250) × 𝑑𝑖𝑠𝑡𝑎𝑛𝑐𝑒 ) −(4 ×
250
2500 −250)] 
Registered at a transplant hospital that is more 
than 2,500 nautical miles away from the 
transplant hospital that originally accepted the 
kidney 
0

---

## 8.3.A — Waiting Time for Candidates Registered at Age 18 Years or Older

<!-- Policy: 8 | Section: 8.3.A | Category: Kidney Allocation -->

If a kidney candidate is 18 years or older on the date the candidate is registered for a kidney, 
then the candidate’s waiting time is based on the earliest of the following: 
 
1. The candidate’s registration date with a glomerular filtration rate (GFR) or measured or 
estimated creatinine clearance (CrCl) less than or equal to 20 mL/min.  
2. The date after registration that a candidate’s GFR or measured or estimated CrCl becomes 
less than or equal to 20 mL/min.  
3. The date that the candidate began regularly administered dialysis as an End Stage Renal 
Disease (ESRD) patient in a hospital based, independent non-hospital based, or home 
setting.

---

## 8.3.B — Waiting Time for Candidates Registered prior to Age 18

<!-- Policy: 8 | Section: 8.3.B | Category: Kidney Allocation -->

If a kidney candidate is less than 18 years old at the time of registration on the waiting list, then 
the candidate’s waiting time is based on the earlier of the following: 
 
1. The date that the candidate registered on the waiting list regardless of clinical criteria. 
2. The date that the candidate began regularly administered dialysis as an ESRD patient in a 
hospital based, independent non-hospital based, or home setting.

---

## 8.3.C — Time at Medically Urgent Status

<!-- Policy: 8 | Section: 8.3.C | Category: Kidney Allocation -->

For registered kidney candidates that also qualify for medically urgent status according to Policy 
8.4.A.i, the candidate accrues time at medically urgent status while active on the waiting list, 
based on the date the transplant program first indicates the candidate’s qualification for 
medically urgent status to the OPTN.

---

## 8.3.D — Waiting Time for Kidney Recipients

<!-- Policy: 8 | Section: 8.3.D | Category: Kidney Allocation | Cross-ref: Policy 3 -->

If a kidney recipient returns to the kidney waiting list, waiting time will be based only on the 
dates after the most recent kidney transplant, unless the candidate qualifies for reinstatement 
of waiting time according to OPTN Policy 3.6.B.i: Non-function of a Transplanted Kidney.

---

## 8.4.A — Candidate Classifications

<!-- Policy: 8 | Section: 8.4.A | Category: Kidney Allocation -->

Each candidate on the kidney waiting list after turning 18 years old receives an Estimated Post 
Transplant Survival (EPTS) score. A candidate’s EPTS score represents the percentage of kidney 
candidates in the nation with a longer expected post-transplant survival time. EPTS is based on 
all of the following:  
 
1. Candidate time on dialysis  
2. Whether or not the candidate has a current diagnosis of diabetes  
3. Whether or not the candidate has had any prior solid organ transplant 

 
 
 
4. Candidate age 
 
If a kidney recipient returns to the kidney waiting list, only time on dialysis after the most recent 
kidney transplant applies for number 1 above, candidate time on dialysis, as defined in OPTN 
Policy 8.3: Waiting Time.  
 
Each candidate’s EPTS score is calculated when the candidate is registered on the waiting list. 
The OPTN will update EPTS scores as follows: 
 
• 
All candidate EPTS scores are updated once each day 
• 
A candidate’s EPTS score will be updated anytime the transplant hospital reports changes to 
any EPTS factor for a candidate 
 
A candidate’s raw EPTS score is equal to:  
 
0.047 * MAX(Age - 25, 0) + 
-0.015 * Diabetes * MAX(Age - 25, 0) + 
0.398 * Prior Solid Organ Transplant + 
-0.237 * Diabetes * Prior Solid Organ Transplant + 
0.315 * log (Years on Dialysis + 1) + 
-0.099 * Diabetes * log(Years on Dialysis + 1) + 
0.130 * (Years on Dialysis = 0) + 
-0.348 * Diabetes * (Years on Dialysis = 0) + 
1.262 * Diabetes 
 
The EPTS calculation uses all the following as binary indicators:  
 
1. Diabetes,  
2. Prior solid organ transplant 
3. Years on dialysis=0 
 
If a binary indicator is true, then it is replaced by a value of 1.0 in the calculation; otherwise, it is 
replaced by 0. Fractional calendar years are used for candidate’s age and years on dialysis. 
 
The OPTN’s EPTS mapping table is used to convert a candidate’s raw EPTS score into an EPTS 
score. All EPTS scores are rounded to the nearest integer. 
 
The reference population used to determine the top 20% EPTS threshold is reviewed annually by 
the Kidney Transplantation Committee and updated by the OPTN on or before June 1 of each 
calendar year. 
 
8.4.A.i 
Medically Urgent Status for Adult and Pediatric Candidates 
To qualify for medically urgent status the candidate must be: 
 
1. An active candidate 
2. Accruing waiting time, according to OPTN Policy 8.3: Waiting Time and 

 
 
 
3. Certified by a transplant nephrologist and transplant surgeon as medically urgent, based 
on meeting the following criteria: 
 
First, the candidate must have exhausted, or has a contraindication to, all dialysis access 
via all of the following methods: 
• 
Vascular access in the upper left extremity 
• 
Vascular access in the upper right extremity 
• 
Vascular access in the lower left extremity 
• 
Vascular access in the lower right extremity 
• 
Peritoneal access in the abdomen 
 
After exhaustion or contraindication to all dialysis via the methods listed above, the 
candidate must also either have exhausted dialysis, be currently dialyzed, or have a 
contraindication to dialysis via one of the following methods: 
• 
Transhepatic IVC Catheter 
• 
Translumbar IVC Catheter 
• 
Other method of dialysis (must specify) 
 
The candidate’s transplant surgeon and transplant nephrologist must review and sign a 
written approval of the candidate’s qualification for medical urgency status. Programs 
must consider clinical characteristics specific to adult and pediatric candidates when 
indicating contraindications to the criteria above. The transplant hospital must 
document this medical urgency qualification in the candidate’s medical record and 
submit supporting documentation to the OPTN within seven business days of indicating 
medical urgency status. 
 
The Kidney Transplantation Committee will review a transplant program’s use of the 
medical urgency status retrospectively. Cases may be referred to Membership & 
Professional Standards Committee (MPSC) for review according to Appendix L of the 
OPTN Management and Membership Policies.

---

## 8.4.B — Deceased Donor Classifications

<!-- Policy: 8 | Section: 8.4.B | Category: Kidney Allocation -->

Kidneys from deceased donors are classified according to the Kidney Donor Profile Index (KDPI). 
The KDPI score is derived directly from the Kidney Donor Risk Index (KDRI) score. The KDPI is the 
percentage of donors in the reference population that have a KDRI less than or equal to this 
donor's KDRI. 
 
 

 
 
 
The donor characteristics used to calculate KDRI are provided in Table 8-5 below.  
 
Table 8-5: KDRI Factors 
This deceased donor characteristic: 
Applies to: 
KDRI score component: 
Age (integer years) 
All donors 
0.0092*(age-40) 
Donors with age < 18 
0.0113*(age-18) 
Donors with age > 50 
0.0067*(age-50) 
Creatinine (mg/dL) 
All donors 
0.2128*(creatinine - 1) 
Donors with creatinine 
> 1.5 
-0.2199*(creatinine - 1.5) 
History of Hypertension 
Hypertensive donors 
0.1106 
History of Diabetes 
Diabetic donors 
0.2577 
Cause of Death 
Donors with 
cerebrovascular 
accident as cause of 
death 
0.0743 
Height (cm) 
All donors 
-0.0557*(height - 170) / 
10 
Weight (kg) 
All donors with weight < 
80 kg 
-0.0333*(weight - 80) / 5 
Donor type 
DCD donors 
0.1966 
 
To calculate KDRI, follow these steps: 
 
1. Sum each of the applicable KDRI score components in Table 8-5 
2. Apply the antilog (base e) function to this sum 
3. Divide the KDRI by the median KDRI value of the most recent donor reference population 
4. Determine the KDPI using the OPTN’s KDRI-to-KDPI mapping table 
 
The KDPI score is rounded to the nearest integer. 
 
The KDPI used for allocation is based on the most recent values of donor characteristics 
reported to the OPTN before executing a match run.  
 
The reference population used to determine the KDRI-to-KDPI mapping is reviewed annually by 
the Kidney Transplantation Committee and updated by the OPTN on or before June 1 of each 
calendar year.

---

## 8.4.C — Sorting Within Each Classification

<!-- Policy: 8 | Section: 8.4.C | Category: Kidney Allocation -->

For candidates within classifications 1 through 7 according to Tables 8-7 and 8-8; classifications 
1 through 6 according to Table 8-9, and classifications 1 through 5 according to Table 8-10, 
candidates are sorted in the following order: 
 
1. Medical urgency status 
2. Total time at medically urgent status for current medically urgent candidates only (highest 
to lowest) 
3. Total points (highest to lowest) 
4. Date and time of the candidate’s registration (oldest to most recent) 
 
For candidates within all other classifications, candidates are sorted in the following order: 
 
1. Total points (highest to lowest) 
2. Date and time of the candidate’s registration (oldest to most recent)

---

## 8.4.D — Allocation of Kidneys by Blood Type

<!-- Policy: 8 | Section: 8.4.D | Category: Kidney Allocation -->

Transplants are restricted by blood type in certain circumstances. Kidneys will be allocated to 
candidates according to the blood type matching requirements in Table 8-6 below:  
 
Table 8-6: Allocation of Kidneys by Blood Type 
Kidneys from Donors with: 
Are Allocated to Candidates with: 
Blood Type O 
Blood type O. 
For offers made to candidates in 0-ABDR 
mismatch categories, blood type O 
kidneys may be transplanted into 
candidates who have blood types other 
than O. 
Blood Type A 
Blood type A or blood type AB.  
Blood Type B 
Blood type B. 
For offers made to candidates in 0-ABDR 
mismatch categories, blood type B 
kidneys may be transplanted into 
candidates who have blood types other 
than B. 
Blood Type AB 
Blood type AB. 
Blood Types A, non-A1 and AB, non-A1B 
Kidneys may be transplanted into 
candidates with blood type B who meet 
all of the following criteria:  
1. The transplant program obtains 
written informed consent from each 
blood type B candidate regarding 
their willingness to accept a blood 

 
 
 
Kidneys from Donors with: 
Are Allocated to Candidates with: 
type A, non-A1 or blood type AB, non-
A1B blood type kidney. 
2. The transplant program establishes a 
written policy regarding its program’s 
titer threshold for transplanting blood 
type A, non-A1 and blood type AB, 
non-A1B kidneys into candidates with 
blood type B. The transplant program 
must confirm the candidate’s 
eligibility every 90 days (+/- 20 days).

---

## 8.4.E — Prior Living Organ Donors

<!-- Policy: 8 | Section: 8.4.E | Category: Kidney Allocation -->

A kidney candidate will be classified as a prior living donor if all of the following conditions are 
met: 
 
1. The candidate donated for transplantation, within the United States or its territories, at 
least one of the following: 
• 
Kidney 
• 
Liver segment 
• 
Lung segment 
• 
Partial pancreas 
• 
Small bowel segment. 
 
2. The candidate’s physician reports all of the following information to the OPTN: 
a. The name of the recipient or intended recipient of the donated organ or organ segment 
b. The recipient’s or intended recipient’s transplant hospital  
c. The date the donated organ was procured

---

## 8.4.F — Prioritization for Liver Recipients on the Kidney Waiting List

<!-- Policy: 8 | Section: 8.4.F | Category: Kidney Allocation | Cross-ref: Policy 3 -->

If a kidney candidate received a liver transplant, but not a liver and kidney transplant from the 
same deceased donor, the candidate will be classified as a prior liver recipient. This classification 
gives priority to a kidney candidate if both of the following criteria are met:  
 
1. The candidate is registered on the kidney waiting list prior to the one-year anniversary of 
the candidate’s most recent liver transplant date  
2. On a date that is at least 60 days but not more than 365 days after the candidate’s liver 
transplant date, at least one of the following criteria is met: 
• 
The candidate has a GFR or measured or estimated CrCl less than or equal to 20 mL/min.  
• 
The candidate is on dialysis.  
 
When the transplant program reports that the candidate meets the criteria for this 
classification, the candidate will remain at this classification for 30 days from the date of the 
qualifying test or treatment. If the transplant program reports additional qualifying tests or 

 
 
 
treatments, then the candidate will remain at this classification for 30 days from the most 
recent date of the test or treatment. If the transplant program reports that the candidate meets 
the criteria for 90 consecutive days, the candidate will remain at this classification until the 
candidate is removed from the kidney waiting list. If the candidate transfers kidney waiting time 
according to Policy 3.6.C: Individual Waiting Time Transfers and has met the criteria for 90 
consecutive days, then the candidate’s classification will be included in the transfer. 
  
If a liver recipient receives a kidney using this priority classification and returns to the kidney 
waiting list after the most recent kidney transplant, the candidate must again meet the criteria 
for this classification, unless the candidate qualifies for kidney waiting time reinstatement 
according to OPTN Policy 3.6.B.i: Non-function of a Transplanted Kidney. If the candidate 
qualifies for kidney waiting time reinstatement, the candidate will be classified as qualifying for 
the classification. 
 
If a kidney candidate received a liver and kidney transplant from the same deceased donor, the 
candidate will only qualify for this classification if the candidate qualifies for kidney waiting time 
reinstatement according to OPTN Policy 3.6.B.i: Non-function of a Transplanted Kidney

---

## 8.4.G — Prioritization for Heart Recipients on the Kidney Waiting List

<!-- Policy: 8 | Section: 8.4.G | Category: Kidney Allocation | Cross-ref: Policy 3 -->

If a kidney candidate received a heart transplant, but not a heart and kidney transplant from the 
same deceased donor, the candidate will be classified as a prior heart recipient. This 
classification gives priority to a kidney candidate if both of the following criteria are met:  
 
1. The candidate is registered on the kidney waiting list prior to the one-year anniversary of 
the candidate’s most recent heart transplant date  
2. On a date that is at least 60 days but not more than 365 days after the candidate’s heart 
transplant date, at least one of the following criteria is met: 
• 
The candidate has a measured or estimated creatinine clearance (CrCl) or glomerular 
filtration rate (GFR) less than or equal to 20 mL/min.  
• 
The candidate is on dialysis.  
 
When the transplant program reports that the candidate meets the criteria for this 
classification, the candidate will remain at this classification for 30 days from the date of the 
qualifying test or treatment. If the transplant program reports additional qualifying tests or 
treatments, then the candidate will remain at this classification for 30 days from the most 
recent date of the test or treatment. If the transplant program reports that the candidate meets 
the criteria for 90 consecutive days, the candidate will remain at this classification until the 
candidate is removed from the kidney waiting list. If the candidate transfers kidney waiting time 
according to OPTN Policy 3.6.C: Individual Waiting Time Transfers and has met the criteria for 90 
consecutive days, then the candidate’s classification will be included in the transfer. 
  
If a heart recipient receives a kidney using this priority classification and returns to the kidney 
waiting list after the most recent kidney transplant, the candidate must again meet the criteria 
for this classification, unless the candidate qualifies for kidney waiting time reinstatement 
according to OPTN Policy 3.6.B.i: Non-function of a Transplanted Kidney. If the candidate 
qualifies for kidney waiting time reinstatement, the candidate will be classified as qualifying for 
the classification. 

 
 
 
 
If a kidney candidate received a heart and kidney transplant from the same deceased donor, the 
candidate will only qualify for this classification if the candidate qualifies for kidney waiting time 
reinstatement according to OPTN Policy 3.6.B.i: Non-function of a Transplanted Kidney.

---

## 8.4.H — Prioritization for Lung Recipients on the Kidney Waiting List

<!-- Policy: 8 | Section: 8.4.H | Category: Kidney Allocation | Cross-ref: Policy 3 -->

If a kidney candidate received a lung transplant, but not a lung and kidney transplant from the 
same deceased donor, the candidate will be classified as a prior lung recipient. This classification 
gives priority to a kidney candidate if both of the following criteria are met:  
 
1. The candidate is registered on the kidney waiting list prior to the one-year anniversary of 
the candidate’s most recent lung transplant date  
2. On a date that is at least 60 days but not more than 365 days after the candidate’s lung 
transplant date, at least one of the following criteria is met: 
• 
The candidate has a measured or estimated creatinine clearance (CrCl) or glomerular 
filtration rate (GFR) less than or equal to 20 mL/min.  
• 
The candidate is on dialysis.  
 
When the transplant program reports that the candidate meets the criteria for this 
classification, the candidate will remain at this classification for 30 days from the date of the 
qualifying test or treatment. If the transplant program reports additional qualifying tests or 
treatments, then the candidate will remain at this classification for 30 days from the most 
recent date of the test or treatment. If the transplant program reports that the candidate meets 
the criteria for 90 consecutive days, the candidate will remain at this classification until the 
candidate is removed from the kidney waiting list. If the candidate transfers kidney waiting time 
according to OPTN Policy 3.6.C: Individual Waiting Time Transfers and has met the criteria for 90 
consecutive days, then the candidate’s classification will be included in the transfer. 
 
If a lung recipient receives a kidney using this priority classification and returns to the kidney 
waiting list after the most recent kidney transplant, the candidate must again meet the criteria 
for this classification, unless the candidate qualifies for kidney waiting time reinstatement 
according to OPTN Policy 3.6.B.i: Non-function of a Transplanted Kidney. If the candidate 
qualifies for kidney waiting time reinstatement, the candidate will be classified as qualifying for 
the classification. 
 
If a kidney candidate received a lung and kidney transplant from the same deceased donor, the 
candidate will only qualify for this classification if the candidate qualifies for kidney waiting time 
reinstatement according to OPTN Policy 3.6.B.i: Non-function of a Transplanted Kidney.

---

## 8.4.I — Allocation of Kidneys from Deceased Donors with KDPI Scores less than or (Part 1)

<!-- Policy: 8 | Section: 8.4.I | Category: Kidney Allocation -->

equal to 20%  
Kidneys from deceased donors with a kidney donor profile index (KDPI) score of less than or 
equal to 20% are allocated to candidates according to Table 8-7 below. For the purposes of 
Table 8-7, distribution will be based on the distance from the candidate’s transplant hospital to 
the donor hospital, unless the kidney is allocated according to OPTN Policy 8.7: Allocation of 

Released Kidneys. For kidneys that are released and the host OPO or the OPTN executes a 
released kidney match run, distribution will be based on the distance from the candidate’s 
transplant hospital to the transplant hospital that released the organ. 

Table 8-7: Allocation of Kidneys from Deceased Donors with KDPI Less Than or Equal To 20% 
Classification Candidates that are 
And registered at a 
transplant hospital 
that is at or within 
this distance from 
the hospital that 
distribution will be 
based upon 
With this donor 
blood type: 
1 
0-ABDR mismatch, CPRA 
equal to 100%, blood type 
identical or permissible 
250NM 
Any 
2 
CPRA equal to 100%, blood 
type identical or permissible 
250NM 
Any 
3 
0-ABDR mismatch, CPRA 
equal 100%, blood type 
identical or permissible 
Nation 
Any 
4 
CPRA equal to 100%, blood 
type identical or permissible 
Nation 
Any 
5 
Prior living donor, blood 
type identical or permissible  
250NM 
Any 
6 
Registered prior to 18 years 
old, blood type identical or 
permissible  
250NM 
Any 
7 
Medically Urgent 
250NM 
Any 
8 
0-ABDR mismatch, CPRA 
equal to 99%, blood type 
identical or permissible 
250NM 
Any 
9 
CPRA equal to 99%, blood 
type identical or permissible 
250NM 
Any 

Classification Candidates that are 
And registered at a 
transplant hospital 
that is at or within 
this distance from 
the hospital that 
distribution will be 
based upon 
With this donor 
blood type: 
10 
0-ABDR mismatch, CPRA 
equal to 98%, blood type 
identical or permissible 
250NM 
Any 
11 
CPRA equal to 98%, blood 
type identical or permissible 
250NM 
Any 
12 
0-ABDR mismatch, top 20% 
EPTS, and blood type 
identical 
250NM 
Any 
13 
0-ABDR mismatch, top 20% 
EPTS, CPRA greater than or 
equal to 80%, and blood 
type identical  
Nation 
Any 
14 
0-ABDR mismatch, less than 
18 years old at time of 
match, CPRA greater than or 
equal to 21% but no greater 
than 79%, and blood type 
identical  
Nation 
Any 
15 
0-ABDR mismatch, less than 
18 years old at time of 
match, CPRA greater than or 
equal to 0% but less than or 
equal to 20%, and blood 
type identical  
Nation 
Any 
16 
0-ABDR mismatch, top 20% 
EPTS, CPRA greater than or 
equal to 21% but no greater 
than 79%, and blood type 
identical  
Nation 
Any 
17 
0-ABDR mismatch, top 20% 
EPTS, and blood type B  
250NM 
O 

Classification Candidates that are 
And registered at a 
transplant hospital 
that is at or within 
this distance from 
the hospital that 
distribution will be 
based upon 
With this donor 
blood type: 
18 
0-ABDR mismatch, top 20% 
EPTS or less than 18 years at 
time of match run, CPRA 
greater than or equal to 
80%, and blood type B  
Nation 
O 
19 
0-ABDR mismatch, less than 
18 at time of match, CPRA 
greater than or equal to 21% 
but no greater than 79%, 
and blood type B  
Nation 
O 
20 
0-ABDR mismatch, less than 
18 at time of match, CPRA 
greater than or equal to 0% 
but less than or equal to 
20%, and blood type B  
Nation 
O 
21 
0-ABDR mismatch, top 20% 
EPTS, CPRA greater than or 
equal to 21% but no greater 
than 79%, and blood type B  
Nation 
O 
22 
0-ABDR mismatch, top 20% 
EPTS, and blood type 
permissible  
250NM 
Any 
23 
0-ABDR mismatch, top 20% 
EPTS, CPRA greater than or 
equal to 80%, and blood 
type permissible  
Nation 
Any 
24 
0-ABDR mismatch, less than 
18 years old at time of 
match run, CPRA greater 
than or equal to 21% but no 
greater than 79%, and blood 
type permissible  
Nation 
Any 
25 
0-ABDR mismatch, less than 
18 years old at time of 
match run, CPRA greater 
than or equal to 0% but less 
than or equal to 20%, and 
blood type permissible  
Nation 
Any 

Classification Candidates that are 
And registered at a 
transplant hospital 
that is at or within 
this distance from 
the hospital that 
distribution will be 
based upon 
With this donor 
blood type: 
26 
0-ABDR mismatch, top 20% 
EPTS, CPRA greater than or 
equal to 21% but no greater 
than 79%, and blood type 
permissible  
Nation 
Any 
27 
Top 20% EPTS, blood type B  
250NM 
A2 or A2B 
28 
Top 20% EPTS, blood type 
identical or permissible 
250NM 
Any 
29 
0-ABDR mismatch, EPTS 
greater than 20%, blood 
type identical  
250NM 
Any 
30 
0-ABDR mismatch, EPTS 
greater than 20%, CPRA 
greater than or equal to 
80%, and blood type 
identical 
Nation 
Any 
31 
0-ABDR mismatch, EPTS 
greater than 20%, CPRA 
greater than or equal to 21% 
but no greater than 79%, 
and blood type identical 
Nation 
Any 
32 
0-ABDR mismatch, EPTS 
greater than 20%, and blood 
type B 
250NM 
O 
33 
0-ABDR mismatch, EPTS 
greater than 20%, CPRA 
greater than or equal to 
80%, and blood type B 
Nation 
O 
34 
0-ABDR mismatch, EPTS 
greater than 20%, CPRA 
greater than or equal to 21% 
but no greater than 79%, 
and blood type B  
Nation 
O

---

## 8.4.I — Allocation of Kidneys from Deceased Donors with KDPI Scores less than or (Part 2)

<!-- Policy: 8 | Section: 8.4.I | Category: Kidney Allocation -->

Classification Candidates that are 
And registered at a 
transplant hospital 
that is at or within 
this distance from 
the hospital that 
distribution will be 
based upon 
With this donor 
blood type: 
35 
0-ABDR mismatch, EPTS 
greater than 20%, and blood 
type permissible  
250NM 
Any 
36 
0-ABDR mismatch, EPTS 
greater than 20%, CPRA 
greater than or equal to 
80%, and blood type 
permissible  
Nation 
Any 
37 
0-ABDR mismatch, EPTS 
greater than 20%, CPRA 
greater than or equal to 21% 
but no greater than 79%, 
and blood type permissible  
Nation 
Any 
38 
EPTS greater than 20%, 
blood type B  
250NM 
A2 or A2B 
39 
All remaining candidates, 
blood type identical or 
permissible 
250NM 
Any 
40 
Registered prior to 18 years 
old, blood type identical or 
permissible  
Nation 
Any 
41 
Top 20% EPTS, blood type B 
Nation 
A2 or A2B 
42 
Top 20% EPTS, blood type 
identical or permissible 
Nation 
Any 
43 
All remaining candidates, 
blood type identical or 
permissible 
Nation 
Any

---

## 8.4.J — Allocation of Kidneys from Deceased Donors with KDPI Scores Greater Than

<!-- Policy: 8 | Section: 8.4.J | Category: Kidney Allocation -->

20% but Less Than 35%  
Kidneys from deceased donors with KDPI scores greater than 20% but less than 35% are 
allocated to candidates according to Table 8-8 below. For the purposes of Table 8-8, distribution 
will be based on the distance from the candidate’s transplant hospital to the donor hospital, 
unless the kidney is allocated according to OPTN Policy 8.7: Allocation of Released Kidneys. For 
kidneys that are released and the host OPO or the OPTN executes a released kidney match run, 
distribution will be based on the distance from the candidate’s transplant hospital to the 
transplant hospital that released the organ. 
 
Table 8-8: Allocation of Kidneys from Deceased Donors with KDPI Scores Greater Than 20% 
but Less Than 35% 
Classification Candidates that are 
And registered at a 
transplant hospital 
that is at or within 
this distance from 
the hospital that 
distribution will be 
based upon 
With this donor 
blood type: 
1 
0-ABDR mismatch, CPRA 
equal to 100%, blood type 
identical or permissible 
250NM 
Any 
2 
CPRA equal to 100%, blood 
type identical or permissible 
250NM 
Any 
3 
0-ABDR mismatch, CPRA 
equal to 100%, blood type 
identical or permissible 
Nation 
Any 
4 
CPRA equal to 100%, blood 
type identical or permissible 
Nation 
Any 
5 
Prior living donor, blood 
type identical or permissible  250NM 
Any 
6 
Registered prior to 18 years 
old, blood type identical or 
permissible 
250NM 
Any 
7 
Medically Urgent 
250NM 
Any 

 
 
 
Classification Candidates that are 
And registered at a 
transplant hospital 
that is at or within 
this distance from 
the hospital that 
distribution will be 
based upon 
With this donor 
blood type: 
8 
0-ABDR mismatch, CPRA 
equal to 99%, blood type 
identical or permissible 
250NM 
Any 
9 
CPRA equal to 99%, blood 
type identical or permissible 
250NM 
Any 
10 
0-ABDR mismatch, CPRA 
equal to 98%, blood type 
identical or permissible 
250NM 
Any 
11 
CPRA equal to 98%, blood 
type identical or permissible 
250NM 
Any 
12 
0-ABDR mismatch, blood 
type identical  
250NM 
Any 
13 
0-ABDR mismatch, CPRA 
greater than or equal to 
80%, and blood type 
identical  
Nation 
Any 
14 
0-ABDR mismatch, CPRA 
greater than or equal to 21% 
but no greater than 79%, 
less than 18 at time of 
match, and blood type 
identical  
Nation 
Any 
15 
0-ABDR mismatch, CPRA 
greater than or equal to 0% 
but less than or equal to 
20%, less than 18 at time of 
match, and blood type 
identical  
Nation 
Any 
16 
0-ABDR mismatch, CPRA 
greater than or equal to 21% 
but no greater than 79%, 
and blood type identical  
Nation 
Any 

 
 
 
Classification Candidates that are 
And registered at a 
transplant hospital 
that is at or within 
this distance from 
the hospital that 
distribution will be 
based upon 
With this donor 
blood type: 
17 
0-ABDR mismatch, blood 
type B  
250NM 
O 
18 
0-ABDR mismatch, CPRA 
greater than or equal to 
80%, and blood type B  
Nation 
O 
19 
0-ABDR mismatch, CPRA 
greater than or equal to 21% 
but no greater than 79%, 
less than 18 at time of 
match, and blood type B 
Nation 
O 
20 
0-ABDR mismatch, CPRA 
greater than or equal to 0% 
but less than or equal to 
20%, less than 18 at time of 
match, and blood type B 
Nation 
O 
21 
0-ABDR mismatch, CPRA 
greater than or equal to 21% 
but no greater than 79%, 
and blood type B 
Nation 
O 
22 
0-ABDR mismatch, blood 
type permissible 
250NM 
Any 
23 
0-ABDR mismatch, CPRA 
greater than or equal to 
80%, and blood type 
permissible  
Nation 
Any 
24 
0-ABDR mismatch, CPRA 
greater than or equal to 21% 
but no greater than 79%, 
less than 18 at time of 
match, and blood type 
permissible  
Nation 
Any 

 
 
 
Classification Candidates that are 
And registered at a 
transplant hospital 
that is at or within 
this distance from 
the hospital that 
distribution will be 
based upon 
With this donor 
blood type: 
25 
0-ABDR mismatch, CPRA 
greater than or equal to 0% 
but less than or equal to 
20%, less than 18 at time of 
match, and blood type 
permissible  
Nation 
Any 
26 
0-ABDR mismatch, CPRA 
greater than or equal to 21% 
but no greater than 79%, 
and blood type permissible  
Nation 
Any 
27 
Prior liver, heart, and lung 
recipients who meet the 
qualifying criteria according 
to OPTN Policies 8.4.F: 
Prioritization for Liver 
Recipients on the Kidney 
Waiting List, 8.4.G: 
Prioritization for Heart 
Recipients on the Kidney 
Waiting List, or 8.4.H: 
Prioritization of Lung 
Recipients on the Kidney 
Waiting List, blood type 
permissible or identical 
250NM 
Any 
28 
Blood type B  
250NM 
A2 or A2B 
29 
All remaining candidates, 
blood type identical or 
permissible 
250NM 
Any 
30 
Registered prior to 18 years 
old, blood type identical or 
permissible  
Nation 
Any 
31 
Blood type B  
Nation 
A2 or A2B 

 
 
 
Classification Candidates that are 
And registered at a 
transplant hospital 
that is at or within 
this distance from 
the hospital that 
distribution will be 
based upon 
With this donor 
blood type: 
32 
All remaining candidates, 
blood type identical or 
permissible 
Nation 
Any

---

## 8.4.K — Allocation of Kidneys from Deceased Donors with KDPI Scores Greater than

<!-- Policy: 8 | Section: 8.4.K | Category: Kidney Allocation -->

or Equal to 35% but Less than or Equal to 85%  
Kidneys from donors with KDPI scores greater than or equal to 35% but less than or equal to 
85% are allocated to candidates according to Table 8-9 below and the following: 
 
• 
Classifications 1 through 30 for one deceased donor kidney 
• 
Classification 31 and 32 for both kidneys from a single deceased donor 
 
For the purposes of Table 8-9, distribution will be based on the distance from the candidate’s 
transplant hospital to the donor hospital, unless the kidney is allocated according to OPTN Policy 
8.7: Allocation of Released Kidneys. For kidneys that are released and the host OPO or the OPTN 
executes a released kidney match run, distribution will be based on the distance from the 
candidate’s transplant hospital to the transplant hospital that released the organ. 
Table 8-9: Allocation of Kidneys from Deceased Donors with KDPI Greater Than or Equal To 
35% and Less Than or Equal To 85% 
Classification 
Candidates that are 
And registered at a 
transplant hospital 
that is at or within 
this distance from 
the hospital that 
distribution will be 
based upon 
With this donor blood 
type: 
1 
0-ABDR mismatch, CPRA 
equal to 100%, blood type 
identical or permissible 
250NM 
Any 
2 
CPRA equal to 100%, blood 
type identical or permissible 
250NM 
Any 
3 
0-ABDR mismatch, CPRA 
equal to 100%, blood type 
identical or permissible 
Nation 
Any 

 
 
 
Classification 
Candidates that are 
And registered at a 
transplant hospital 
that is at or within 
this distance from 
the hospital that 
distribution will be 
based upon 
With this donor blood 
type: 
4 
CPRA equal to 100%, blood 
type identical or permissible 
Nation 
Any 
5 
Prior living donor, blood 
type identical or permissible 
250NM 
Any 
6 
Medically Urgent 
250NM 
Any 
7 
0-ABDR mismatch, CPRA 
equal to 99%, blood type 
identical or permissible 
250NM 
Any 
8 
CPRA equal to 99%, blood 
type identical or permissible 
250NM 
Any 
9 
0-ABDR mismatch, CPRA 
equal to 98%, blood type 
identical or permissible 
250NM 
Any 
10 
CPRA equal to 98%, blood 
type identical or permissible 
250NM 
Any 
11 
0-ABDR mismatch, blood 
type identical  
250NM 
Any 
12 
0-ABDR mismatch, CPRA 
greater than or equal to 
80%, and blood type 
identical  
Nation 
Any 
13 
0-ABDR mismatch, CPRA 
greater than or equal to 21% 
but no greater than 79%, 
less than 18 at time of 
match, and blood type 
identical  
Nation 
Any 

 
 
 
Classification 
Candidates that are 
And registered at a 
transplant hospital 
that is at or within 
this distance from 
the hospital that 
distribution will be 
based upon 
With this donor blood 
type: 
14 
0-ABDR mismatch, CPRA 
greater than or equal to 0% 
but less than or equal to 
20%, less than 18 at time of 
match, and blood type 
identical  
Nation 
Any 
15 
0-ABDR mismatch, CPRA 
greater than or equal to 21% 
but no greater than 79%, 
and blood type identical  
Nation 
Any 
16 
0-ABDR mismatch, and 
blood type B  
250NM 
O 
17 
0-ABDR mismatch, CPRA 
greater than or equal to 
80%, and blood type B  
Nation 
O 
18 
0-ABDR mismatch, CPRA 
greater than or equal to 21% 
but no greater than 79%, 
less than 18 at time of 
match, and blood type B  
Nation 
O 
19 
0-ABDR mismatch, CPRA 
greater than or equal to 0% 
but less than or equal to 
20%, less than 18 at time of 
match, and blood type B  
Nation 
O 
20 
0-ABDR mismatch, CPRA 
greater than or equal to 21% 
but no greater than 79%, 
and blood type B  
Nation 
O 
21 
0-ABDR mismatch, blood 
type permissible  
250NM 
Any 
22 
0-ABDR mismatch, CPRA 
greater than or equal to 
80%, and blood type 
permissible  
Nation 
Any 

 
 
 
Classification 
Candidates that are 
And registered at a 
transplant hospital 
that is at or within 
this distance from 
the hospital that 
distribution will be 
based upon 
With this donor blood 
type: 
23 
0-ABDR mismatch, CPRA 
greater than or equal to 21% 
but no greater than 79%, 
less than 18 years old at 
time of match, and blood 
type permissible  
Nation 
Any 
24 
0-ABDR mismatch, CPRA 
greater than or equal to 0% 
but less than or equal to 
20%, less than 18 years old 
at time of match, and blood 
type permissible  
Nation 
Any 
25 
0-ABDR mismatch, CPRA 
greater than or equal to 21% 
but no greater than 79%, 
and blood type permissible  
Nation 
Any 
26 
Prior liver, heart, and lung 
recipients who meet the 
qualifying criteria according 
to Policy 8.4.F: Prioritization 
for Liver Recipients on the 
Kidney Waiting List, Policy 
8.4.G: Prioritization for 
Heart Recipients on the 
Kidney Waiting List, or Policy 
8.4.H: Prioritization for Lung 
Recipients on the Kidney 
Waiting List, blood type 
permissible or identical 
250NM 
Any 
27 
Blood type B  
250NM 
A2 or A2B 
28 
All remaining candidates, 
blood type identical or 
permissible 
250NM 
Any 
29 
Blood type B  
Nation 
A2 or A2B 

 
 
 
Classification 
Candidates that are 
And registered at a 
transplant hospital 
that is at or within 
this distance from 
the hospital that 
distribution will be 
based upon 
With this donor blood 
type: 
30 
All remaining candidates, 
blood type identical or 
permissible 
Nation 
Any 
31 
Candidates who have 
specified they are willing to 
accept both kidneys from a 
single deceased donor, 
blood type identical or 
permissible 
250NM 
Any 
32 
Candidates who have 
specified they are willing to 
accept both kidneys from a 
single deceased donor, 
blood type identical or 
permissible 
Nation 
Any

---

## 8.4.L — Allocation of Kidneys from Deceased Donors with KDPI Scores Greater than

<!-- Policy: 8 | Section: 8.4.L | Category: Kidney Allocation -->

85%  
With the exception of 0-ABDR mismatches, kidneys from deceased donors with KDPI scores 
greater than 85% are allocated to adult candidates according to Table 8-10 below and the 
following: 
 
• 
Classifications 1 through 21, 23, and 24 for one deceased donor kidney 
• 
Classifications 22 and 25 for both kidneys from a single deceased donor 
 
For the purposes of Table 8-10, distribution will be based on the distance from the candidate’s 
transplant hospital to the donor hospital, unless the kidney is allocated according to OPTN Policy 
8.7: Allocation of Released Kidneys. For kidneys that are released and the host OPO or the OPTN 
executes a released kidney match run, distribution will be based on the distance from the 
candidate’s transplant hospital to the transplant hospital that released the organ. 
 

 
 
 
Table 8-10: Allocation of Kidneys from Deceased Donors with KDPI Scores Greater Than 85% 
Classification 
Candidates that are 
And registered at a 
transplant hospital 
that is at or within 
this distance from 
the hospital that 
distribution will be 
based upon 
With this donor blood 
type: 
1 
0-ABDR mismatch, CPRA 
equal to 100%, blood type 
identical or permissible 
250NM 
Any 
2 
CPRA equal to 100%, blood 
type identical or permissible 
250NM 
Any 
3 
0-ABDR mismatch, CPRA 
equal to 100%, blood type 
identical or permissible 
Nation 
Any 
4 
CPRA equal to 100%, blood 
type identical or permissible 
Nation 
Any 
5 
Medically Urgent 
250NM 
Any 
6 
0-ABDR mismatch, CPRA 
equal to 99%, blood type 
identical or permissible 
250NM 
Any 
7 
CPRA equal to 99%, blood 
type identical or permissible 
250NM 
Any 
8 
0-ABDR mismatch, CPRA 
equal to 98%, blood type 
identical or permissible 
250NM 
Any 
9 
CPRA equal to 98%, blood 
type identical or permissible 
250NM 
Any 
10 
0-ABDR mismatch, blood 
type identical or permissible  
250NM 
Any 

 
 
 
Classification 
Candidates that are 
And registered at a 
transplant hospital 
that is at or within 
this distance from 
the hospital that 
distribution will be 
based upon 
With this donor blood 
type: 
11 
0-ABDR mismatch, CPRA 
greater than or equal to 
80%, and blood type 
identical  
Nation 
Any 
12 
0-ABDR mismatch, CPRA 
greater than or equal to 21% 
but no greater than 79%, 
and blood type identical  
Nation 
Any 
13 
0-ABDR mismatch, blood 
type B  
250NM 
O 
14 
0-ABDR mismatch, CPRA 
greater than or equal to 
80%, and blood type B  
Nation 
O 
15 
0-ABDR mismatch, CPRA 
greater than or equal to 21% 
but no greater than 79%, 
and blood type B  
Nation 
O 
16 
0-ABDR mismatch, blood 
type permissible  
250NM 
Any 
17 
0-ABDR mismatch, CPRA 
greater than or equal to 80% 
, and blood type permissible  
Nation 
Any 
18 
0-ABDR mismatch, CPRA 
greater than or equal to 21% 
but no greater than 79%, 
and blood type permissible  
Nation 
Any 

 
 
 
Classification 
Candidates that are 
And registered at a 
transplant hospital 
that is at or within 
this distance from 
the hospital that 
distribution will be 
based upon 
With this donor blood 
type: 
19 
Prior liver, heart, and lung 
recipients who meet the 
qualifying criteria according 
to Policy 8.4.F: Prioritization 
for Liver Recipients on the 
Kidney Waiting List, Policy 
8.4.G: Prioritization for 
Heart Recipients on the 
Kidney Waiting List, or Policy 
8.4.H: Prioritization of Lung 
Recipients on the Kidney 
Waiting List, blood type 
permissible or identical 
250NM 
Any 
20 
Blood type B 
250NM 
A2 or A2B 
21 
All remaining candidates, 
blood type identical or 
permissible 
250NM 
Any 
22 
Candidates who have 
specified they are willing to 
accept both kidneys from a 
single deceased donor, 
blood type identical or 
permissible 
250NM 
Any 
23 
Blood type B 
Nation 
A2 or A2B 
24 
All remaining candidates, 
blood type identical or 
permissible 
Nation 
Any 
25 
Candidates who have 
specified they are willing to 
accept both kidneys from a 
single deceased donor, 
blood type identical or 
permissible 
Nation 
Any

---

## 8.5.A — Allocation of Dual Kidneys

<!-- Policy: 8 | Section: 8.5.A | Category: Kidney Allocation -->

[8.5 Allocation of Both Kidneys from a Single Deceased Donor to a]
Single Candidate

If a host OPO procures both kidneys with a KDPI score greater than or equal to 35% from a single 
deceased donor who weighs greater than or equal to 18 kg, those kidneys will be offered to 
candidates according to OPTN Policy 8.4.K: Allocation of Kidneys from Deceased Donors with 
KDPI Scores Greater than or Equal to 35% but Less than or Equal to 85% or OPTN Policy 8.4.L: 
Allocation of Kidneys from Deceased Donors with KDPI Scores Greater Than 85%.

---

## 8.5.B — Allocation of En Bloc Kidneys

<!-- Policy: 8 | Section: 8.5.B | Category: Kidney Allocation -->

If a host OPO procures both kidneys from a single deceased donor less than 18 kg, the host OPO 
must offer both kidneys en bloc according to OPTN Policy 8.4.I: Allocation of Kidneys from 
Deceased Donors with KDPI Scores less than or equal to 20%.

---

## 8.5.C — Transplanting Kidneys Individually after Allocation of Both Kidneys from a

<!-- Policy: 8 | Section: 8.5.C | Category: Kidney Allocation | Cross-ref: Policy 5 -->

Single Deceased Donor to a Single Candidate 
If the transplanting surgeon determines, based on medical judgment, that kidneys procured 
together from a single donor should instead be transplanted individually, then the receiving 
transplant program must do one of the following: 
 
• 
Transplant one of the kidneys into the originally designated recipient and document the 
reason for not transplanting the kidneys together. The receiving transplant program will 
decide which of the two kidneys to transplant into the originally designated recipient and 
release the other kidney according to OPTN Policy 5.9: Released Organs. 
• 
Release both kidneys to be allocated according to the KDPI score of the deceased donor, 
pursuant to OPTN Policy 5.9: Released Organs. Kidneys originally allocated en bloc and then 
split can no longer be allocated as en bloc.

---

## 8.6.A — Choice of Right versus Left Donor Kidney

<!-- Policy: 8 | Section: 8.6.A | Category: Kidney Allocation -->

If both kidneys from a deceased donor are able to be transplanted, the transplant hospital that 
received the offer for the candidate with higher priority on the waiting list will get to choose first 
which of the two kidneys it will receive.  
 
However, when a kidney is offered to a 0-ABDR mismatched candidate, a candidate with a CPRA 
greater than or equal to 99% (classifications 1 through 4, 8 or 9 in Tables 8-7 and 8-8; 
classifications 1 through 4, 7 or 8 in Table 8-9; and classifications 1 through 4, 6 or 7 in Table 8-
10) or to a combined kidney and non-renal organ candidate, the host OPO determines whether 
to offer the left or the right kidney.

---

## 8.6.B — National Kidney Offers

<!-- Policy: 8 | Section: 8.6.B | Category: Kidney Allocation -->

The host OPO must allocate deceased donor kidneys according to Table 8-11 below. For 
purposes of this section, national candidates are those candidates registered at transplant 
programs more than 250 nautical miles from the donor hospital. 
 
Table 8-11: National Kidney Offers 
If the organ offer is for: 
Then the host OPO must: 
A national 0-ABDR mismatch candidate 
Allocate the kidney or contact the Organ 
Center for assistance allocating the kidney 
A national 100% CPRA candidate in match 
classifications 1 through 4 in allocation 
sequences according to Tables 8-7 through 8-
10  
Allocate the kidney or contact the Organ 
Center for assistance allocating the kidney 
Any other national candidates 
Contact the Organ Center for assistance 
allocating the kidney

---

## 8.6.C — Kidney Allocation in Multi-Organ Combinations

<!-- Policy: 8 | Section: 8.6.C | Category: Kidney Allocation | Cross-ref: Policy 11, Policy 5, Policy 9 -->

If a host OPO procures a kidney along with other organs, the host OPO must first offer the 
kidney according to one of the following policies before allocating the kidney to kidney alone 
candidates according to OPTN Policy 8: Allocation of Kidneys: 
• 
OPTN Policy 5.10.E: Allocation of Heart-Kidneys 
• 
OPTN Policy 5.10.F: Allocation of Lung-Kidneys 
• 
OPTN Policy 9.9: Liver-Kidney Allocation 
• 
OPTN Policy 11.4.A: Kidney-Pancreas Allocation Order

---

## 8.6.D — Multi-Organ Combinations Allocated but Not Transplanted

<!-- Policy: 8 | Section: 8.6.D | Category: Kidney Allocation | Cross-ref: Policy 5 -->

If a multi-organ combination that includes a kidney is allocated but the kidney transplant is not 
performed, the kidney must be reallocated according to OPTN Policy 5.9: Released Organs.

---

## 8.6.E — Location of Donor Hospitals

<!-- Policy: 8 | Section: 8.6.E | Category: Kidney Allocation -->

For the purpose of determining the location of the donor hospital, kidneys procured in Alaska 
will be considered procured from the Sea-Tac Airport, Seattle, Washington.

---

## 8.7 — Allocation of Released Kidneys

<!-- Policy: 8 | Section: 8.7 | Category: Kidney Allocation | Cross-ref: Policy 5, Policy 9 -->

For kidneys allocated according to OPTN Policy 5.9: Released Organs, the host OPO may  
1. Continue allocation according to the original match run 
2. Allocate the kidney using the released kidney match run in accordance with Tables 8-7, 8-8, 8-9, and 
8-10 or 
3. Contact the OPTN for assistance allocating the kidney 

 
 
 
 
Policy 9: Allocation of Livers and Liver-Intestines 
9.1 
Status and Score Assignments 
178 
9.2 
Status and Laboratory Values Update Schedule 
184 
9.3 
Status Exceptions 
186 
9.4 
MELD or PELD Score Exceptions 
186 
9.5 
Specific Standardized MELD or PELD Score Exceptions 
189 
9.6 
Waiting Time 
199 
9.7 
Liver Allocation Points 
199 
9.8 
Liver Allocation, Classifications, and Rankings 
200 
9.9 
Liver-Kidney Allocation 
232 
9.10 Expedited Placement of Livers 
234 
9.11 Administrative Rules 
235 
9.12 Variances 
235

---
