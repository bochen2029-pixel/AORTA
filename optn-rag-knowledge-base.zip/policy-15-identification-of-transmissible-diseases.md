# OPTN Policy 15: Identification of Transmissible Diseases

**Source:** OPTN Policies | **Effective:** 12/10/2025 | **Category:** Transmissible Diseases
**Confidence:** HIGH — Official OPTN policy language

---

## 15.1 — Patient Safety Contact

<!-- Policy: 15 | Section: 15.1 | Category: Transmissible Diseases -->

Each OPO and transplant program must identify a primary and secondary Patient Safety Contact and 
develop and comply with a written protocol for the patient safety contact to fulfill all the following 
responsibilities: 
 
1. A Patient Safety Contact must be available 24 hours a day. 
2. The OPO’s primary or secondary Patient Safety Contact must communicate medical information that 
may affect recipient care to the Patient Safety Contact at the recipient’s transplant program as soon 
as possible, but no later than 24 hours after receipt. 
3. The transplant program’s primary or secondary Patient Safety Contact must communicate medical 
information that may affect recipient care to the medical staff responsible for the recipient’s clinical 
care at the transplant program as soon as possible, but no later than 24 hours after receipt. 
4. The receiving primary or secondary Patient Safety Contact must acknowledge the receipt of any 
information that may affect or change recipient care within 24 hours of receipt. 
5. The transplant program’s Patient Safety Contact must acknowledge receipt of post-procurement 
donor results, through the OPTN Donor Data and Matching System, within 24 hours of notification 
of post-procurement donor results reported in accordance with OPTN Policy 15.4.A Host OPO 
Requirements for Reporting Post-Procurement Donor Results and Discovery of Potential Disease 
Transmissions. 
6. OPOs and transplant programs must report to the OPTN a valid phone number and email address 
for both the primary and secondary Patient Safety Contacts. 
7. OPOs and transplant programs must verify their primary and secondary Patient Safety Contacts are 
accurate through the OPTN Computer System during the biannual OPTN audit.

---

## 15.2 — Candidate Pre-Transplant Infectious Disease Reporting and

<!-- Policy: 15 | Section: 15.2 | Category: Transmissible Diseases -->

Testing Requirements   
Transplant candidates must be tested for: 
1. HIV using a CDC recommended laboratory HIV testing algorithm 

OPTN Policies                                                                                                              Policy 15: Identification of Transmissible Diseases 
 
 
2. Hepatitis B surface antigen (HBsAg) 
3. Hepatitis B core antibody (total anti-HBc) 
4. Hepatitis B surface antibody (HBsAb) 
5. Hepatitis C antibody (anti-HCV) 
6. Hepatitis C ribonucleic acid (RNA) by nucleic acid test (NAT) 
 
unless the testing would violate state or federal laws. 
Infectious disease testing must be performed in a CLIA-certified laboratory or in a laboratory meeting 
equivalent requirements as determined by CMS using FDA-licensed, approved, or cleared tests. 
 
For all candidates 12 years or older, candidate samples must be drawn during the hospital admission for 
transplant but prior to anastomosis of the first organ. 
 
If the candidate is known to be living with HIV, HBV, or HCV, then testing for the known viral infection or 
infections is not required, however the other tests required according to this policy must still be 
performed. 
 
Candidates who test positive for HIV, hepatitis B, or hepatitis C must be offered appropriate counseling. 
 
As part of the candidate’s medical evaluation, an assessment for the need to provide HBV vaccination 
must occur. The transplant program must report the candidate’s HBV vaccination status to the OPTN. If 
the transplant program determines that vaccination cannot be initiated or completed due to timing 
related to transplant, medical contraindication, or other reasons in the transplant program’s medical 
judgement, the reason for not initiating or completing HBV vaccination must be documented in the 
candidate’s medical records and reported to the OPTN.

---

## 15.3.A — General Risks of Potential Malignancy or Disease Transmission

<!-- Policy: 15 | Section: 15.3.A | Category: Transmissible Diseases | Cross-ref: Policy 14, Policy 2 -->

Transplant programs must inform candidates of the general risks of potential transmission of 
malignancies and disease from organ donors, including all of the following information: 
 
1. Deceased donors are evaluated and screened according to OPTN Policy 2.3: Evaluating and 
Screening Potential Deceased Donors. 
2. Living donors are required to undergo screening for diseases according to OPTN Policy 14.4: 
Medical Evaluation Requirements for Living Donor. 
3. There is no comprehensive way to screen deceased and living donors for all transmissible 
diseases. 
4.  Malignancies and diseases may be identified and transmitted after transplant. 
5. Donor evaluation and screening results may impact post-transplant evaluation, screening, 
and management of the candidate. 
 
The transplant program must do both of the following: 
 
1. Explain these risks and obtain informed consent from the candidate or candidate’s agent 
any time prior to transplant. 

OPTN Policies                                                                                                              Policy 15: Identification of Transmissible Diseases 
 
 
2. Document consent in the candidate’s medical record.

---

## 15.3.B — Donors with Risk Identified Pre-Transplant

<!-- Policy: 15 | Section: 15.3.B | Category: Transmissible Diseases -->

Transplant programs must meet the requirements according to Table 15-1 below when the 
deceased or living donor has risk of disease transmission identified pre-transplant. 
 
Table 15-1: Requirements for Donors with Risk Identified Pre-Transplant 
Each time any of the following occurs: 
Then transplant programs must do all of the 
following: 
• The donor tests positive for any of the 
following: 
a. Hepatitis B surface antigen (HBsAg) 
b. Hepatitis B nucleic acid test (NAT) 
c. Hepatitis C NAT 
1. Explain the risks and obtain informed 
consent from the intended recipient or 
the intended recipient’s agent after the 
organ offer but before transplant 
2. Document this consent in the intended 
recipient’s medical record 
3. Follow the recipient for the development 
of potential donor-derived disease after 
transplant 
• The donor tests positive for HIV antibody 
(anti-HIV), HIV antigen/antibody (Ag/Ab), 
or HIV NAT, and the organ offered is a 
kidney, liver, or liver-kidney 
1. A transplant physician must confirm that 
the candidate is living with HIV. 
2. A transplant physician must explain the 
risks and obtain informed consent from 
the intended recipient or the intended 
recipient’s agent after the organ offer but 
before transplant. 
3. Document this consent in the intended 
recipient’s medical record 
• The donor tests positive for HIV antibody 
(anti-HIV), HIV antigen/antibody (Ag/Ab), 
or HIV NAT, and the transplant program 
participates in an approved variance 
according to Policy 15.7.D: Open Variance 
for the Recovery and Transplantation of 
Non-Kidney and Non-Liver Organs from 
Donors with HIV 
1. Confirm that the candidate is living with 
HIV. 
2. Explain the risks and obtain informed 
consent from the intended recipient or 
the intended recipient’s agent after the 
organ offer but before transplant. 
3. Document this consent in the intended 
recipient’s medical record 
• The donor has any risk criteria for acute 
HIV, HBV, or HCV infection according to the 
U.S. Public Health Service (PHS) Guideline 
1. Inform the intended recipient or the 
intended recipient’s agent after the organ 
offer but before transplant that risk 
criteria are present in the donor 
2. Document that this information was 
provided in the intended recipient’s 
medical record 
 
If in the medical judgment of the transplanting physician, extra vessels are required for use in an emergency 
transplant procedure for an organ other than the organ with which they were recovered, then the transplant 

hospital must do both of the following post-transplant: 
1.
Inform the recipient of the use of the extra vessels and if the donor had any risk criteria for acute
HIV, HBV, or HCV infection according to the U.S. Public Health Service (PHS) Guideline
2.
Provide follow up to the recipient according to OPTN Policy 15.3.C: Required Post-Transplant
Infectious Disease Testing

---

## 15.3.C — Required Post-Transplant Infectious Disease Testing

<!-- Policy: 15 | Section: 15.3.C | Category: Transmissible Diseases -->

1.
Transplant programs must test all recipients post-transplant for:
a.
HIV ribonucleic acid (RNA) by nucleic acid test (NAT)
b.
HBV deoxyribonucleic acid (DNA) by nucleic acid test (NAT)
c.
HCV ribonucleic acid (RNA) by nucleic acid test (NAT)
2.
Testing must be performed on the recipient at least 28 days but no later than 56 days post-
transplant.
3.
If the candidate is known to be infected with HIV, HBV, or HCV, then testing for the known
viral infection or infections is not required, however the other tests required according to
this policy must still be performed.
4.
The transplant program must offer recipients treatment of or prophylaxis for HIV, HBV, or
HCV, when medically appropriate.
5.
Transplant programs must conduct HBV NAT testing on liver recipients at least 335 days but
no later than 395 days post-transplant.

---

## 15.4 — Host OPO Requirements for Reporting Post-Procurement Test

<!-- Policy: 15 | Section: 15.4 | Category: Transmissible Diseases -->

Results and Discovery of Potential Disease Transmissions 
Host OPOs must report any test results or information received post-procurement that indicate 
there may be a possibility for donor-derived disease as follows.

---

## 15.4.A — Host OPO Requirements for Reporting Post-Procurement Donor Results and

<!-- Policy: 15 | Section: 15.4.A | Category: Transmissible Diseases -->

Discovery of Potential Disease Transmissions 
The host OPO must report all positive test results and other relevant information received post-
procurement for each donor to all the receiving transplant programs’ Patient Safety Contacts 
through the OPTN Donor Data and Matching System as soon as possible but no later than 24 
hours after receipt. 
1.
All results indicating Pathogens of Special Interest must also be reported through the OPTN 
Improving Patient Safety Portal. The OPTN Contractor provides a list of Pathogens of Special 
Interest, including any results that can be excluded from reporting. The OPTN Contractor 
reviews and updates this list at least annually
2.
All other positive test results and relevant information must be reported according to Table

OPTN Policies                                                                                                              Policy 15: Identification of Transmissible Diseases 
 
 
15-2 below. 
 
Table 15-2: Host OPO Reporting Requirements for Positive Post-Procurement Donor Results and 
Discovery of Potential Disease Transmissions 
The host following 
OPO must report all of the positive results: 
To: 
 
Serologic, NAT, or antigen results 
indicating presence of parasites, 
virus, or fungi 
The receiving transplant program’s 
patient safety contact 
Samples 
relevant to 
all recipients 
Cultures from the following 
specimens: 
• 
Ascites  
• 
Blood  
• 
Cerebrospinal fluid (CSF)  
• 
Deep wound  
• 
Genital 
• 
Pericardial  
• 
Pleural fluid  
The receiving transplant program’s 
patient safety contact 
Mycobacterial smears and cultures 
Fungal smears and cultures with the 
exception of Candida species  
The receiving transplant program’s 
patient safety contact 
The receiving transplant program’s 
patient safety contact 
 
 
Respiratory samples (bacterial or 
Candida species) only to transplant 
programs receiving lungs or covered 
head and neck VCAs 
The receiving transplant program’s 
patient safety contact 
Relevant 
information 
Urine cultures (bacterial or Candida 
species) only to transplant programs 
receiving kidneys or covered 
genitourinary organ VCAs  
The receiving transplant program’s 
patient safety contact 
Malignancy or other findings highly 
suggestive of malignancy recognized 
after procurement 
1. The receiving transplant 
program’s patient safety contact 
2. The OPTN Improving Patient 
Safety Portal 
Histopathology results reported post-
procurement 
The receiving transplant program’s 
patient safety contact 
All final culture information for any 
culture results that were reported 
according to these requirements 
The receiving transplant program’s 
patient safety contact 

OPTN Policies                                                                                                              Policy 15: Identification of Transmissible Diseases 
 
 
The host following 
OPO must report all of the positive results: 
To: 
Relevant 
information 
Other psycho-social history, medical 
history, autopsy, testing, and 
laboratory findings identifying 
infectious conditions that may 
adversely affect a potential 
transplant recipient 
The receiving transplant program’s 
patient safety contact

---

## 15.4.B — Host OPO Requirements for Reporting Post-Procurement Discovery of

<!-- Policy: 15 | Section: 15.4.B | Category: Transmissible Diseases -->

Recipient Disease or Malignancy  
If the host OPO is notified that an organ recipient is suspected to have, is confirmed positive for, 
or dies from a potential transmissible disease, infection, or malignancy and there is substantial 
concern that it could be from the transplanted organ, then the host OPO must do all of the 
following: 
 
1. Communicate the suspected donor’s and affected organ recipient’s test results and 
diagnosis that may be relevant to acute patient care, as soon as possible but no more than 
24 hours after receipt, to all transplant programs’ primary Patient Safety Contacts and 
tissue banks that received organs or tissue from the donor. This includes any test results 
that were not available at the time of procurement or that were performed after 
procurement. If the transplant program's primary Patient Safety Contact does not 
acknowledge receipt of the information within 24 hours, then the host OPO must notify 
the transplant program’s secondary Patient Safety Contact. 
2. Document that this information is shared with all receiving transplant programs and 
tissue banks.

---

## 15.4.C — Host OPO Requirements for Post-Reporting Follow Up

<!-- Policy: 15 | Section: 15.4.C | Category: Transmissible Diseases -->

For each potential disease transmission event reported through the OPTN Improving Patient 
Safety Portal, the host OPO must do all of the following: 
 
1. Complete and submit the Potential Disease Transmission Report Form no later than 24 
hours after the event is reported to the OPO through the OPTN Improving Patient Safety 
Portal.  
2. Contribute to a follow up review of the event, in partnership with OPTN patient safety staff. 
3. Provide additional information or specimens related to the deceased donor if requested.

---

## 15.5 — Transplant Program Requirements for Communicating  Discovery

<!-- Policy: 15 | Section: 15.5 | Category: Transmissible Diseases -->

of Potential Transmission of Unexpected Pathogen, Disease or 
Malignancy  
A potential transmission of a pathogen, disease, or malignancy is unexpected if the pathogen, 
disease, or malignancy was not known to the transplant program by the time of donor cross-
clamp. 
 

OPTN Policies                                                                                                              Policy 15: Identification of Transmissible Diseases 
 
 
Transplant programs must communicate any test results or information that indicates 
unexpected donor-derived disease is possible as follows.

---

## 15.5.A — Transplant Program Requirements for Discovery of Potential Transmission

<!-- Policy: 15 | Section: 15.5.A | Category: Transmissible Diseases -->

of Unexpected Donor Pathogen, Disease or Malignancy 
If the transplant program identifies any results indicative of unexpected pathogen, disease or 
malignancy from donor specimen testing collected pre-transplant, then the transplant program 
must do all of the following: 
 
1. Notify the host OPO or living donor recovery hospital of the findings within 24 hours of 
discovery. 
2. Notify the recipients under care at the transplant program, or the recipient’s agents, of the 
risk or confirmation of unexpected transmissible disease or malignancy. 
3. Document the new information about the donor and potential risk or confirmation of 
unexpected transmissible disease or malignancy in the recipient’s medical records. 
4. Follow the notified recipients for the potential development of the disease or malignancy 
after transplant. 
5. Offer the recipients additional testing, monitoring, and treatment as appropriate, in 
addition to routine follow up care.

---

## 15.5.B — Transplant Program Requirements for Reporting Discovery of Potential

<!-- Policy: 15 | Section: 15.5.B | Category: Transmissible Diseases -->

Transmission of Unexpected Recipient Pathogen, Disease or Malignancy 
 
Transplant programs are required to report the discovery of a potential transmission for the 
following recipients: 
 
• 
A non-lung organ recipient who: 
1. Is suspected to have, is confirmed positive for, or has died from any unexpected 
potential transmissible pathogen, disease, or malignancy, and 
2. There is substantial concern that the suspected or confirmed pathogen, disease, or 
malignancy could be from the transplant organ 
• 
A lung recipient who: 
1. Is suspected to have, is confirmed positive for, or has died from an unexpected potential 
transmissible pathogen, disease, or malignancy, and 
2. There is substantial concern that the suspected or confirmed disease, malignancy, or 
infection could be from the transplanted organ and 
3. There is clinical evidence of infection. A lung recipient is considered to have clinical 
evidence of infection based on the clinical judgment of the treating physician or team if: 
1. An organism is isolated from the respiratory tract or other site and 
2. There is substantial concern that the organism is donor-derived and contributes to 
the lung recipient’s illness 
• 
A lung recipient who: 
1. Shows evidence of colonization but not clinical evidence of infection and 
2. Respiratory tract testing reveals an unexpected positive result identifying a Pathogen of 
Special Interest or malignancy, and 

OPTN Policies                                                                                                              Policy 15: Identification of Transmissible Diseases 
 
 
3. There is substantial concern that the unexpected positive result is from the transplanted 
organ. 
 
When an organ recipient is suspected to have, is confirmed positive for, or has died from 
potential transmissible disease, infection, or malignancy and there is substantial concern that it 
could be from the transplanted organ, then the transplant program must do all of the following: 
 
1. Notify the primary Patient Safety Contact at the host OPO of the deceased donor or transplant 
program at which the living donor was recovered and provide available documentation 
within 24 hours of learning of the event. If the primary Patient Safety Contact of the host 
OPO of the deceased donor or transplant program at which the living donor was recovered 
does not acknowledge receipt of the information within 24 hours, then the transplant 
program must notify the secondary Patient Safety Contact. 
2. Report the event through the OPTN Patient Safety Reporting Portal within 24 hours after 
learning of the event. 
3. Provide additional related information or specimens if requested.

---

## 15.5.C — Transplant Program Requirements for Post-Reporting Follow-Up

<!-- Policy: 15 | Section: 15.5.C | Category: Transmissible Diseases -->

If the transplant program has a recipient that is involved in an OPTN Improving Patient Safety 
Portal report, then the transplant program must also do all of the following: 
 
1. Submit any relevant test results including cultures, infectious disease testing results, imaging 
studies, or autopsy results to OPTN patient safety staff. 
2. Respond to host OPO, living donor recovery hospital, and OPTN patient safety staff requests 
for information regarding the recipient and communicate updated information regarding 
recipient condition, test results, diagnosis, and plans for treatment and follow up.  
3. Contribute to a follow up review of the event in partnership with OPTN patient safety staff. 
4. Provide additional related information or specimens if requested.

---

## 15.6 — Living Donor Recovery Hospital Requirements for Reporting

<!-- Policy: 15 | Section: 15.6 | Category: Transmissible Diseases -->

Post-Donation Discovery of Disease or Malignancy  
Living donor recovery hospitals must report any post donation test results or information that 
indicate there may be a possibility for donor-derived disease.

---

## 15.6.A — Living Donor Recovery Hospital Requirements for Reporting Post-Donation

<!-- Policy: 15 | Section: 15.6.A | Category: Transmissible Diseases -->

Discovery of Living Donor Disease or Malignancy 
If a living donor recovery hospital learns new information about a living donor during the first 
two years post donation that indicates risk of potential transmission of disease or malignancy, 
then the living donor recovery hospital must do all of the following: 
 
1. Disclose to the living donor that the potential disease transmission or malignancy will be 
reported to the receiving transplant program and the OPTN Improving Patient Safety Portal. 
2. Notify the receiving transplant program. 

OPTN Policies                                                                                                              Policy 15: Identification of Transmissible Diseases 
 
 
3. Report the potential transmission through the OPTN Improving Patient Safety Portal as soon 
as possible but no more than seven days after receipt of the new information.

---

## 15.6.B — Living Donor Program Requirements for Post Reporting Follow-Up

<!-- Policy: 15 | Section: 15.6.B | Category: Transmissible Diseases -->

If the living donor recovery hospital reports test results or other information to the OPTN 
through the Improving Patient Safety Portal, then the recovery hospital must also do all of the 
following: 
 
1. Contribute to a follow up review of the event in partnership with OPTN patient safety staff. 
2. Provide additional information or specimens related to the living donor if requested.

---

## 15.7.A — Requirements for Allocating Organs from Deceased Donors with HIV

<!-- Policy: 15 | Section: 15.7.A | Category: Transmissible Diseases | Cross-ref: Policy 2 -->

The OPO may allocate  organs from deceased donors with HIV only after determining the 
following: 
1. That the potential deceased donor has been tested according to Policy 2.9: Required 
Deceased Donor Infectious Testing and has HIV and 
2. That the candidate is living with HIV and willing to accept an organ from a donor with HIV  
3. For non-kidney and non-liver candidates living with HIV, that the candidate must be willing 
to accept the organ as part of an IRB-approved research protocol that meets the 
requirements in the National Institutes of Health (NIH) Final Notice regarding the recovery 
and transplantation of organs from donors with HIV and the requirements outlined in Policy 
15.7.D: Open Variance for the Recovery and Transplantation of Non-Kidney and Non-Liver 
Organs from Donors with HIV. 
 
The OPO must only allocate organs from donors with HIV to candidates living with HIV 
appearing on the match run, except in cases of directed donation. The OPO must verify that the 
potential recipient is  a  candidate living with HIV who is registered at a transplant  program that 
meets the requirements in OPTN Policy 15.7.B: Transplant Program Requirements for 
Transplantation of Organs from Donors with HIV.

---

## 15.7.B — Transplant Program Requirements for Transplantation of Organs from

<!-- Policy: 15 | Section: 15.7.B | Category: Transmissible Diseases -->

Donors with HIV 
The transplant program must meet the informed consent requirements according to Policy 15.3: 
Informed Consent of Transmissible Disease Risk. 
 
In order for a candidate living with HIV to appear on a deceased donor match run for an organ 
from a donor with HIV, the transplant hospital must complete a two-person reporting and 
verification process. This process must include two different individuals who each make an 
independent report to the OPTN that the candidate is living with HIV and willing to accept an 
organ from a donor with HIV. 
 

OPTN Policies                                                                                                              Policy 15: Identification of Transmissible Diseases 
 
 
For kidney, liver, and liver-kidney candidates, a transplant physician must verify and document 
in the medical record that the candidate is living with HIV and willing to accept an organ from a 
donor with HIV. This must occur prior to the two-person reporting and verification process. 
 
For non-kidney and non-liver candidates, the candidate must be willing to accept an organ from 
a donor with HIV as part of an IRB-approved research protocol that meets the requirements in 
the NIH Final Notice and the requirements outlined in Policy 15.7: Open Variance for the 
Recovery and Transplantation of Non-Kidney and Non-Liver Organs from Donors with HIV.

---

## 15.7.C — Recovery Hospital Requirements for Transplantation of Organs from Living

<!-- Policy: 15 | Section: 15.7.C | Category: Transmissible Diseases -->

Donors with HIV 
The recovery hospital must confirm that the potential living donor is living with HIV and the 
candidate is living with HIV and willing to accept an organ from a living donor with HIV. 
 
For non-kidney and non-liver living donors with HIV, the recovery hospital must confirm that the 
candidate is willing to accept an organ from a living donor with HIV as part of an IRB-approved 
research protocol that meets the requirements in the NIH Final Notice and the requirements 
outlined in Policy 15.7.D: Open Variance for the Recovery and Transplantation of Non-Kidney 
and Non-Liver Organs from Donors with HIV.

---

## 15.7.D — Open Variance for the Recovery and Transplantation of Non-Kidney and

<!-- Policy: 15 | Section: 15.7.D | Category: Transmissible Diseases | Cross-ref: Policy 16 -->

Non-Liver Organs from Donors with HIV 
This variance applies to transplant programs participating in an institutional review board (IRB) 
approved research protocol regarding the recovery of non-kidney and non-liver organs from 
donors that test positive for human immunodeficiency virus (HIV) and the transplantation of 
these organs into candidates living with HIV. 
 
Transplant programs may transplant non-kidney and non-liver organs from donors with HIV only 
if all of the following are true: 
 
1. The transplant program notifies and provides documentation to the OPTN that it is 
participating in an IRB-approved research protocol that meets the requirements in the NIH 
Final Notice regarding the research criteria for recovery and transplantation of non-kidney 
and non-liver organs from donors with HIV. 
2. The transplant program obtains informed consent from the potential transplant recipient to 
participate in the IRB-approved protocol that meets research criteria requirements 
described in the NIH Final Notice. 
3. The transplant program meets the informed consent requirements according to Policy: 15.3 
Informed Consent of Transmissible Disease Risk. 
 
The OPTN has the authority to collect data safety monitoring reports from transplant programs 
participating in this variance upon request. 
 

OPTN Policies                                                                                                              Policy 15: Identification of Transmissible Diseases 
 
 
Transplant programs must notify the OPTN of when protocols will be renewed and if they will no 
longer be participating in an IRB-approved research protocol that meets the requirements in the 
NIH Final Notice regarding the recovery and transplantation of non-kidney and non-liver organs 
from donors with HIV. 
 
The OPTN may release to the public the names of transplant programs participating in this 
variance.

OPTN Policies                                                                   Policy 16: Organ and Extra Vessel Packaging, Labeling, Shipping, and Storage 
 
 
Policy 16: Organ and Extra Vessel Packaging, Labeling, 
Shipping, and Storage 
16.1 Packaging and Labeling Requirements for Living Donor Organs and Extra Vessels 
316 
16.2 Packaging and Labeling Responsibilities 
316 
16.3 Packaging and Labeling 
317 
16.4 Documentation Accompanying the Organ or Extra Vessels 
320 
16.5 Verification and Recording of Information before Shipping 
321 
16.6 Extra Vessels Transplant and Storage 
321 
16.7 Transportation Responsibilities 
322

---
