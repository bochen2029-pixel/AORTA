# OPTN Policy 21: Composite Allocation Score Reference

**Source:** OPTN Policies | **Effective:** 12/10/2025 | **Category:** Composite Allocation Score
**Confidence:** HIGH — Official OPTN policy language

---

## 21.1.A — Waiting List Survival Formulas

<!-- Policy: 21 | Section: 21.1.A | Category: Composite Allocation Score -->

21.1.A.1 Lung Waitlist Area Under the Curve (WLAUC) 
The area under the lung waiting list survival probability curve within one year 
(WLAUC) is calculated using the formula 
 
𝑊𝐿𝑖= ∑𝑆𝑊𝐿,𝑖(𝑘−1)
365
𝑘=1
 
 
The calculation for SWL,i is in OPTN Policy 21.1.A.2 Expected Lung Waiting List Survival 
Probability Within One Year. 
 
21.1.A.2 Expected Lung Waiting List Survival Probability Within One Year 
The formula used to calculate expected lung waiting list survival probability within 
one year is 
 
𝑆𝑊𝐿,𝑖(𝑡) = 𝑆𝑊𝐿,0(𝑡)𝑒𝛽1𝑋1𝑖+𝛽2𝑋2𝑖+...+𝛽𝑝𝑋𝑝𝑖
 
 
Table 21-1: Expected Lung Waiting List Survival Probability Within One Year 
Variables lists what each variable in the formula represents. 
 
Table 21-1 Expected Lung Waiting List Survival Probability Within One Year Variables 
The variable  
Represents 
SWL,i(t) 
the expected waiting list survival probability at time t for candidate i 
SWL,0(t) 
the baseline waiting list survival probability at time t 
β1, β2, … βp 
the parameter estimates from the waiting list model (Table 21-5) 
Xji 
the value of characteristic j for candidate i 
I 
1, 2, …, N is the candidate identifier 
 
21.1.A.3 Converting Lung WLAUC to Lung Waiting List Survival Points 
Waiting list Survival Points are equal to  
 
((25(1-WLAUC/365) – 1)/24)*25

---

## 21.1.B — Post-Transplant Outcomes Formulas

<!-- Policy: 21 | Section: 21.1.B | Category: Composite Allocation Score -->

21.1.B.1 Expected Lung Five Years Post-Transplant Area Under the Curve 
(PTAUC) 
The area under the post-transplant survival probability curve during the first five 
years post-transplant (PTAUC) is calculated using the formula 
 
PT𝑖= ∑𝑆𝑇𝑋,𝑖(𝑘)
1826
𝑘=1
 
 
21.1.B.2 Expected Lung Post-Transplant Survival Probability Within Five 
Years 
The formula used to calculate expected lung post-transplant survival probability 
within five years is 
𝑆𝑇𝑋,𝑖(𝑡) = 𝑆𝑇𝑋,0(𝑡)𝑒𝛼1𝑌1+𝛼2𝑌2+...+𝛼𝑞𝑌𝑞 
 
 
Table 21-2: Expected Lung Post-Transplant Survival Probability Within Five Years 
Variables lists what each variable in the formula represents. 
 
Table 21-2 Expected Lung Post-Transplant Survival Probability Within Five Years Variables 
The variable  
Represents 
STX,i(t) 
expected post-transplant survival probability at time t for candidate i 
STX,0(t) 
the baseline post-transplant survival probability at time t  
α1, α2, … αq 
the parameter estimates from the post-transplant model (Table 21-8) 
Yji 
the value of characteristic j for candidate i 
I 
1, 2, …, N is the candidate identifier 
 
21.1.B.3 Converting Lung PTAUC to Lung Post-Transplant Outcomes Points 
Post-Transplant Outcomes Points are equal to  
 
(PTAUC/1826)*25

---

## 21.1.C — Biological Disadvantages Formulas

<!-- Policy: 21 | Section: 21.1.C | Category: Composite Allocation Score -->

21.1.C.1 Lung CPRA Points 
The Lung CPRA points are equal to 
((100CPRA-1)/99)*5 
 
The variable CPRA represents the probability of incompatibility based on the 
candidate’s CPRA. 
 

 
 
 
21.1.C.2 Lung Height Points 
The Lung Height points are equal to 
((100HTIN-1)/99)*5 
 
The variable HTIN represents the probability of incompatibility based on the 
candidate’s height found in OPTN Policy 21.2.C.1: Probability of Incompatible Lung 
Donors Based on Height.

---

## 21.1.D — Efficient Management Formulas

<!-- Policy: 21 | Section: 21.1.D | Category: Composite Allocation Score -->

21.1.D.1 Lung Travel Efficiency Points 
The Lung travel efficiency points are equal to 
 
(1 – [6.3*NM + 247.63 * (NM – 43.44) * I{NM > 43.44} – 104.44 * (NM – 67.17) * 
I{NM > 67.17} – 128.34 * (NM – 86.9) * I{NM > 86.9}] / 116989.1)*5 
 
The variable NM represents straight-line distance between donor hospital and 
candidate hospital in nautical miles. 
 
21.1.D.2 Lung Proximity Efficiency Points  
The Lung proximity efficiency points are equal to 
 
(I{NM ≤ 45} + I{NM ∈ (45,90)}*(1 – 0.15 / 45 * (NM – 45)) + I{NM ≥ 90}*0.875 / [1 + 
exp(0.0025 * (NM – 1500))])*5 
 
The variable NM represents straight-line distance between donor hospital and 
candidate hospital in nautical miles.

---

## 21.2.A — Values Used in the Calculation of Lung Waiting List Survival

<!-- Policy: 21 | Section: 21.2.A | Category: Composite Allocation Score | Cross-ref: Policy 10 -->

Table 21-3 provides the covariates and their coefficients for the waiting list mortality calculation. 
See OPTN Policy 10.1.F.i: Lung Disease Diagnosis Groups for specific information on each 
diagnosis group.  
 
 

 
 
 
 
Table 21-3: Waiting List Survival Calculation: Covariates and their Coefficients 
For this covariate: 
When 
The following coefficient is used in 
the lung waiting list survival 
calculation: 
Age at the time of the 
match run (fractional 
calendar year) 
Candidates are 
at least 12 years 
old 
 0.0281444188123287*age 
Bilirubin (mg/dL) value 
with the most recent 
test date and time  
Bilirubin is more 
than 1.0 mg/dL 
 0.15572123729572*(bilirubin – 1)  
  
1.0 mg/dL or 
less 
0 
Body mass index (BMI) 
(kg/m2) 
BMI less than 20 
kg/m2 
 0.10744133677215*(20 – BMI) 
  
BMI is at least 
20 kg/m2 
0 
Assisted ventilation 
ECMO or 
continuous 
mechanical-
hospitalized 
1.57618530736936 
 
Not ECMO or 
continuous 
mechanical-
hospitalized 
0 
Creatinine (serum) 
(mg/dL) with the most 
recent test date and 
time  
Candidate is at 
least 18 years 
old 
 0.0996197163645* creatinine 
  
Candidate is less 
than 18 years 
old 
0 
Diagnosis Group  
A 
0 
Diagnosis Group 
B 
1.26319338239175 
Diagnosis Group  
C 
1.78024171092307 
Diagnosis Group 
D 
1.51440083414275 
Detailed diagnosis 
within group A 
 
Bronchiectasis 
0.40107198445555 
Sarcoidosis with 
PA mean 
pressure of 30 
mm Hg or less 
1.39885489102977 
Sarcoidosis with 
PA mean 
pressure missing  
1.39885489102977 

 
 
 
For this covariate: 
When 
The following coefficient is used in 
the lung waiting list survival 
calculation: 
Detailed Diagnosis 
within group D 
COVID-19: 
pulmonary 
fibrosis  
0.2088684500011 
Pulmonary 
fibrosis, other 
0.2088684500011 
Sarcoidosis with 
PA mean 
pressure greater 
than 30 mm Hg 
-0.64590852776042 
Functional Status 
No assistance 
needed with 
activities of 
daily living 
 -0.59790409246653  
Some or total 
assistance 
needed with 
activities of 
daily living 
0 
Amount of 
supplemental oxygen 
required to maintain 
adequate oxygen 
saturation (88% or 
greater) (L/min) 
At rest, 
Diagnosis Group 
B 
 0.0340531822566417*O2  
At rest, 
Diagnosis 
Groups A, C, and 
D 
0.08232292818591*O2 
Not needed at 
rest 
0 
PCO2 (mm Hg): current 
PCO2 is at least 
40 mm Hg 
 0.12639905519026*PCO2/10  
PCO2 threshold change 
PCO2 increase is 
at least 15% 
 0.15556911866376 
PCO2 increase is 
less than 15% 
0 
Pulmonary artery (PA) 
systolic pressure (mm 
Hg) at rest, prior to any 
exercise 
Diagnosis Group 
A and the PA 
systolic 
pressure is 
greater than 40 
mm Hg 
 0.55767046368853*(PA systolic – 
40)/10 

 
 
 
For this covariate: 
When 
The following coefficient is used in 
the lung waiting list survival 
calculation: 
Diagnosis Group 
A and the PA 
systolic 
pressure is 40 
mm Hg or less 
0 
Diagnosis 
Groups B, C, 
and D 
0.1230478043299*PA systolic/10 
Six-minute-walk 
distance (feet)  
Candidates are 
at least 12 years 
old 
 -0.09937981549564*Six-minute-
walk distance/100 
 
If values for certain covariates are missing, expired, or outside the threshold as defined by Table 21-
4, then the composite allocation score calculation will substitute values to calculate the candidate’s 
waiting list survival score. Table 21-4: Substituted Values in Calculating Waiting List Survival Score lists 
the values that will be substituted. 
 
Table 21-4: Substituted Values in Calculating Waiting List Survival Score 
If this covariate’s value: 
Is: 
Then the waiting list survival 
calculation will use this 
substituted value: 
Bilirubin 
Missing, expired, or less than 
0.7 mg/dL 
0.7 mg/dL  
Height or weight to 
determine body mass index 
(BMI) 
Missing  
100 kg/m2 
Weight to determine BMI 
Expired 
100 kg/m2 

 
 
 
If this covariate’s value: 
Is: 
Then the waiting list survival 
calculation will use this 
substituted value: 
Assisted ventilation 
ECMO, and not expired 
26.33L/min needed at rest 
for the “amount of 
supplemental oxygen 
required to maintain 
adequate oxygen saturation 
(88% or greater) (L/min)” 
covariate 
Assisted ventilation 
Missing or expired 
No mechanical ventilation 
  
Creatinine (serum) (mg/dL)  
Missing or expired 
0.1 mg/dL  
Functional status 
Missing or expired 
No assistance needed  
 
Amount of supplemental 
oxygen required to maintain 
adequate oxygen saturation 
(88% or greater) (L/min) 
Greater than 26.33 L/min at 
rest, and not expired

---

## 21.2.B — Values Used in the Calculation of Post-Transplant Outcomes

<!-- Policy: 21 | Section: 21.2.B | Category: Composite Allocation Score | Cross-ref: Policy 10 -->

21.2.B.1 
Coefficients Used in Calculating Lung Post-Transplant Outcomes 
Table 21-6: Post-Transplant Outcomes Calculation: Covariates and Their Coefficients 
lists the covariates and corresponding coefficients in the waiting list and post-
transplant survival measures. See OPTN Policy 10.1.F: Lung Disease Diagnosis Groups 
for specific information on each diagnosis group. 
 
Table 21-6: Post-Transplant Outcomes Calculation: Covariates and Their Coefficients 
For this covariate 
When 
The following coefficient is 
used in the lung post-
transplant outcomes score 
calculation 
Age at the time of the match 
run (fractional calendar year) 
age is less than 20 
0.0676308559079852 x (20 
- age) + 0.78241832 
age is at least 20 and less 
than 30 
-0.0782418319259552 x 
(age - 20) + 0.78241832 
age is at least 30 and less 
than 40 
0 
age is at least 40 and less 
than 50 
0.0025908121347866 x 
(age - 40) 
age is at least 50 and less 
than 60 
0.0167463361760962 x 
(age - 50) + 0.02590812 
age is at least 60 and less 
than 70 
0.0227144625797883 x 
(age - 60) + 0.19337148 
age is at least 70 
0.0612288624399672 x 
(age - 70) + 0.42051611 
Creatinine (serum) (mg/dL) 
with the most recent test 
date and time 
creatinine is less than 0.4 
and candidate is at least 18 
years old 
-7.4016726145812200 x 
(0.4 - creatinine) + 
0.41872820  
creatinine is at least 0.4 and 
less than 0.6 and candidate 
is at least 18 years old 
-1.2584103289549000 x 
(creatinine - 0.4) + 
0.41872820 

 
 
 
For this covariate 
When 
The following coefficient is 
used in the lung post-
transplant outcomes score 
calculation 
creatinine is at least 0.6 and 
less than 0.8 and candidate 
is at least 18 years old 
0.3712348866558860 x 
(creatinine - 0.6) + 
0.16704614 
creatinine is at least 0.8 and 
less than 1.4 and candidate 
is at least 18 years old 
0.6844301806854400 x 
(creatinine - 0.8) + 
0.24129311 
creatinine is at least 1.4 and 
candidate is at least 18 
years old 
0.6881894154264970 x 
(creatinine - 1.4) + 
0.65195122 
Candidate is less than 18 
years old 
0 
Cardiac index (L/min/m2) at 
rest, prior to any exercise 
Less than 2 L/min/m2 
 
-0.4837491139906200 x (2 
– cardiac index) + 
0.04030226 
At least 2 and less than 2.5 
L/min/m2 
-0.0806045255202868 x 
(cardiac index - 2) + 
0.04030226 
At least 2.5 and less than

---

## 21.2.C — Values Used in the Calculation of Biological Disadvantages

<!-- Policy: 21 | Section: 21.2.C | Category: Composite Allocation Score -->

21.2.C.1 Probability of Incompatible Lung Donors Based on Height 
Table 21-9 lists the proportion of incompatible donors based on the candidate’s 
height and diagnosis group. 
 
Table 21-9 Proportion of Incompatible Donors Based on Lung Height 
Candidate 
height (cm) 
Proportion for Candidates 
in Diagnosis Groups A and 
C 
Proportion for 
Candidates in Diagnosis 
Group B 
Proportion for 
Candidates in Diagnosis 
Group D 
63 or 
less 
0.9989 
0.9989 
0.9989 
64 
0.9982 
0.9989 
0.9989 
65 
0.9982 
0.9989 
0.9989 
66 
0.9978 
0.9989 
0.9989 
67 
0.9975 
0.9989 
0.9989 
68 
0.9975 
0.9989 
0.9989 
69 
0.9975 
0.9982 
0.9989 
70 
0.9975 
0.9982 
0.9989 

 
 
 
Candidate 
height (cm) 
Proportion for Candidates 
in Diagnosis Groups A and 
C 
Proportion for 
Candidates in Diagnosis 
Group B 
Proportion for 
Candidates in Diagnosis 
Group D 
71 
0.9971 
0.9975 
0.9982 
72 
0.9971 
0.9975 
0.9982 
73 
0.9967 
0.9975 
0.9978 
74 
0.9967 
0.9975 
0.9975 
75 
0.9967 
0.9975 
0.9975 
76 
0.9971 
0.9971 
0.9975 
77 
0.9967 
0.9971 
0.9975 
78 
0.9967 
0.9967 
0.9971 
79 
0.9967 
0.9967 
0.9971 
80 
0.9967 
0.9971 
0.9967 
81 
0.9967 
0.9971 
0.9967 
82 
0.9971 
0.9967 
0.9967 
83 
0.9971 
0.9967 
0.9967 
84 
0.9975 
0.9967 
0.9964 
85 
0.9975 
0.9967 
0.9967 
86 
0.9975 
0.9971 
0.9967 
87 
0.9967 
0.9971 
0.9967 
88 
0.9967 
0.9975 
0.9967 
89 
0.9967 
0.9975 
0.9967 
90 
0.9967 
0.9975 
0.9967 
91 
0.9967 
0.9975 
0.9971 
92 
0.9964 
0.9967 
0.9971 
93 
0.9964 
0.9967 
0.9975 
94 
0.9960 
0.9967 
0.9967 
95 
0.9960 
0.9967 
0.9967 
96 
0.9960 
0.9967 
0.9967 
97 
0.9960 
0.9964 
0.9967 
98 
0.9960 
0.9964 
0.9967 
99 
0.9956 
0.9960 
0.9964 
100 
0.9964 
0.9960 
0.9964 
101 
0.9964 
0.9960 
0.9960 
102 
0.9971 
0.9960 
0.9960 
103 
0.9971 
0.9960 
0.9960 
104 
0.9971 
0.9964 
0.9960 
105 
0.9971 
0.9964 
0.9960 
106 
0.9971 
0.9967 
0.9956 
107 
0.9971 
0.9971 
0.9956 
108 
0.9975 
0.9971 
0.9956 
109 
0.9975 
0.9971 
0.9964 
110 
0.9967 
0.9971 
0.9964 
111 
0.9967 
0.9975 
0.9967 
112 
0.9964 
0.9971 
0.9971 
113 
0.9964 
0.9975 
0.9971 

 
 
 
Candidate 
height (cm) 
Proportion for Candidates 
in Diagnosis Groups A and 
C 
Proportion for 
Candidates in Diagnosis 
Group B 
Proportion for 
Candidates in Diagnosis 
Group D 
114 
0.9964 
0.9975 
0.9967 
115 
0.9956 
0.9967 
0.9967 
116 
0.9949 
0.9967 
0.9971 
117 
0.9935 
0.9964 
0.9964 
118 
0.9917 
0.9964 
0.9967 
119 
0.9913 
0.9964 
0.9964 
120 
0.9877 
0.9956 
0.9960 
121 
0.9866 
0.9949 
0.9960 
122 
0.9837 
0.9924 
0.9956 
123 
0.9822 
0.9913 
0.9949 
124 
0.9815 
0.9913 
0.9935 
125 
0.9731 
0.9877 
0.9917 
126 
0.9728 
0.9866 
0.9913 
127 
0.9586 
0.9822 
0.9877 
128 
0.9503 
0.9822 
0.9866 
129 
0.9488 
0.9815 
0.9837 
130 
0.9274 
0.9731 
0.9815 
131 
0.9270 
0.9728 
0.9808 
132 
0.8987 
0.9517 
0.9731 
133 
0.8824 
0.9503 
0.9728 
134 
0.8795 
0.9492 
0.9586 
135 
0.8410 
0.9274 
0.9499 
136 
0.8225 
0.9267 
0.9485 
137 
0.8156 
0.8987 
0.9270 
138 
0.7586 
0.8824 
0.9267 
139 
0.7525 
0.8799 
0.8987 
140 
0.6947 
0.8261 
0.8824 
141 
0.6697 
0.8218 
0.8795 
142 
0.6639 
0.8156 
0.8407 
143 
0.5800 
0.7586 
0.8221 
144 
0.5735 
0.7525 
0.8156 
145 
0.5183 
0.6762 
0.7586 
146 
0.4973 
0.6682 
0.7525 
147 
0.4904 
0.6642 
0.6947 
148 
0.4174 
0.5800 
0.6697 
149 
0.4131 
0.5735 
0.6639 
150 
0.3673 
0.5002 
0.5797 
151 
0.3426 
0.4973 
0.5731 
152 
0.3372 
0.4911 
0.5183 
153 
0.2548 
0.4174 
0.4966 
154 
0.2526 
0.4131 
0.4897 
155 
0.2069 
0.3481 
0.4167 
156 
0.1902 
0.3434 
0.4123 

 
 
 
Candidate 
height (cm) 
Proportion for Candidates 
in Diagnosis Groups A and 
C 
Proportion for 
Candidates in Diagnosis 
Group B 
Proportion for 
Candidates in Diagnosis 
Group D 
157 
0.1837 
0.3387 
0.3673 
158 
0.1165 
0.2555 
0.3419 
159 
0.1143 
0.2519 
0.3358 
160 
0.0947 
0.1917 
0.2515 
161 
0.0889 
0.1909 
0.2490 
162 
0.0857 
0.1866 
0.2040 
163 
0.0806 
0.1165 
0.1858 
164 
0.0820 
0.1140 
0.1789 
165 
0.0809 
0.1027 
0.1103 
166 
0.0897 
0.0893 
0.1089 
167 
0.0904 
0.0998 
0.0918 
168 
0.1267 
0.0820 
0.0799 
169 
0.1285 
0.0824 
0.0770 
170 
0.1310 
0.1027 
0.0588 
171 
0.1822 
0.0900 
0.0584 
172 
0.1862 
0.1183 
0.0708 
173 
0.2083 
0.1296 
0.0664 
174 
0.2479 
0.1310 
0.0679 
175 
0.2541 
0.1848 
0.0857 
176 
0.3307 
0.1855 
0.0838 
177 
0.3379 
0.1924 
0.1118 
178 
0.3637 
0.2479 
0.1252 
179 
0.4258 
0.2541 
0.1281 
180 
0.4327 
0.3303 
0.1815 
181 
0.5064 
0.3368 
0.1840 
182 
0.5096 
0.3423 
0.1909 
183 
0.5358 
0.4258 
0.2479 
184 
0.5898 
0.4323 
0.2537 
185 
0.5942 
0.5064 
0.3292 
186 
0.6599 
0.5093 
0.3358 
187 
0.6675 
0.5162 
0.3416 
188 
0.6719 
0.5898 
0.4258 
189 
0.7564 
0.5942 
0.4323 
190 
0.7608 
0.6399 
0.5064 
191 
0.8243 
0.6653 
0.5093 
192 
0.8279 
0.6715 
0.5162 
193 
0.8334 
0.7564 
0.5898 
194 
0.9056 
0.7604 
0.5942 
195 
0.9089 
0.8062 
0.6399 
196 
0.9408 
0.8261 
0.6653 
197 
0.9430 
0.8334 
0.6715 
198 
0.9459 
0.9056 
0.7564 
199 
0.9724 
0.9089 
0.7604 

 
 
 
Candidate 
height (cm) 
Proportion for Candidates 
in Diagnosis Groups A and 
C 
Proportion for 
Candidates in Diagnosis 
Group B 
Proportion for 
Candidates in Diagnosis 
Group D 
200 
0.9735 
0.9281 
0.8062 
201 
0.9779 
0.9423 
0.8261 
202 
0.9880 
0.9459 
0.8334 
203 
0.9880 
0.9724 
0.9056 
204 
0.9931 
0.9731 
0.9089 
205 
0.9946 
0.9750 
0.9281 
206 
0.9953 
0.9880 
0.9423 
207 
0.9975 
0.9880 
0.9459 
208 
0.9975 
0.9931 
0.9724 
209 
0.9989 
0.9942 
0.9731 
210 
0.9989 
0.9946 
0.9750 
211 
0.9989 
0.9975 
0.9880 
212 
0.9989 
0.9975 
0.9880 
213 
0.9993 
0.9989 
0.9931 
214 
1.0000 
0.9989 
0.9942 
215 
1.0000 
0.9989 
0.9946 
216 
1.0000 
0.9989 
0.9975 
217 
1.0000 
0.9993 
0.9975 
218 
1.0000 
1.0000 
0.9989 
219 
1.0000 
1.0000 
0.9989 
220 
1.0000 
1.0000 
0.9989 
221 
1.0000 
1.0000 
0.9989 
222 
1.0000 
1.0000 
0.9993 
223 or 
more 
1.0000 
1.0000 
1.0000

---
