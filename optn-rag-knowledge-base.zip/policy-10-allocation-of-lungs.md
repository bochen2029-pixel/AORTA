# OPTN Policy 10: Allocation of Lungs

**Source:** OPTN Policies | **Effective:** 12/10/2025 | **Category:** Lung Allocation
**Confidence:** HIGH — Official OPTN policy language

---

## 10.1 — Lung Composite Allocation Score

<!-- Policy: 10 | Section: 10.1 | Category: Lung Allocation -->

The lung composite allocation score is the combined total of the candidate’s lung medical urgency score, 
lung post-transplant outcomes score, lung biological disadvantages score, lung patient access score and 
lung placement efficiency score. The lung composite allocation score is awarded on a scale from 0 to 
100. 
 
Candidates will be rank-ordered by lung composite allocation score. If two or more candidates have the 
same lung composite allocation score, the tied candidates will be ranked by order of their registration 
date (oldest to newest).

---

## 10.1.A — Prioritizing Medically Urgent Candidates

<!-- Policy: 10 | Section: 10.1.A | Category: Lung Allocation | Cross-ref: Policy 21 -->

The lung medical urgency score is equal to the candidate’s lung waitlist survival points.  
 
10.1.A.1. Waitlist Survival Points for Candidates at least 12 Years Old 
For candidates at least 12 years old at the time of the match run lung waitlist 
survival points are awarded based on the candidate’s waiting list survival 
probability, based on the following factors:  
• 
Age at the time of the match run (fractional calendar years) 
• 
Bilirubin (mg/dL) value with the most recent test date and time  
• 
Body mass index (BMI) (kg/m2) 
• 
Assisted ventilation 
• 
Creatinine (serum) (mg/dL) with the most recent test date and time  
• 
Diagnosis Group (A, B, C, or D), as defined in OPTN Policy 10.1.F Lung Disease 
Diagnosis Groups 
• 
Whether the candidate has one of the following specific diagnoses within 
Diagnosis Group A:  
o Bronchiectasis  
o Sarcoidosis with pulmonary artery (PA) mean pressure of 30 mm Hg or 
less 
o Sarcoidosis with PA mean pressure missing 
• 
Whether the candidate has one of the following specific diagnoses within 
Diagnosis Group D:  
o COVID-19: pulmonary fibrosis 
o Pulmonary fibrosis, other specify cause  
o Sarcoidosis with PA mean pressure greater than 30 mm Hg 
• 
Functional Status 

 
 
 
• 
Amount of supplemental oxygen required to maintain adequate oxygen 
saturation (88% or greater) at rest (L/min) 
• 
PCO2 (mm Hg): current 
• 
PCO2 increase of at least 15% 
• 
PA systolic pressure (mm Hg) at rest, prior to any exercise 
• 
Six-minute-walk distance (feet) 
 
Lung waitlist survival points are awarded on a scale of 0-25. OPTN Policy 21.1.A: 
Waiting List Survival Formulas details the calculation of lung waitlist survival points. 
 
10.1.A.2 Waitlist Survival Points for Candidates Less than 12 Years Old 
Lung candidates assigned pediatric priority 1 receive 1.9073 waitlist survival points 
based on the candidate’s waitlist survival probability.  
 
Lung candidates assigned pediatric priority 2 receive 0.4406 waitlist survival points 
based on the candidate’s waitlist survival probability.  
 
10.1.A.2.a Candidates Less than 12 Years Old - Priority 1 
A lung candidate less than 12 years old may be assigned priority 1 if at least one of 
the following requirements is met: 
 
1. Candidate has respiratory failure, evidenced by at least one of the following: 
• 
Requires continuous mechanical ventilation  
• 
Requires supplemental oxygen delivered by any means to achieve FiO2 
greater than 50% in order to maintain oxygen saturation levels greater than 
90% 
• 
Has an arterial or capillary PCO2 greater than 50 mm Hg 
• 
Has a venous PCO2 greater than 56 mm Hg 
 
2. Candidate has pulmonary hypertension, evidenced by at least one of the 
following: 
• 
Has pulmonary vein stenosis involving 3 or more vessels 
• 
Exhibits any of the following, in spite of medical therapy:  
o Cardiac index less than 2 L/min/M2 
o Syncope 
o Hemoptysis 
o Suprasystemic PA pressure on cardiac catheterization or by 
echocardiogram estimate 
 
10.1.A.2.b Candidates Less than 12 Years Old - Priority 2 
If a lung candidate less than 12 years old does not meet any of the above criteria to 
qualify for priority 1, then the candidate is assigned priority 2.

---

## 10.1.B — Improving Post-Transplant Outcomes

<!-- Policy: 10 | Section: 10.1.B | Category: Lung Allocation | Cross-ref: Policy 21 -->

Each lung candidate is assigned a lung post-transplant outcomes score. The lung post-transplant 
outcomes score is equal to the candidate’s lung post-transplant outcomes points.  
 
10.1.B.1 Post-Transplant Outcomes Points for Candidates at Least 12 Years 
Old 
For candidates at least 12 years old at the time of the match run, lung post-
transplant outcomes points are awarded based on the candidate’s post-transplant 
survival probability, based on the following factors: 
• 
Age at the time of the match run (fractional calendar years) 
• 
Creatinine (serum) (mg/dL) with the most recent test date and time 
• 
Cardiac index (L/min/m2) at rest, prior to any exercise 
• 
Assisted ventilation 
• 
Diagnosis Group (A, B, C, or D), as defined in OPTN Policy 10.1.F: Lung Disease 
Diagnosis Groups  
• 
Whether the candidate has one of the following specific diagnoses within 
Diagnosis Group A:  
o Bronchiectasis 
o Lymphangioleiomyomatosis 
o Sarcoidosis with PA mean pressure of 30 mm Hg or less 
o Sarcoidosis with PA mean pressure missing 
• 
Whether the candidate has one of the following specific diagnoses within 
Diagnosis Group D:  
o COVID-19: pulmonary fibrosis 
o Obliterative bronchiolitis (non-retransplant) 
o Constrictive bronchiolitis 
o Sarcoidosis with PA mean pressure greater than 30 mm Hg 
o Pulmonary fibrosis, other specify cause 
• 
Functional Status 
• 
Six-minute-walk-distance (feet)  
Lung post-transplant outcomes points are awarded on a scale of 0-25. OPTN Policy 
21.1.B: Post-Transplant Outcomes Formulas details the calculation of lung post-
transplant outcomes points. 
 
10.1.B.2 Post-Transplant Outcomes Points for Candidates Less than 12 
years Old 
Lung candidates who are less than 12 years old are assigned 18.6336 post-
transplant outcomes points based on the candidate’s post-transplant survival 
probability.

---

## 10.1.C — Reducing Biological Disadvantages

<!-- Policy: 10 | Section: 10.1.C | Category: Lung Allocation | Cross-ref: Policy 21 -->

Each lung candidate is assigned a lung biological disadvantages score. The lung biological 
disadvantages score is equal to the total of the candidate’s lung blood type points, lung CPRA 
points, and lung height points.  

 
 
 
 
10.1.C.1 Blood Type 
Each lung candidate is assigned lung blood type points determined based on the 
proportion of donors the candidate could accept based on blood type compatibility, 
according to Table 10-1: Points by Blood Type. Candidates who are eligible to accept 
blood group incompatible donors according to OPTN Policy 10.4.A Eligibility for 
Intended Blood Group Incompatible Offers for Deceased Donor Lungs receive the 
same blood type points as other candidates in their blood group.  
 
Table 10-1: Points by Blood Type 
A candidate with a blood type of  
Will receive this many lung blood 
type points 
AB 
0 
A 
0.3032 
B 
2.2382 
O 
5.0000 
 
10.1.C.2 CPRA 
Each lung candidate is assigned lung CPRA points based on the proportion of donors 
the candidate could accept based on antigen acceptability. Lung CPRA points are 
awarded on a scale of 0-5. OPTN Policy 21.1.C.1: Lung CPRA Points details the 
calculation of lung CPRA points. 
 
10.1.C.3 Height 
Each lung candidate is assigned lung height points based on the proportion of 
donors the candidate could accept based on height compatibility. Lung height points 
are awarded on a scale of 0-5. OPTN Policy 21.1.C.2: Lung Height Points details the 
calculation of lung height points.

---

## 10.1.D — Promoting Patient Access

<!-- Policy: 10 | Section: 10.1.D | Category: Lung Allocation -->

The lung patient access score is equal to the total of the candidate’s lung pediatric points and 
lung living donor points.  
 
10.1.D.1 Pediatric Candidates 
A candidate who was less than 18 years old at the time of registration on the lung 
waiting list will receive 20 lung pediatric points. 
 
10.1.D.2 Prior Living Donors 
A candidate who is a prior living organ donor will receive 5 lung living donor points. 
A lung candidate will be classified as a prior living donor if the candidate donated for 
transplantation, within the United States or its territories, at least one organ and the 
candidate’s physician reports all of the following information to the OPTN:  

 
 
 
a. The name of the recipient or intended recipient of the donated 
organ or organ segment  
b. The recipient’s or intended recipient’s transplant hospital  
c. The date the donated organ was procured

---

## 10.1.E — Promoting the Efficient Management of the Organ Placement System

<!-- Policy: 10 | Section: 10.1.E | Category: Lung Allocation | Cross-ref: Policy 21 -->

The lung placement efficiency score is the total of the candidate’s lung travel efficiency and lung 
proximity efficiency points. 
  
10.1.E.1 Travel Efficiency 
A candidate’s lung travel efficiency points are determined based on the straight-line 
distance between the donor hospital and the transplant hospital where the 
candidate is listed. Lung travel efficiency points are awarded on a scale of 0-5. OPTN 
Policy 21.1.D.1: Lung Travel Efficiency Points details the calculation of lung proximity 
efficiency points. 
 
10.1.E.2 Proximity Efficiency 
A candidate’s lung proximity efficiency points are determined based on the straight-
line distance between the donor hospital and the transplant hospitals where the 
candidate is listed. Lung proximity efficiency points are awarded on a scale of 0-5. 
OPTN Policy 21.1.D.2: Lung Proximity Efficiency Points details the calculation of lung 
travel efficiency points.

---

## 10.1.F — Lung Disease Diagnosis Groups

<!-- Policy: 10 | Section: 10.1.F | Category: Lung Allocation -->

Each candidate is assigned a diagnosis group, based on their lung disease diagnosis, which is 
used in the calculation of their medical urgency score and their post-transplant survival score.  
 
Group A 
A candidate is in Group A if the candidate has any of the following diagnoses: 
 
• 
Allergic bronchopulmonary aspergillosis  
• 
Alpha-1 antitrypsin deficiency 
• 
Bronchiectasis 
• 
Bronchopulmonary dysplasia 
• 
Chronic obstructive pulmonary disease/emphysema 
• 
Ehlers-Danlos syndrome 
• 
Granulomatous lung disease 
• 
Inhalation burns/trauma 
• 
Kartagener’s syndrome  
• 
Lymphangioleiomyomatosis 
• 
Obstructive lung disease 
• 
Primary ciliary dyskinesia; 
• 
Sarcoidosis with either: 

 
 
 
o Pulmonary artery (PA) mean pressure of 30 mm Hg or less 
o PA mean pressure missing 
• 
Tuberous sclerosis 
• 
Wegener’s granuloma – bronchiectasis 
 
Group B 
A candidate is in Group B if the candidate has any of the following diagnoses: 
 
• 
Congenital malformation 
• 
CREST – pulmonary hypertension 
• 
Eisenmenger’s syndrome: atrial septal defect (ASD) 
• 
Eisenmenger’s syndrome: multi-congenital anomalies 
• 
Eisenmenger’s syndrome: other specify 
• 
Eisenmenger’s syndrome: patent ductus arteriosus (PDA) 
• 
Eisenmenger’s syndrome: ventricular septal defect (VSD) 
• 
Portopulmonary hypertension 
• 
Pulmonary hypertension/pulmonary arterial hypertension 
• 
Pulmonary capillary hemangiomatosis 
• 
Pulmonary telangiectasia – pulmonary hypertension 
• 
Pulmonary thromboembolic disease 
• 
Pulmonary vascular disease 
• 
Pulmonary veno-occlusive disease 
• 
Pulmonic stenosis 
• 
Right hypoplastic lung 
• 
Scleroderma – pulmonary hypertension 
• 
Secondary pulmonary hypertension 
• 
Thromboembolic pulmonary hypertension 
 
Group C 
A candidate is in Group C if the candidate has any of the following diagnoses: 
 
• 
Common variable immune deficiency 
• 
Cystic fibrosis 
• 
Fibrocavitary lung disease 
• 
Hypogammaglobulinemia 
• 
Schwachman-Diamond syndrome 
 
Group D 
A candidate is in Group D if the candidate has any of the following diagnoses: 
 
• 
ABCA3 transporter mutation 
• 
Alveolar proteinosis 
• 
Amyloidosis 
• 
Acute respiratory distress syndrome or pneumonia 
• 
Bronchioloalveolar carcinoma (BAC) 
• 
Carcinoid tumorlets 

 
 
 
• 
Chronic pneumonitis of infancy 
• 
Combined pulmonary fibrosis and emphysema (CPFE) 
• 
Constrictive bronchiolitis 
• 
COVID-19: acute respiratory distress syndrome 
• 
COVID-19: pulmonary fibrosis 
• 
CREST – Restrictive  
• 
Eosinophilic granuloma 
• 
Fibrosing Mediastinitis 
• 
Graft versus host disease (GVHD) 
• 
Hermansky Pudlak syndrome 
• 
Hypersensitivity pneumonitis 
• 
Idiopathic interstitial pneumonia, with at least one of the following disease entities: 
o Acute interstitial pneumonia 
o Cryptogenic organizing pneumonia/Bronchiolitis obliterans with organizing pneumonia 
(BOOP) 
o Desquamative interstitial pneumonia 
o Idiopathic pulmonary fibrosis (IPF) 
o Nonspecific interstitial pneumonia  
o Lymphocytic interstitial pneumonia (LIP) 
o Respiratory bronchiolitis-associated interstitial lung disease 
• 
Idiopathic pulmonary hemosiderosis 
• 
Lung retransplant or graft failure: acute rejection 
• 
Lung retransplant or graft failure: non-specific 
• 
Lung retransplant or graft failure: obliterative bronchiolitis-obstructive 
• 
Lung retransplant or graft failure: obliterative bronchiolitis-restrictive 
• 
Lung retransplant or graft failure: obstructive 
• 
Lung retransplant or graft failure: other specify 
• 
Lung retransplant or graft failure: primary graft failure 
• 
Lung retransplant or graft failure: restrictive 
• 
Lupus 
• 
Mixed connective tissue disease 
• 
Obliterative bronchiolitis: non-retransplant 
• 
Occupational lung disease: other specify 
• 
Paraneoplastic pemphigus associated Castleman’s disease 
• 
Polymyositis 
• 
Pulmonary fibrosis: other specify cause 
• 
Pulmonary hyalinizing granuloma 
• 
Pulmonary lymphangiectasia (PL) 
• 
Pulmonary telangiectasia – restrictive  
• 
Rheumatoid disease 
• 
Sarcoidosis with PA mean pressure greater than 30 mm Hg  
• 
Scleroderma – restrictive 
• 
Silicosis 
• 
Sjogren’s syndrome 
• 
Surfactant protein B deficiency 
• 
Surfactant protein C deficiency 

 
 
 
• 
Teratoma 
• 
Wegener’s granuloma – restrictive

---

## 10.2 — Lung Composite Score Exceptions

<!-- Policy: 10 | Section: 10.2 | Category: Lung Allocation -->

If a candidate’s current lung composite allocation score does not appropriately prioritize the candidate 
for transplant, the candidate’s transplant program may submit an exception request to the Lung Review 
Board. A candidate’s lung composite allocation score cannot exceed 100, inclusive of score exceptions.

---

## 10.2.A — Lung Review Board Composition

<!-- Policy: 10 | Section: 10.2.A | Category: Lung Allocation -->

For lung exceptions, there is a Lung Review Board. 
 
The Lung Review Board reviews lung medical urgency score, lung post-transplant outcomes 
score, lung biological disadvantages score, and lung patient access score exceptions.  
 
The Lung Transplantation Committee will develop and approve operational guidelines that detail 
the administrative details of the Lung Review Board operations. The Lung Transplantation 
Committee may develop clinical guidance documents for specific clinical scenarios. These 
guidelines may include appropriate documentation for the Lung Review Board to consider, 
appropriate clinical values, and suggested (but not automatically accepted) exception requests.

---

## 10.2.B — Exception Requests

<!-- Policy: 10 | Section: 10.2.B | Category: Lung Allocation -->

An exception request must include all of the following: 
1. Indication of the applicable goal in the composite allocation score 
2. A request for a specific score 
3. A justification of how the medical criteria supports the higher score for the candidate 
4. An explanation of how the candidate’s current condition is comparable to that of other 
candidates with the requested score 
 
Approved exception scores are valid until the candidate is transplanted, is removed from the 
lung waiting list, or withdraws the exception.

---

## 10.2.C — Review of Exceptions

<!-- Policy: 10 | Section: 10.2.C | Category: Lung Allocation -->

The Lung Review Board must review exception requests within five days of the date the request 
is submitted to the Lung Review Board.

---

## 10.2.D — Appeals to Lung Review Board

<!-- Policy: 10 | Section: 10.2.D | Category: Lung Allocation -->

If the Lung Review Board denies an exception request, the candidate’s transplant program may 
appeal to the Lung Review Board within seven days of receiving the denial. The Lung Review 
Board must review appeals within five days of the date the appeal is submitted to the Lung 
Review Board.

---

## 10.2.E — Appeals to Lung Transplantation Committee

<!-- Policy: 10 | Section: 10.2.E | Category: Lung Allocation -->

If the Lung Review Board denies an exception request on appeal, the candidate’s transplant 
program may appeal to the Lung Transplantation Committee within seven days of receiving the 

 
 
 
denial. The Lung Transplantation Committee must review the appeal no later than fourteen days 
following the request to the Committee.

---

## 10.3 — Clinical Values and Update Schedule

<!-- Policy: 10 | Section: 10.3 | Category: Lung Allocation -->

Transplant programs must report to the OPTN clinical data corresponding with the factors outlined in 
OPTN Policies 10.1.A.1: Waitlist Survival Points for Candidates at least 12 Years Old and 10.1.B.1: Post-
Transplant Outcomes Points for Candidates at Least 12 Years Old.  
 
For any six-minute walk distances reported during the six months preceding a candidate turning 12 
years old, and for any initial six-minute walk distances reported for candidates at least 12 years old, 
transplant programs must perform an oxygen titration test prior to conducting the six-minute walk test 
for a candidate on the lung waiting list. The final amount of supplemental oxygen from the oxygen 
titration test must be the amount provided to the candidate at the start of the six-minute walk test and 
documented in the candidate’s medical record.  
 
For six-minute walk distances reported prior to the six months preceding the candidate turning 12 years 
old, and for any subsequent updates to the six-minute walk distance according to Policy 10.3.B Lung 
Clinical Values That Must Be Updated Every Six Months, transplant programs may conduct an oxygen 
titration test prior to the six-minute walk test and may modify the amount of supplemental oxygen 
provided to the candidate at the start of the six-minute walk test. 
 
The data reported at the time of the candidate’s registration on the lung transplant waiting list must be 
six months old or less from the date of the candidate’s registration date, with the exception of the 
following values: 
• 
Cardiac index (L/min/m2) at rest, prior to any exercise 
• 
PA mean pressure 
• 
Pulmonary artery (PA) systolic pressure (mm Hg) at rest, prior to any exercise 
 
The transplant program must maintain source documentation for all clinical values reported in the 
candidate’s medical chart.

---

## 10.3.A — Lung Clinical Values That Must Be Updated Every 28 Days

<!-- Policy: 10 | Section: 10.3.A | Category: Lung Allocation -->

When a transplant program reports that a candidate on the lung waiting list is on continuous 
mechanical ventilation or ECMO, or requires supplemental oxygen provided via a high flow nasal 
cannula, the program must report the following values, assessed within the 28 days preceding 
the report: 
• 
Amount of supplemental oxygen required to maintain adequate oxygen saturation (88% or 
greater) (L/min) 
• 
Assisted ventilation status 
 
The transplant program must continue to assess and report the amount of supplemental oxygen 
required to maintain adequate oxygen saturation (88% or greater) and assisted ventilation 
status every 28 days following the most recent assessment while the candidate remains on 
continuous mechanical ventilation or ECMO, or continues to require supplemental oxygen 
provided via a high flow nasal cannula.

---

## 10.3.B — Lung Clinical Values That Must Be Updated Every Six Months

<!-- Policy: 10 | Section: 10.3.B | Category: Lung Allocation -->

Transplant hospitals must update all of the following clinical values at least once in every six 
month period following registration for each candidate on the lung waiting list:  
• 
Bilirubin (mg/dL) value with the most recent test date and time  
• 
Weight to determine body mass index (BMI) (kg/m2) 
• 
Creatinine (serum) (mg/dL) value with the most recent test date and time  
• 
Functional Status 
• 
Amount of supplemental oxygen required to maintain adequate oxygen saturation (88% or 
greater) (L/min) 
• 
PCO2 (mm Hg) 
• 
Six-minute-walk distance (feet)  
• 
Assisted ventilation status 
 
The transplant program must maintain source documentation for all clinical values reported in 
the candidate’s medical chart. 
 
Candidates who are less than 12 years old and are assigned priority 1 based on evidence of 
respiratory failure in accordance with OPTN Policy 10.1.A.2.a Candidates Less than 12 Years Old 
- Priority 1 will be assigned to priority 2 if the clinical values that qualify the candidates for 
priority 1 are more than six months old on the six-month anniversary of the candidate’s listing 
date.

---

## 10.3.C — Lung Clinical Values That Must Be Updated When Performed

<!-- Policy: 10 | Section: 10.3.C | Category: Lung Allocation -->

Transplant hospitals must report updated values for the following clinical values if they were 
obtained within any six month period following registration for each candidate at an active or 
inactive status.  
• 
Cardiac index (L/min/m2) at rest, prior to any exercise 
• 
PA mean pressure, if candidate’s diagnosis is Sarcoidosis 
• 
Pulmonary artery (PA) systolic pressure (mm Hg) at rest, prior to any exercise 
The transplant program must maintain source documentation for all clinical values reported in 
the candidate’s medical chart.

---

## 10.4.A — Eligibility for Intended Incompatible Blood Type Offers for Deceased Donor

<!-- Policy: 10 | Section: 10.4.A | Category: Lung Allocation -->

Lungs 
Incompatible blood types are defined in Table 10-2: Incompatible Blood Types for Deceased 
Donor Lungs.  
Table 10-2: Incompatible Offers Blood Types for  
Deceased Donor Lungs 
Deceased Donor’s Blood Type 
Candidate’s Blood Type 
A 
O and B 
B 
O and A 
AB 
O, A, and B 
 
Candidates with incompatible blood types will be screened from lung match runs unless the 
candidate meets the criteria for eligibility in Table 10-3: Eligibility for Intended Incompatible 
Blood Type Offers for Deceased Donor Lungs below. 
 
Table 10-3: Eligibility for Intended Incompatible Blood Type Offers for  
Deceased Donor Lungs 
If the candidate is registered 
prior to turning 18 years old 
and is: 
And meets all of the following: 
Less than one year old at the 
time of the match run 
1. Has reported isohemagglutinin titer 
information for A or B blood type antigens 
to the OPTN within the last 30 days 
At least one year old at the 
time of the match run 
1. Has reported to the OPTN 
isohemagglutinin titers less than or equal 
to 1:16 for A or B blood type antigens 
from a blood sample collected within the 
last 30 days. The candidate must not have 
received treatments that may have 
reduced isohemagglutinin titers to 1:16 or 
less within 30 days of when this blood 
sample was collected

---

## 10.4.B — Isohemagglutinin Titer Reporting Requirements for a Candidate Willing to

<!-- Policy: 10 | Section: 10.4.B | Category: Lung Allocation | Cross-ref: Policy 11 -->

Receive an Intended Blood Group Incompatible Lung 
If a laboratory provides more than one isohemagglutinin titer value for a tested blood sample, 
the transplant program must report the highest titer value to the OPTN. 
 
Accurate isohemagglutinin titers must be reported for candidates eligible for an intended blood 
type incompatible lung, according to Table 10-4 below, at all of the following times: 
 

 
 
 
1. Upon initially reporting that a candidate is willing to accept an intended blood type 
incompatible lung. 
2. Every 30 days after initially reporting that a candidate is willing to accept an intended blood 
type incompatible lung. 
Table 10-4: Isohemagglutinin Titer Reporting Requirements for a Candidate  
Willing to Receive an Intended Blood Type Incompatible Lung 
If the candidate’s blood 
type is: 
Then the transplant program must report the 
following isohemagglutinin titers to the OPTN: 
A 
Anti-B 
B 
Anti-A 
O 
Anti-A and Anti-B 
 
Accurate isohemagglutinin titers must be reported for recipients of an intended blood type 
incompatible lung, according to Table 10-5, as follows: 
 
1. At transplant, from a blood sample taken within 24 hours prior to transplant. 
2. If graft loss occurs within one year after transplant from the most recent sample, if 
available. 
3. If recipient death occurs within one year after transplant from the most recent blood 
sample, if available. 
 
Table 10-5: Isohemagglutinin Titer Reporting Requirements for a Recipient of an Intended Blood Type 
Incompatible Lung 
If the deceased 
donor’s blood type 
is: 
And the recipient’s 
blood type is: 
Then the transplant program must 
report the following 
isohemagglutinin titers to the 
OPTN: 
A 
B or O 
Anti-A 
B 
A or O 
Anti-B 
AB 
A 
Anti-B 
AB 
B 
Anti-A 
AB 
O 
Anti-A and Anti-B 
 
 

OPTN Policies                                                                                                Policy 11: Allocation of Pancreas, Kidney-Pancreas, and Islets 
 
 
Policy 11: Allocation of Pancreas, Kidney-Pancreas, and Islets  
11.1  Pancreas Allocation Score 
250 
11.2 Waiting List Registration 
251 
11.3 Waiting Time 
252 
11.4 Pancreas, Kidney-Pancreas, and Islet Allocation Classifications and Rankings 
254 
11.5 Reallocation of Unsuitable Islets 
258 
11.6 Facilitated Pancreas Allocation 
258 
11.7 Allocation of Released Kidney-Pancreas, Pancreas or Islets 
259 
11.8 Administrative Rules 
259

---
