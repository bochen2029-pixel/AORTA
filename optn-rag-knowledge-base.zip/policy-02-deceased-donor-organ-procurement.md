# OPTN Policy 2: Deceased Donor Organ Procurement

**Source:** OPTN Policies | **Effective:** 12/10/2025 | **Category:** Donor Procurement
**Confidence:** HIGH — Official OPTN policy language

---

## 2.1 — OPO Organ Acceptance Criteria

<!-- Policy: 2 | Section: 2.1 | Category: Donor Procurement -->

Each organ procurement organization (OPO) must establish criteria for an acceptable deceased donor or 
deceased donor organ for the transplant programs in its Donation Service Area (DSA). If a host OPO 
rejects a deceased donor, the OPO must offer the organs to OPOs that have more liberal acceptance 
criteria.

---

## 2.2 — OPO Responsibilities

<!-- Policy: 2 | Section: 2.2 | Category: Donor Procurement | Cross-ref: Policy 16 -->

The host OPO is responsible for all of the following: 
 
1. Identifying potential deceased donors. 
2. Providing evidence of authorization for donation. 
3. Evaluating deceased donors. 
4. Maintaining documentation used to exclude any patient from the imminent neurological death data 
definition or the eligible data definition. 
5. Verifying that death is pronounced according to applicable laws. 
6. Establishing and then implementing a plan to address organ donation for diverse cultures and ethnic 
populations. 
7. Ensuring the clinical management of the deceased donor. 
8. Ensuring that the necessary tissue-typing material is procured, divided, and packaged. 

 
 
 
9. Assessing deceased donor organ quality. 
10. Preserving, labeling, packaging, and transporting the organs. Labeling and packaging must be 
completed using the OPTN organ tracking system according to Policy 16: Organ and Vessel 
Packaging, Labeling, Shipping, and Storage. 
11. Executing the match run and using the resulting match for each deceased donor organ allocation.  
12. Documenting and maintaining complete deceased donor information for seven years for all organs 
procured. 
13. Ensuring that all deceased donor information, according to Policy 2.11: Required Deceased Donor 
Information, is reported to the OPTN upon receipt to enable complete and accurate evaluation of 
donor suitability by transplant programs. 
14. Ensuring that documentation for all of the following deceased donor information is submitted to the 
OPTN upon receipt:  
a. ABO source documentation 
b. ABO subtype source documentation 
c. Infectious disease results source documentation 
d. Death pronouncement source documentation 
e. Authorization for donation source documentation 
f. HLA typing source documentation 
15. Maintaining blood specimens appropriate for serologic and nucleic acid testing (NAT), as available, 
for each deceased donor for at least 10 years after the date of organ transplant, and ensuring these 
samples are available for retrospective testing. The samples must be collected within 24 hours prior 
to organ procurement. The host OPO must document the type of sample in the deceased donor 
medical record and, if possible, should use qualified specimens.

---

## 2.3 — Evaluating and Screening Potential Deceased Donors

<!-- Policy: 2 | Section: 2.3 | Category: Donor Procurement -->

The host OPO must perform all of the following and report the resulting information to all receiving 
OPOs or transplant hospitals: 
 
1. Attempt to obtain the deceased donor’s medical and behavioral history from one or more 
individuals familiar with the donor according to Policy 2.4: Deceased Donor Medical and Behavioral 
History, to screen for medical conditions that may affect the decision to use the donated organ.  
2. Review the deceased donor’s medical record. 
3. Complete a physical examination of the deceased donor, including the donor’s vital signs. 
4. Document in the deceased donor medical record if any of this information is not available and the 
reason it is not available.

---

## 2.4 — Deceased Donor Medical and Behavioral History

<!-- Policy: 2 | Section: 2.4 | Category: Donor Procurement -->

The medical and behavioral history for each potential deceased donor must include all of the following: 
 
1. Any testing and laboratory results used to identify the presence of transmissible diseases or 
malignancies, treated and untreated, or any other known condition that may be transmitted by the 
deceased donor organ and may reasonably impact the recipient. 
2. Whether the potential deceased donor has any risk factors associated with disease transmission, 
including blood-borne pathogens. If the deceased donor has any risk criteria for acute HIV, HBV, or 
HCV infection according to the U.S. Public Health Services (PHS) Guideline, the host OPO must 
communicate this information to all transplant programs receiving organs from the deceased donor. 
3. Whether the potential deceased donor has a history of prior exposure or treatment with non-
recombinant Human Pituitary Derived Growth Hormone (HPDGH). If so, the potential deceased 
donor has an increased risk of prion disease and the host OPO must communicate this information 
to all transplant programs receiving organs from the donor.

---

## 2.5 — Hemodilution Assessment

<!-- Policy: 2 | Section: 2.5 | Category: Donor Procurement -->

OPOs must use qualified (non-hemodiluted) blood samples for deceased donor screening tests if 
available. If a qualified sample is not available for testing, a hemodiluted sample may be used for 
deceased donor screening tests. 
 
Prior to screening, the host OPO must assess all potential deceased donor blood samples that were 
obtained for screening tests for hemodilution using a hemodilution calculation. The host OPO must 
document in the deceased donor medical record a complete history of all blood products and 
intravenous fluid transfusions the deceased donor received since admission to the donor hospital. 
 
Additionally, the host OPO must report all of the following to the accepting transplant programs when a 
hemodiluted specimen is used in deceased donor screening tests: 
 
1. Any screening results from the hemodiluted specimens. 
2. The tests completed on the hemodiluted specimens. 
3. The hemodilution calculation used for the hemodiluted specimens, if requested.

---

## 2.6 — Deceased Donor Blood Type Determination and Reporting

<!-- Policy: 2 | Section: 2.6 | Category: Donor Procurement -->

Host OPOs must develop and comply with a written protocol for blood type determination and reporting 
that includes all the requirements below.

---

## 2.6.A — Deceased Donor Blood Type Determination

<!-- Policy: 2 | Section: 2.6.A | Category: Donor Procurement -->

The host OPO must ensure that each deceased donor’s blood type is determined by testing at 
least two donor blood samples prior to the match run. 
 
 
 

 
 
 
The deceased donor blood samples must: 
 
1. Be drawn on two separate occasions 
2. Have different collection times 
3. Be submitted as separate samples 
 
The host OPO must include a process to address conflicting or indeterminate primary blood type 
results in their written protocol. 
 
The host OPO must document: 
 
1. That blood type determination was conducted according to the OPO’s written protocol and 
2. A complete history of all blood products the deceased donor received since admission to the 
donor hospital in the deceased donor medical record.

---

## 2.6.B — Deceased Donor Blood Subtype Determination

<!-- Policy: 2 | Section: 2.6.B | Category: Donor Procurement -->

Deceased donor blood subtyping must be completed according to the Table 2-1 and the 
requirements below.  
 
Table 2-1: Subtyping Requirements by Primary Blood Type and First Subtype Result  
If the donor’s primary 
blood type is: 
Then subtyping is 
A second subtyping must be completed if 
the first subtype result is: 
A 
Required 
Blood type A, non-A1 
AB 
Optional 
Blood type AB, non-A1B 
 
Deceased donor blood samples for subtyping must: 
 
1. Be tested using pre-red blood cell transfusion samples 
2. Be drawn on two separate occasions  
3. Have different collection times 
4. Be submitted as separate samples 
 
All subtype results reported to the OPTN must be from two separate tests indicating the same 
result. If there are conflicting or indeterminate subtype results, the subtype results must not be 
reported to the OPTN and the deceased donor must be allocated based on the primary blood 
type. 
For all blood type A donors, the host OPO must document either that subtyping was completed 
or the reason it could not be completed.

---

## 2.6.C — Reporting of Deceased Donor Blood Type and Subtype

<!-- Policy: 2 | Section: 2.6.C | Category: Donor Procurement -->

The deceased donor is not eligible for a match run until the host OPO completes verification and 
reporting as follows: 
 
1. Two different qualified health care professionals, as defined in the host OPO’s protocol, 
must each make an independent report of the donor’s blood type to the OPTN.  
2. If the donor’s blood subtype will be used for allocation, a qualified health care professional 
must report the subtype to the OPTN. This report must be verified by a different qualified 
health care professional according to the OPO’s protocol. 
3. Both qualified health care professionals must use all known available blood type and 
subtype determination source documents to verify they: 
a. Contain blood type and subtype (if used for allocation) results for the donor 
b. Indicate the same blood type and subtype (if used for allocation) on the test results. If 
the results are conflicting or indeterminate, the host OPO must refer to their written 
protocol as outlined in Policy 2.6.A: Deceased Donor Blood Type Determination. 
c. Match the result reported to the OPTN 
 
The OPO must document that reporting was completed according to the OPO’s protocol and the 
above requirements. 
 
If donation must be accelerated to avoid organ waste, the host OPO may instead complete these 
requirements after the match run, but prior to organ release to a transplant hospital. The host 
OPO must document all of the following: 
 
1. The reason that both blood type tests (and subtype tests, if used for allocation) could not be 
completed, verified, and reported prior to the match run. 
2. If there are conflicting or indeterminate primary blood type test results, the host OPO must 
follow its protocol for resolving the discrepancy and must re-execute the match run if the 
final ABO result is different from the initial ABO on the original match run.  
3. That all required blood type and subtype determinations, verification, and reporting were 
completed prior to organ release to a transplant hospital.

---

## 2.7 — HIV Screening of Potential Deceased Donors

<!-- Policy: 2 | Section: 2.7 | Category: Donor Procurement | Cross-ref: Policy 15, Policy 5 -->

The host OPO must accurately document HIV test results for every deceased donor. All deceased donors 
must be tested for HIV according to Policy 2.9: Required Deceased Donor Infectious Disease Testing.  
 
The host OPO must report the results of all HIV tests it performs directly to all receiving OPOs and 
transplant programs. Allocation of organs from deceased donors with HIV must follow the requirements 
in Policy 5.5.C: OPO Requirements for Positive HIV Test Results and Policy 15.7.A: Requirements for 
Allocating Organs from Deceased Donors with HIV.

---

## 2.7.A — Informing Personnel

<!-- Policy: 2 | Section: 2.7.A | Category: Donor Procurement -->

The host OPO must only inform health care personnel caring for potential deceased donors or 
deceased donors who test positive for HIV when it is necessary for making medical decisions.

---

## 2.8 — Required Deceased Donor General Risk Assessment

<!-- Policy: 2 | Section: 2.8 | Category: Donor Procurement -->

The host OPO is responsible for evaluating each potential donor in order to obtain the following 
information: 
 
1. Arterial blood gas results 
2. Blood type determination and reporting according to Policy 2.6: Deceased Donor Blood Type 
Determination and Reporting, including sub-typing for blood type A donors 
3. Chest x-ray 
4. Complete blood count (CBC) 
5. Electrolytes 
6. Serum glucose 
7. Urinalysis, within 24 hours before cross clamp

---

## 2.9 — Required Deceased Donor Infectious Disease Testing

<!-- Policy: 2 | Section: 2.9 | Category: Donor Procurement -->

The host OPO is responsible for ensuring that all of the following infectious disease testing is completed in 
Clinical Laboratory Improvement Amendments (CLIA)-certified laboratories, or in laboratories meeting 
equivalent requirements as determined by the Centers for Medicare and Medicaid Services (CMS): 
 
1. Blood and urine cultures  
2. Infectious disease testing for all potential deceased organ donors using FDA licensed, approved or 
cleared tests, as listed below: 
a. HIV antibody (anti-HIV) donor screening test or HIV antigen/antibody (Ag/Ab) combination test 
b. HIV ribonucleic acid (RNA) by donor screening or diagnostic nucleic acid test (NAT) 
c. Hepatitis B surface antigen (HBsAg) donor screening test 
d. Hepatitis B core antibody (total anti-HBc) donor screening test 
e. Hepatitis B deoxyribonucleic acid (DNA) by donor screening or diagnostic nucleic acid test (NAT) 
f. 
Hepatitis C antibody donor screening test (anti-HCV) 
g. Hepatitis C ribonucleic acid (RNA) by donor screening or diagnostic nucleic acid test (NAT) 
h. Cytomegalovirus (CMV) antibody (anti-CMV) donor screening or diagnostic test  
i. 
Epstein-Barr Virus (EBV) antibody (anti-EBV) donor screening or diagnostic test  
j. 
Syphilis donor screening or diagnostic test 
k. Toxoplasma Immunoglobulin G (IgG) antibody test 
 
Donor samples for all required HIV, HBV, and HCV testing must be obtained within 96 hours prior to 
organ procurement. 

 
 
 
 
3. Infectious disease testing for all potential deceased lung donors using an FDA licensed, approved, 
cleared, or emergency use authorized, lower respiratory specimen test for SARS-CoV-2 (COVID-19) by 
nucleic acid test (NAT) 
 
Lower respiratory specimen test results for SARS-CoV-2 by nucleic acid test (NAT) must be available 
pre-transplant of lungs. 
 
4.   Infectious disease testing for all potential deceased donors for Strongyloides antibody, using either  
• 
an FDA licensed, approved, cleared, or Class 1, 510(k)-exempt test or 
• 
a Laboratory Developed Test (LDT), as described by the FDA. 
 
5.   Infectious disease testing for all potential deceased donors whose donor history reflects the donor’s  
birthplace was in a country classified as endemic for Chagas disease by the CDC at the time of 
testing. The OPTN maintains a list of countries currently classified as endemic for Chagas disease by 
the CDC. This testing must be performed using an FDA licensed, approved, or cleared donor 
screening test for T. cruzi antibody.  
 
Within 72 hours of receipt of a positive T. cruzi antibody donor screening test, the host OPO must 
submit a sample for confirmatory testing. Confirmatory testing requires either 
• 
submission through the CDC or  
• 
performance of at least two different FDA licensed, approved, or cleared antibody diagnostic 
tests.

---

## 2.10 — Additional Deceased Donor Testing

<!-- Policy: 2 | Section: 2.10 | Category: Donor Procurement -->

If a host OPO completes any testing in addition to what is required for a potential donor, the results of 
these tests must be reported to all recipient transplant hospitals as soon as possible, but no later than 24 
hours after receiving the test result.

---

## 2.11 — Required Deceased Donor Information

<!-- Policy: 2 | Section: 2.11 | Category: Donor Procurement -->

The host OPO must report to the OPTN upon receipt all of the following information for each potential 
deceased donor: 
 
1. Age 
2. Diagnosis (or cause of brain death) 
3. Donor behavioral and social history 
4. Donor management information 
5. Donor medical history 
6. Donor evaluation information to include all laboratory testing, radiologic results, and injury to the 
organ 
7. Ethnicity  
8. Race 

 
 
 
9. Height 
10. Organ anatomy and recovery information 
11. Sex 
12. All vital signs, including blood pressure, heart rate, and temperature 
13. Weight 
14. SARS-CoV-2 (COVID-19) testing status. If COVID-19 testing was performed, the host OPO must report 
to the OPTN the date and time, type of specimen, testing method, and results 
 
The potential transplant program team must have the opportunity to speak directly with responsible 
onsite OPO donor personnel to obtain current information about the deceased donor’s physiology.

---

## 2.11.A — Required Information for Deceased Kidney Donors

<!-- Policy: 2 | Section: 2.11.A | Category: Donor Procurement -->

The host OPO must provide all the following additional information for all deceased donor 
kidney offers: 
 
1. Anatomical description, including number of blood vessels, ureters, and approximate length 
of each 
2. Human leukocyte antigen (HLA) information as follows: A, B, Bw4, Bw6, C, DR, DR51, DR52, 
DR53, DQA1, DQB1, DPA1, and DPB1 antigens prior to organ offers 
3. Injuries to or abnormalities of blood vessels, ureters, or kidney 
4. Kidney perfusion information, if performed 
5. Kidney laterality 
6. Biopsy results, if performed. The host OPO must make reasonable efforts to perform a 
biopsy on deceased donor kidneys from donors that meet at least one of the following 
criteria, excluding donors less than 18 years old: 
• 
Anuria, or a urine output of less than 100ml in 24 hours during current hospital 
admission or in the course of donor management 
• 
Donor has received hemodialysis or other renal replacement therapy during current 
hospital admission or in the course of donor management 
• 
History of diabetes, or HbA1C of 6.5 or greater during donor evaluation or 
management 
• 
KDPI greater than 85% at the time of original match run. 
• 
Donor age 60 years or older 
• 
Donor age 50-59 years, and meets at least two of the following criteria: 
o History of hypertension 
o Manner of death: Cerebrovascular Accident (CVA) 
o Terminal serum creatinine greater than or equal to 1.5mg/dl 
 
If the biopsy is not performed, the host OPO must document the reason and make this 
documentation available to the OPTN on request.

---

## 2.11.B — Required Information for Deceased Liver Donors

<!-- Policy: 2 | Section: 2.11.B | Category: Donor Procurement -->

The host OPO must provide all the following additional information for all deceased donor liver 
offers: 
 
1. Human leukocyte antigen (HLA) typing if requested by the transplant hospital, including A, 
B, Bw4, Bw6, C, DR, DR51, DR52, DR53, DQA1, DQB1, DPA1, and DPB1 antigens in the 
timeframe specified by the transplant program 
2. Other laboratory tests within 12 hours of the offer:  
a. Alanine aminotransferase/asparate aminotransferase (ALT/AST) 
b. Alkaline phosphatase 
c. Total and direct bilirubin  
d. International normalized ration (INR) or Prothrombin (PT) if INR is not available 
e. Partial thromboplastin time (PTT) 
3. Pre-procurement biopsy results, if performed 
4. Pre-procurement CT imaging results, if performed

---

## 2.11.C — Required Information for Deceased Heart Donors

<!-- Policy: 2 | Section: 2.11.C | Category: Donor Procurement -->

The host OPO must provide all the following additional information for all deceased donor heart 
offers: 
 
1. 12-lead electrocardiogram interpretation, if available 
2. Arterial blood gas results and ventilator settings 
3. Cardiology consult, if performed 
4. Echocardiogram 
5. Human leukocyte antigen (HLA) typing if requested by the transplant hospital, including A, 
B, Bw4, Bw6, C, DR, DR51, DR52, DR53, DQA1, DQB1, DPA1, and DPB1 antigens prior to the 
final organ acceptance

---

## 2.11.D — Required Information for Deceased Lung Donors

<!-- Policy: 2 | Section: 2.11.D | Category: Donor Procurement | Cross-ref: Policy 5 -->

The host OPO must provide all the following additional information for all deceased lung donor 
offers: 
 
1. Arterial blood gases and ventilator settings on 5 cm/H20/PEEP including PO2/FiO2 ratio and 
preferably 100% FiO2, within 2 hours prior to the offer  
2. Bronchoscopy results, if performed  
3. Chest x-ray interpreted by a radiologist or qualified physician within 3 hours prior to the 
offer 
4. HLA typing if requested by the transplant hospital, including A, B, Bw4, Bw6, C, DR, DR51, 
DR52, DR53, DQA1, DQB1, DPA1, and DPB1 antigens prior to final organ acceptance 
5. Sputum gram stain, with description of sputum  
6. Lung laterality 
 
 
 

 
 
 
If the host OPO cannot perform a bronchoscopy, it must document that it is unable to provide 
bronchoscopy results and the receiving transplant hospital may perform it. The lung recovery 
team may perform a confirmatory bronchoscopy provided unreasonable delays are avoided and 
deceased donor stability and the time limitations in Policy 5.6.B: Time Limit for Review and 
Acceptance of Organ Offers are maintained.

---

## 2.11.E — Required Information for Deceased Pancreas Donors

<!-- Policy: 2 | Section: 2.11.E | Category: Donor Procurement -->

The host OPO must provide all the following additional information for all deceased donor 
pancreas offers: 
 
1. Family history of diabetes (including Type 1 and Type 2) 
2. Hemoglobin A1C, if performed 
3. HLA information as follows: A, B, Bw4, Bw6, C, DR, DR51, DR52, DR53, DQA1, DQB1, DPA1, 
and DPB1 antigens prior to organ offers 
4. Insulin protocol  
5. Serum amylase 
6. Serum lipase

---

## 2.12 — Post Procurement Follow Up and Reporting

<!-- Policy: 2 | Section: 2.12 | Category: Donor Procurement | Cross-ref: Policy 15 -->

The host OPO is responsible for follow up and reporting of deceased donor test results received after 
procurement. The host OPO must develop and comply with written protocols to do all of the following: 
 
1. Obtain and report all deceased donor test results to the OPTN  
2. Report all positive test results and relevant information according to Policy 15.4: Host OPO 
Requirements for Reporting Post-Procurement Test Results and Discovery of Potential Disease 
Transmissions 
3. Report relevant test results and other information to tissue banks receiving donor tissue

---

## 2.13 — Deceased Donor Management

<!-- Policy: 2 | Section: 2.13 | Category: Donor Procurement -->

The host OPO must make reasonable efforts to manage the deceased donor by addressing all of the 
following: 
 
1. Maintaining blood pressure for perfusion of vital organs 
2. Monitoring vital signs 
3. Administering IV therapy or drugs, as required 
4. Administering antibiotic therapy, as required 
5. Administering and monitoring fluid intake and output  
 
The OPO must document that these efforts were made and report the results to the receiving OPOs or 
transplant hospitals.

---

## 2.14.A — Conflicts of Interest

<!-- Policy: 2 | Section: 2.14.A | Category: Donor Procurement -->

The organ recovery procedure and the transplantation of organs must not be performed by the 
donor hospital healthcare team member who declares the death of the potential deceased 
donor. Death is declared in accordance with hospital policy and applicable state and local 
statutes or regulation.

---

## 2.14.B — Pre-Recovery Verification

<!-- Policy: 2 | Section: 2.14.B | Category: Donor Procurement -->

Host OPOs must develop and comply with a written protocol to perform a pre-recovery 
verification for each organ recovered as required below. Qualified health care 
professionals, as defined in the host OPO’s protocol, must perform all verifications. At least 
one of the individuals performing a verification must be an OPO staff member.  
 
The host OPO must conduct the verification prior to organ recovery according to Table 2-2 
below. OPOs may use the OPTN organ tracking system to assist with completion of this 
verification. 
Table 2-2: Pre-Recovery Verification Requirements 
The host OPO must verify all 
of the following information: 
Using at least one of the 
following: 
By both of the following 
individuals: 
Donor ID 
• Donor identification band 
containing the donor ID 
• Donor identification band 
and OPTN computer system 
1. On-site recovering surgeon 
2. Qualified health care 
professional 
Organ (and laterality, if 
applicable) 
• Donor medical record 
• OPTN computer system 
1. On-site recovering surgeon 
2. Qualified health care 
professional 
Donor blood type and 
subtype (if used for 
allocation) 
• Donor blood type and 
subtype source documents 
1. On-site recovering surgeon 
2. Qualified health care 
professional 
 
When the intended recipient is known prior to organ recovery, the host OPO must verify all of 
the additional information according to Table 2-3 below. 
 

 
 
 
Table 2-3: Additional Pre-Recovery Verification Requirements When the Intended Recipient is Known 
Prior to Organ Recovery 
The host OPO must verify all 
of the following information: 
Using the: 
By the following individuals: 
Intended recipient unique 
identifier 
• OPTN computer system 
Two qualified health care 
professionals 
Intended recipient blood type • OPTN computer system 
Two qualified health care 
professionals 
Donor and intended recipient 
are blood type compatible (or 
intended incompatible) 
• OPTN computer system 
Two qualified health care 
professionals 
 
The host OPO must document that the verifications were completed according to the OPO’s 
protocol and the above requirements.

---

## 2.14.C — Organ Procurement Procedures

<!-- Policy: 2 | Section: 2.14.C | Category: Donor Procurement -->

To ensure organ procurement quality, the host OPO must do all of the following: 
 
1. Ensure that the deceased donor receives medications at appropriate times 
2. Document in the deceased donor record any medications administered 
3. Begin tissue typing and crossmatching as soon as possible 
4. Use standard surgical techniques in a sterile environment 
5. Maintain flush solutions, additives, and preservation media at appropriate temperatures 
6. Document in the deceased donor record, flush solutions and additives with lot numbers, 
along with organ anatomy, organ flush characteristics, flush solution amount, and flush 
solution type 
7. Document any organ abnormalities and surgical damage for all organs except extra vessels

---

## 2.14.D — Required Tissue Typing and Blood Type Verification Materials

<!-- Policy: 2 | Section: 2.14.D | Category: Donor Procurement -->

The host OPO must establish a written policy with a histocompatibility laboratory that includes 
specific details of the minimum tissue typing material, type of specimen, medium, and shipping 
requirements for these items. Extra vessels recovered for transplantation are excluded from 
minimum tissue typing material requirements. Table 2-4 shows the minimum tissue typing 
material requirements for each organ. 
 
Table 2-4: Minimum Typing Materials 
The host OPO must provide: 
For this organ: 
One 7 to 10 mL clot red top tube 
Any organ 
Two acid-citrate-dextrose (ACD) yellow top 
tubes 
Kidney or pancreas 
If available, one 2 by 4 cm wedge of spleen in 
culture medium 
Kidney or pancreas 

 
 
 
The host OPO must provide: 
For this organ: 
Three to five lymph node samples 
Each kidney or pancreas 
Any organ, if the receiving transplant 
hospital requests and they are available. 
 
The host OPO will provide specimens for tissue typing for all other organs as requested.

---

## 2.14.E — Deceased Donor Authorization Requirement

<!-- Policy: 2 | Section: 2.14.E | Category: Donor Procurement -->

The host OPO may only recover organs that it has received authorization to recover. An 
authorized organ should be recovered if it is transplantable, or a potential transplant recipient is 
identified for the organ. If an authorized organ is not recovered, the host OPO must document 
the specific reason for non-recovery. 
 
Extra vessels may only be recovered with at least one organ. To recover and use extra vessels in 
an organ transplant, the deceased donor authorization forms must include language indicating 
that the extra vessels will be used for transplant. 
 
Recovery of covered VCAs for transplant must be specifically authorized from individuals 
authorizing donation, whether that be the donor or a surrogate donation decision-maker 
consistent with applicable state law. The specific authorization for covered VCAs must be 
documented by the host OPO.

---

## 2.14.F — Non-renal Organ Procurement

<!-- Policy: 2 | Section: 2.14.F | Category: Donor Procurement -->

Non-renal organ recovery teams have the option to remove the non-renal organ first unless 
extenuating circumstances dictate otherwise. All organ recovery teams must cooperate with 
each other.

---

## 2.14.G — Start Time for Organ Procurement

<!-- Policy: 2 | Section: 2.14.G | Category: Donor Procurement -->

After organs have been offered and accepted, recovery teams must agree on the time the 
procurement will begin. If they cannot agree on the start time for the procurement, the host 
OPO has the authority to withdraw the offer from the transplant hospital that cannot agree on 
the start time for procurement.

---

## 2.15 — Requirements for Controlled Donation after Circulatory Death

<!-- Policy: 2 | Section: 2.15 | Category: Donor Procurement -->

(DCD)  Protocols  
Donation after Circulatory Death (DCD) describes the organ recovery process that may occur following 
death by irreversible cessation of circulatory and respiratory functions. Potential DCD donors are limited 
to patients who have died, or whose death is imminent, whose medical treatment no longer offers a 
medical benefit to the patient as determined by the patient, the patient’s authorized surrogate, or the 
patient’s advance directive if applicable, in consultation with the healthcare team. Any planned 
withdrawal of life sustaining medical treatment/support will be carried out in accordance with hospital 
policy. Prior to the OPO initiating any discussion with the legal next-of-kin about organ donation for a 
potential DCD donor, the OPO must confirm that the legal next-of-kin has elected to withdraw life 

 
 
 
sustaining medical treatment. The timing of a potential DCD donor evaluation and donation discussion 
will be coordinated with the OPO and the patient’s healthcare team, in accordance with hospital policy. 
Death is declared by a healthcare team member in accordance with hospital policy and applicable state 
and local statutes or regulations. A DCD donor may also be called a non-heart beating, asystolic, or 
donation after cardiac death donor.  
 
These policies will help OPOs and transplant hospitals develop necessary DCD protocols. These set the 
minimum requirements for DCD recovery but do not address local practices, cultural and resource 
issues, and therefore should not be the only resource consulted when developing DCD protocols. DCD 
protocols should continue to be developed through collaboration between OPOs, transplants hospitals, 
and donor hospitals.

---

## 2.15.A — Agreement

<!-- Policy: 2 | Section: 2.15.A | Category: Donor Procurement -->

The OPO must have a written agreement with all hospitals that participate in DCD recovery.

---

## 2.15.B — Protocols

<!-- Policy: 2 | Section: 2.15.B | Category: Donor Procurement -->

OPOs and donor hospitals must establish protocols that define the roles and responsibilities for 
the evaluation and management of potential DCD donors, organ recovery, and organ placement 
in compliance with OPTN Policy.

---

## 2.15.C — Potential DCD Donor Evaluation

<!-- Policy: 2 | Section: 2.15.C | Category: Donor Procurement -->

The primary healthcare team and the OPO must evaluate potential DCD donors to determine if 
the patient meets the OPO’s criteria for DCD donation.

---

## 2.15.D — Consent for DCD

<!-- Policy: 2 | Section: 2.15.D | Category: Donor Procurement -->

Conditions involving a potential DCD donor being medically treated/supported in a conscious 
mental state will require that the OPO confirms that the healthcare team has assessed the 
patient’s competency and capacity to make withdrawal/support and other medical decisions.  
 
The OPO must confirm that consent has been obtained for any DCD related procedures or drug 
administration that occur prior to patient death.

---

## 2.15.E — Authorization for DCD

<!-- Policy: 2 | Section: 2.15.E | Category: Donor Procurement -->

For the purpose of obtaining authorization for a DCD recovery, “legal next of kin” can include 
any of the following: 
 
1. The patient who authorizes deceased donation.  
2. Persons defined by state/local laws to authorize organ donation.

---

## 2.15.F — Withdrawal of Life Sustaining Medical Treatment or Support

<!-- Policy: 2 | Section: 2.15.F | Category: Donor Procurement -->

Prior to the donor hospital withdrawing life-sustaining medical treatment or ventilated support, 
the OPO is required to conduct a timeout to confirm: 
 
 

 
 
 
1. The patient’s identification. 
2. The process for withdrawing life-sustaining treatment or ventilated support. 
3. Roles and responsibilities of the primary patient care team, the OPO team, and the organ 
recovery team. 
4. The hospital’s plan for continued patient care if the patient does not become a donor, and 
appropriate communication with the next of kin. 
 
No recovery personnel (surgeons and other recovery practitioners) may be present for the 
withdrawal of life-sustaining medical treatment or ventilated support. No member of the organ 
recovery team or OPO staff may guide or administer palliative care or declare death.

---

## 2.15.G — Pronouncement of Death

<!-- Policy: 2 | Section: 2.15.G | Category: Donor Procurement -->

The donor hospital healthcare team member who declares the death of the potential deceased 
donor cannot be involved in any aspect of the organ recovery procedure or transplantation of 
that donor’s organs. Death is declared in accordance with hospital policy and applicable state 
and local statutes or regulation.

---

## 2.15.H — Organ Recovery

<!-- Policy: 2 | Section: 2.15.H | Category: Donor Procurement -->

Organ recovery will only proceed after circulatory death is determined, inclusive of a 
predetermined waiting period of circulatory cessation to ensure no auto-resuscitation occurs.

---

## 2.15.I — DCD Potential Donor Who Converts to Brain Death after an Organ Offer Has

<!-- Policy: 2 | Section: 2.15.I | Category: Donor Procurement | Cross-ref: Policy 3, Policy 5 -->

Been Made 
When a DCD donor converts to brain death, the host OPO must re-execute the match system 
and allocate the organs according to the organ allocation policies. Policy 5.4: Organ Offers does 
not apply when a DCD donor converts to brain death. Additionally, OPOs should initiate 
allocation of organs that may have been ruled out due to the donor’s initial DCD status. 
 
However, the host OPO may choose not to reallocate organs from a DCD donor who converts to 
brain death for any one of the following reasons:  
 
1. Donor instability 
2. Lack of donor family approval and authorization 
3. Other extraordinary circumstances 
 
The host OPO must document the reason for not reallocating organs when a DCD donor 
converts to brain death and make this documentation available to the OPTN on request.

 
 
Policy 3: Candidate Registrations, Modifications, and 
Removals 
3.1 
Access to Computer Systems 
38 
3.2 
Notifying Patients of Their Options 
42 
3.3 
Candidate Blood Type Determination and Reporting before Waiting List Registration 
43 
3.4 
Waiting List Registration 
44 
3.5 
Patient Notification 
46 
3.6 
Waiting Time 
46 
3.7 
Waiting Time Modifications 
49 
3.8 
Collective Patient Transfers 
52 
3.9 
Removing Candidates from the Waiting List 
53

---
