# OPTN Policy RAG Knowledge Base — Index

**Source:** OPTN (Organ Procurement and Transplantation Network)
**Effective Date:** 12/10/2025
**Total Chunks:** 468
**Format:** RAG-optimized semantic chunks with metadata headers
**Target Model:** AORTA-7B (Qwen2.5-7B fine-tune for organ transplant coordination)

## Files

- **policy-01-administrative-rules-and-definitions.md** — Policy 1: Administrative Rules and Definitions (23 sections)
- **policy-02-deceased-donor-organ-procurement.md** — Policy 2: Deceased Donor Organ Procurement (39 sections)
- **policy-03-candidate-registrations-modifications-and-removals.md** — Policy 3: Candidate Registrations, Modifications, and Removals (26 sections)
- **policy-04-histocompatibility.md** — Policy 4: Histocompatibility (24 sections)
- **policy-05-organ-offers-acceptance-and-verification.md** — Policy 5: Organ Offers, Acceptance, and Verification (35 sections)
- **policy-06-allocation-of-hearts-and-heart-lungs.md** — Policy 6: Allocation of Hearts and Heart-Lungs (29 sections)
- **policy-07-allocation-of-intestines.md** — Policy 7: Allocation of Intestines (7 sections)
- **policy-08-allocation-of-kidneys.md** — Policy 8: Allocation of Kidneys (28 sections)
- **policy-09-allocation-of-livers-and-liver-intestines.md** — Policy 9: Allocation of Livers and Liver-Intestines (57 sections)
- **policy-10-allocation-of-lungs.md** — Policy 10: Allocation of Lungs (19 sections)
- **policy-11-allocation-of-pancreas-kidney-pancreas-and-islets.md** — Policy 11: Allocation of Pancreas, Kidney-Pancreas, and Islets (21 sections)
- **policy-12-allocation-of-covered-vascularized-composite-allografts.md** — Policy 12: Allocation of Covered Vascularized Composite Allografts (2 sections)
- **policy-13-kidney-paired-donation-kpd.md** — Policy 13: Kidney Paired Donation (KPD) (41 sections)
- **policy-14-living-donation.md** — Policy 14: Living Donation (31 sections)
- **policy-15-identification-of-transmissible-diseases.md** — Policy 15: Identification of Transmissible Diseases (20 sections)
- **policy-16-organ-and-extra-vessel-packaging-labeling-shipping-and-storage.md** — Policy 16: Organ and Extra Vessel Packaging, Labeling, Shipping, and Storage (19 sections)
- **policy-17-international-organ-transplantation.md** — Policy 17: International Organ Transplantation (7 sections)
- **policy-18-data-submission-requirements.md** — Policy 18: Data Submission Requirements (14 sections)
- **policy-19-data-release.md** — Policy 19: Data Release (1 sections)
- **policy-20-travel-expense-and-reimbursement.md** — Policy 20: Travel Expense and Reimbursement (18 sections)
- **policy-21-composite-allocation-score-reference.md** — Policy 21: Composite Allocation Score Reference (7 sections)

## Chunk Structure

Each `## Section` heading is a self-contained retrieval unit:

```
## 5.3.A — Minimum Acceptance Criteria for Heart Transplant Programs

<!-- Policy: 5 | Section: 5.3.A | Category: Organ Offers | Cross-ref: Policy 6 -->

[Policy text content...]

---
```

**Metadata fields:**
- `Policy` / `Section`: Enables precise citation (e.g. "Per OPTN Policy 5.3.A...")
- `Category`: Supports topic-level filtering
- `Cross-ref`: Identifies related policies for multi-hop retrieval

## LM Studio Configuration

1. Create a Knowledge Base and load all 21 `.md` files
2. LM Studio will detect `---` delimiters and `##` headers as chunk boundaries
3. Recommended retrieval settings:
   - Chunk overlap: 0 (sections are self-contained)
   - Top-K: 3-5 chunks per query
   - Similarity threshold: 0.7+
4. Pair with AORTA-7B system prompt that instructs citation of section numbers

## Confidence Calibration

All content is **verbatim OPTN policy language** — Confidence: HIGH.
When AORTA retrieves from this KB, it should:
- Cite the specific section number (e.g. "Per OPTN Policy 9.5.I...")
- Distinguish retrieved policy from model-generated interpretation
- Flag when a query falls outside policy scope