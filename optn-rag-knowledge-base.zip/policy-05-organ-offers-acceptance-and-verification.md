# OPTN Policy 5: Organ Offers, Acceptance, and Verification

**Source:** OPTN Policies | **Effective:** 12/10/2025 | **Category:** Organ Offers
**Confidence:** HIGH — Official OPTN policy language

---

## 5.1.A — Kidney Minimum Acceptance Criteria

<!-- Policy: 5 | Section: 5.1.A | Category: Organ Offers -->

Kidney transplant programs must report to the OPTN annually minimum kidney acceptance 
criteria for offers for deceased donor kidneys more than 250 nautical miles away from the 
transplant program. The kidney minimum acceptance criteria will not apply to imported 0-ABDR 
mismatch offers or offers to candidates with a CPRA of 99% or above.

---

## 5.1.B — Minimum Acceptance Criteria for Other Transplant Programs

<!-- Policy: 5 | Section: 5.1.B | Category: Organ Offers -->

All other transplant hospitals may report minimum organ-specific acceptance criteria to the 
OPTN, including multi-organ combinations.

---

## 5.2 — Maximum Mismatched Antigens

<!-- Policy: 5 | Section: 5.2 | Category: Organ Offers -->

A transplant program may also specify the maximum number of mismatched antigens it will accept and 
any unacceptable antigens for any of its candidates. If a transplant program specifies these mismatched 
antigens, the OPTN will only offer organs from deceased donors with mismatched antigens equal to or 
less than the maximum specified. This policy does not apply to VCA transplants.

---

## 5.3.A — Reporting Unacceptable Antigens for Calculated Panel Reactive Antibody

<!-- Policy: 5 | Section: 5.3.A | Category: Organ Offers -->

(CPRA)  
In order to list an unacceptable antigen for a candidate on the waiting list, the transplant 
program must do at least one of the following: 

 
 
 
1. Define the criteria for unacceptable antigens that are considered as contraindications for 
transplant. This may include clarification of unacceptable antigens based on solid phase 
testing, consideration of prior donor antigens or non-self antigens involved in pregnancies, 
prior blood transfusion, and unexpected positive crossmatches. 
2. Base unacceptable antigens on laboratory detection of human leukocyte antigen (HLA) 
specific antibodies using at least one solid phase immunoassay with purified HLA molecules.  
 
Transplant programs may establish criteria for additional unacceptable antigens including, but 
not limited to, multiple unexpected positive crossmatches.

---

## 5.3.B — Infectious Disease Screening Criteria

<!-- Policy: 5 | Section: 5.3.B | Category: Organ Offers | Cross-ref: Policy 15 -->

A transplant hospital may specify whether a candidate is willing to accept an organ from a donor 
known to have certain infectious diseases, according to Table 5-1 below: 
 
Table 5-1: Donor Infectious Disease Screening Options 
If the donor tests positive for: 
Then candidates may choose not to receive 
offers on the following match runs: 
Cytomegalovirus (CMV) 
Intestine 
Hepatitis B core antibody (HBcAb) 
Heart, Intestine, Kidney, Liver, Lung, Pancreas, 
Heart-Lung, Kidney-Pancreas, VCA 
Hepatitis B Nucleic Acid Test (NAT) 
Heart, Intestine, Kidney, Liver, Lung, Pancreas, 
Heart-Lung, Kidney-Pancreas, VCA 
Hepatitis C (HCV) Antibody 
Heart, Intestine, Kidney, Liver, Lung, Pancreas, 
Heart-Lung, Kidney-Pancreas, VCA 
Hepatitis C Nucleic Acid Test (NAT) 
Heart, Intestine, Kidney, Liver, Lung, Pancreas, 
Heart-Lung, Kidney-Pancreas, VCA 
Human Immunodeficiency Virus (HIV); 
Organs from donors with HIV may only be 
recovered and transplanted according to 
the requirements in Policy 15.7: Recovery 
and Transplantation of Organs from 
Donors with HIV  
Heart, Intestine, Kidney, Liver, Lung, Pancreas, 
Heart-Lung, Kidney-Pancreas, VCA

---

## 5.3.C — Informed Consent for Kidneys Based on KDPI Greater than 85%

<!-- Policy: 5 | Section: 5.3.C | Category: Organ Offers -->

Prior to receiving an offer for a kidney with a Kidney Donor Profile Index (KDPI) score greater 
than 85%, transplant programs must obtain written, informed consent from each kidney 
candidate willing to receive offers for kidneys in this category. This requirement also applies to 
multi-organ offers that include a kidney; however, this informed consent may be obtained any 
time prior to transplant.

---

## 5.3.D — Liver Acceptance Criteria

<!-- Policy: 5 | Section: 5.3.D | Category: Organ Offers | Cross-ref: Policy 9 -->

The responsible transplant surgeon must determine the acceptable deceased donor weight for 
each of its liver candidates, and the determined acceptable weight must be reported to the 
OPTN. 
 

 
 
 
Liver transplant programs may also specify additional liver acceptance criteria, including any of 
the following: 
 
1. The maximum number of mismatched antigens it will accept for any of its liver candidates 
2. Minimal acceptance criteria for livers 
3. Acceptance criteria for expedited offers as outlined in OPTN Policy 9.10.A: Expedited Liver 
Placement Acceptance Criteria 
4. If a blood type O candidate will accept a liver from a deceased donor with blood type A, 
non-A1 
5. For status 1A or 1B candidates, if they will accept a liver from a deceased donor with any 
blood type  
6. If a candidate with a Model for End-Stage Liver Disease (MELD) or Pediatric End Stage Liver 
Disease (PELD) score of at least 30 will accept a liver from a deceased donor with any blood 
type  
7. If a candidate will accept a liver for other methods of hepatic support  
8. If a candidate is willing to accept a segmental graft  
9. If a candidate living with HIV is willing to accept a liver from a donor with HIV

---

## 5.3.E — Pediatric Heart Acceptance Criteria to Receive Intended Incompatible Blood

<!-- Policy: 5 | Section: 5.3.E | Category: Organ Offers -->

Type Hearts  
 
A transplant hospital may specify whether a candidate registered before 18 years of age is 
willing to accept a heart or heart-lungs from an intended incompatible blood type deceased 
donor.

---

## 5.3.F — Pancreas Candidates after Kidney Transplant Acceptance Criteria

<!-- Policy: 5 | Section: 5.3.F | Category: Organ Offers -->

When listing a candidate for a pancreas after a kidney transplant, the transplant program may 
enter the candidate’s prior deceased or living kidney donor’s antigens, which will then be 
considered self antigens in pancreas match runs. If a candidate’s prior kidney donor’s antigens 
are entered, the pancreas match run will take into account the candidate’s antigens and all of 
the kidney donor’s mismatched antigens that are reported to the OPTN. 
 
Antigens that are common to a candidate’s prior deceased or living kidney donor and a 
subsequent deceased pancreas donor are considered as matches and the candidate will appear 
on the match run for all deceased pancreas donors who meet these mismatch criteria. Use of 
these modified mismatch criteria is optional.

---

## 5.3.G — Dual and En Bloc Kidney Acceptance Criteria

<!-- Policy: 5 | Section: 5.3.G | Category: Organ Offers -->

In order for a kidney candidate to receive offers of both kidneys from a single deceased donor, a 
transplant hospital must specify to the OPTN that the candidate is willing to accept these 
kidneys.

---

## 5.3.H — Kidney Offer Filters

<!-- Policy: 5 | Section: 5.3.H | Category: Organ Offers -->

The OPTN generates model-identified offer filters for all kidney transplant programs based off of 
a program’s transplantation behavior within the most recently available 365 days of data. New 
model-identified filters will be generated and enabled for each transplant program every six 
months. A model-identified offer filter is generated for a program if all of the following criteria 
are met:  
 
• 
The program declined all kidney offers on at least 20 donors that met the filter criteria,   
• 
The program transplanted 0 donors that met the filter criteria, and  
• 
The kidneys that meet the filter criteria were transplanted elsewhere   
 
All model-identified offer filters will automatically not apply to candidates with any of the 
following criteria at the time of the match run:   
 
• 
Greater than 90% CPRA,  
• 
0-ABDR mismatch,   
• 
in medically urgent status, or   
• 
less than 18 years old  
 
Model-identified offer filters will be applied to all adult kidney transplant programs. Pediatric 
alone programs may manually apply model-identified filters.   
 
All programs may remove their model-identified filters or modify automatic candidate exclusion 
criteria of their model-identified filters. Any program may create their own program-identified 
filters.  
 
Model-identified and program-identified offer filters will not be applied to kidney match runs 
from a donor with HIV.

---

## 5.4.A — Nondiscrimination in Organ Allocation

<!-- Policy: 5 | Section: 5.4.A | Category: Organ Offers -->

A candidate’s citizenship or residency status in the United States must not be considered when 
allocating deceased donor organs to candidates for transplantation. Allocation of deceased 
donor organs must not be influenced positively or negatively by political influence, national 
origin, ethnicity, race, sex, religion, or financial status.

---

## 5.4.B — Order of Allocation

<!-- Policy: 5 | Section: 5.4.B | Category: Organ Offers | Cross-ref: Policy 16 -->

The process to allocate deceased donor organs occurs with these steps:  
 
1. The match system eliminates candidates who cannot accept the deceased donor based on 
size or blood type.  
2. The match system ranks candidates according to the allocation sequences in the organ 
allocation policies. 

 
 
 
3. OPOs must first offer organs to potential transplant recipients (PTRs) in the order that the 
PTRs appear on a match run. 
4. If no transplant program on the initial match run accepts the organ, the host OPO may give 
transplant programs the opportunity to update candidates’ data with the OPTN. The host 
OPO must re-execute the match run to allocate the organ. 
5. Extra vessels allocated with an organ but not required for its transplant can be shared 
according to OPTN Policy 16.6.A: Extra Vessels Use and Sharing. 
6. Members may export deceased donor organs to hospitals in foreign countries only after 
offering these organs to all PTRs on the match run. Members must submit the Organ Export 
Verification Form to the OPTN prior to exporting deceased donor organs.

---

## 5.4.C — Liver Offers

<!-- Policy: 5 | Section: 5.4.C | Category: Organ Offers -->

The host OPO must make the initial liver offer using only a match run that is less than eight 
hours old. The host OPO may only re-execute the match run for use in allocation sooner than 
eight hours if one of the following occurs: 
 
• 
A previously accepted liver is later refused because there is a change in specific medical 
information related to the deceased liver donor 
• 
The deceased donor liver has not been allocated within two hours of procurement 
• 
New donor information is received that would screen any potential recipient from 
appearing on the match run due to donor acceptance criteria according to OPTN Policy 5.5: 
Re-Execution of the Match Run Due to New Information

---

## 5.4.D — Backup Organ Offers

<!-- Policy: 5 | Section: 5.4.D | Category: Organ Offers -->

OPOs may make backup offers for all organs. Transplant programs must treat backup offers the 
same as actual organ offers and must respond within one hour of receiving the required 
deceased donor information for an organ. If a transplant program refuses to consider or does 
not respond to a backup offer, the offer will be considered refused. 
 
If a transplant program accepts a backup offer, it may later refuse to accept the organ based on 
medical or logistical criteria. Transplant programs must be promptly notified of any change in 
deceased donor status or organ availability.

---

## 5.4.E — Allocation to Candidates Not on the Match Run

<!-- Policy: 5 | Section: 5.4.E | Category: Organ Offers | Cross-ref: Policy 15 -->

When a candidate does not appear on at least one of the deceased donor’s match runs for at 
least one organ type, the transplant hospital must document the reason the candidate does not 
appear and ensure that the organ is safe and appropriate for the candidate. Acceptable reasons 
for allocation to the candidate may include, but are not limited to, directed donations or to 
prevent organ waste. 
 
In such an event, the transplant hospital must document all of the following: 
 
1. The reason for transplanting an organ into a candidate who did not appear on the match run 
2. The reason the candidate did not appear on the match run 

 
 
 
3. Whether the transplant hospital is willing to accept a kidney from a deceased donor with a 
KDPI score greater than 85% or from a donation after circulatory death (DCD) donor, if 
applicable  
4. Prior to transplant, the transplant hospital must verify the medical suitability between the 
deceased donor organ and recipient in at least, but not limited to, all the following areas 
according to organ type: 
 
• 
Blood type 
• 
Blood subtype, when used for allocation 
• 
Donor HLA and candidate’s unacceptable antigens 
• 
Donor height 
• 
Donor weight 
• 
Infectious disease test results 
• 
For deceased donors with HIV, the OPO and transplant program  must also do both of 
the following: 
 
a. Verify that the potential recipient is  living with HIV and willing to accept an organ 
from a donor with HIV 
b. Meet the requirements in OPTN Policy 15.7: Recovery and Transplantation of 
Organs from Donors with HIV 
 
The transplant hospital must maintain all related documentation.

---

## 5.4.F — Local Conflicts

<!-- Policy: 5 | Section: 5.4.F | Category: Organ Offers -->

If any member believes there is an inequity or has a conflict with an OPO policy regarding the 
allocation of organs that cannot be resolved, the member may submit the issue to the 
appropriate organ-specific committee and Board of Directors for review and a final decision.

---

## 5.4.G — Open Variance for Expedited Placement

<!-- Policy: 5 | Section: 5.4.G | Category: Organ Offers -->

This variance allows participating members to allocate organs in a manner consistent with any 
expedited placement protocol approved by the Executive Committee. This variance supersedes 
OPTN Policies 5.4.B: Order of Allocation, 5.6.B: Time Limit for Review and Acceptance of Organ 
Offers for all participating members, and 5.9: Released Organs. 
The Executive Committee will approve protocols for expedited placement of organs. Each 
protocol must include 1) criteria for organs eligible for expedited placement; 2) criteria for 
candidates eligible to receive expedited placement offers; 3) conditions for the use of expedited 
placement; and 4) OPO and transplant hospital responsibilities. 
Approved expedited placement protocols will be made available to the public. Protocols can last 
no longer than six months unless amended by the Executive Committee. 
This variance will be monitored for the following metrics: 
• 
For kidney and liver transplants, Percent of weekly transplants that went to pediatric 
candidates among the participating members compared to the median percent of 

 
 
 
weekly transplants that went to pediatric candidates among the participating members 
for the last six months. 
• 
Percent of weekly transplants that went to female candidates among the participating 
members compared to the median percent of weekly transplants that went to female 
candidates among the participating members for the last six months. 
• 
Percent of weekly transplants that went to non-white ethnicity candidates among the 
participating members compared to the median percent of weekly transplants that 
went to non-white ethnicity candidates among the participating members for the last six 
months. 
Expedited placement protocols for a given organ will expire if any of the below respective organ 
specific conditions occur for any of the above monitoring metrics: 
• 
One or more points below the 3-sigma limits; however, if the average sample size over a 
six month period is less than ten this rule does not apply. 
• 
Two out of three successive points below a 2-sigma limit; however, if the average 
sample size over a six month period is less than ten this rule will not apply. 
• 
Four out of five successive points below a 1-sigma limit. 
• 
A run of eight successive points below the center line. 
Each participating member must report to the OPTN expedited placements with the date, time, 
and match run when they initiate an expedited placement protocol. Participating members must 
meet monthly to review the results of this variance. 
This variance will expire on December 31, 2025.

---

## 5.5.B — Host OPO and Transplant Hospital Requirements for Positive Hepatitis B,

<!-- Policy: 5 | Section: 5.5.B | Category: Organ Offers -->

[5.5 Re-Execution of the Match Run Due to New Information]
5.5.A 
(Reserved)

Hepatitis C, or Cytomegalovirus (CMV) Infectious Disease Results 
If a host OPO executes a match run with negative or pending results for any of the infectious 
diseases listed in Table 5-1: Donor Infectious Disease Screening Options and subsequently 
receives a positive result for any of these tests, then it must report the updated information to 
the OPTN and do the following:  
 
1. When a deceased donor organ has not been accepted for a potential transplant recipient, 
then the OPO must do all of the following for each organ being allocated: 
a. Stop allocation on the original match run for this donor 
b. Re-execute the match run according to the infectious disease screening options as 
follows: 
i. A new positive Cytomegalovirus (CMV) result will apply to re-execution of the 
intestine match run 

 
 
 
ii. A new positive hepatitis B (HBcAb or HBV NAT) or hepatitis C (HCV Ab or HCV NAT) 
result will apply to re-execution of all organ types 
c. Allocate the organ using this updated match run 
 
2. When a deceased donor organ has already been accepted for a potential transplant 
recipient, the host OPO must do all of the following for each organ being allocated: 
a. Report this new infectious disease test result to the first transplant hospital on the match 
run that accepted the organ as soon as possible, but within one hour, of receipt of the 
new test result 
b. Re-execute the match run for use as follows: 
i.  For re-allocation of the organ if the offer to the primary potential transplant recipient 
is declined after receipt of the positive infectious disease test 
ii. For back-up organ offers based upon the new positive test result 
 
When the transplant hospital is notified by the host OPO of these new positive infectious 
disease results, it must notify the host OPO whether the organ will be accepted or declined, 
within one hour of receipt of the new test result.

---

## 5.5.C — OPO Requirements for Positive HIV Test Results

<!-- Policy: 5 | Section: 5.5.C | Category: Organ Offers | Cross-ref: Policy 15 -->

If a donor is found to have a positive test result for HIV after any match run has been executed, 
the host OPO must report the updated information on the donor with HIV to the OPTN and do 
all of the following for each organ being allocated: 
 
1. Stop allocation on the original match run for this donor 
2. Re-execute match runs in order to include only kidney, liver, or liver-kidney candidates living 
with HIV who are willing to accept organs from donors with HIV, and on-kidney or non-liver 
candidates living with HIV who are participating in an institutional review board (IRB) 
approved research protocol that meets the requirements in the National Institutes of Health 
(NIH) Final Notice regarding the recovery and transplantation of organs from donors with 
HIV and the requirements outlined in Policy 15.7.D: Open Variance for the Recovery and 
Transplantation of Non-Kidney and Non-Liver Organs from Donors with HIV.  
3. Withdraw any pending offers to candidates who are not living with HIV and willing to accept 
an organ from a donor with HIV. 
4. Withdraw any pending offers to non-kidney and non-liver candidates who are not also 
participating in an IRB- approved research protocol that meets the requirements in the NIH 
Final Notice and the requirements outlined in Policy 15.7.D: Open Variance for the Recovery 
and Transplantation of Non-Kidney and Non-Liver Organs from Donors with HIV 
5. Continue allocating organs using the re-executed match run. Only recover and send extra 
vessels from this donor with an organ allocated from this donor.

---

## 5.6.A — Receiving and Reviewing Organ Offers

<!-- Policy: 5 | Section: 5.6.A | Category: Organ Offers -->

Transplant hospitals must view organ offers and respond to these offers through the match 
system.  
 
The transplanting surgeon at the receiving transplant hospital is responsible for ensuring the 
medical suitability of organs offered for transplant to potential recipients, including whether 
deceased donor and candidate blood types (and donor subtype, when used for allocation) are 
compatible or intended incompatible.

---

## 5.6.B — Time Limit for Review and Acceptance of Organ Offers

<!-- Policy: 5 | Section: 5.6.B | Category: Organ Offers | Cross-ref: Policy 2, Policy 9 -->

This policy does not apply to expedited liver offers as outlined in OPTN Policy 9.10.B: Expedited 
Liver Offers. 
 
A transplant hospital has a total of one hour after receiving the initial organ offer notification 
to access the deceased donor information and submit a provisional yes or an organ offer 
refusal. 
 
Once the host OPO has provided all the required deceased donor information according to 
OPTN Policy 2.11: Required Deceased Donor Information, with the exception of organ anatomy 
and recovery information, the transplant hospital for the initial primary potential transplant 
recipient must respond to the host OPO within one hour with either of the following: 
 
• 
An organ offer acceptance 
• 
An organ offer refusal 
All other transplant hospitals who have entered a provisional yes must respond to the host 
OPO within 30 minutes of receiving notification that their offer is for the primary potential 
transplant recipient with either of the following: 
 
• 
An organ offer acceptance 
• 
An organ offer refusal 
The transplant hospital must respond as required by these timeframes or it is permissible 
for the host OPO to offer the organ to the transplant hospital for the candidate that appears 
next on the match run.

---

## 5.6.C — Organ Offer Acceptance Limit

<!-- Policy: 5 | Section: 5.6.C | Category: Organ Offers -->

For any one candidate, the transplant hospital can only have one organ offer acceptance for 
each organ type. The host OPO must immediately report transplant hospital organ offer 
acceptances to the OPTN.

---

## 5.6.D — Effect of Acceptance

<!-- Policy: 5 | Section: 5.6.D | Category: Organ Offers -->

When a transplant hospital accepts an OPO’s organ offer without conditions, this acceptance 
binds the transplant hospital and OPO unless they mutually agree on an alternative allocation of 
the organ. 
 
If an organ has been accepted by a transplant program for a primary potential transplant 
recipient, the organ is not required to be offered according to Policy 5.10: Allocation of Multi-
Organ Combinations.

---

## 5.7 — Organ Check-In

<!-- Policy: 5 | Section: 5.7 | Category: Organ Offers -->

Transplant hospitals must develop and comply with a written protocol to perform organ check-ins as 
required below.  
 
The transplant hospital must complete an organ check-in any time an organ is recovered outside the 
facility where the transplant will take place. The organ check-in must be completed upon arrival at the 
transplant hospital prior to opening the organ’s external transport container.  
 
The transplant hospital must use the OPTN external organ label to confirm that the label contains the 
expected: 
 
1. Donor ID 
2. Organ type and laterality (if applicable) 
 
Assistance using an OPTN-approved electronic method is permitted. If the transplant hospital 
determines that the donor ID, organ type or laterality label information conflicts with the expected 
information, then the transplant hospital must notify the host OPO as soon as possible, but within one 
hour, of the determination. 
 
The transplant hospital must document that the organ check-in was completed.

---

## 5.8 — Pre-Transplant Verification

<!-- Policy: 5 | Section: 5.8 | Category: Organ Offers -->

Transplant hospitals must develop and comply with a written protocol to perform pre-transplant 
verifications as required below.

---

## 5.8.A — Pre-Transplant Verification Prior to Organ Receipt

<!-- Policy: 5 | Section: 5.8.A | Category: Organ Offers -->

If the recipient surgery will begin prior to organ receipt in the operating room, the transplant 
hospital must conduct a pre-transplant verification that meets all of the following requirements: 
 
1. The intended recipient must be present in the operating room 
2. The verification must occur either:  
a. Prior to induction of general anesthesia  
b. Prior to incision if the patient has been receiving continuous sedation prior to arrival in 
the operating room 

 
 
 
3. Transplant hospitals must use at least one of the acceptable sources during the pre-
transplant verification prior to organ receipt to verify all of the following information 
according to Table 5-2 below. Transplant hospitals may use the OPTN organ tracking system 
to assist with completion of this verification. 
 
Table 5-2: Pre-Transplant Verification Prior to Organ Receipt Requirements 
The transplant hospital must 
verify all of the following 
information: 
Using at least one of the 
following: 
By both of the following 
individuals: 
Expected donor ID 
• OPTN computer system 
• Recipient medical record 
Two licensed health care 
professionals 
Expected organ (and lung 
laterality if applicable) 
• OPTN computer system 
• Recipient medical record 
Two licensed health care 
professionals 
Expected donor blood type 
and subtype (if used for 
allocation)  
• Donor blood type and 
subtype source documents 
• OPTN computer system 
Two licensed health care 
professionals 
Recipient unique identifier 
• Recipient identification 
band 
Two licensed health care 
professionals 
Recipient blood type 
• OPTN computer system 
• Recipient blood type and 
subtype source documents 
• Recipient medical record 
Two licensed health care 
professionals 
Expected donor and recipient 
are blood type compatible (or 
intended incompatible). 
• OPTN computer system 
• Recipient medical record 
• Attestation following 
verification of donor and 
recipient blood types 
Two licensed health care 
professionals 
For kidneys and livers from 
donors with HIV, that the 
recipient is living with HIV 
and willing to accept an 
organ from a donor with HIV 
• OPTN computer system 
• Recipient medical record 
• Attestation following 
verification of HIV status of 
donor and candidate 
1. Transplant surgeon 
2. Licensed health care 
professional 
 
If a pre-transplant verification was conducted prior to organ receipt, the transplant hospital 
must document that the verification was completed according to the hospital’s protocol and the 
above requirements.

---

## 5.8.B — Pre-Transplant Verification Upon Organ Receipt

<!-- Policy: 5 | Section: 5.8.B | Category: Organ Offers -->

At the time of organ receipt in the operating room, the transplant hospital must conduct a pre-
transplant verification with all the following requirements: 
1. The intended recipient must be present in the operating room 
2. The verification must occur after the organ arrives in the operating room, but prior to 

 
 
 
anastomosis of the first organ  
3. Transplant hospitals must use at least one of the acceptable sources during the pre-
transplant verification upon organ receipt to verify all of the following information 
according to Table 5-3 below. Transplant hospitals may use the OPTN organ tracking system 
to assist with completion of this verification. 
 
Table 5-3: Pre-Transplant Verification Upon Organ Receipt Requirements 
The transplant hospital must 
verify all of the following 
information: 
Using at least one of the 
following: 
By both of the following 
individuals: 
Donor ID 
• External and internal organ 
package labels  
• Documentation with organ 
 
Transplant surgeon 
 
Licensed health care 
professional 
Organ (and laterality if 
applicable) 
• Organ received 
1. Transplant surgeon 
2. Licensed health care 
professional 
Donor blood type and subtype  
(if used for allocation)  
• Donor blood type and 
subtype source documents  
 
1. Transplant surgeon 
2. Licensed health care 
professional 
Recipient unique identifier 
• Recipient identification 
band 
 
1. Transplant surgeon 
2. Licensed health care 
professional 
Recipient blood type 
• Recipient blood type source 
documents 
• Recipient medical record 
1. Transplant surgeon 
2. Licensed health care 
professional 
Donor and recipient are blood 
type compatible (or intended 
incompatible) 
• OPTN computer system 
• Recipient medical record 
• Attestation following 
verification of donor and 
recipient blood types 
1. Transplant surgeon 
2. Licensed health care 
professional 
Correct donor organ has been 
identified for the correct 
recipient 
• Recipient medical record 
• OPTN computer system 
• Attestation following 
verification of donor ID, 
organ, and recipient unique 
identifier 
1. Transplant surgeon 
2. Licensed health care 
professional 
For kidneys and livers from 
donors with HIV, that the 
recipient is living with HIV and 
willing to accept an organ 
from a donor with HIV 
• OPTN computer system 
• Recipient medical record 
• Attestation following 
verification of HIV status of 
donor and candidate 
1. Transplant surgeon 
2. Licensed health care 
professional 
 
 
The transplant hospital must document that the pre-transplant verification upon organ receipt 

 
 
 
was completed according to the hospital’s protocol and the above requirements.

---

## 5.8.C — Additional Pre-Transplant Verification Requirements for Extra Vessels

<!-- Policy: 5 | Section: 5.8.C | Category: Organ Offers -->

If any of the following occurs: 
 
• 
Deceased donor extra vessels recovered with an organ will be used in the transplantation of 
a different organ 
• 
Extra vessels will be used in the modification of a transplanted organ 
 
Then, prior to transplant of the extra vessels, transplant hospitals must complete all of the 
following: 
1. Meet the requirements according to OPTN Policy 5.8: Pre-Transplant Verification 
2. Verify the extra vessels are within 14 days of the recovery date 
3. Verify the extra vessels donor’s infectious disease testing results for HIV, hepatitis B (HBV), 
and hepatitis C (HCV) 
4. Document and maintain these verifications in the recipient medical record

---

## 5.9 — Released Organs

<!-- Policy: 5 | Section: 5.9 | Category: Organ Offers | Cross-ref: Policy 16 -->

The transplant surgeon or physician responsible for the care of a candidate will make the final 
decision whether to transplant the organ. 
 
The transplant program must transplant all accepted, deceased donor organs into the original 
intended recipient or release the deceased donor organs back to and immediately notify the 
host OPO or the OPTN for further distribution. If a transplant program released an organ, it must 
explain to the OPTN the reason for refusing the organ for that candidate. The host OPO or OPTN 
must then allocate the organ to other candidates according to the organ-specific policies. The 
host OPO may contact the OPTN for assistance allocating the organs. The host OPO may 
delegate the responsibility to the OPO serving the candidate transplant programs’s DSA, except 
in the cases of released kidneys, pancreata, and islets. 
 
If extra vessels are not used for the recipient, then the transplant hospital may use, share, or 
store extra vessels, according to OPTN Policy 16: Organ and Extra Vessels Packaging, Labeling, 
Shipping, and Storage.

---

## 5.10.A — Allocation of Heart-Lungs

<!-- Policy: 5 | Section: 5.10.A | Category: Organ Offers | Cross-ref: Policy 6 -->

Heart-lung combinations are allocated according to OPTN Policy 6.6.F: Allocation of Heart-Lungs.

---

## 5.10.B — Allocation of Liver-Kidneys

<!-- Policy: 5 | Section: 5.10.B | Category: Organ Offers | Cross-ref: Policy 9 -->

Liver-kidney combinations are allocated according to OPTN Policy 9.9: Liver-Kidney Allocation.

---

## 5.10.C — Allocation of Kidney-Pancreas

<!-- Policy: 5 | Section: 5.10.C | Category: Organ Offers | Cross-ref: Policy 11 -->

Kidney-pancreas combinations are allocated according to OPTN Policy 11: Allocation of 
Pancreas, Kidney-Pancreas, and Islets.

---

## 5.10.D — Allocation of Liver-Intestines

<!-- Policy: 5 | Section: 5.10.D | Category: Organ Offers | Cross-ref: Policy 9 -->

Liver-intestine combinations are allocated according to OPTN Policy 9: Allocation of Livers and 
Liver-Intestines. 
5.10.E: 
Allocation of Heart-Kidneys 
When an OPO is offering a heart, and a kidney is also available from the same deceased donor, 
then the OPO must offer the kidney to a potential transplant recipient (PTR) who is registered 
for a heart and a kidney at the same transplant hospital, and who meets either of the following 
criteria: 
 
• 
PTR is registered at a transplant hospital at or within 500 NM of the donor hospital and 
is any active pediatric status, or 
• 
PTR is registered at a transplant hospital at or within 500 NM of the donor hospital and 
heart adult status 1, 2, 3, 4, or 5, and meets the eligibility criteria established in Table 5-
4: Medical Eligibility Criteria for Heart-Kidney Allocation 
 
If a host OPO is offering a kidney and a heart from the same deceased donor, then before 
allocating the kidney to kidney-alone candidates, the host OPO must offer the kidney with the 
heart to candidates who meet either of the eligibility criteria described in OPTN Policy 5.10.E. 
 
Table 5-4: Medical Eligibility Criteria for Heart-Kidney Allocation 
 
If the candidate’s transplant nephrologist 
confirms a diagnosis of:  
Then the transplant program must report to 
the OPTN and document in the candidate’s 
medical record: 
Chronic kidney disease (CKD) with a 
measured or estimated glomerular filtration 
rate (GFR) less than or equal to 60 mL/min 
for greater than 90 consecutive days 
At least one of the following: 
• That the candidate has begun regularly 
administered dialysis as an end-stage renal 
disease (ESRD) patient in a hospital based, 
independent non-hospital based, or home 
setting. 
• At the time of registration on the kidney 
waiting list, that the candidate’s most 
recent measured or estimated creatinine 
clearance (CrCl) or GFR is less than or equal 
to 30 mL/min. 
• On a date after registration on the kidney 
waiting list, that the candidate’s measured 
or estimated CrCl or GFR is less than or 
equal to 30 mL/min. 
 

 
 
 
If the candidate’s transplant nephrologist 
confirms a diagnosis of:  
Then the transplant program must report to 
the OPTN and document in the candidate’s 
medical record: 
Sustained acute kidney injury 
At least one of the following, or a 
combination of both of the following, for the 
last 6 weeks: 
 
• That the candidate has been on dialysis at 
least once every 7 days. 
• That the candidate has a measured or 
estimated CrCl or GFR less than or equal to 
25 mL/min at least once every 7 days. 
 
If the candidate’s eligibility is not confirmed 
at least once every seven days for the last 6 
weeks, the candidate is not eligible to receive 
a heart and a kidney from the same donor. 
 
5.10.F: Allocation of Lung-Kidneys 
 
When an OPO is offering a lung, and a kidney is also available from the same deceased donor, 
then the OPO must offer the kidney to a potential transplant recipient (PTR) who is registered 
for a lung and a kidney at the same transplant hospital, and who meets either of the following 
criteria: 
 
• 
PTR was less than 18 years old when registered on the lung waiting list, or 
• 
PTR has a Lung Composite Allocation Score of 251 or greater, and meets eligibility 
according to Table 5-5: Medical Eligibility Criteria for Lung-Kidney Allocation 
 
If a host OPO is offering a kidney and a lung from the same deceased donor, then before 
allocating the kidney to kidney-alone candidates, the host OPO must offer the kidney with the 
lung to candidates who meet either of the eligibility criteria described in OPTN Policy 5.10.F. 
 
 
1 When this proposal was approved by the OPTN Board of Directors on June 27, 2022, this policy required a Lung Composite Allocation Score of 
28 or greater. A subsequent proposal approved by the OPTN Board of Directors on December 5, 2022, changed the requirement to a Lung 
Composite Allocation Score of 25 or greater. See: https://optn.transplant.hrsa.gov/media/ai4npr5x/policy-notice_mot-for-cd_lung.pdf. 

 
 
 
Table 5-5: Medical Eligibility Criteria for Lung-Kidney Allocation 
If the candidate’s transplant nephrologist 
confirms a diagnosis of:  
Then the transplant program must report to 
the OPTN and document in the candidate’s 
medical record: 
Chronic kidney disease (CKD) with a 
measured or estimated glomerular filtration 
rate (GFR) less than or equal to 60 mL/min 
for greater than 90 consecutive days 
At least one of the following: 
• That the candidate has begun regularly 
administered dialysis as an end-stage renal 
disease (ESRD) patient in a hospital based, 
independent non-hospital based, or home 
setting. 
• At the time of registration on the kidney 
waiting list, that the candidate’s most 
recent measured or estimated creatinine 
clearance (CrCl) or GFR is less than or equal 
to 30 mL/min. 
• On a date after registration on the kidney 
waiting list, that the candidate’s measured 
or estimated CrCl or GFR is less than or 
equal to 30 mL/min. 
Sustained acute kidney injury 
At least one of the following, or a 
combination of both of the following, for the 
last 6 weeks: 
 
• That the candidate has been on dialysis at 
least once every 7 days. 
• That the candidate has a measured or 
estimated CrCl or GFR less than or equal to 
25 mL/min at least once every 7 days. 
 
If the candidate’s eligibility is not confirmed at 
least once every seven days for the last 6 
weeks, the candidate is not eligible to receive 
a lung and a kidney from the same donor.

---

## 5.10.G — Allocation of Heart-Liver and Lung-Liver

<!-- Policy: 5 | Section: 5.10.G | Category: Organ Offers | Cross-ref: Policy 6 -->

When an OPO is offering a heart or lung, and a liver is also available from the same deceased 
donor, PTRs who meet the criteria in Table 5-6: When Offering a Heart or Lung and Second 
Organ Is a Liver must be offered the liver. When an OPO is offering a heart or lung and two PTRs 
meet the criteria in Table 5-6, the OPO has the discretion to offer the liver to either PTR. 
 

 
 
 
Table 5-6: When Offering a Heart or Lung and Second Organ Is a Liver 
If an OPO is offering a heart or lung, and a 
PTR is also registered for a liver: 
The OPO must offer the liver if the 
PTR meets the following criteria: 
Heart 
• 
Registered at a transplant hospital at or 
within 500 NM of the donor hospital 
• 
Heart Adult Status 1, 2, 3 or any active 
pediatric status 
Lung 
Has a Lung Composite Allocation Score of 252 
or greater 
 
It is permissible for the OPO to offer the liver to other PTRs who do not meet the criteria in 
OPTN Policy 5.10.G. 
 
 
2 When this proposal was approved by the OPTN Board of Directors on June 27, 2022, this policy required a Lung Composite Allocation Score of 
28 or greater. A subsequent proposal approved by the OPTN Board of Directors on December 5, 2022, changed the requirement to a Lung 
Composite Allocation Score of 25 or greater. See: https://optn.transplant.hrsa.gov/media/ai4npr5x/policy-notice_mot-for-cd_lung.pdf 

 
 
 
Policy 6: Allocation of Hearts and Heart-Lungs  
6.1 
Adult Status Assignments and Update Requirements 
105 
6.2 
Pediatric Status Assignments and Update Requirements 
124 
6.3 
Status Updates 
126 
6.4 
Adult and Pediatric Status Exceptions 
126 
6.5 
Waiting Time 
130 
6.6 
Heart Allocation Classifications and Rankings 
130

---
