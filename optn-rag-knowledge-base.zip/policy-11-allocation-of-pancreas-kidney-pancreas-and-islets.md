# OPTN Policy 11: Allocation of Pancreas, Kidney-Pancreas, and Islets

**Source:** OPTN Policies | **Effective:** 12/10/2025 | **Category:** Pancreas Allocation
**Confidence:** HIGH — Official OPTN policy language

---

## 11.1 — Pancreas Allocation Score

<!-- Policy: 11 | Section: 11.1 | Category: Pancreas Allocation -->

Candidates receive an allocation score according to the total of all points assigned in Table 11-1. 
 
Table 11-1: Allocation Points 
 
If the candidate: 
Then the candidate receives this many points: 
Is registered for pancreas or islet transplant 
1/365 points for each day since candidate’s 
registration date 
Is registered for kidney-pancreas transplant and 
meets the qualifying criteria described in OPTN 
Policy 11.4: Waiting Time 
1/365 points for each day since meeting the 
qualifying criteria in OPTN Policy 11.4: Waiting 
Time 
Meets the qualifying criteria described in Table 
11-2: Points for Allocation of Pancreas, Kidney-
Pancreas, and Islets based on Proximity to 
Donor Hospital 
See Table 11-2: Points for Allocation of Pancreas, 
Kidney-Pancreas, and Islets based on Proximity to 
Donor Hospital 
 
 
 

OPTN Policies                                                                                                Policy 11: Allocation of Pancreas, Kidney-Pancreas, and Islets 
 
 
Table 11-2: Points for Allocation of Pancreas, Kidney-Pancreas, and Islets  
based on Proximity to Donor Hospital 
For purposes of this section, distance is calculated in nautical miles between candidate’s hospital of 
registration and the donor hospital. 
 
If the candidate is: 
Then the candidate receives this many points: 
Registered at a transplant program that is 
250 nautical miles or less away from the 
donor hospital 
 
2 −[(
2
250 −0) × 𝑑𝑖𝑠𝑡𝑎𝑛𝑐𝑒] 
 
Registered at a transplant program that is 
more than 250 nautical miles but 2,500 
nautical miles or less away from the donor 
hospital 
 
4 −[((
4
2500 −250) × 𝑑𝑖𝑠𝑡𝑎𝑛𝑐𝑒 )
−(4 ×
250
2500 −250)] 
 
Registered at a transplant program that is 
more than 2,500 nautical miles away from 
the donor hospital 
0

---

## 11.2.A — Pancreas Registration

<!-- Policy: 11 | Section: 11.2.A | Category: Pancreas Allocation -->

Each candidate registered on the pancreas waiting list must meet one of the following 
requirements: 
 
• 
Be diagnosed with diabetes 
• 
Have pancreatic exocrine insufficiency 
• 
Require the procurement or transplantation of a pancreas as part of a multiple organ 
transplant for technical reasons

---

## 11.2.B — Combined Kidney-Pancreas Registration

<!-- Policy: 11 | Section: 11.2.B | Category: Pancreas Allocation -->

Each candidate registered on the kidney-pancreas waiting list must be diagnosed with diabetes 
or have pancreatic exocrine insufficiency with renal insufficiency.

---

## 11.2.C — Islet Registration Status

<!-- Policy: 11 | Section: 11.2.C | Category: Pancreas Allocation -->

A transplant hospital may register an islet candidate on the waiting list with an active status if 
the candidate meets either of the following requirements: 
 
1. Is insulin dependent 
2. Has a hemoglobin A1c (HbA1c) value greater than 6.5% 
 

OPTN Policies                                                                                                Policy 11: Allocation of Pancreas, Kidney-Pancreas, and Islets 
 
 
An islet candidate that does not meet either of these requirements above must have an inactive 
status on the waiting list. If the transplant hospital changes a candidate’s status from inactive to 
active, the transplant hospital must document that the candidate met one of the above 
requirements. 
 
If a candidate’s clinical condition changes and the candidate becomes inactive, the transplant 
hospital must report this to the OPTN within 72 hours of the transplant hospital’s knowledge of 
this change. The transplant hospital must document in the candidate’s medical record when the 
transplant hospital learned of this change. 
 
If the candidate is active and is insulin independent, then the transplant hospital must document 
in the candidate’s medical record the candidate’s insulin status and HbA1c value. The transplant 
hospital must use the most recent HbA1c test performed within the last six months when 
determining whether the candidate meets the criteria for active status.

---

## 11.3 — Waiting Time

<!-- Policy: 11 | Section: 11.3 | Category: Pancreas Allocation -->

Waiting time for pancreas and islet candidates begins on the date the candidate is first 
registered as a pancreas or islet candidate on the waiting list.  
 
Pancreas, kidney-pancreas, and islet candidates continue to accrue waiting time while registered 
as active or inactive.

---

## 11.3.A — Kidney-Pancreas Waiting Time Criteria for Candidates Less than 18 Years

<!-- Policy: 11 | Section: 11.3.A | Category: Pancreas Allocation -->

Old  
To accrue waiting time for a kidney-pancreas transplant, a kidney-pancreas candidate who is 
less than 18 years old at the time of kidney-pancreas registration does not have to meet the 
qualifying criteria according to OPTN Policy 11.4.B below.

---

## 11.3.B — Kidney-Pancreas Waiting Time Criteria for Candidates At Least 18 Years Old

<!-- Policy: 11 | Section: 11.3.B | Category: Pancreas Allocation | Cross-ref: Policy 8 -->

If a kidney-pancreas candidate is 18 years or older on the date the candidate is registered for a 
kidney-pancreas, then the candidate begins to accrue waiting time once the candidate has met 
all of the following conditions: 
 
1. The candidate is registered for a kidney-pancreas. 
2. The candidate qualifies for kidney waiting time according to OPTN Policy 8.: Waiting Time.  
3. The candidate is on insulin. 
 
Once a kidney-pancreas candidate begins to accrue waiting time, the candidate will remain 
qualified for waiting time.  
 
 

OPTN Policies                                                                                                Policy 11: Allocation of Pancreas, Kidney-Pancreas, and Islets

---

## 11.3.C — Islet Waiting Time Criteria

<!-- Policy: 11 | Section: 11.3.C | Category: Pancreas Allocation -->

An islet candidate will retain waiting time through three registrations at the registering 
transplant hospital, including the waiting time from the previous registrations and any 
intervening time. After a candidate has received a series of three islet infusions at the 
registering transplant hospital, waiting time will be reset, and the candidate will retain waiting 
time through another three infusions.

---

## 11.3.D — Waiting Time Assignments for Kidney, Kidney-Pancreas, Pancreas, and Islet

<!-- Policy: 11 | Section: 11.3.D | Category: Pancreas Allocation | Cross-ref: Policy 3 -->

Candidates  
The OPTN may assign multi-organ candidates waiting time from one waiting list to another 
waiting list according to Table 11-3 below.  
 
Table 11-3: Waiting Time Assignments for Multi-organ Candidates 
From this registration: 
To this registration: 
Kidney 
Kidney-pancreas; if criteria in OPTN Policy 11.3.B: Kidney-
Pancreas Waiting Time Criteria for Candidates At Least 18 
Years Old are met. 
Kidney 
Pancreas 
Kidney-pancreas 
Kidney 
Kidney-pancreas 
Pancreas 
Pancreas  
Islet; if criteria in OPTN Policy 11.3.D.i below are met. 
Islet 
Pancreas; if criteria in OPTN Policy 11.3.D.ii below are met. 
 
Waiting time accrued by an isolated pancreas candidate or an islet candidate while registered on 
the waiting list will not be assigned to the listing for a combined kidney-pancreas transplant or 
an isolated kidney transplant unless the candidate qualifies for a waiting time modification 
according to OPTN Policy 3.7: Waiting Time Modifications. 
 
Waiting time accrued by an islet candidate while registered on the waiting list will not be 
assigned to the registration for a combined kidney-pancreas transplant or an isolated kidney 
transplant except as outlined in OPTN Policy 3.7: Waiting Time Modifications.  
 
Additionally, a kidney-pancreas candidate who received a kidney transplant and subsequently 
registered on the pancreas or islet waiting list will be assigned waiting time beginning on the 
earliest of the following dates: 
 
1. The date the candidate registered for a pancreas transplant. 
2. The date the candidate registered for a kidney-pancreas transplant. 
3. The date the candidate began accruing waiting time for a kidney-pancreas transplant. 
 
 

OPTN Policies                                                                                                Policy 11: Allocation of Pancreas, Kidney-Pancreas, and Islets 
 
 
11.3.D.i 
Criteria to assign Pancreas Waiting Time to Islet Waiting Time 
Waiting time accrued by an isolated pancreas transplant candidate while registered 
on the waiting list will be assigned to the registration for an islet transplant after 
consideration and approval of a request for transfer by the OPTN Pancreas 
Transplantation Committee. Waiting time transfer requests must document to the 
satisfaction of the Pancreas Transplantation Committee that the transfer is 
reasonable and is in the candidate’s best interest and comply with other application 
requirements set by the Committee. These requests, along with decisions of the 
Pancreas Transplantation Committee, will be reported to the Board of Directors 
retrospectively.  
 
11.3.D.ii 
Criteria to assign Islet Waiting Time to Pancreas 
Waiting time accrued by an islet transplant candidate while registered on the 
waiting list will be assigned to the registration for an isolated pancreas transplant 
after consideration and approval of a request for transfer by the OPTN Pancreas 
Transplantation Committee. Waiting time transfer requests must document to the 
satisfaction of the Pancreas Transplantation Committee that the transfer is 
reasonable and is in the candidate’s best interest, and comply with other application 
requirements set by the Committee. These requests, along with decisions of the 
Pancreas Transplantation Committee, will be reported to the Board of Directors 
retrospectively.

---

## 11.4.A — Kidney-Pancreas Allocation Order

<!-- Policy: 11 | Section: 11.4.A | Category: Pancreas Allocation | Cross-ref: Policy 5, Policy 8 -->

[11.4 Pancreas, Kidney-Pancreas, and Islet Allocation Classifications]
and Rankings

If a host OPO has both a kidney and a pancreas to offer for allocation, then the host OPO  
 
1. Must offer the kidney and pancreas according to classifications 1–4 in Tables 11-5: 
Allocation of Kidneys and Pancreas from Deceased Donors 50 Years Old and Less with a BMI 
less than or equal to 30 kg/m2 and Table 11-6: Allocation of Kidneys and Pancreas from 
Deceased Donors more than 50 Years Old or with a BMI greater than 30 kg/m2. 
 
2. Then, the host OPO may do either: 
a. Continue to offer the kidney and pancreas according to the remaining classifications in 
Table 11-5 and Table 11-6. 
b. Offer the pancreas to pancreas and islet candidates, but not kidney-pancreas 
candidates, according to the remaining classifications Table 11-5 and Table 11-6 and 
offer the kidney to kidney candidates according to OPTN Policy 8: Allocation of Kidneys. 
 
The host OPO may switch between options 2.a and 2.b above at any time after completing step 
1 above. 
 
This subsection does not apply if the kidney and pancreas have been released according to 
OPTN Policy 5.9: Released Organs. 

OPTN Policies                                                                                                Policy 11: Allocation of Pancreas, Kidney-Pancreas, and Islets

---

## 11.4.B — Pancreas Allocation When a Kidney is Unavailable

<!-- Policy: 11 | Section: 11.4.B | Category: Pancreas Allocation -->

If a host OPO only has a pancreas, but not a kidney to offer for allocation, then the host OPO 
must offer the pancreas to pancreas and islet candidates but not kidney-pancreas candidates 
according to Tables 11-5: Allocation of Kidneys and Pancreas from Deceased Donors 50 Years Old 
and Less with a BMI less than or equal to 30 kg/m2 and Table 11-6: Allocation of Kidneys and 
Pancreas from Deceased Donors more than 50 Years Old or with a BMI Greater than 30 kg/m2. 
 
OPOs may not allocate a kidney to a potential pancreas recipient who is receiving the pancreas 
offer due to the match run prioritization of the potential recipient’s isolated pancreas 
registration.

---

## 11.4.C — Organ Offer Limits

<!-- Policy: 11 | Section: 11.4.C | Category: Pancreas Allocation | Cross-ref: Policy 5, Policy 8 -->

Any pancreas that will be allocated as 0-ABDR mismatches, either alone or in combination with 
kidneys, must be offered within eight hours after procurement.  
 
If there are at least 10 0-ABDR mismatched potential recipients on the match run, the pancreas 
must be offered to the first 10 0-ABDR mismatched potential recipients. If there are less than 10 
0-ABDR mismatched potential recipients, the pancreas must be offered to all 0-ABDR 
mismatched potential recipients.  
 
If these offers are not accepted then the host OPO must: 
 
• 
Allocate the kidney according to the match run under OPTN Policy 8.5: Kidney Allocation 
Classifications and Rankings and allocate the pancreas according to OPTN Policy 11.4: 
Pancreas, Kidney-Pancreas, and Islet Allocation Classifications and Rankings.  
• 
Allocate the organ for the remaining 0-ABDR mismatched potential recipients. 
 
This subsection does not apply if the kidney and pancreas have been released according to 
OPTN Policy 5.9: Released Organs.

---

## 11.4.D — Blood Type for Kidney-Pancreas Allocation

<!-- Policy: 11 | Section: 11.4.D | Category: Pancreas Allocation -->

Within each classification, kidney-pancreas will be allocated to candidates according to the 
blood type matching requirements in Table 11-4 below:  
 
 

OPTN Policies                                                                                                Policy 11: Allocation of Pancreas, Kidney-Pancreas, and Islets 
 
 
11-4: Allocation of Kidney-Pancreas by Blood Type 
Kidney-Pancreas from Deceased Donors 
with: 
Are Allocated to Candidates with: 
Blood Type O 
Blood type O or blood type A, B, or AB if 
the candidate has a 0-ABDR mismatch 
with the deceased donor and a CPRA 
greater than or equal to 80 percent 
Blood Type A 
Blood type A or AB 
Blood Type B 
Blood type B 
Blood Type AB 
Blood type AB

---

## 11.4.E — Sorting Within Each Classification

<!-- Policy: 11 | Section: 11.4.E | Category: Pancreas Allocation -->

Within each allocation classification, pancreas, kidney-pancreas, and islet candidates are sorted 
in the following order:  
 
1. Total points (highest to lowest) 
2. Date and time of the candidate’s registration (oldest to most recent)

---

## 11.4.F — Deceased Donors 50 Years Old and Less with a BMI Less Than or Equal To

<!-- Policy: 11 | Section: 11.4.F | Category: Pancreas Allocation -->

30 kg/m2 
Pancreas, kidney-pancreas, and islets from donors 50 years old or less and who have a BMI less 
than or equal to 30 kg/m2 will be allocated to candidates according to Table 11-5. 
 
Table 11-5: Allocation of Kidneys and Pancreas from Deceased Donors 50 Years Old and Less with a 
BMI Less Than or Equal To 30 kg/m2 
Classification 
Candidates that are 
And registered at a transplant program 
that is at or within this distance from 
the donor hospital: 
1 
Either pancreas or kidney-pancreas 
candidates, 0-ABDR mismatch, and CPRA 
greater than or equal to 80% 
250NM 
2 
Either pancreas or kidney-pancreas 
candidates and CPRA greater than or 
equal to 80% 
250NM 
3 
Either pancreas or kidney-pancreas 
candidates, 0-ABDR mismatch, and CPRA 
greater than or equal to 80% 
Nation 
4 
Pancreas or kidney-pancreas candidates 
250NM 

OPTN Policies                                                                                                Policy 11: Allocation of Pancreas, Kidney-Pancreas, and Islets 
 
 
Classification 
Candidates that are 
And registered at a transplant program 
that is at or within this distance from 
the donor hospital: 
5 
Either pancreas or kidney-pancreas 
candidates, and CPRA greater than or 
equal to 80% 
Nation 
6 
Pancreas or kidney-pancreas candidates 
Nation 
7 
Islet candidates 
250NM 
8 
Islet candidates 
Nation

---

## 11.4.G — Deceased Donors More than 50 Years Old or with a BMI Greater Than 30

<!-- Policy: 11 | Section: 11.4.G | Category: Pancreas Allocation -->

kg/m2 
Pancreas, kidney-pancreas, and islets from deceased donors more than 50 years old or from 
deceased donors who have a BMI greater than 30 kg/m2 are allocated to candidates according 
to Table 11-6. 
 
Table 11-6: Allocation of Kidneys and Pancreas from Deceased Donors More Than 50 Years Old or with 
a BMI Greater Than 30 kg/m2 
Classification 
Candidates that are: 
And registered at a transplant program 
that is at or within this distance from the 
donor hospital: 
1 
Either pancreas or kidney-pancreas 
candidates, 0-ABDR mismatch, and CPRA 
greater than or equal to 80% 
250NM 
2 
Either pancreas or kidney-pancreas 
candidates and CPRA greater than or 
equal to 80% 
250NM 
3 
Either pancreas or kidney-pancreas 
candidates, 0-ABDR mismatch, and CPRA 
greater than or equal to 80% 
Nation 
4 
Pancreas or kidney-pancreas candidates 
250NM 
5 
Islet candidates 
250NM 
6 
Islet candidates 
Nation 
7 
Either pancreas or kidney-pancreas 
candidates and CPRA greater than or 
equal to 80% 
Nation 
8 
Pancreas or kidney-pancreas candidates  
Nation 
 

OPTN Policies                                                                                                Policy 11: Allocation of Pancreas, Kidney-Pancreas, and Islets

---

## 11.5 — Reallocation of Unsuitable Islets

<!-- Policy: 11 | Section: 11.5 | Category: Pancreas Allocation -->

Islets must be allocated to the most medically suitable candidate based on the transplant program’s 
Investigational New Drug (IND) application, as approved by the United States Food and Drug 
Administration (FDA). After islet processing is completed, the transplant program must determine and 
document both: 
1. Whether the islet preparation meets the transplant program’s islet product release criteria 
contained in the IND. 
2. Whether the islets are medically suitable or medically unsuitable for the candidate that accepted 
the islets.  
 
If the islets are found medically unsuitable for the candidate, the transplant program must document 
the reason the islets were determined to be medically unsuitable for the candidate. 
 
If the transplant program determines that the islets are medically unsuitable for the candidate, the 
transplant program will reallocate the islets according to all of the following criteria: 
1. To a candidate that is medically suitable 
2. To a candidate that is registered at a transplant program covered by the same IND 
3. The candidate’s allocation score according to Table 11-1: Allocation Points 
 
The transplant program that reallocates the islets must document that it followed this policy.

---

## 11.6.A — Transplant Program Qualifications

<!-- Policy: 11 | Section: 11.6.A | Category: Pancreas Allocation -->

A transplant program qualifies to receive facilitated pancreas offers if within the two previous 
years it has transplanted a minimum of two pancreas recovered from deceased donors located 
at hospitals more than 250 NM away from the transplant program. This includes pancreas 
transplanted as part of a multi-organ transplant. 
 
Transplant programs that qualify for facilitated pancreas allocation must notify the OPTN in 
writing if they do not wish to participate.

---

## 11.6.B — Facilitated Pancreas Offers

<!-- Policy: 11 | Section: 11.6.B | Category: Pancreas Allocation -->

OPOs and the OPTN are permitted to make facilitated pancreas offers if no pancreas offer has 
been accepted three hours prior to the scheduled donor organ recovery. The OPO or OPTN must 
offer the pancreas only to potential transplant recipients registered at a transplant program that 
participates in facilitated pancreas allocation. Facilitated pancreas offers must be made in the 
order of the match run, and OPOs will only have access to facilitated allocation after all pancreas 
and kidney-pancreas offers made to candidates registered at transplant programs within 250 
nautical miles of the donor hospital have been declined. 
 
 

OPTN Policies                                                                                                Policy 11: Allocation of Pancreas, Kidney-Pancreas, and Islets

---

## 11.7 — Allocation of Released Kidney-Pancreas, Pancreas or Islets

<!-- Policy: 11 | Section: 11.7 | Category: Pancreas Allocation | Cross-ref: Policy 5, Policy 8 -->

For kidney-pancreas, pancreas or islets released according to OPTN Policy 5.9: Released Organs, the host 
OPO may  
1. Continue allocation according to the original match run 
2. Allocate the kidney-pancreas, pancreas or islets to a potential transplant recipient at the transplant 
program that originally accepted the organ(s). If allocating to a pancreas alone potential transplant 
recipient at the same program, the kidney must be allocated according to OPTN Policy 8.7: 
Allocation of Released Kidneys or 
3. Contact the OPTN for assistance allocating the organ(s)

---

## 11.8.A — Location of Donor Hospitals

<!-- Policy: 11 | Section: 11.8.A | Category: Pancreas Allocation | Cross-ref: Policy 12 -->

For the purpose of determining the location of the donor hospital for allocation of pancreas, 
kidney-pancreas, or islets, kidneys and pancreata procured in Alaska will be considered procured 
from the Sea-Tac Airport, Seattle, Washington. 

OPTN Policies                                                                                                Policy 11: Allocation of Pancreas, Kidney-Pancreas, and Islets 
 
 
Policy 12: Allocation of Covered Vascularized Composite 
Allografts 
12.1 Waiting Time 
260 
12.2 Covered VCA Allocation 
260

---
