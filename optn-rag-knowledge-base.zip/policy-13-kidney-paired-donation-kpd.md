# OPTN Policy 13: Kidney Paired Donation (KPD)

**Source:** OPTN Policies | **Effective:** 12/10/2025 | **Category:** Kidney Paired Donation
**Confidence:** HIGH — Official OPTN policy language

---

## 13.1 — Candidate Requirements for Participation

<!-- Policy: 13 | Section: 13.1 | Category: Kidney Paired Donation -->

In order to participate in the OPTN Kidney Paired Donation (KPD) program, candidates must be 
registered on the deceased donor kidney waiting list at the transplant hospital that wishes to enroll the 
candidate in the OPTN KPD program.

---

## 13.2 — Potential KPD Donor Requirements for Participation

<!-- Policy: 13 | Section: 13.2 | Category: Kidney Paired Donation -->

In order to participate in the OPTN KPD program, potential KPD donors must comply with both of the 
following requirements: 
 
1. Be at least 18 years old 
2. Not be currently registered as a potential KPD donor for any other candidate registered in the OPTN 
KPD program

---

## 13.3 — Informed Consent for KPD Candidates

<!-- Policy: 13 | Section: 13.3 | Category: Kidney Paired Donation -->

The below requirements apply to candidates participating in any KPD program, unless otherwise 
specified.

---

## 13.3.A — Release of Protected Health Information

<!-- Policy: 13 | Section: 13.3.A | Category: Kidney Paired Donation -->

For any KPD exchange, a paired candidate will not be eligible for a KPD match run until the 
paired candidate’s transplant hospital obtains written consent from the paired candidate to 
share protected health information (PHI) with all other transplant hospitals in the KPD exchange. 

OPTN Policies                                                                                                                                       Policy 13: Kidney Paired Donation (KPD) 
 
 
The paired candidate’s transplant hospital must maintain documentation of this consent in the 
paired candidate’s medical record.

---

## 13.3.B — Agreement to Accept a Shipped Kidney

<!-- Policy: 13 | Section: 13.3.B | Category: Kidney Paired Donation -->

The OPTN KPD program will only match a paired candidate with a donor whose recovery will 
occur at a transplant hospital that is different than the paired candidate’s transplant hospital if 
the paired candidate’s transplant hospital has obtained documentation in the candidate’s 
medical record that the candidate is willing to receive a shipped kidney. 
 
For any KPD exchange, the paired candidate’s transplant hospital must document in the 
candidate’s medical record that the candidate has been informed of the potentially negative 
consequences related to shipping a kidney, including that the donor’s kidney could be lost in 
transport.

---

## 13.3.C — Additional Requirements for KPD Candidates

<!-- Policy: 13 | Section: 13.3.C | Category: Kidney Paired Donation -->

For any KPD exchange, the paired candidate’s transplant hospital must document in the 
candidate’s medical record that it has informed the paired candidate of all the following 
elements of the KPD program: 
 
1. The KPD program’s matching requirements  
2. KPD donors and candidates do not choose their match 
3. A KPD donor or a candidate may decline a match  
4. The KPD program’s rules for when members are allowed to facilitate meetings between 
matched donors and recipients  
5. That even if the candidate’s paired donor donates, the paired candidate might not be 
transplanted. 
6. The KPD program’s remedy for failed KPD exchanges and that the remedy does not include 
any additional priority for the paired candidate on the deceased donor waiting list 
 
The paired candidate’s transplant hospital must inform the candidate of the right to withdraw 
from participation in the KPD program at any time, for any reason.

---

## 13.4 — Informed Consent for KPD Donors

<!-- Policy: 13 | Section: 13.4 | Category: Kidney Paired Donation -->

The below requirements apply to candidates participating in any KPD program, unless otherwise 
specified.

---

## 13.4.A — Release of Protected Health Information (PHI)

<!-- Policy: 13 | Section: 13.4.A | Category: Kidney Paired Donation -->

For any KPD exchange, a paired donor will not be eligible for a KPD match run until the paired 
donor’s transplant hospital obtains written consent from the paired donor to share protected 
health information (PHI) with all other transplant hospitals in the KPD exchange. The paired 
donor’s transplant hospital must maintain documentation of this consent in the paired donor’s 
medical record. 
 

OPTN Policies                                                                                                                                       Policy 13: Kidney Paired Donation (KPD)

---

## 13.4.B — General KPD Donor Informed Consent

<!-- Policy: 13 | Section: 13.4.B | Category: Kidney Paired Donation | Cross-ref: Policy 14 -->

For any KPD exchange, the paired donor’s transplant hospital is responsible for obtaining and 
documenting informed consent from the paired donor according to OPTN Policy 14.3: Informed 
Consent Requirements. If a different transplant hospital performs the organ recovery, the 
recovery hospital must also obtain and document informed consent according to OPTN Policy 
14.

---

## 13.4.C — Additional Requirements for KPD Donors

<!-- Policy: 13 | Section: 13.4.C | Category: Kidney Paired Donation -->

For any KPD exchange, the paired donor’s transplant hospital must maintain documentation in 
the paired donor’s medical record that it has informed the paired donor of all of the following: 
 
1. The KPD program’s matching requirements 
2. KPD donors and candidates do not choose their match 
3. A KPD donor or a candidate may decline a match  
4. The possibility of helping more than one candidate receive a transplant 
5. The possibility that the paired donor may have to wait to find a match 
6. The possibility that the paired donor might have to wait longer to donate after a match has 
been identified because of logistical issues 
7. The possibility that the paired candidate might not receive a transplant because of an 
unexpected issue with the matched donor’s kidney found during or after surgery 
8. The possibility that the paired donor’s kidney might not be transplanted or the paired 
donor’s matched candidate might not receive a transplant because of unexpected events 
9. The KPD program’s remedy for failed KPD exchanges and that the remedy does not include 
any additional priority for the paired candidate on the deceased donor waiting list 
10. The possibility that personal expenses of travel, housing, childcare costs, and lost wages 
related to donation might not be reimbursed; however, resources might be available to 
defray some donation related costs. 
11. The possibility that the paired donor’s paired recipient and the paired donor’s matched 
recipient might not have equal outcomes 
12. The possibility of the paired donor’s name appearing on the matched candidate’s insurance 
estimation of benefits 
13. That the donor’s kidney could be lost in transport, and other potentially negative 
consequences related to shipping a kidney 
14. That the paired donor may require additional testing, including multiple blood draws for 
crossmatching 
15. That the paired donor may require re-evaluation 
16. The KPD program’s rules for when members are allowed to facilitate meetings between 
matched donors and recipients 
 
For initial evaluations of all donors, the paired donor’s transplant hospital must obtain the 
paired donor’s signature that confirms the donor has been informed that of the paired donor 
may withdraw from participation in the KPD program at any time, for any reason. 
 
For re-evaluation of OPTN KPD donors, the paired donor’s transplant hospital must confirm the 
donor has been informed that the paired donor may withdraw from participation in the KPD 
program at any time, for any reason. 

OPTN Policies                                                                                                                                       Policy 13: Kidney Paired Donation (KPD)

---

## 13.4.D — Additional Requirements for Non-Directed Donor (NDD) Participants in KPD

<!-- Policy: 13 | Section: 13.4.D | Category: Kidney Paired Donation | Cross-ref: Policy 14 -->

Programs 
For any KPD exchange, before a NDD can participate in the KPD program, the NDD’s transplant 
hospital must document in the NDD’s medical record that it has informed the NDD of all their 
donation options including: 
 
1. Participating in KPD 
2. Donating to a candidate waiting for a deceased donor kidney according to OPTN Policy 
14.6.B: Placement of Non-directed Living Donor Kidneys  
3. Any other options available to the NDD

---

## 13.4.E — Additional Requirements for Bridge Donors

<!-- Policy: 13 | Section: 13.4.E | Category: Kidney Paired Donation -->

For any KPD exchange, before a bridge donor is entered into a KPD match run, the bridge 
donor’s transplant hospital is responsible for obtaining and maintaining documentation in the 
donor’s medical record that it has informed the bridge donor of all of the following: 
 
1. The bridge donor may need to have another medical evaluation at a future time. 
2. The bridge donor may need to be available to provide blood on multiple occasions for 
crossmatching. 
3. How the KPD program determines whether a chain ends with a bridge donor 
4. The bridge donor may decline to donate at any time, for any reason 
5. All of the bridge donor’s options for donation, including: 
a. Continued participation as a bridge donor in the KPD program 
b. Donation to a candidate waiting for a deceased donor kidney 
c. Any other options available to the bridge donor 
6. The bridge donor determines the amount of time the donor is willing to be a bridge donor. 
The bridge donor’s transplant hospital will document in the donor’s medical record how 
long the donor is willing to be a bridge donor. If the bridge donor revises the amount of time 
the donor is willing to be a bridge donor, the bridge donor’s transplant hospital must 
document that revision in the donor’s medical record. 
 
The bridge donor’s transplant hospital must maintain documentation in the donor’s medical 
record that the donor has verbally consented to remain a bridge donor each time the donor is 
identified as a bridge donor in an accepted KPD exchange.

---

## 13.5.A — HLA Typing Requirements for OPTN KPD Candidates

<!-- Policy: 13 | Section: 13.5.A | Category: Kidney Paired Donation -->

Before a candidate can appear on an OPTN KPD match run, the paired candidate’s transplant 
hospital is responsible for reporting to the OPTN Contractor serological split level molecular 
typing results for all of the following: 
 

OPTN Policies                                                                                                                                       Policy 13: Kidney Paired Donation (KPD) 
 
 
• 
HLA-A 
• 
HLA-B 
• 
HLA-Bw4 
• 
HLA-Bw6 
• 
HLA-DR 
 
If the candidate has unacceptable antigens listed for any of the following HLA types, then the 
paired candidate’s transplant hospital is responsible for reporting to the OPTN Contractor 
serological split level molecular typing results for the corresponding HLA type before the 
candidate can appear on an OPTN KPD match run: 
• 
HLA-C 
• 
HLA-DR51 
• 
HLA-DR52 
• 
HLA-DR53 
• 
HLA-DPA1 
• 
HLA-DPB1 
• 
HLA-DQA1 
• 
HLA-DQB1

---

## 13.5.B — Antibody Screening Requirements for OPTN KPD Candidates

<!-- Policy: 13 | Section: 13.5.B | Category: Kidney Paired Donation -->

The paired candidate’s transplant hospital must complete antibody screening tests and report to 
the OPTN Contractor as follows: 
 
1. Use an antibody testing method that is at least as sensitive as the crossmatch method. If 
antibodies are detected, then identify unacceptable antigens using a solid-phase single 
phenotype or solid-phase single-antigen test.  
2. If no HLA antibodies or unacceptable antigens are detected, then report the paired 
candidate as unsensitized. 
Report donor antigens that are considered absolute contraindications to transplant with the paired 
candidate as unacceptable antigens. 
Before candidates can appear on their first OPTN KPD match run, each paired candidate’s physician or 
surgeon or their designee and the histocompatibility laboratory director or the director’s designee must 
review and sign a written approval of the unacceptable antigens listed for the paired candidate. The 
paired candidate’s transplant hospital must document this review in the paired candidate’s medical 
record. 
Retest active candidates for antibodies according to #1 above at all of the following times: 
 
• 
Within 110 days from the date of the most recent antibody test  
• 
When any potentially sensitizing event occurs 
• 
When a paired candidate who has been inactive for more than 90 days has been 
reactivated 
• 
When an unacceptable and positive physical crossmatch occurs that precludes 
transplantation of the matched candidate 
 

OPTN Policies                                                                                                                                       Policy 13: Kidney Paired Donation (KPD) 
 
 
If any new unacceptable antigens are identified, then the paired candidate’s transplant hospital 
must report these antigens using the process outlined in #3 and #4 above. If no new 
unacceptable antigens are identified, the paired candidate’s transplant hospital must document 
the antibody screening results in the paired candidate’s medical record.

---

## 13.5.C — HLA Typing Requirements for OPTN KPD Donors

<!-- Policy: 13 | Section: 13.5.C | Category: Kidney Paired Donation -->

Before a donor can appear on an OPTN KPD match run, the donor’s transplant hospital is 
responsible for reporting to the OPTN Contractor serological split level molecular typing results 
for all of the following: 
 
• 
HLA-A 
• 
HLA-B 
• 
HLA-Bw4 
• 
HLA-Bw6 
• 
HLA-C 
• 
HLA-DR 
• 
HLA-DR51 
• 
HLA-DR52 
• 
HLA-DR53 
• 
HLA-DPA1 
• 
HLA-DQA1 
• 
HLA-DQB1 
• 
HLA-DPB1

---

## 13.5.D — Responding to OPTN KPD Match Offers

<!-- Policy: 13 | Section: 13.5.D | Category: Kidney Paired Donation -->

1. Before declining an OPTN KPD match offer due to unacceptable antigens, the matched 
candidate’s physician or surgeon or their designee must review the matched donor’s 
antigens and their matched candidate’s unacceptable antigens with the histocompatibility 
laboratory director or the director’s designee. This joint review must be documented in the 
matched candidate’s medical record. 
 
When an OPTN KPD match offer is declined due to either a positive crossmatch or unacceptable 
antigens prior to crossmatch, the transplant hospital declining the offer must submit a written 
explanation to the OPTN Contractor within 7 days after declining the offer. 
The matched candidate’s transplant hospital is responsible for performing HLA typing on the 
matched donor and verifying the HLA information reported prior to transplant.

---

## 13.6.A — Requirements for Match Run Eligibility for Candidates

<!-- Policy: 13 | Section: 13.6.A | Category: Kidney Paired Donation -->

The OPTN KPD program will only match candidates who comply with all of the following 
requirements: 
 
1. The candidate’s transplant hospital must comply with OPTN Policies 5.6.A: Receiving and 
Reviewing Organ Offers, 5.7: Organ Check-In, and 5.8: Pre-Transplant Verification 

OPTN Policies                                                                                                                                       Policy 13: Kidney Paired Donation (KPD) 
 
 
2. The candidate’s transplant hospital must complete the informed consent process according 
to OPTN Policy 13.3: Informed Consent for KPD Candidates 
3. The candidate’s transplant hospital must submit all the information for these required fields 
to the OPTN Contractor: 
a. Candidate details, including all of the following: 
• 
Last name 
• 
First name 
• 
SSN 
• 
Date of birth 
• 
Gender 
• 
Ethnicity 
• 
Race 
• 
ABO 
• 
Whether the candidate has signed an agreement to participate in the OPTN KPD 
program 
• 
Whether the candidate has signed a release of protected health information 
• 
Whether the candidate is a prior living donor 
• 
KPD status: active, inactive or removed. A candidate must have current active status 
in the OPTN KPD program to be eligible for a match run. 
 
b. Candidate choices, including all of the following 
• 
Whether the candidate would be willing to travel, and, if so, the transplant hospitals 
to which a candidate would be willing to travel or the distance the candidate is 
willing to travel 
• 
Whether the candidate is willing to accept a shipped kidney, and, if so, from which 
transplant hospitals the candidate would be willing to accept a shipped kidney 
• 
Minimum and maximum acceptable donor age 
• 
Minimum acceptable donor creatinine clearance or glomerular filtration rate (GFR) 
• 
Maximum acceptable donor BMI  
• 
Maximum acceptable systolic and diastolic blood pressure 
• 
Whether the candidate is willing to accept a hepatitis B core antibody positive KPD 
donor, a CMV positive KPD donor, and an EBV positive KPD donor 
• 
Whether the candidate would be willing to accept a left kidney, right kidney, or 
either kidney 
c. Candidate HLA as defined in OPTN Policy 13.5.A: Histocompatibility Requirements for 
KPD Candidates 
4. The candidate must have at least one active and eligible potential KPD donor registered in 
the OPTN KPD program 

OPTN Policies                                                                                                                                       Policy 13: Kidney Paired Donation (KPD) 
 
 
5. The candidate’s transplant hospital must submit a response for all previous match offers for 
the candidate in the OPTN KPD program, including reasons for refusing offers 
6. The candidate must not be in a pending exchange in the OPTN KPD program

---

## 13.6.B — Requirements for Match Run Eligibility for Potential KPD Donors

<!-- Policy: 13 | Section: 13.6.B | Category: Kidney Paired Donation | Cross-ref: Policy 14 -->

The OPTN KPD program will only match potential KPD donors that comply with all of the 
following requirements: 
1. The transplant hospital registering the potential KPD donor must perform blood typing and 
subtyping as required by OPTN Policy 14.5: Living Donor Blood Type Determination and 
Reporting with the following modifications: 
a. 
The transplant hospital registering the potential KPD donor must report the potential 
KPD donor’s actual blood type to the OPTN Contractor 
b. 
A qualified health care professional, other than the qualified health care professional 
who initially reported the potential KPD donor’s blood type to the OPTN Contractor, 
must compare the blood type from the two source documents, and separately report 
the potential KPD donor’s blood type to the OPTN Contractor 
c. 
The potential KPD donor is not eligible for a KPD match run until the transplant 
hospital verifies and reports two identical blood types 
2. The transplant hospital registering the potential KPD donor must complete the informed 
consent process according to OPTN Policy 13.4: Informed Consent for KPD Donors. 
3. The transplant hospital registering the potential KPD donor must complete the evaluation 
process according to OPTN Policy 14: Living Donation. 
4. The transplant hospital registering the potential KPD donor must submit the information for 
the required fields below to the OPTN Contractor: 
a. 
Donor details, including all of the following: 
• 
Last name 
• 
First name 
• 
SSN 
• 
Date of birth 
• 
Gender 
• 
Ethnicity 
• 
Race 
• 
ABO 
• 
Height and weight 
• 
Whether the potential KPD donor is a non-directed donor or a paired donor 
• 
If the potential KPD donor is a paired donor, the KPD Candidate ID of the paired 
candidate and the potential KPD donor’s relationship to the candidate 
• 
Whether the potential KPD donor has signed an agreement to participate in the 
OPTN KPD program 
• 
Whether the potential KPD donor has signed a release of protected health 
information 

OPTN Policies                                                                                                                                       Policy 13: Kidney Paired Donation (KPD) 
 
 
• 
Whether the potential KPD donor has signed an informed consent as required in 
policy 
• 
Whether the potential KPD donor has undergone all evaluations as required in 
OPTN Policy 14: Living Donation 
• 
Whether the potential KPD donor has had all cancer screenings as required in OPTN 
Policy 14: Living Donation 
• 
KPD status: active, inactive or removed. A donor must have current active status in 
the OPTN KPD program to be eligible for a match run. 
b. 
Clinical information, including all of the following: 
• 
The number of anti-hypertensive medications the potential KPD donor is currently 
taking 
• 
Systolic and diastolic blood pressure with date (either 24-hour monitoring or two 
measurements) 
• 
Creatinine clearance or glomerular filtration rate (GFR), date, and method 
• 
Anti-CMV, EBV, HbsAg, and Anti-HbcAb serology results 
c. 
Donor choices, including all of the following: 
• 
Whether the potential KPD donor would be willing to travel, and, if so, the 
transplant hospitals to which the potential KPD donor would be willing to travel or 
the distance the donor is willing to travel 
• 
Whether the potential KPD donor is willing to ship a kidney 
• 
Whether the potential KPD donor is willing to donate a left kidney, right kidney, or 
either kidney 
• 
Whether the KPD candidate-donor pair and the transplant hospital are willing to 
participate in a three-way exchange or a donor chain 
• 
Whether the potential KPD donor and the transplant hospital are willing for the 
potential KPD donor to be a bridge donor 
d. 
Donor HLA as defined in OPTN Policy 13.5.C: HLA Typing Requirements for OPTN KPD 
Donors  
5. The potential KPD donor must be paired to an active and eligible candidate registered in the 
OPTN KPD program or be a non-directed donor  
6. The transplant hospital registering the potential KPD donor must submit a response for all 
previous match offers for the potential KPD donor in the OPTN KPD program, including reason 
for refusing offers 
7. The potential KPD donor must not be in a pending exchange in the OPTN KPD program 
8. The transplant program has re-evaluated the potential KDP donor per Policy 13.7: Re- 
Evaluation Requirements for KPD Donors and reported to the OPTN the date of re-
evaluation

---

## 13.7 — Re-Evaluation Requirements for OPTN KPD Donors

<!-- Policy: 13 | Section: 13.7 | Category: Kidney Paired Donation -->

Transplant programs must re-evaluate donors in the OPTN KPD Program annually. The donor’s 
re-evaluation deadline is based on donor’s date of registration in the OPTN KPD program or the 
date of the donor’s re-evaluation, whichever is most recent.  

OPTN Policies                                                                                                                                       Policy 13: Kidney Paired Donation (KPD) 
 
 
Transplant programs will have 30 days after the donor’s re-evaluation deadline to perform the re-
evaluation. The paired donor’s transplant hospital must report the date the donor re-evaluation was 
completed and any changes to the donor information reported per Policy 13.6.B: Requirements for 
Match Run Eligibility for Potential Donors. Failure to report date of completed donor re-evaluation by 
this time will render the donor ineligible to participate in match runs in the OPTN KPD program until a 
re-evaluation date is reported.

---

## 13.7.A — Psychosocial Re-Evaluation Requirements for OPTN KPD Donors

<!-- Policy: 13 | Section: 13.7.A | Category: Kidney Paired Donation | Cross-ref: Policy 14 -->

A psychosocial re-evaluation of the OPTN KPD donor must be performed by the paired donor’s 
transplant program per OPTN Policy 14.1.A: Living Donor Psychosocial Evaluation Requirements.

---

## 13.7.B — Medical Re-Evaluation Requirements for OPTN KPD Donors (Part 1)

<!-- Policy: 13 | Section: 13.7.B | Category: Kidney Paired Donation -->

A medical re-evaluation of the paired donor must be performed by a physician or surgeon 
experienced in living donation at the paired donor’s transplant program. Documentation of the 
medical re-evaluation must be maintained in the donor medical record.  

The medical re-evaluation must include all of the components in Table 13-1 and Table 13-2 
below. 

Table 13-1: Requirements for OPTN KPD Donor Medical Re-Evaluation: 

This re-evaluation 
must be completed: 
Including evaluation for and assessment of this information: 
General Donor History 
1. A personal history of significant medical conditions, which include but are 
not limited to: 
o 
Hypertension 
o 
Diabetes 
o 
Lung disease 
o 
Heart disease 
o 
Gastrointestinal disease 
o 
Autoimmune disease 
o 
Neurologic disease 
o 
Genitourinary disease 
o 
Hematologic disorders 
o 
Bleeding or clotting disorders 
o 
History of cancer including melanoma 
2. History of infections 
3. Active and past medications with special consideration for known 
nephrotoxic and hepatotoxic medications or chronic use of pain medication 
4. Allergies  
5. Evaluation for coronary artery disease 
Kidney-specific Donor 
History 
1. A personal history of significant medical conditions which include, but are 
not limited to, kidney-specific personal history including: 
o Kidney disease, proteinuria, hematuria 
o Kidney injury 
o Diabetes including gestation diabetes 

OPTN Policies                                                                                                                                       Policy 13: Kidney Paired Donation (KPD) 

This re-evaluation 
must be completed: 
Including evaluation for and assessment of this information: 
o Nephrolithiasis 
o Recurrent urinary tract infections 
Social History  
1. Occupation 
2. Employment status 
3. Health insurance status 
4. Living arrangements 
5. Social support 
6. Smoking, alcohol and drug use and abuse 
7. Psychiatric illness, depression, suicide attempts 
8. Risk criteria for acute HIV, HBV, and HCV infection according to the U.S. 
Public Health Services (PHS) Guideline 
Physical Exam 
1. Height 
2. Weight 
3. BMI 
4. Vital signs 
5. Examination of all major organ systems 
6. Blood pressure taken on at least two different occasions or 24-hour or 
overnight blood pressure monitoring 
General laboratory and 
imaging tests 
1. Complete blood count (CBC) with platelet count 
2. Prothrombin Time (PT) or International Normalized Ratio (INR) 
3. Partial Thromboplastin Time (PTT) 
4. Metabolic testing (to include electrolytes, BUN, creatinine, transaminase 
levels, albumin, calcium, phosphorus, alkaline phosphatase, bilirubin) 
5. HCG quantitative pregnancy test for premenopausal women without 
surgical sterilization 
6. Chest X-Ray 
7. Electrocardiogram (ECG) 
Other metabolic testing: 1. Fasting blood glucose 
2. Fasting lipid profile (cholesterol, triglycerides, HDL cholesterol, and LCL 
cholesterol) 
3. Glucose tolerance test or glycosylated hemoglobin in first degree relatives 
       of diabetics and in high-risk individuals 
Kidney-specific tests 
1. Urinalysis or urine microscopy 
2. Measurement of urinary protein and albumin excretion 
3. The following, if clinically indicated: 
o Urine culture 
o Measurement of glomerular filtration rate by isotopic methods or 
creatinine clearance calculated from a 24-hour urine collection 
o Patients with a history of nephrolithiasis or nephrolithiasis (>3 mm) 
identified on radiographic imaging must have a 24-hour urine stone 
panel measuring calcium, oxalate, uric acid, citric acid, creatinine, 
and sodium 
Cancer Screening:  
1. The paired donor’s transplant hospital must develop and comply with 
protocols consistent with the American Cancer Society (ACS) or the U.S. 
Preventive Services Task Force to screen for: 

OPTN Policies                                                                                                                                       Policy 13: Kidney Paired Donation (KPD) 

This re-evaluation 
must be completed: 
Including evaluation for and assessment of this information: 
o Cervical cancer 
o Breast cancer 
o Prostate cancer 
o Colon cancer 
o Lung cancer 
Anatomic assessment 
1. The following, if clinically indicated: 
o Whether the kidneys are of equal size 
o If the kidneys have masses, cysts, or stones 
o If the kidneys have other anatomical defects 
o Which kidney is more anatomically suited for transplant 

The paired donor’s transplant program must re-evaluate the donor for transmissible diseases per 
Table 13-2. 

Table 13-2: Infectious Disease Testing Re-Evaluation Requirements:  

This re-evaluation 
must be completed: 
Including evaluation for and assessment of this information: 
Transmissible disease 
screening: 
Infectious disease testing must be performed in a CLIA-certified laboratory 
or in a laboratory meeting equivalent requirements as determined by 
Centers for Medicare and Medicaid Services (CMS) using FDA-licensed, 
approved, or cleared tests. Testing must include all the following: 
1. CMV (Cytomegalovirus) antibody 
2. EBV (Epstein Barr Virus) antibody 
3. HIV antibody (anti-HIV) testing or HIV antigen/antibody (Ag/Ab) 
combination 
4. HIV ribonucleic acid (RNA) by nucleic acid test (NAT) 
5. Hepatitis B surface antigen (HbsAg) 
6. Hepatitis B core antibody (total anti-HBc) testing 
7. HBV deoxyribonucleic acid (DNA) by nucleic acid test (NAT) 
8. Hepatitis C antibody (anti-HCV) testing 
9. HCV ribonucleic acid (RNA) by nucleic acid test (NAT) 
10. Syphilis testing 

The donor does not need to be retested for the following infectious disease 
antibodies for which they have previously tested positive: 
1. CMV (Cytomegalovirus) antibody 
2. EBV (Epstein Barr Virus) antibody 
3. Hepatitis B core antibody (total anti-HBc) testing 
4. Hepatitis C antibody (anti-HCV) testing

---

## 13.7.B — Medical Re-Evaluation Requirements for OPTN KPD Donors (Part 2)

<!-- Policy: 13 | Section: 13.7.B | Category: Kidney Paired Donation | Cross-ref: Policy 14 -->

For tuberculosis (TB), the paired donor’s transplant hospital must retest and 
follow protocol per Policy 14.4: Medical Evaluation Requirements for Living 
Donors 

OPTN Policies                                                                                                                                       Policy 13: Kidney Paired Donation (KPD) 

This re-evaluation 
must be completed: 
Including evaluation for and assessment of this information: 
Each living donor hospital must develop and follow a written protocol for 
identifying and testing donors at risk for transmissible seasonal or 
geographically defined endemic disease as part of its medical evaluation.

---

## 13.7.C — Informed Consent Requirements Upon Donor Re-Evaluation

<!-- Policy: 13 | Section: 13.7.C | Category: Kidney Paired Donation -->

Upon re-evaluation of the OPTN KPD donor, the paired donor’s transplant hospital must 
maintain documentation in the paired donor’s medical record that it has informed the paired 
donor of all of the requirements in Policy 13.4.C: Informed Consent for KPD Donors. The paired 
donor’s transplant hospital must also confirm that the donor has been re-informed that they 
may withdraw from participation in the OPTN KPD program at any time, for any reason.

---

## 13.8.A — Blood Type

<!-- Policy: 13 | Section: 13.8.A | Category: Kidney Paired Donation -->

The OPTN Contractor will only match candidates and potential donors who have identical or 
compatible blood types as defined in Table 13-1 below.  
 
Table 13-3: Allocation by Blood Type 
Donors with: 
Are Matched to Candidates with: 
Blood Type O 
Blood type O  
Blood types A, A1, or A, non-A1 
Blood types B, AB, A1B, or AB, non- A1B 
Blood Type A or A1 
Blood types A, A1, or A, non-A1  
Blood types AB, A1B, or AB, non- A1B 
Blood Type A, non-A1 
Blood types A, A1, or A, non-A1 
Blood types AB, A1B, or AB, non-A1B 
Blood type O or B if the candidate meets 
the requirements in Policy 13.7.B: Blood 
Type A, non-A1 and Blood Type AB, non-
A1B Matching.  
Blood Type B 
Blood type B 
Blood types AB, A1B, or AB, non-A1B 
Blood Type AB 
Blood types AB, A1B, or AB, non-A1B 
Blood Type A1B 
Blood types AB, A1B, or AB, non-A1B 

OPTN Policies                                                                                                                                       Policy 13: Kidney Paired Donation (KPD) 
 
 
Donors with: 
Are Matched to Candidates with: 
Blood Type AB, non-A1B 
Blood types AB, A1B, or AB, non-A1B 
Blood type B if the candidate meets the 
requirements in Policy 13.7.B: Blood Type 
A, non-A1 and Blood Type AB, non-A1B 
Matching.  
 
13.8.B 
Blood Type A, non-A1 and Blood Type AB, non-A1B Matching 
Kidneys from donors with blood types A, non-A1 may be matched with candidates with blood 
type B or blood type O, and kidneys from donors with blood types AB, non-A1B may be matched 
with candidates with blood type B, so long as all of the following criteria are met: 
 
1. The paired candidate’s transplant program establishes a written policy regarding its 
programs titer threshold for transplanting blood type A, non-A1 and blood type AB, 
non- A1B kidneys into candidates with blood type B and for transplanting blood type 
A, non- A1 into candidates with blood type O. 
2. The paired candidate’s transplant program obtains written informed consent from 
the candidate regarding their willingness to accept a blood type A, non-A1, or blood 
type AB, non-A1B blood type kidney 
3. The paired candidate’s transplant program must confirm the candidate’s eligibility 
every 90 days (+/- 20 days).

---

## 13.8.B — Logistical Requirements

<!-- Policy: 13 | Section: 13.8.B | Category: Kidney Paired Donation -->

In two-way or three-way exchanges in the OPTN KPD program, each matched donor recovery 
must be scheduled to begin within 24 hours of the start of the previous matched donor 
recovery. The donor surgeries in the exchange will begin only after all transplant programs agree 
to proceed.

---

## 13.8.C — Unacceptable Antigens

<!-- Policy: 13 | Section: 13.8.C | Category: Kidney Paired Donation -->

A transplant hospital must specify any unacceptable antigens it will not accept for its paired 
candidates using the process outlined in OPTN Policy 13.5.B: Antibody Screening Requirements 
for OPTN KPD Candidates. The OPTN Contractor will not match the paired candidate with any 
potential KPD donor who has one of the candidate’s unacceptable antigens entered as a human 
leukocyte antigen (HLA) value.

---

## 13.8.D — Candidate and Potential Donor Choices

<!-- Policy: 13 | Section: 13.8.D | Category: Kidney Paired Donation -->

A transplant hospital may specify criteria it will not accept for any of its KPD candidates as 
outlined in OPTN Policy 13.6.A: Requirements for Match Run Eligibility for Candidates or 
potential KPD donors as outlined in OPTN Policy 13.6.B: Requirements for Match Run Eligibility 
for Potential KPD Donors. The OPTN Contractor will not match the KPD candidates with potential 
KPD donors who fall outside the specified criteria or potential KPD donors with KPD candidates 
who fall outside the specified criteria.

---

## 13.8.E — Donor Pre-Acceptance and Pre-Refusal

<!-- Policy: 13 | Section: 13.8.E | Category: Kidney Paired Donation -->

If an OPTN KPD candidate has a CPRA greater than or equal to 90%, then the candidate’s 
transplant hospital must pre-accept or pre-refuse potential donors. The OPTN KPD candidate 
will only be matched with donors that are pre-accepted. If a donor is not pre-accepted, the 
donor will automatically be treated as pre-refused and will not be matched with the candidate. 
 

OPTN Policies                                                                                                                                       Policy 13: Kidney Paired Donation (KPD) 
 
 
If an OPTN KPD candidate has a CPRA less than 90%, then the candidate’s transplant hospital has 
the option to pre-accept or pre-refuse potential donors. These candidates will automatically be 
matched with all potential donors, unless the candidate’s transplant hospital exercises the 
option to pre-refuse a potential donor.

---

## 13.8.F — OPTN KPD Prioritization Points

<!-- Policy: 13 | Section: 13.8.F | Category: Kidney Paired Donation -->

All OPTN KPD matches receive 100 base points. KPD matches will receive additional points 
according to Table 13-2: OPTN KPD Prioritization Points when the OPTN Contractor identifies all 
possible matches and exchanges from the list of eligible KPD donors and candidates. The OPTN 
Contractor will then prioritize the set of exchanges with the highest total point value.  
Table 13-4: OPTN KPD Prioritization Points 
If the: 
Then the match will receive: 
Candidate is registered for the OPTN KPD 
program 
.07 points for each day according to Policy 
13.7.G: OPTN KPD Waiting Time 
Reinstatement 
Candidate is a 0-ABDR mismatch with the 
potential donor 
10 points 
Transplant hospital that registered both 
the candidate and potential donor in the 
OPTN KPD program is the same 
75 points 
Candidate and potential donor had a 
previous crossmatch that was one of the 
following: 
• Negative 
• Positive and acceptable with 
desensitization 
• Positive and acceptable without 
desensitization 
75 points 
Candidate was less than 18 years old at the 
time the candidate was registered in the 
OPTN KPD program 
100 points 
Candidate is a prior living organ donor 
150 points 
Candidate ABO is O 
100 points 
Candidate ABO is B 
50 points 
Candidate ABO is A 
25 points 
Candidate ABO is AB 
0 points 
Paired donor ABO is O 
0 points 
Paired donor ABO is B 
100 points 

OPTN Policies                                                                                                                                       Policy 13: Kidney Paired Donation (KPD) 
 
 
If the: 
Then the match will receive: 
Paired donor ABO is A 
250 points 
Paired donor ABO is AB 
500 points 
Candidate CPRA is 0-19 
0 points 
Candidate CPRA is 20-29 
5 points 
Candidate CPRA is 30-39 
10 points 
Candidate CPRA is 40-49 
15 points 
Candidate CPRA is 50-59 
20 points 
Candidate CPRA is 60-69 
25 points 
Candidate CPRA is 70-74 
50 points 
Candidate CPRA is 75-79 
75 points 
Candidate CPRA is 80-84 
125 points 
Candidate CPRA is 85-89 
200 points 
Candidate CPRA is 90-94 
300 points 
Candidate CPRA is 95 
500 points 
Candidate CPRA is 96 
700 points 
Candidate CPRA is 97 
900 points 
Candidate CPRA is 98 
1250 points 
Candidate CPRA is 99 
1500 points 
Candidate CPRA is 100 
2000 points 
Candidate is an orphan candidate 
1,000,000 points 
 
If a candidate has multiple paired donors with different blood types, then all of the candidate’s 
matches will be awarded the priority point value associated with the paired donor whose ABO 
receives the fewest amount of points.

---

## 13.8.G — OPTN KPD Waiting Time Reinstatement

<!-- Policy: 13 | Section: 13.8.G | Category: Kidney Paired Donation -->

KPD waiting time begins on the day the candidate’s transplant hospital registers the candidate in 
the OPTN KPD program. Candidates accrue 0.07 points per day from the date the candidate is 
registered in the OPTN KPD program. A candidate will accrue KPD waiting time at both active 
and inactive status in the OPTN KPD program.  
The OPTN Contractor will reinstate OPTN KPD waiting time to recipients, without interruption, if 
the OPTN KPD candidate experiences immediate and permanent non-function of any 
transplanted kidney and the KPD candidate is re-registered in the OPTN KPD program with 

OPTN Policies                                                                                                                                       Policy 13: Kidney Paired Donation (KPD) 
 
 
another living donor. Immediate and permanent non-function of a transplanted kidney is 
defined as either: 
1. Kidney graft removal within the first 90 days of transplant documented by a report of the 
removal of the transplanted kidney. 
 
2. Kidney graft failure within the first 90 days of transplant with documentation that the 
candidate is either on dialysis or has measured creatinine clearance (CrCl) or calculated 
glomerular filtration rate (GFR) less than or equal to 20 mL/min within 90 days after the 
candidate’s kidney transplant. 
KPD waiting time will be reinstated when the OPTN Contractor receives a request for 
reinstatement of KPD waiting time and the required supporting documentation from the KPD 
candidate’s transplant hospital.

---

## 13.8.H — Priority for Orphan Candidates

<!-- Policy: 13 | Section: 13.8.H | Category: Kidney Paired Donation -->

A candidate will be eligible for orphan candidate priority only if the candidate qualified for 
orphan status through participation in the OPTN KPD program. An orphan candidate will receive 
priority according to Table 13-2: OPTN KPD Prioritization Points, even if the candidate has 
another willing living donor. The orphan candidate will retain this priority until the orphan 
candidate receives a kidney transplant. The orphan candidate can always refuse a match offer 
and retain orphan candidate priority.

---

## 13.9.A — Match Size

<!-- Policy: 13 | Section: 13.9.A | Category: Kidney Paired Donation -->

The OPTN Contractor will match KPD donor-candidate pairs only in two-way or three-way 
exchanges unless the exchange includes a non-directed donor (NDD) according to OPTN Policy 
13.9: Donor Chains.

---

## 13.10.A — Chain Size

<!-- Policy: 13 | Section: 13.10.A | Category: Kidney Paired Donation -->

In the OPTN KPD program, there is no limit on the length of the KPD donor chains.

---

## 13.10.B — Logistical Requirements for Donor Chains

<!-- Policy: 13 | Section: 13.10.B | Category: Kidney Paired Donation -->

In OPTN KPD chains, each matched donor recovery must be scheduled to begin within 21 days 
from the date the matched donor’s paired candidate receives a transplant. However, a KPD 

OPTN Policies                                                                                                                                       Policy 13: Kidney Paired Donation (KPD) 
 
 
candidate-donor pair has the option to either have their surgeries begin within 24 hours of one 
another or refuse the match. Surgeries occurring within 24 hours would follow the same 
requirements as the two-way or three-way exchange according to OPTN Policy 13.8.B: Logistical 
Requirements for Two- and Three-Way Matches.

---

## 13.10.C — Ending Chains

<!-- Policy: 13 | Section: 13.10.C | Category: Kidney Paired Donation -->

Transplant hospitals participating in OPTN KPD must follow the requirements for ending a chain 
according to Table 13-3 below. 
 
Table 13-5: Logistical Requirements for Ending Chains 
If a chain begins that: 
Then: 
Does not include a match for an orphan 
candidate 
The transplant hospital that entered the non-
directed donor (NDD) can choose to either: 
Allow the chain to continue through bridge 
donation, if the last paired donor in the chain 
is willing to be a bridge donor. 
End the chain with a donation from the last 
paired donor in the chain to a candidate on the 
deceased donor waiting list at the transplant 
hospital that entered the NDD that started the 
chain.  
Includes a match for an orphan candidate 
The chain must end with a donation to the 
orphan candidate. 
 
If the transplant hospital that entered the non-directed donor initially chooses to allow the 
chain to continue through bridge donation, the chain will extend until the transplant hospital 
reports to the OPTN Contractor that one of the following events has occurred: 
 
• 
The bridge donor declines to donate 
• 
The bridge donor donates to an orphan candidate  
• 
The bridge donor donates to the deceased donor waitlist  
• 
The transplant hospital that registered the bridge donor in the OPTN KPD program 
refuses to allow the donor to serve as a bridge donor 
 
A transplant hospital that entered the non-directed donor can also request to end the chain 
with a donation to the deceased donor waiting list.

---

## 13.10.D — What to Do When a Chain Breaks

<!-- Policy: 13 | Section: 13.10.D | Category: Kidney Paired Donation -->

In the OPTN KPD program, a donor chain will proceed until a KPD candidate or matched donor 
refuses a match offer. 
 
If a KPD candidate or matched donor in a chain refuses a match offer, then the matched donor 
at the end of the chain may donate to an orphan candidate, the deceased donor waiting list, or 
may be a bridge donor as outlined in OPTN Policy 13.9.B: Logistical Requirements for Donor 
Chains and Policy 13.9.C: Ending Chains. 

OPTN Policies                                                                                                                                       Policy 13: Kidney Paired Donation (KPD)

---

## 13.11 — OPTN KPD Crossmatching Requirements

<!-- Policy: 13 | Section: 13.11 | Category: Kidney Paired Donation -->

The matched candidate’s transplant hospital must do all of the following: 
 
1. Perform a physical crossmatch between the matched candidate and the matched donor before the 
matched donor’s recovery is scheduled. 
2. Perform a final crossmatch prior to transplant. 
3. Report all crossmatching results to the OPTN Contractor and the matched donor’s transplant 
hospital. 
 
If, at any time, the matched candidate’s transplant hospital refuses a match offer due to an 
unacceptable positive crossmatch between the candidate and the matched donor, then the matched 
candidate is ineligible for subsequent match runs. The candidate will remain ineligible until all of the 
following are completed: 
 
1. The matched candidate’s physician or surgeon or their designee and the histocompatibility 
laboratory director or the director’s designee review the unacceptable antigens reported for the 
candidate. 
2. The matched candidate’s transplant hospital reports to the OPTN Contractor that the review has 
occurred.

---

## 13.12 — KPD Match Offer and Transplant Timing Requirements

<!-- Policy: 13 | Section: 13.12 | Category: Kidney Paired Donation -->

Each OPTN KPD program must designate a KPD contact to receive notification of match offers. 
 
Table 13-6: Deadlines for Performing Responsibilities upon Receiving a KPD Match Offer 
The following members:  
Must: 
Within: 
Each transplant hospital receiving 
a match offer 
Report to the OPTN Contractor a 
preliminary response  
2 business days of receiving 
the match offer. 
The matched candidate’s 
transplant hospital and the 
matched donor’s transplant 
hospital  
Agree in writing upon all of the 
following:  
• Contents required in the 
crossmatch kit 
• Instructions for the donor 
• Address at which to send the 
completed blood samples 
3 business days of receiving 
the match offer. 
The matched donor’s transplant 
hospital 
Report to the OPTN Contractor 
the agreed upon date of the 
crossmatch  
3 business days of receiving 
the match offer. 

OPTN Policies                                                                                                                                       Policy 13: Kidney Paired Donation (KPD) 
 
 
The following members:  
Must: 
Within: 
The matched donor’s transplant 
hospital 
Make all of the following matched 
donor’s records accessible to the 
matched candidate’s transplant 
hospital:  
• Any serologic and nucleic acid 
testing (NAT) results that have 
not already been shared with 
the matched candidate’s 
transplant hospital 
• Whether the matched donor 
has any risk criteria for acute 
HIV, HBV, or HCV infection 
according to the U.S. Public 
Health Service (PHS) Guideline 
• Additional records requested 
by the matched candidate’s 
transplant hospital 
3 business days of receiving 
the match offer. 
The matched candidate’s 
transplant hospital 
Report to the OPTN Contractor 
the results of the crossmatch 
10 business days of 
receiving the match offer. 
The matched candidate’s 
transplant hospital 
Review the matched donor’s 
records and confirm acceptance or 
report a refusal of the match offer 
to the OPTN Contractor 
10 business days of 
receiving the match offer. 
The matched candidate’s 
transplant hospital and the 
matched donor’s transplant 
hospital 
Agree upon a date and time for 
the recovery of the matched 
kidney(s) 
15 business days of 
receiving the match offer 
The matched donor’s transplant 
hospital and matched candidate’s 
transplant hospital 
Schedule both the recovery of the 
kidney from one of the matched 
donors in the exchange and the 
subsequent transplant of their 
matched candidate to occur 
60 days of receiving the 
match offer 
 
If the matched candidate’s and matched donor’s transplant hospitals do not meet any of the deadlines 
above, then the exchange will be terminated unless a transplant hospital requests an extension. If a 
transplant hospital submits an extension request before the deadline, the exchange will not terminate 
until the resolution of the extension request or the deadline is reached, whichever comes last.

---

## 13.12.A — Requesting a Deadline Extension for a KPD Exchange

<!-- Policy: 13 | Section: 13.12.A | Category: Kidney Paired Donation -->

The transplant hospital may request an extension for any of the deadlines in Table 13-4 by 
submitting a request in writing to the OPTN Contractor. This written request must include the 
reason for the request and the new requested deadline date. Upon receipt of the request for 
extension, the OPTN Contractor will notify all of the transplant hospitals in the exchange. Upon 
notification, the transplant hospitals in the exchange must respond to the request for extension 

OPTN Policies                                                                                                                                       Policy 13: Kidney Paired Donation (KPD) 
 
 
within 2 business days. If all other transplant hospitals in the exchange agree to the extension, 
it will be granted. If any of the transplant hospitals in the exchange refuse the extension 
request, the extension will not be granted. 
 
The transplant hospitals will have two business days to respond to the extension request. At 
the end of the first business day, the OPTN will send a second notification to any transplant 
hospital that has not yet responded. If any of the transplant hospitals fail to respond to the 
extension request at the end of the second business day, the extension will be granted.

---

## 13.13 — Transportation of Kidneys

<!-- Policy: 13 | Section: 13.13 | Category: Kidney Paired Donation | Cross-ref: Policy 16 -->

For any KPD exchange, the recovery hospital is responsible for packaging, labeling, and transporting 
kidneys from donors according to OPTN Policy 16.1: Organs Recovered by Living Donor Recovery 
Hospitals. 
 
In the OPTN KPD program, the recovery hospital must specify both of the following:  
 
1. The location where the recovered kidney must be picked up for transport to the recipient’s 
transplant hospital. 
2. The name and telephone number of the person or company who will package and label the kidney. 
 
The recipient’s transplant hospital must document both of the following: 
 
1. The location where the recovered kidney must be delivered. 
2. The name and telephone number of the person or company who will be transporting the kidney 
from the time that the kidney is recovered until the kidney is delivered to the location specified by 
the KPD recipient’s transplant hospital. 
 
The recovery and recipient hospitals must complete this documentation, along with the date and time it 
was documented, before the potential KPD donor enters the operating room for the kidney recovery 
surgery and must maintain this documentation in the donor’s medical record.

---

## 13.14 — Communication between KPD Donors and Recipients

<!-- Policy: 13 | Section: 13.14 | Category: Kidney Paired Donation | Cross-ref: Policy 14 -->

The following rules apply to communication between KPD donors and matched KPD recipients that 
participated in an OPTN KPD program exchange. These rules do not apply to meetings between 
potential KPD donors and paired KPD candidates. 
 
Members can facilitate communication such as meetings or other correspondence between KPD donors 
and their matched recipients that participated in an OPTN KPD program exchange only if all of the follow 
conditions are met: 
 
1. All the KPD donors and recipients participating in the communication agree on conditions of the 
meeting or correspondence. 
2. The meeting or communication occurs after the donor kidney recovery and transplant surgeries 
have been completed. 

OPTN Policies                                                                                                                                       Policy 13: Kidney Paired Donation (KPD) 
 
 
3. The transplant hospital establishes and complies with a written protocol for when KPD donors and 
their matched recipients can communicate. This protocol must include, at a minimum, the timing of 
the meeting or correspondence and what staff must be involved.  
4. The transplant hospital complies with the written protocol for when KPD donors and recipients can 
communicate. The transplant hospital must maintain documentation of compliance in the KPD 
donor’s or matched recipient’s medical record. 

 
 
 
Policy 14: Living Donation 
14.1 Psychosocial Evaluation Requirements for Living Donors 
283 
14.2 Independent Living Donor Advocate (ILDA) Requirements 
284 
14.3 Informed Consent Requirements 
285 
14.4 Medical Evaluation Requirements for Living Donors 
290 
14.5 Living Donor Blood Type Determination and Reporting 
298 
14.6 Placement of Living Donor Organs 
299 
14.7 Living Donor Pre-Recovery Verification 
300 
14.8 Packaging, Labeling, and Transporting of Living Donor Organs, Extra Vessels, and Tissue Typing 
Materials 
302 
14.9 Requirements for Domino Donors and Non-Domino Therapeutic Donors 
302 
14.10 Living Donor Organ Check-In 
304 
14.11 Living Donor Pre-Transplant Verification 
304 
14.12 Reporting Requirements 
304

---
