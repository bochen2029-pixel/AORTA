# OPTN Policy 16: Organ and Extra Vessel Packaging, Labeling, Shipping, and Storage

**Source:** OPTN Policies | **Effective:** 12/10/2025 | **Category:** Packaging and Shipping
**Confidence:** HIGH — Official OPTN policy language

---

## 16.1 — Packaging and Labeling Requirements for Living Donor Organs

<!-- Policy: 16 | Section: 16.1 | Category: Packaging and Shipping -->

and Extra Vessels  
Living donor recovery hospitals are responsible for packaging, labeling, and transporting living donor 
organs and tissue typing samples according to OPTN Policy 16, with these differences: 
 
1. Members are not required to use the OPTN organ tracking system for labeling and packaging living 
donor organs and tissue typing samples. 
2. When a member repackages a living donor organ, the member is not required to notify the member 
that originally packaged the organ. 
3. In addition to the list of documents in OPTN Policy 16.4: Documentation Accompanying the Organ or 
Extra Vessels, living donor organs must contain the blood type source documents, donor informed 
consent form, and the complete medical record of the living donor. Extra vessels that are shipped 
separately from living donor organs must include the same documents as are required for shipping 
living donor organs. 
4. Blood samples and tissue typing materials must contain the donor ID and one of the following 
identifiers: donor date of birth, donor initials, or a locally assigned unique ID. Each sample must 
contain the donor’s blood type and subtype, the type of tissue, and the date and time when the 
sample was obtained. The recovery hospital must document in the donor record all unique 
identifiers used to label blood samples and tissue typing materials. 
5. The recovery hospital will provide specimens for tissue typing if requested. The minimum typing 
materials for living donor kidneys are: two ACD (yellow top) tubes per kidney.

---

## 16.2 — Packaging and Labeling Responsibilities

<!-- Policy: 16 | Section: 16.2 | Category: Packaging and Shipping | Cross-ref: Policy 18 -->

The host OPO or recovery hospital is responsible for packaging and labeling organs and tissue typing 
materials that travel outside the recovery facilities.  
 
The host OPO must complete labeling and packaging using the OPTN organ tracking system. The OPO 

OPTN Policies                                                                   Policy 16: Organ and Extra Vessel Packaging, Labeling, Shipping, and Storage 
 
 
must develop and comply with a written protocol for an alternative labeling and packaging process if, for 
any temporary reason, the OPTN organ tracking system is not used. This written protocol must fulfill all 
the requirements according to OPTN Policy 16: Organ and Extra Vessels Packaging, Labeling, Shipping, 
and Storage and the host OPO must document the reasons the OPTN organ tracking system was not 
used.  
 
Transplant hospital staff may not leave the operating room without allowing the host OPO to 
package and label deceased donor organs and tissue typing specimens as required. OPOs are required 
to report these events according to OPTN Policy 18.5: Reporting of Patient Safety Events. 
 
If a transplant hospital repackages an organ for transport, it must package, label, and transport the 
organ according to OPTN Policy 16: Organ and Extra Vessels Packaging, Labeling, Shipping, and 
Storage, except that the use of the OPTN organ tracking system is not required. The transplant hospital 
must immediately notify the host OPO of the repackaging.

---

## 16.3 — Packaging and Labeling

<!-- Policy: 16 | Section: 16.3 | Category: Packaging and Shipping -->

The host OPO must package all organs and tissue typing materials in a sterile environment using 
universal precautions. 
 
The packaged organs from the deceased or living donor’s surgical back table are to be placed directly 
into the wet iced shipping container. Proper insulation and temperature controlled packaging including 
adequate ice or refrigeration must be used to protect the organs during transport. The host OPO may 
either package extra vessels in the same external transport container with the organ or separate from 
the organs. 
 
The transplant hospital or OPO must use both internal and external transport containers to package a 
deceased or living donor organ that travels outside of the facility where the organ is recovered.

---

## 16.3.A — Internal Packaging

<!-- Policy: 16 | Section: 16.3.A | Category: Packaging and Shipping -->

A triple sterile barrier must protect organs. A rigid container must be used as one of these layers 
when packaging kidneys, pancreas, or extra vessels that are packaged separately from the 
organs. If the rigid container is sterile, it can serve as one layer of the required triple sterile 
barrier. The use of a rigid container is optional for all other organs.

---

## 16.3.B — Internal Labeling of Organs

<!-- Policy: 16 | Section: 16.3.B | Category: Packaging and Shipping -->

The host OPO must securely attach the completed OPTN internal label, identifying the specific 
contents, to the outer-most layer of the triple sterile barrier or cassette of mechanical 
preservation machine holding each organ. The OPTN Contractor distributes a standardized label 
that must be used for this purpose. The internal label must be completed using the OPTN organ 
tracking system. The label must include a description of the contents of the package, the donor 
ID, and donor blood type and blood subtype, if used for allocation.

---

## 16.3.C — Internal Labeling of Blood and Tissue Typing Materials

<!-- Policy: 16 | Section: 16.3.C | Category: Packaging and Shipping -->

Each separate specimen container of blood or tissue typing material must have a label that will 

OPTN Policies                                                                   Policy 16: Organ and Extra Vessel Packaging, Labeling, Shipping, and Storage 
 
 
remain secured to the container under normal conditions of transport. If the blood and tissue 
typing materials will be accompanying the organ, the internal label must be completed using 
the OPTN organ tracking system. The label must include the donor ID and at least one of the 
following identifiers: 
 
1. Locally assigned unique ID 
2. Donor date of birth 
3. Donor initials 
 
Additionally each specimen should be labeled with both of the following: 
 
1. The date and time the sample was procured 
2. The type of tissue 
 
The donor blood type and subtype, if used for allocation, should be included on tissue typing 
material and blood samples if known. If the donor ID or blood type is not available during the 
preliminary evaluation of a donor, a locally assigned unique ID and one other identifier for the 
transportation of initial screening specimens may be used. The OPO must document in the OPO 
donor record all unique identifiers used to label tissue typing specimens.

---

## 16.3.D — Internal Labeling of Extra Vessels

<!-- Policy: 16 | Section: 16.3.D | Category: Packaging and Shipping -->

The rigid container holding the extra vessels and the outermost layer of the triple sterile barrier 
must each have a completed OPTN extra vessels label. The OPTN Contractor distributes 
standardized labels that must be used for this purpose. The internal label on the outermost 
layer of the triple sterile barrier must be completed using the OPTN organ tracking system. The 
labels must include all of the following information according to Table 16-1 below. 
 
Table 16-1: Required Information on Internal Labels for Vessels 
This information must be included: 
On the rigid 
container: 
On the 
outermost layer 
of the triple 
sterile barrier: 
1. Donor ID 
⚫ 
⚫ 
2. Donor blood type 
⚫ 
⚫ 
3. Donor blood subtype, if used for allocation 
⚫ 
⚫ 
4. Recovery date 
⚫ 
⚫ 
5. Description of the container contents 
⚫ 
⚫ 
6. That the extra vessels are for use in organ 
transplantation only 
⚫ 
⚫ 

OPTN Policies                                                                   Policy 16: Organ and Extra Vessel Packaging, Labeling, Shipping, and Storage 
 
 
This information must be included: 
On the rigid 
container: 
On the 
outermost layer 
of the triple 
sterile barrier: 
7. Infectious disease donor screening test results for 
all of the following: 
a. anti-HIV I/II 
b. HIV Ag/Ab combo 
c. HIV NAT 
d. total anti-HBc 
e. HBsAg 
f. HBV NAT 
g. anti-HCV 
h. HCV NAT 
 
⚫ 
8. Whether the extra vessels are from a donor with 
a positive result (NAT included) for any of the 
following:  
• HIV, HBV, or HCV  
• total anti-HBc 
⚫ 
 
9. Whether the extra vessels are from a donor that 
has any risk criteria for acute HIV, HBV, or HCV 
infection, according to the U.S. Public Health 
Service (PHS) Guideline 
 
⚫ 
 
⚫

---

## 16.3.E — External Packaging

<!-- Policy: 16 | Section: 16.3.E | Category: Packaging and Shipping -->

Only disposable shipping boxes, coolers, or mechanical preservation machines must be used as 
external transport containers.  
 
16.3.E.i 
Disposable Shipping Box 
If organs or tissue typing materials are shipped commercially, they must be 
transported in a new disposable shipping box. Disposable shipping boxes may not be 
reused and each box must contain all of the following: 
1. A closed plastic liner inside the insulated container to encase the cooling 
material. The liner must be secured and leak-proof. 
2. An inner insulated container, 1.5 inches thick, or a container with an equivalent 
thermal resistance. The container must have proper insulation and enough 
cooling material to protect the organs during normal conditions of transport. 
3. A water-tight, secured, colored, opaque plastic liner between the outer and 
inner containers. The liner must be secured and leak-proof. 
4. An outer container of corrugated plastic or corrugated cardboard, with at least 
200 pounds burst strength, that is coated with a water resistant substance. 
 
 

OPTN Policies                                                                   Policy 16: Organ and Extra Vessel Packaging, Labeling, Shipping, and Storage 
 
 
16.3.E.ii 
Mechanical Preservation Machine 
Members may use a mechanical preservation machine to transport organs. A 
mechanical preservation machine may be reused only if it is properly cleaned and 
sanitized and all labels from previous donor organs are removed. 
 
16.3.E.iii Cooler 
If a member of the organ recovery team is accompanying the organ to the potential 
transplant recipient’s transplant hospital, the organs and tissue typing material may 
be transported in a cooler. A cooler may be reused only if it is properly cleaned and 
sanitized and all labels from previous donor organs are removed.

---

## 16.3.F — External Labeling

<!-- Policy: 16 | Section: 16.3.F | Category: Packaging and Shipping -->

A label, that under normal conditions of transport will remain secured, must be attached to the 
outside of the external transport container. Disposable shipping boxes, coolers, and mechanical 
preservation machines must have the OPTN external label. The OPTN Contractor distributes a 
standardized label that must be used for this purpose. 
 
The OPTN External label must be completed using the OPTN organ tracking system. The label 
must include all of the following: 
 
1. The donor ID 
2. The sender’s name and telephone number 
3. The donor’s blood type 
4. The donor’s subtype, if used for allocation 
5. A description of the specific contents of the box 
6. The Organ Center’s telephone number

---

## 16.4.A — Organ Documentation

<!-- Policy: 16 | Section: 16.4.A | Category: Packaging and Shipping -->

Each external deceased and living donor transport container holding an organ must be sent with 
all of the following source documentation: 
 
1. Blood type  
2. Blood subtype, if used for allocation  
3. Infectious disease testing results available at the time of organ packaging 
 
The source documentation must be placed in a watertight container in either of the following: 
 
1. A location specifically designed for documentation 
2. Between the inner and external transport containers 
 

OPTN Policies                                                                   Policy 16: Organ and Extra Vessel Packaging, Labeling, Shipping, and Storage 
 
 
For deceased donor organs, the host OPO must label the watertight container. This label must 
be completed using the OPTN organ tracking system. The label must include the donor ID, blood 
type, and blood subtype if used for allocation. 
 
If extra vessels are not shipped in the same external transport container as other organs, then 
the separate extra vessels external transport container must include the same complete donor 
documentation.

---

## 16.5 — Verification and Recording of Information before Shipping

<!-- Policy: 16 | Section: 16.5 | Category: Packaging and Shipping -->

Each OPO or recovery hospital must establish and then implement a protocol for verifying the accuracy 
of organ packaging labels by an individual other than the individual initially performing the labeling and 
documentation.  
 
This verification must occur after completing the required labels and documentation for organs and the 
host OPO or recovery hospital must document that verification. 
 
The host OPO must use the OPTN organ tracking system to: 
 
1. Record each item placed into the external organ package 
2. Report to the OPTN that the package is ready for tracking

---

## 16.6.A — Extra Vessels Use and Sharing

<!-- Policy: 16 | Section: 16.6.A | Category: Packaging and Shipping -->

Extra vessels must only be used for organ transplantation or modification of an organ transplant. 
 
Transplant hospitals may share deceased donor extra vessels with other transplant hospitals, 
unless storage is prohibited by OPTN Policy 16.6.B: Extra Vessels Storage. Extra vessels from a 
living donor must only be used for transplant or modification of an organ transplant for the 
original intended recipient and must not be shared. Extra vessels from a donor with HIV must 
only be used for transplant for the original intended recipient.

---

## 16.6.B — Extra Vessels Storage

<!-- Policy: 16 | Section: 16.6.B | Category: Packaging and Shipping -->

Transplant hospitals must not store a donor’s extra vessels if the donor has tested positive for 
any of the following: 
 
• 
HIV by antibody, antigen, or nucleic acid test (NAT) 
• 
Hepatitis B surface antigen (HBsAg) 
• 
Hepatitis B (HBV) by NAT 
• 
Hepatitis C (HCV) by antibody or NAT 
 
Extra vessels from donors that do not test positive for HIV, HBV, or HCV as above may be stored. 
When a transplant hospital stores extra vessels it must do all of the following: 
 
1. Use stored extra vessels only for organ transplantation 

OPTN Policies                                                                   Policy 16: Organ and Extra Vessel Packaging, Labeling, Shipping, and Storage 
 
 
2. Designate at least one person to monitor extra vessels storage, use, destruction, and 
reporting 
3. Package and label extra vessels as required by OPTN Policy 16.3: Packaging and Labeling 
and OPTN Policy 16.4: Documentation Accompanying the Organ or Extra Vessels  
4. Store extra vessels in a Food and Drug Administration (FDA) approved preservation solution 
5. Store extra vessels in a secured refrigerator with a temperature monitor and maintain the 
temperature no colder than 2 degrees Celsius and no warmer than 8 degrees Celsius 
6. Maintain a log of stored extra vessels 
7. Maintain all records relating to the monitoring and use of extra vessels 
8. Monitor extra vessels daily and log security and refrigerator temperature checks 
9. Destroy unused extra vessels within 14 days after the recovery date

---

## 16.6.C — Reporting Requirements for Extra Vessels

<!-- Policy: 16 | Section: 16.6.C | Category: Packaging and Shipping -->

Transplant hospitals must report to the OPTN the disposition of all extra vessels, including their 
use, sharing, or destruction, within seven days of their use, sharing, or destruction.

---

## 16.7.A — Transportation Arrangements

<!-- Policy: 16 | Section: 16.7.A | Category: Packaging and Shipping -->

The host OPO is responsible for determining that non-local procurement teams have 
transportation to and from the local airport.

---

## 16.7.B — Transportation Costs for Deceased Donor Kidneys

<!-- Policy: 16 | Section: 16.7.B | Category: Packaging and Shipping -->

If deceased donor kidneys, and associated tissue typing materials are shipped without any other 
organs, then the host OPO is responsible for all transportation costs.

---

## 16.7.C — Transportation Costs for Living Donor Kidneys

<!-- Policy: 16 | Section: 16.7.C | Category: Packaging and Shipping -->

The organ recipient’s transplant hospital is responsible for transportation costs for living donor 
kidneys and associated tissue typing material according to CMS regulations.

---

## 16.7.D — Transportation Costs for all other Organs

<!-- Policy: 16 | Section: 16.7.D | Category: Packaging and Shipping -->

For all non-renal organs and tissue typing materials from deceased or living donors, including 
kidney-pancreas, transportation costs are the responsibility of the member receiving the organ. 
If an organ or tissue typing material is forwarded to another member for any reason the 
member that finally receives the organ or tissue typing material is responsible for transportation 
costs; unless otherwise agreed upon by the parties involved.

---

## 16.7.E — Transportation Costs for Tissue Typing Material

<!-- Policy: 16 | Section: 16.7.E | Category: Packaging and Shipping | Cross-ref: Policy 17 -->

The organ recipient’s transplant hospital is responsible for payment of transportation costs for 
tissue typing material sent to crossmatch potential recipients of a living donor kidney. When an 
organ recipient’s transplant hospital requests tissue typing material to crossmatch potential 
recipients for a non-renal organ, it must pay transportation costs for the tissue typing material. 

OPTN Policies                                                                                                                          Policy 17: International Organ Transplantation 
 
 
Policy 17: International Organ Transplantation 
17.1 Registration and Transplants of Non-US Citizens/Non-US Residents 
323 
17.2 Importation of Deceased Donor Organs from Foreign Sources 
323

---
