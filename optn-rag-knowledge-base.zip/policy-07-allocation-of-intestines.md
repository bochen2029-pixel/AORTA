# OPTN Policy 7: Allocation of Intestines

**Source:** OPTN Policies | **Effective:** 12/10/2025 | **Category:** Intestine Allocation
**Confidence:** HIGH — Official OPTN policy language

---

## 7.1 — Status Assignments

<!-- Policy: 7 | Section: 7.1 | Category: Intestine Allocation -->

Each intestine candidate is assigned a status that reflects the candidate’s medical condition. Candidates 
may be assigned any of the following: 
 
• 
Status 1 
• 
Status 2 
• 
Inactive status

---

## 7.1.A — Status 1 Requirements

<!-- Policy: 7 | Section: 7.1.A | Category: Intestine Allocation -->

To assign an intestine candidate status 1, the candidate’s transplant program must submit a 
Status 1 Justification Form to the OPTN. A candidate may be assigned status 1 if the candidate 
has any of the following conditions: 
 
• 
Liver function test abnormalities 
• 
No vascular access through the subclavian, jugular, or femoral veins for intravenous feeding 
• 
Medical indications that warrant intestinal organ transplantation on an urgent basis

---

## 7.1.B — Status 2 Requirements

<!-- Policy: 7 | Section: 7.1.B | Category: Intestine Allocation -->

Any active candidate that does not meet the criteria for status 1 must be registered as status 2.

---

## 7.1.C — Inactive Status

<!-- Policy: 7 | Section: 7.1.C | Category: Intestine Allocation -->

If the candidate is temporarily unsuitable for transplant, then the candidate’s transplant 
program may classify the candidate as inactive, and the candidate will not receive any intestine 
offers.

---

## 7.2 — Waiting Time

<!-- Policy: 7 | Section: 7.2 | Category: Intestine Allocation -->

Inactive candidates will accrue waiting time while inactive for up to a maximum of 30 cumulative days.

---

## 7.3.A — Sorting Within Each Classification

<!-- Policy: 7 | Section: 7.3.A | Category: Intestine Allocation -->

Within each allocation classification, candidates are sorted by waiting time (longest to shortest).

---

## 7.3.B — Allocation of Intestines

<!-- Policy: 7 | Section: 7.3.B | Category: Intestine Allocation | Cross-ref: Policy 8 -->

Intestines are allocated to candidates according to Table 7-1 below. 
 
Table 7-1: Allocation of Intestines 
Classification 
Candidates registered at a 
transplant hospital that is at or 
within this distance from the 
donor hospital 
Who are: 
1 
500NM  
Status 1 and a blood type identical to the 
donor 
2 
500NM  
Status 1 and a blood type compatible 
with the donor 
3 
Nation 
Status 1 and a blood type identical to the 
donor 
4 
Nation 
Status 1 and a blood type compatible 
with the donor 
5 
500NM  
Status 2 and a blood type identical to the 
donor 
6 
500NM  
Status 2 and a blood type compatible 
with the donor 
7 
Nation 
Status 2 and a blood type identical to the 
donor 
8 
Nation 
Status 2 and a blood type compatible 
with the donor 
 
 
 

 
 
 
Policy 8: Allocation of Kidneys  
8.1 
Exceptions 
147 
8.2 
Kidney Allocation Score 
147 
8.3 
Waiting Time 
150 
8.4 
Kidney Allocation Classifications and Rankings 
150 
8.5 
Allocation of Both Kidneys from a Single Deceased Donor to a Single Candidate 
175 
8.6 
Administrative Rules 
175 
8.7 
Allocation of Released Kidneys 
177

---
