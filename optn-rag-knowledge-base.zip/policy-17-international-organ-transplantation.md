# OPTN Policy 17: International Organ Transplantation

**Source:** OPTN Policies | **Effective:** 12/10/2025 | **Category:** International
**Confidence:** HIGH — Official OPTN policy language

---

## 17.1.A — Referrals

<!-- Policy: 17 | Section: 17.1.A | Category: International -->

[17.1 Registration and Transplants of Non-US Citizens/Non-US]
Residents

Members may not enter into contracts with foreign agencies or governments for the transplant 
of non-US residents/non-US citizens. Members may negotiate the terms and conditions under 
which any individual candidate would be treated with the understanding that each candidate 
must be referred on a case-by-case and physician-to-physician basis.

---

## 17.1.B — Review of Non-US Citizens/Non-US Resident Registrations and Transplants

<!-- Policy: 17 | Section: 17.1.B | Category: International -->

The Ad Hoc International Relations Committee will review all citizenship data reported to the 
OPTN. The Ad Hoc International Relations Committee may request that transplant hospitals 
voluntarily provide additional information about registrations or transplants of non-US 
citizens/non-US residents.

---

## 17.1.C — Report of Activities Related to The Transplantation of Non-US Citizens/Non-

<!-- Policy: 17 | Section: 17.1.C | Category: International -->

US Residents 
The Ad Hoc International Relations Committee will prepare and provide public access to an 
annual report of transplant hospital activities related to the registration and transplantation of 
non-US citizens/non-US residents.

---

## 17.2 — Importation of Deceased Donor Organs from Foreign Sources

<!-- Policy: 17 | Section: 17.2 | Category: International -->

Members may import deceased donor organs from foreign sources according to the 
requirements in the Policies outlined below.

---

## 17.2.A — Formal Deceased Donor Import Agreement

<!-- Policy: 17 | Section: 17.2.A | Category: International -->

A member that wishes to enter into a formal, deceased donor organ import agreement with a 
foreign entity must  
 
1. Submit a proposal to the Ad Hoc International Relations Committee for review 
2. Have approval of the agreement by the OPTN Board of Directors 
 
Each formal agreement cannot exceed two years in duration and must include all of the 
following: 
 
1. The basis for the agreement. 
2. The expected benefits to the foreign and domestic participants. 

OPTN Policies                                                                                                                          Policy 17: International Organ Transplantation 
 
 
3. Credentials of the foreign entity. 
4. The number and type of deceased donor organs anticipated for import. 
5. An outline of a plan for reporting the results of the agreement. 
6. A requirement for the donor organization to submit documentation certifying the 
authorization of the deceased donor or the deceased donor’s agent. 
7. A requirement for the donor organization to submit documentation certifying that the 
deceased donor has met the brain death or donation after circulatory death (DCD) protocols 
that are in compliance with recognized US standards for domestic organ procurement. 
8. A requirement for the donor organization to submit documentation of the deceased donor’s 
ABO. 
 
The Ad Hoc International Relations Committee will review each formal agreement every two 
years.

---

## 17.2.B — Requirements for Importing Deceased Donor Organs through a Formal

<!-- Policy: 17 | Section: 17.2.B | Category: International | Cross-ref: Policy 15, Policy 2, Policy 3, Policy 5 -->

Agreement 
The member importing any deceased donor organ from a foreign entity must fulfill all the 
following requirements: 
 
1. Report the event within 72 hours to the Organ Center. 
2. Allocate the organ according to the organ allocation policies. 
3. Provide the minimum required information about the foreign deceased donor organ, as 
specified in OPTN Policy 2: Deceased Donor Organ Procurement and Policy 5: Organ Offers, 
Acceptance, and Verification. 
4. Comply with the blood type verification requirements in OPTN Policy 2.6: Deceased Donor 
Blood Type Determination and Reporting and OPTN Policy 3.3: Candidate Blood Type 
Determination and Reporting before Waiting List Registration. 
5. Evaluate the organ for transmissible diseases as specified in OPTN Policy 15: Identification of 
Transmissible Diseases. 
6. Verify that the foreign entity is authorized as a transplant hospital or organ procurement 
program by an appropriate agency of its national government. 
7. Obtain official documentation from the exporting party that it is a medical center authorized 
to export organs for transplantation.

---

## 17.2.C — Deceased Donor Organs Imported from Outside of the United States

<!-- Policy: 17 | Section: 17.2.C | Category: International | Cross-ref: Policy 18 -->

without a Formal Agreement 
A member may import a deceased donor organ recovered outside of the United States without 
a formal agreement. An imported deceased donor organ must meet all the requirements in 
OPTN Policy 17.2.B: Requirements for Importing Deceased Donor Organ through a Formal 
Agreement. The member must notify the Organ Center immediately so that the OPTN 
Contractor can allocate the organ according to the match run for that organ. 
 
 

OPTN Policies                                                                                                                          Policy 17: International Organ Transplantation 
 
 
The member importing the organ must provide all of the following to the OPTN: 
 
1. Documentation certifying that the donor has met brain death or DCD protocols that are in 
compliance with recognized standards for domestic organ procurement. 
2. Documentation from the donor organization certifying the authorization of the donor or the 
donor’s agent. 
3. Documentation from the donor organization verifying the donor’s ABO. 
 
The Ad Hoc International Relations Committee will review the circumstances of each deceased 
donor organ imported without a formal agreement. 

OPTN Policies                                                                                                                                    Policy 18: Data Submission Requirement 
 
 
Policy 18: Data Submission Requirements 
18.1 Data Submission Requirements 
326 
18.2 Timely Collection of Data 
332 
18.3 Recording and Reporting the Outcomes of Organ Offers 
332 
18.4 Living Donor Data Submission Requirements 
332 
18.5 Reporting of Patient Safety Events 
335

---
