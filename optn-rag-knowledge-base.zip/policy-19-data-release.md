# OPTN Policy 19: Data Release

**Source:** OPTN Policies | **Effective:** 12/10/2025 | **Category:** Data Release
**Confidence:** HIGH — Official OPTN policy language

---

## 19.0 — Data Release

<!-- Policy: 19 | Section: 19.0 | Category: Data Release -->

The OPTN will release OPTN data according to the Final Rule and other applicable federal and state laws 
and regulations. The OPTN will release all OPTN data requested by the Secretary of the Department of 
Health and Human Services (HHS).

---
