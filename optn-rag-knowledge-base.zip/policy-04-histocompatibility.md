# OPTN Policy 4: Histocompatibility

**Source:** OPTN Policies | **Effective:** 12/10/2025 | **Category:** Histocompatibility
**Confidence:** HIGH — Official OPTN policy language

---

## 4.1 — Requirements for Laboratory Review of Reports

<!-- Policy: 4 | Section: 4.1 | Category: Histocompatibility -->

Reports must be reviewed by the laboratory director, technical supervisor, or a staff member who meets 
at least the minimum requirements of a general supervisor prior to release. All deceased donor HLA 
typing and crossmatch reports must be reviewed during the next day of regular laboratory operation.

---

## 4.2 — Requirements for Waiting List Data Verification

<!-- Policy: 4 | Section: 4.2 | Category: Histocompatibility -->

All histocompatibility laboratories must review and verify the waiting list histocompatibility data for 
every patient whose test results the laboratory completed. Documentation of the review must be kept 
for at least three years or the period required by local, state and federal regulations, whichever is 
longer. This document must be available to the OPTN on request.

---

## 4.3 — Requirements for Performing and Reporting HLA Typing

<!-- Policy: 4 | Section: 4.3 | Category: Histocompatibility -->

Laboratories must ensure that all HLA typing is accurately determined and report HLA typing results to 
the OPO or Transplant Program according to the deadlines specified in the written agreement between 
the laboratory and the OPO or transplant program. Laboratories must report HLA typing results to the 
OPTN Contractor. HLA typing results that are entered manually must be verified by reporting each result 
twice.

---

## 4.3.A — Deceased Donor HLA Typing

<!-- Policy: 4 | Section: 4.3.A | Category: Histocompatibility -->

If the laboratory performs HLA typing on a deceased donor, the laboratory must perform 
molecular typing and report results at the level of serological splits to the OPO for all required 
HLA types on deceased donors according to Table 4-1: Deceased Donor HLA Typing 
Requirements. 
 
 

 
 
 
Table 4-1 below provides the requirements of HLA typing of HLA A, B, Bw4, Bw6, C, DR, 
DR51, DR52, DR53, DQA1, DQB1, DPA1, and DPB1 antigens. 
 
Table 4-1: Deceased Donor HLA Typing Requirements 
If a Laboratory Performs HLA Typing on a: 
Then the Laboratory Must Report Results 
to the OPO at the Following Times:  
Deceased Kidney, Kidney-Pancreas, Pancreas, or 
Pancreas Islet Donor 
Prior to organ offers 
Deceased Heart, Heart-Lung, or Lung Donors 
Prior to final acceptance, if required by the 
transplant program 
Deceased Liver Donors 
Within the period specified by the 
transplant program

---

## 4.3.B — HLA Typing for Candidates

<!-- Policy: 4 | Section: 4.3.B | Category: Histocompatibility -->

Laboratories must perform HLA typing on a kidney, kidney-pancreas, pancreas, or pancreas 
islet candidate and report results for HLA A, B, Bw4, Bw6, and DR to the transplant program 
prior to registration on the waiting list.

---

## 4.4 — Critical HLA Discrepancies in Candidate, Donor, and Recipient

<!-- Policy: 4 | Section: 4.4 | Category: Histocompatibility -->

HLA Typing Results  
A human leukocyte antigen (HLA) critical discrepancy is a difference among non-equivalent 
values at one or more loci in a candidate’s, donor’s, or recipient’s HLA typing. 
• 
For typing recorded from a low-resolution method by serologic nomenclature, values 
within the same serologic split antigen group or within the same P group according to 
IPD-IMGT/HLA are considered equivalent. 
• 
For typing reported at the two-field resolution, values within the same P group 
according to IPD-IMGT/HLA are considered equivalent.

---

## 4.4.A — Requirement to Notify Transplant Programs and OPOs

<!-- Policy: 4 | Section: 4.4.A | Category: Histocompatibility -->

4.4.A.i Donor HLA Critical Discrepancies 
If a laboratory becomes aware of a critical discrepancy in a deceased donor’s 
HLA typing, the laboratory must notify the host OPO of the discrepancy. 
Notification and supporting documentation must be provided as soon as 
possible, but no later than one hour following determination of the correct HLA 
typing. 
Upon independent discovery or receipt of documentation of the discrepancy, the OPO must 
do the following: 
• 
If the discrepancy is discovered prior to procurement, the OPO must notify and provide 
supporting documentation to all accepting transplant programs as soon as possible, but 

 
 
 
no later than 12 hours following discovery of the discrepancy or prior to procurement, 
whichever occurs first. 
• 
If the discrepancy is discovered post-procurement, the OPO must notify and 
provide supporting documentation to all accepting transplant programs 
within 24 hours following the discovery. 
4.4.A.ii Candidate and Recipient HLA Critical Discrepancies 
If a laboratory discovers a critical HLA discrepancy in a candidate’s or recipient’s 
HLA typing, the laboratory must notify the listing transplant program and 
provide documentation of the discrepancy as soon as possible, but within 5 days 
following determination of the correct HLA typing.

---

## 4.4.B — Requirement to Resolve and Report to the OPTN Critical Discrepant

<!-- Policy: 4 | Section: 4.4.B | Category: Histocompatibility -->

Donor and Recipient HLA Typing Results 
The laboratory director of each laboratory involved in a candidate, donor, or recipient 
critical HLA typing discrepancy, or their designee, must identify the correct HLA typing. The 
laboratory director of the laboratory who discovers the critical HLA typing discrepancy, or 
their designee, must report the critical HLA typing discrepancy to the OPTN via the OPTN 
Improving Patient Safety Portal within 72 hours of discovery of the discrepancy. Each 
laboratory director involved in the critical HLA typing discrepancy, or their designee, must 
report the reason for the discrepancy to the OPTN within 60 days of the initial report. 
 
4.5 Antibody Screening and Reporting  
The laboratory must screen a patient for the presence of anti-HLA antibodies if requested by a 
physician or other authorized individuals. 
 
When a laboratory performs an antibody screening, the laboratory must do all of the following: 
1. Report anti-HLA antibodies identified to the candidate’s requesting provider 
2. Use at least one solid phase immunoassay using purified HLA molecules

---

## 4.6 — Calculated Panel Reactive Antibody (CPRA) Calculation

<!-- Policy: 4 | Section: 4.6 | Category: Histocompatibility -->

CPRA for a candidate will be calculated automatically when a transplant hospital reports 
unacceptable antigens to the OPTN. 
 
 

 
 
 
The equation for CPRA calculation is 
 
CPRA = ∑i [GF × Di] 
  
Table 4-2: CPRA Calculation Values  
Where…  
Is defined as…  
i  
The racial or ethnic base population, as reported to the 
OPTN for deceased donors  
GF  
The frequency of HLA genotypes in each specific racial 
or ethnic population i equivalent to the unacceptable 
HLA antigens, alleles, and epitopes reported on the 
waiting list  
Di  
The proportion of donors in each specific racial or 
ethnic population i in the OPTN deceased donor 
population  
  
The CPRA derived from this calculation will be rounded to the sixth decimal place. The maximum 
CPRA is 100%.   
The determination of the HLA genotype frequencies GF used in the CPRA calculation includes all 
donor alleles equivalent to a candidate's reported unacceptable antigens, alleles, or epitopes 
according to OPTN Policy 4.10: Reference Tables of HLA Antigen Values and Split Equivalences. The 
antigens in Table 4-3 will have combined frequencies for the purpose of CPRA calculation.   
  
Table 4-3: Unacceptable Antigens with Combined Frequencies for CPRA Calculation  
Locus  
Antigens with combined frequencies for CPRA 
calculation  
DQA1  
01:01, 01:04, 01:05  
DQA1  
01:02, 01:11  
DQA1  
03:02, 03:03  
DQA1  
05:01, 05:05, 05:09, 05:11  
DQA1  
05:03, 05:07  
  
The OPTN maintains a list of genotype frequencies (GF) for each reportable unacceptable antigen, 
allele, and epitope.

---

## 4.7.A — Crossmatching for Kidney Transplants

<!-- Policy: 4 | Section: 4.7.A | Category: Histocompatibility -->

Laboratories performing histocompatibility testing for kidney transplants or multi-organ 
transplants in which a kidney is to be transplanted must perform a final crossmatch and report 
the results to the Transplant Program before transplant.

---

## 4.7.B — General Crossmatching Requirements

<!-- Policy: 4 | Section: 4.7.B | Category: Histocompatibility -->

When a laboratory performs a physical crossmatch, the laboratory must do all of the following: 

 
 
 
 
1. Perform a crossmatch according to the terms specified in the written agreement between 
the laboratory and the OPO or transplant program if a physician or other authorized 
individual requests it. 
2. Perform crossmatches with potential donor T lymphocytes to identify class I anti-HLA 
antibodies. 
3. Perform crossmatches with potential donor B lymphocytes to identify class I and class II anti-
HLA antibodies using a method that distinguishes between reactions with T and B 
lymphocytes. 
4. Use a crossmatching technique with increased sensitivity.

---

## 4.8 — Blood Type Determination

<!-- Policy: 4 | Section: 4.8 | Category: Histocompatibility -->

If a laboratory performs blood type testing, the laboratory must: 
 
1. Follow manufacturer’s directions for materials and equipment used in testing. 
2. Perform testing in compliance with federal regulations.

---

## 4.9 — Preservation of Excess Specimens

<!-- Policy: 4 | Section: 4.9 | Category: Histocompatibility -->

If a laboratory performs testing to determine histocompatibility between a donor and recipient, then 
the laboratory must preserve enough specimen from the deceased donor to perform subsequent testing 
for at least five years after the transplant.

---

## 4.10 — HLA Value Updates

<!-- Policy: 4 | Section: 4.10 | Category: Histocompatibility | Cross-ref: Policy 5 -->

The Histocompatibility Committee must review the HLA matching and unacceptable antigen equivalency 
tables and the proportions of donors (Di) used in CPRA calculation on an annual basis. Changes to the 
equivalency tables in Policy 4.11 and proportions of donors (Di) are eligible for future expedited updates 
pursuant to OPTN Management and Membership Policy 5.8: Expedited Actions.

---

## 4.11 — Reference Tables of HLA Antigen Values and Split Equivalences (Part 1)

<!-- Policy: 4 | Section: 4.11 | Category: Histocompatibility -->

4.11.A: HLA Matching Equivalences 
Tables 4-2, 4-3, and 4-4 show candidate-donor antigen equivalencies. All of the candidate and 
donor antigens that are considered equivalent to each other for the purposes of HLA matching 
are listed within each row. All other combinations are considered mismatches for the purposes 
of HLA matching. 

Table 4-2: HLA A Matching Antigen Equivalences 
Candidate and Donor A-Locus Antigens Equivalent to Each Other 
1, 01:01P, 01:01, 01:02P, 01:02, 01:03P 
2, 02:01P, 02:01, 02:02P, 02:02, 02:03P, 02:03, 02:04P, 02:05P, 
02:05, 02:06P, 02:06, 02:07P, 02:07, 02:10P, 02:10, 02:11P, 

Candidate and Donor A-Locus Antigens Equivalent to Each Other 
02:14P, 02:16P, 02:18, 02:20P, 02:22P, 02:29P, 02:49P, 02:65P, 
02:81P 
3, 03:01P, 03:01, 03:02P, 03:02, 03:04P, 32:04 
9 
10 
11, 11:01P, 11:01, 11:02P, 11:02, 11:03P, 11:05P 
19 
23, 23:01P 
24, 24:02P, 24:02, 24:03P, 24:03, 24:05P, 24:07P, 24:10P, 24:26P 
25, 25:01P 
26, 26:01P, 26:01, 26:02, 26:03P, 26:03 
28 
29, 29:01P, 29:01, 29:02P, 29:02 
30, 30:01P, 30:01, 30:02P, 30:02, 30:04P 
31, 31:01P 
32, 32:01P 
33, 33:01P, 33:01, 33:03P, 33:03 
34, 34:01P, 34:01, 34:02 
36, 36:01P 
43 
66, 66:01P, 66:01, 66:02P, 66:02 
68, 68:01P, 68:01, 68:02P, 68:02, 68:03P 
69 
74, 74:01P, 74:06P 
80, 80:01P 

Table 4-3: HLA B Matching Antigen Equivalences 
Candidate and Donor B-Locus Antigens Equivalent to Each 
Other 
5 
7, 07:02P, 07:02, 07:03, 07:05P, 07:14 
8, 08:01P, 08:01, 08:02, 08:03, 08:04 
12 
13, 13:01P, 13:01, 13:02P, 13:02 
14 
15 
16 
17 
18, 18:01P 

Candidate and Donor B-Locus Antigens Equivalent to Each 
Other 
21 
22 
27, 27:02P, 27:03, 27:04P, 27:04, 27:05P, 27:05, 27:06P, 27:06, 
27:07P 
27:08 
35, 35:01P, 35:01, 35:02P, 35:02, 35:03P, 35:03, 35:05P, 35:08P, 
35:14P, 35:08, 35:12P, 35:12, 35:43P, 35:137P  
37, 37:01P 
38, 38:01P, 38:01, 38:02P, 38:02 
39, 39:01P, 39:01, 39:02P, 39:02, 39:03P, 39:04, 39:05P, 39:05, 
39:06P, 39:06, 39:09P, 39:10P, 39:13, 39:15P 
40, 40:40P, 40:213P 
41, 41:01P, 41:01, 41:02P, 41:02 
42, 42:01P, 42:01, 42:02 
44, 44:02P, 44:02, 44:03P, 44:03, 44:05P, 44:29P, 44:53P, 
51:42P 
45, 45:01P, 50:02P, 50:02 
46, 46:01P 
47, 47:01P 
48, 48:01P, 48:01, 48:02, 48:04P 
49, 49:01P 
50, 50:01P, 50:01, 40:05 
51, 51:01P, 51:01, 51:02, 51:08P, 51:09P, 51:143P 
52, 52:01P 
53, 53:01P 
54, 54:01P 
55, 55:01P, 55:01, 55:02P, 55:02, 55:04 
56, 56:01P, 56:01, 56:03 
57, 57:01P, 57:01, 57:03P, 57:03 
58, 58:01P, 58:02P 
59, 59:01P 
60, 40:01P, 40:01 
61, 40:02P, 40:02, 40:03P, 40:03, 40:04, 40:06P, 40:06 
62, 15:01P, 15:01, 15:04, 15:06, 15:07P, 15:07, 15:20P, 15:20, 
15:25P, 15:27, 15:28P, 15:30P, 15:32P, 15:35P, 15:39P 
63, 15:16P, 15:16, 15:17P, 15:17 
64, 14:01P, 14:01 
65, 14:02P, 14:02 
67, 67:01P 
70, 15:123P 
71, 15:10P, 15:10, 15:18P, 15:18 
72, 15:03P, 15:03 
73, 73:01P 
75, 15:02P, 15:02, 15:11P, 15:11, 15:21P, 15:21 

Candidate and Donor B-Locus Antigens Equivalent to Each 
Other 
76, 15:12P, 15:12, 15:14P 
77, 15:13, 15:24 
78 
81, 81:01P 
82 
83:01 

Table 4-4: HLA DR Matching Antigen Equivalences 
Candidate and Donor DR-Locus Antigens Equivalent to Each 
Other 
1, 01:01P, 01:01, 01:02P, 01:02 
2 
3 
4, 04:01P, 04:01, 04:02P, 04:02, 04:03P, 04:03, 04:04P, 04:04, 
04:05P, 04:05, 04:06P, 04:06, 04:07P, 04:08P, 04:10P, 04:10, 
04:11 
5 
6 
7, 07:01P 
8, 08:01P, 08:01, 08:02P, 08:02, 08:03P, 08:03, 08:04P, 08:07 
9, 09:01P, 09:01, 09:02 
10, 10:01P 
11, 11:01P, 11:01, 11:02P, 11:03P, 11:03, 11:04P, 11:04, 11:06P, 
11:11P 
12, 12:01P, 12:01, 12:02P, 12:02 
13, 13:01P, 13:01, 13:02P, 13:02, 13:03P, 13:03, 13:05, 13:12P 
14, 14:01P, 14:01, 14:02P, 14:02, 14:03P, 14:03, 14:04P, 14:04, 
14:05, 14:06, 14:08P, 14:24P, 14:54 
15, 15:01P, 15:01, 15:02P, 15:02, 15:03P, 15:03, 15:04P, 15:07P 
16, 16:01P, 16:01, 16:02P, 16:02 
17, 03:01P, 03:01 
18, 03:02P, 03:02, 03:03 
103, 01:03P, 01:03 

4.11.B: HLA Unacceptable Antigen Equivalences 
At the time of the match run, if an antigen or epitope is entered as unacceptable for a 
candidate, then the candidate will not appear on the match run for donors reported with any of 
the equivalent antigens described in 4-5, 4-6, 4-7, 4-8, 4-9, 4-10, 4-11, 4-12, 4-13, 4-14, 4-15, 
and 4-16 below. 

CPRA calculations include all donor alleles equivalent to a candidate’s reported unacceptable 
antigens, alleles, and epitopes. 

Table 4-5: HLA A Unacceptable Antigen Equivalences 
If this A-Locus Unacceptable 
Antigen is reported: 
The following HLA values are considered equivalent to the 
reported unacceptable antigen: 
1  
1, 01:01P, 01:01, 01:02P, 01:02, 01:03P  
01:01  
01:01  
01:02  
01:02  
2  
2, 02:01P, 02:01, 02:02P, 02:02, 02:03P, 02:03, 02:04P, 02:05P, 
02:05, 02:06P, 02:06, 02:07P, 02:07, 02:10P, 02:10, 02:11P, 
02:14P, 02:16P, 02:18, 02:20P, 02:22P, 02:29P, 02:49P, 02:65P, 
02:81P  
02:01  
02:01  
02:02  
02:02  
02:03  
02:03  
02:05  
02:05  
02:06  
02:06  
02:07  
02:07  
02:10  
02:10  
02:18  
02:18  
3  
3, 03:01P, 03:01, 03:02P, 03:02, 03:04P, 32:04  
03:01  
03:01  
03:02  
03:02  
9  
9, 23, 23:01P, 24, 24:02P, 24:02, 24:03P, 24:03, 24:05P, 24:07P, 
24:10P, 24:26P  
10  
10, 25, 25:01P, 26, 26:01P, 26:01, 26:02, 26:03P, 26:03, 34, 
34:01P, 34:01, 34:02, 66, 66:01P, 66:01, 66:02P, 66:02, 43  
11  
11, 11:01P, 11:01, 11:02P, 11:02, 11:03P, 11:05P  
11:01  
11:01  
11:02  
11:02  
19  
19, 29, 29:01P, 29:01, 29:02P, 29:02, 30, 30:01P, 30:01, 30:02P, 
30:02, 30:04P, 31, 31:01P, 32, 32:01P, 33, 33:01P, 33:01, 33:03P, 
33:03, 74, 74:01P, 74:06P  
23  
23, 23:01P  
24  
24, 24:02P, 24:02, 24:03P, 24:03, 24:05P, 24:07P, 24:10P, 24:26P  
24:02  
24:02  
24:03  
24:03  
25  
25, 25:01P  
26  
26, 26:01P, 26:01, 26:02, 26:03P, 26:03  
26:01  
26:01  
26:02  
26:02

---

## 4.11 — Reference Tables of HLA Antigen Values and Split Equivalences (Part 2)

<!-- Policy: 4 | Section: 4.11 | Category: Histocompatibility -->

If this A-Locus Unacceptable 
Antigen is reported: 
The following HLA values are considered equivalent to the 
reported unacceptable antigen: 
26:03  
26:03  
28  
28, 68, 69, 68:01P, 68:01, 68:02P, 68:02, 68:03P  
29  
29, 29:01P, 29:01, 29:02P, 29:02  
29:01  
29:01  
29:02  
29:02  
30  
30, 30:01P, 30:01, 30:02P, 30:02, 30:04P  
30:01  
30:01  
30:02  
30:02  
31  
31, 31:01P  
32  
32, 32:01P  
32:04  
32:04  
33  
33, 33:01P, 33:01, 33:03P, 33:03  
33:01  
33:01  
33:03  
33:03  
34  
34, 34:01P, 34:01, 34:02  
34:01  
34:01  
34:02  
34:02  
36  
36, 36:01P  
43  
43  
66  
66, 66:01P, 66:01, 66:02P, 66:02  
66:01  
66:01  
66:02  
66:02  
68  
68, 68:01P, 68:01, 68:02P, 68:02, 68:03P  
68:01  
68:01  
68:02  
68:02  
69  
69  
74  
74, 74:01P, 74:06P  
80  
80, 80:01P  

Table 4-6 HLA B Unacceptable Antigen Equivalences 
If this B-Locus Unacceptable 
Antigen is reported: 
The following HLA values are considered equivalent to the 
reported unacceptable antigen: 
5 
5, 51, 51:01P, 51:01, 51:02, 51:08P, 51:09P, 51:143P, 52, 52:01P 
7 
7, 07:02P, 07:02, 07:03, 07:05P, 07:14 
07:02 
07:02 
07:03 
07:03 
07:14 
07:14 
8 
8, 08:01P, 08:01, 08:02, 08:03, 08:04 
08:01 
08:01 

If this B-Locus Unacceptable 
Antigen is reported: 
The following HLA values are considered equivalent to the 
reported unacceptable antigen: 
08:02 
08:02 
08:03 
08:03 
08:04 
08:04 
12 
12, 44, 44:02P, 44:02, 44:03P, 44:03, 44:05P, 44:29P, 44:53P, 
51:42P, 45, 50:02P, 50:02 
13 
13, 13:01P, 13:01, 13:02P, 13:02 
13:01 
13:01 
13:02 
13:02 
14  
14, 64, 65, 14:01P, 14:01, 14:02P, 14:02  
14:01  
14:01, 64  
14:02  
14:02, 65  
15  
15, 62, 63, 70, 71, 72, 75, 76, 77, 15:01P, 15:01, 15:02P, 15:02, 
15:03P, 15:03, 15:04, 15:06, 15:07P, 15:07, 15:10P, 15:10, 15:11P, 
15:11, 15:12P, 15:12, 15:13, 15:14P, 15:16P, 15:16, 15:17P, 15:17, 
15:18P, 15:18, 15:20P, 15:20, 15:21P, 15:21, 15:24, 15:25P, 15:27, 
15:28P, 15:30P, 15:32P, 15:35P, 15:39P, 15:123P  
15:01  
15:01  
15:02  
15:02  
15:03  
15:03  
15:04  
15:04  
15:06  
15:06  
15:07  
15:07  
15:10  
15:10  
15:11  
15:11  
15:12  
15:12  
15:13  
15:13  
15:16  
15:16  
15:17  
15:17  
15:18  
15:18  
15:20  
15:20  
15:21  
15:21  
15:24  
15:24  
15:27  
15:27  
16  
16, 38, 38:01P, 38:01, 38:02P, 38:02, 39, 39:01P, 39:01, 39:02P, 
39:02, 39:03P, 39:04, 39:05P, 39:05, 39:06P, 39:06, 39:09P, 
39:10P, 39:13, 39:15P  
17  
17, 57, 57:01P, 57:01, 57:03P, 57:03, 58, 58:01P, 58:02P  
18  
18, 18:01P  
21  
21, 49, 49:01P, 50, 40:05, 50:01P, 50:01  
22  
22, 54, 54:01P, 55, 55:01P, 55:01, 55:02P, 55:02, 55:04, 56, 
56:01P, 56:01, 56:03  
27  
27, 27:02P, 27:03, 27:04P, 27:04, 27:05P, 27:05, 27:06P, 27:06, 
27:07P  
27:03  
27:03  

If this B-Locus Unacceptable 
Antigen is reported: 
The following HLA values are considered equivalent to the 
reported unacceptable antigen: 
27:04  
27:04  
27:05  
27:05  
27:06  
27:06  
27:08  
27:08  
35  
35, 35:01P, 35:01, 35:02P, 35:02, 35:03P, 35:03, 35:05P, 35:08P, 
35:08, 35:12 35:14P, 35:43P, 35:137P  
35:01  
35:01  
35:02  
35:02  
35:03  
35:03  
35:08  
35:08  
35:12  
35:12  
37  
37, 37:01P  
38  
38, 38:01P, 38:01, 38:02P, 38:02  
38:01  
38:01  
38:02  
38:02  
39  
39, 39:01P, 39:01, 39:02P, 39:02, 39:03P, 39:04, 39:05P, 39:05, 
39:06P, 39:06, 39:09P, 39:10P, 39:13, 39:15P  
39:01  
39:01  
39:02  
39:02  
39:04  
39:04  
39:05  
39:05  
39:06  
39:06  
39:13  
39:13  
40  
40, 60, 61, 40:01P, 40:01, 40:02P, 40:02, 40:03P, 40:03, 40:04, 
40:06P, 40:06, 40:40P, 40:213P  
40:01  
40:01  
40:02  
40:02  
40:03  
40:03  
40:04  
40:04  
40:05  
40:05  
40:06  
40:06  
41  
41, 41:01P, 41:01, 41:02P, 41:02  
41:01  
41:01  
41:02  
41:02  
42  
42, 42:01P, 42:01, 42:02  
42:01  
42:01  
42:02  
42:02  
44  
44, 44:02P, 44:02, 44:03P, 44:03, 44:05P, 44:29P, 44:53P, 51:42P  
44:02  
44:02  
44:03  
44:03  
45  
45, 45:01P, 50:02P, 50:02  
46  
46, 46:01P  
47  
47, 47:01P  
48  
48, 48:01P, 48:01, 48:02, 48:04P  

If this B-Locus Unacceptable 
Antigen is reported: 
The following HLA values are considered equivalent to the 
reported unacceptable antigen: 
48:01  
48:01  
48:02  
48:02  
49  
49, 49:01P  
50  
50, 40:05, 50:01P, 50:01  
50:01  
50:01  
50:02  
50:02  
51  
51, 51:01P, 51:01, 51:02, 51:08P, 51:09P, 51:143P  
51:01  
51:01  
51:02  
51:02  
52  
52, 52:01P  
53  
53, 53:01P  
54  
54, 54:01P  
55  
55, 55:01P, 55:01, 55:02P, 55:02, 55:04  
55:01  
55:01  
55:02  
55:02  
55:04  
55:04  
56  
56, 56:01P, 56:01, 56:03  
56:01  
56:01  
56:03  
56:03  
57  
57, 57:01P, 57:01, 57:03P, 57:03  
57:01  
57:01  
57:03  
57:03  
58  
58, 58:01P, 58:02P  
59  
59, 59:01P  
60  
60, 40:01P, 40:01  
61  
61, 40:02P, 40:02, 40:03P, 40:03, 40:04, 40:06P, 40:06  
62  
62, 15:01P, 15:01, 15:04, 15:06, 15:07P, 15:07, 15:20P, 15:20, 
15:25P, 15:27, 15:28P, 15:30P, 15:32P, 15:35P, 15:39P  
63  
63, 15:16P, 15:16, 15:17P, 15:17  
64  
64, 14:01P, 14:01  
65  
65, 14:02P, 14:02  
67  
67, 67:01P  
70  
70, 71, 72, 15:03P, 15:03, 15:10P, 15:10, 15:18P, 15:18, 15:123P  
71  
71, 15:10P, 15:10, 15:18P, 15:18  
72  
72, 15:03P, 15:03  
73  
73, 73:01P  
75  
75, 15:02P, 15:02, 15:11P, 15:11, 15:21P, 15:21  
76  
76, 15:12P, 15:12, 15:14P  
77  
77, 15:13  
78  
78  
81  
81, 81:01P  
82  
82  
83:01  
83:01

---

## 4.11 — Reference Tables of HLA Antigen Values and Split Equivalences (Part 3)

<!-- Policy: 4 | Section: 4.11 | Category: Histocompatibility -->

If this B-Locus Unacceptable 
Antigen is reported: 
The following HLA values are considered equivalent to the 
reported unacceptable antigen: 
Bw4  
Bw4, 08:02, 08:03, 5, 13, 13:01P, 13:01, 13:02P, 13:02, 15:13, 
15:16P, 15:16, 15:17P, 15:17, 15:24, 17, 27, 27:02P, 27:03, 
27:04P, 27:04, 27:05P, 27:05, 27:06P, 27:06, 27:07P, 37, 37:01P, 
38, 38:01P, 38:01, 38:02P, 38:02, 44, 44:02P, 44:02, 44:03P, 
44:03, 44:05P, 44:29P, 44:53P, 47, 47:01P, 49, 49:01P, 51, 51:01P, 
51:01, 51:02, 51:08P, 51:09P, 51:42P, 51:143P, 52, 52:01P, 53, 
53:01P, 57, 57:01P, 57:01, 57:03P, 57:03, 58, 58:01P, 58:02P, 59, 
59:01P, 63, 77  
Bw6  
Bw6, 7, 07:02P, 07:02, 07:03, 07:05P, 07:14, 8, 08:01P, 08:01, 
08:04, 14, 14:01P, 14:01, 14:02P, 14:02, 15:01P, 15:01, 15:02P, 
15:02, 15:03P, 15:03, 15:04, 15:06, 15:07P, 15:07, 15:10P, 15:10, 
15:11P, 15:11, 15:12P, 15:12, 15:14P, 15:18P, 15:18, 15:20P, 
15:20, 15:21P, 15:21, 15:25P, 15:27, 15:28P, 15:30P, 15:32P, 
15:35P, 15:39P, 15:123P, 18, 18:01P, 22, 27:08, 35, 35:01P, 35:01, 
35:02P, 35:02, 35:03P, 35:03, 35:05P, 35:08P, 35:08, 35:12P, 
35:12, 35:14P, 35:43P, 35:137P, 39, 39:01P, 39:01, 39:02P, 39:02, 
39:03P, 39:04, 39:05P, 39:05, 39:06P, 39:06, 39:09P, 39:10P, 
39:13, 39:15P, 40, 40:01P, 40:01, 40:02P, 40:02, 40:03P, 40:03, 
40:04, 40:05, 40:06P, 40:06, 40:40P, 40:213P, 41, 41:01P, 41:01, 
41:02P, 41:02, 42, 42:01P, 42:01, 42:02, 45, 45:01P, 48, 48:01P, 
48:01 48:02, 48:04P, 50, 50:01P, 50:01, 50:02P, 50:02, 54, 54:01P, 
55, 55:01P, 55:01, 55:02P, 55:02, 55:04, 56, 56:01P, 56:01, 56:03, 
60, 61, 62, 64, 65, 67, 67:01P, 70, 71, 72, 75, 76, 78, 81, 81:01P, 82 

Table 4-7: HLA C Unacceptable Antigen Equivalences 
If this C-Locus Unacceptable 
Antigen is reported: 
The following HLA values are considered equivalent to the 
reported unacceptable antigen: 
01  
01, 01:02P, 01:02, 01:03P, 01:03, 01:63P  
01:02  
01:02  
01:03  
01:03  
02  
02, 02:02P, 02:02, 02:10, 02:14P, 02:16P, 02:134P, 02:159P, 
02:182P  
02:02  
02:02  
02:10  
02:10  
03  
03, 03:02P, 03:02, 03:03P, 03:03, 03:04P, 03:04, 03:05P, 03:05, 
03:06, 03:14P, 03:40P, 09, 10  
03:02  
03:02  
03:03  
03:03  
03:04  
03:04  
03:05  
03:05  
03:06  
03:06  
04  
04, 04:01P, 04:01, 04:03P, 04:03, 04:04, 04:06P, 04:07, 04:09L, 
04:10P, 04:59P, 04:355P, 04:360P  
04:01  
04:01  
04:03  
04:03  

If this C-Locus Unacceptable 
Antigen is reported: 
The following HLA values are considered equivalent to the 
reported unacceptable antigen: 
04:04  
04:04  
04:07  
04:07  
05  
05, 05:01P, 05:01  
05:01  
05:01  
06  
06, 06:02P, 06:02, 06:06P, 06:87P  
06:02  
06:02  
07  
07, 07:01P, 07:01, 07:02P, 07:02, 07:04P, 07:04, 07:06, 07:18, 
07:19P, 07:22P, 07:26P, 07:27P, 07:28P, 07:165P, 07:450P, 
07:919P  
07:01  
07:01  
07:02  
07:02  
07:04  
07:04  
07:06  
07:06  
07:18  
07:18  
08  
08, 08:01P, 08:01, 08:02P, 08:02, 08:03P, 08:03, 08:04  
08:01  
08:01  
08:02  
08:02  
08:03  
08:03  
08:04  
08:04  
09  
09, 03:03P, 03:03  
10  
10, 03:02P, 03:02, 03:04P, 03:04, 03:06  
12  
12, 12:02P, 12:02, 12:03P, 12:03, 12:04, 12:14P  
12:02  
12:02  
12:03  
12:03 
12:04 
12:04 
14 
14, 14:02P, 14:02, 14:03P, 14:03 
14:02 
14:02 
14:03 
14:03 
15 
15, 15:02P, 15:02, 15:04P, 15:04, 15:05P, 15:05, 15:06, 15:09, 
15:103P 
15:02 
15:02 
15:04 
15:04 
15:05 
15:05 
15:06 
15:06 
15:09 
15:09 
16 
16, 16:01P, 16:01, 16:02P, 16:02, 16:04, 16:15P 
16:01 
16:01 
16:02 
16:02 
16:04 
16:04 
17 
17, 17:01P, 17:01, 17:03 
17:01 
17:01 
17:03 
17:03 
18 
18, 18:01P, 18:01, 18:02 
18:01 
18:01 

If this C-Locus Unacceptable 
Antigen is reported: 
The following HLA values are considered equivalent to the 
reported unacceptable antigen: 
18:02 
18:02 

Table 4-8: HLA DR Unacceptable Antigen Equivalences 
If this DR-Locus Unacceptable 
Antigen is reported: 
The following HLA values are considered equivalent to the 
reported unacceptable antigen: 
1 
1, 01:01P, 01:01, 01:02P, 01:02 
01:01 
01:01 
01:02 
01:02 
01:03 
01:03, 103 
2 
2, 15, 15:01P, 15:01, 15:02P, 15:02, 15:03P, 15:03, 15:04P, 
15:07P, 16, 16:01P, 16:01, 16:02P, 16:02 
3 
3, 17, 18, 03:01P, 03:01, 03:02P, 03:02, 03:03 
03:01 
03:01 
03:02 
03:02 
03:03 
03:03 
4 
4, 04:01P, 04:01, 04:02P, 04:02, 04:03P, 04:03, 04:04P, 04:04, 
04:05P, 04:05, 04:06P, 04:06, 04:07P, 04:07, 04:08P, 04:10P, 
04:10, 04:11 
04:01 
04:01 
04:02 
04:02 
04:03 
04:03 
04:04 
04:04 
04:05 
04:05 
04:06 
04:06 
04:07 
04:07 
04:10 
04:10 
04:11 
04:11 
5 
5, 11, 11:01P, 11:01, 11:02P, 11:03P, 11:04P, 11:04, 11:06P, 
11:11P, 12, 12:01P, 12:01, 12:02P, 12:02 
6 
6, 13, 13:01P, 13:01,13:02P, 13:02, 13:03P, 13:03, 13:05, 
13:12P, 14, 14:01P, 14:01, 14:02P, 14:02, 14:03P, 14:03, 14:04P, 
14:04, 14:05, 14:06, 14:08P, 14:24P 
7 
7, 07:01P 
8 
8, 08:01P, 08:01, 08:02P, 08:02, 08:03P, 08:03, 08:04P, 08:07 
08:01 
08:01 
08:02 
08:02 
08:03 
08:03 
08:07 
08:07 
9 
9, 09:01P, 09:01, 09:02 
09:01 
09:01 
09:02 
09:02 
10 
10, 10:01P 
11 
11, 11:01P, 11:01, 11:02P, 11:03P, 11:03, 11:04P, 11:04, 11:06P, 
11:11P 

If this DR-Locus Unacceptable 
Antigen is reported: 
The following HLA values are considered equivalent to the 
reported unacceptable antigen: 
11:01 
11:01 
11:03 
11:03 
11:04 
11:04 
12 
12, 12:01P, 12:01, 12:02P, 12:02 
12:01 
12:01 
12:02 
12:02 
13 
13, 13:01P, 13:01, 13:02P, 13:02, 13:03P, 13:03, 13:05, 13:12P 
13:01 
13:01 
13:02 
13:02 
13:03 
13:03 
13:05 
13:05 
14 
14, 14:01P, 14:01, 14:02P, 14:02, 14:03P, 14:03, 14:04P, 14:04, 
14:05, 14:06, 14:08P, 14:24P, 14:54 
14:01 
14:01 
14:02 
14:02 
14:03 
14:03 
14:04 
14:04 
14:05 
14:05 
14:06 
14:06 
14:54 
14:54 
15 
15, 15:01P, 15:01, 15:02P, 15:02, 15:03P, 15:03, 15:04P, 15:07P 
15:01 
15:01 
15:02 
15:02 
15:03 
15:03 
16 
16, 16:01P, 16:01, 16:02P, 16:02 
16:01 
16:01 
16:02 
16:02 
17 
17, 03:01P, 03:01 
18 
18, 03:02P, 03:02, 03:03 
103 
103, 01:03P, 01:03

---

## 4.11 — Reference Tables of HLA Antigen Values and Split Equivalences (Part 4)

<!-- Policy: 4 | Section: 4.11 | Category: Histocompatibility -->

Table 4-9: HLA DR51 Unacceptable Antigen Equivalences 
If this DR51-Locus Unacceptable 
Antigen is reported: 
The following HLA values are considered equivalent to the 
reported unacceptable antigen: 
5*01  
5*01, 5*01:01P, 5*01:01, 5*01:02P, 5*01:02  
5*01:01  
5*01:01  
5*01:02  
5*01:02  
5*02  
5*02, 5*02:02P, 5*02:02  
5*02:02  
5*02:02  
51  
51, 5*01:01P, 5*01:01, 5*01:02P, 5*01:02, 5*02:02P, 5*02:02, 
5*01, 5*02  

Table 4-10: HLA DR52 Unacceptable Antigen Equivalences 
If this DR52-Locus Unacceptable 
Antigen is reported: 
The following HLA values are considered equivalent to the 
reported unacceptable antigens: 
3*01  
3*01, 3*01:01P, 3*01:01  
3*01:01  
3*01:01  
3*02  
3*02, 3*02:01P, 3*02:01, 3*02:02P, 3*02:02, 3*02:100P  
3*02:01  
3*02:01  
3*02:02  
3*02:02  
3*03  
3*03, 3*03:01P, 3*03:01, 3*03:22P  
3*03:01  
3*03:01  
52  
52, 3*01:01P, 3*01:01, 3*02:01P, 3*02:01, 3*02:02P, 3*02:02, 
3*02:100P, 3*03:01P, 3*03:01, 3*03:22P, 3*01, 3*02, 3*03  

Table 4-11: HLA DR53 Unacceptable Antigen Equivalences 
If this DR-53 Locus Unacceptable 
Antigen is reported: 
The following HLA values are considered equivalent to the 
reported unacceptable antigen: 
4*01  
4*01, 4*01:01P, 4*01:01, 4*01:03, 4*01:75P, 4*01:78P  
4*01:01  
4*01:01  
4*01:03  
4*01:03  
53  
53, 4*01:01P, 4*01:01, 4*01:03, 4*01:75P, 4*01:78P, 4*01  

Table 4-12: HLA DQA1 Unacceptable Antigen Equivalences 
If this DQA1-Locus Unacceptable 
Antigen is reported: 
The following HLA values are considered equivalent to the 
reported unacceptable antigen: 
01 
01, 01:01P, 01:01, 01:02P, 01:02, 01:03P, 01:03, 01:04, 01:05, 
01:06, 01:07P, 01:07, 01:08, 01:09, 01:10, 01:11, 01:12 
01:01 
01:01 
01:02 
01:02 
01:03 
01:03 
01:04 
01:04 
01:05 
01:05 
01:06 
01:06 
01:07 
01:07 
01:08 
01:08 
01:09 
01:09 
01:10 
01:10 
01:11 
01:11 
01:12 
01:12 

If this DQA1-Locus Unacceptable 
Antigen is reported: 
The following HLA values are considered equivalent to the 
reported unacceptable antigen: 
02 
02, 02:01P, 02:01 
02:01 
02:01 
03 
03, 03:01P, 03:01, 03:02, 03:03 
03:01 
03:01 
03:02 
03:02 
03:03 
03:03 
04 
04, 04:01P, 04:01, 04:02, 04:04 
04:01 
04:01 
04:02 
04:02 
04:04 
04:04 
05 
05, 05:01P, 05:01, 05:02, 05:03, 05:04, 05:05, 05:06, 05:07, 05:08, 
05:09, 05:10, 05:11, 05:23P 
05:01 
05:01 
05:02 
05:02 
05:03 
05:03 
05:04 
05:04 
05:05 
05:05 
05:06 
05:06 
05:07 
05:07 
05:08 
05:08 
05:09 
05:09 
05:10 
05:10 
05:11 
05:11 
06 
06, 06:01P, 06:01, 06:02 
06:01 
06:01 
06:02 
06:02 

Table 4-13: HLA DQB1 Unacceptable Antigen Equivalences 
If this DQB1-Locus Unacceptable 
Antigen is reported: 
The following HLA values are considered equivalent to the 
reported unacceptable antigen: 
2 
2, 02:01P, 02:01, 02:02, 02:03P, 02:57P, 02:135P 
02:01 
02:01 
02:02 
02:02 
3 
3, 7, 8, 9, 03:01P, 03:01, 03:02P, 03:02, 03:03P, 03:03, 03:04P, 
03:05P, 03:10P, 03:19, 03:71P, 03:113P 
03:01 
03:01 

If this DQB1-Locus Unacceptable 
Antigen is reported: 
The following HLA values are considered equivalent to the 
reported unacceptable antigen: 
03:02 
03:02 
03:03 
03:03 
03:19 
03:19 
4 
4, 04:01P, 04:01, 04:02P, 04:02 
04:01 
04:01 
04:02 
04:02 
5 
5, 05:01P, 05:01, 05:02P, 05:02, 05:03P, 05:03, 05:04P 
05:01 
05:01 
05:02 
05:02 
05:03 
05:03 
6 
6, 06:01P, 06:01, 06:02P, 06:02, 06:03P, 06:03, 06:04P, 06:04, 
06:08P, 06:09P, 06:09, 06:46P, 06:92P 
06:01 
06:01 
06:02 
06:02 
 06:03 
06:03 
 06:04 
06:04 
 06:09 
06:09 
7 
7, 03:01P, 03:01, 03:04P, 03:19 
8 
8, 03:02P, 03:02, 03:05P, 03:10P 
9 
9, 03:03P, 03:03 

Table 4-14: HLA DPA1 Unacceptable Antigen Equivalences 
If this DPA1-Locus 
Unacceptable Antigen is 
reported: 
The following HLA values are considered equivalent to the reported 
unacceptable antigen:  
01 
01, 01:03P, 01:03, 01:04, 01:05P, 01:05, 01:06, 01:07, 01:08, 01:09, 
01:10, 01:11, 01:12 
01:03 
01:03 
01:04 
01:04 
01:05 
01:05 
01:06 
01:06 
01:07 
01:07 
01:08 
01:08 
01:09 
01:09 
01:10 
01:10 
01:11 
01:11 
01:12 
01:12 
02 
02, 02:01P, 02:01,02:02P, 02:02, 02:03, 02:04, 02:07, 02:21P, 02:54P 
02:01 
02:01 
02:02 
02:02 
02:03 
02:03 

If this DPA1-Locus 
Unacceptable Antigen is 
reported: 
The following HLA values are considered equivalent to the reported 
unacceptable antigen:  
02:04 
02:04 
02:07 
02:07 
03 
03, 03:01P, 03:01, 03:02, 03:03, 03:07P 
03:01 
03:01 
03:02 
03:02 
03:03 
03:03 
04 
04, 04:01P, 04:01 
04:01 
04:01 

Table 4-15: HLA DPB1 Unacceptable Antigen Equivalences 
In addition to the alleles and p-groups displayed in this table, all non-null HLA-DPB1 alleles as of 
IPD-IMGT/HLA version 3.52.0 are available for reporting candidate, donor, or recipient HLA 
typing. 
If this DPB1-Locus Unacceptable 
Antigen is reported: 
All of the following HLA values are considered equivalent to the 
unacceptable antigen reported and to all the values within the 
row: 
01:01 

01:01P, 01:01, 162:01, 417:01, 462:01, 616:01, 733:01, 807:01, 
810:01, 853:01, 931:01, 953:01, 979:01, 998:01, 999:01, 
1024:01, 1038:01, 1050:01, 1068:01, 1076:01, 1151:01, 1162:01, 
1183:01, 1287:01, 1314:01, 1361:01, 1392:01, 1406:01, 1443:01 

If this DPB1-Locus Unacceptable 
Antigen is reported: 
All of the following HLA values are considered equivalent to the 
unacceptable antigen reported and to all the values within the 
row: 
02:01 

02:01P, 02:01, 141:01, 352:01, 414:01, 416:01, 461:01, 617:01, 
640:01, 678:01, 723:01, 783:01, 799:01, 819:01, 845:01, 857:01, 
861:01, 955:01, 967:01, 975:01, 1036:01, 1051:01, 1055:01, 
1077:01, 1082:01, 1094:01, 1102:01, 1115:01, 1160:01, 1175:01, 
1198:01, 1227:01, 1243:01, 1248:01, 1266:01, 1290:01, 1298:01, 
1307:01, 1312:01, 1315:01, 1320:01, 1323:01, 1326:01, 1344:01, 
1352:01, 1360:01, 1363:01, 1369:01, 1372:01, 1405:01, 1417:01, 
1419:01, 1456:01 
02:02 

02:02P, 02:02, 547:01,721:01, 766:01, 1188:01, 1376:01, 
1437:01 
03:01

---

## 4.11 — Reference Tables of HLA Antigen Values and Split Equivalences (Part 5)

<!-- Policy: 4 | Section: 4.11 | Category: Histocompatibility -->

03:01P, 03:01, 104:01, 124:01, 351:01, 669:01, 675:01, 676:01, 
704:01, 706:01, 728:01, 829:01, 855:01, 938:01, 946:01, 948:01, 
952:01, 1000:01, 1014:01, 1021:01, 1049:01, 1114:01, 1134:01, 
1157:01, 1245:01, 1246:01, 1254:01, 1263:01, 1295:01, 1382:01, 
1388:01, 1401:01, 1407:01, 1429:01 

If this DPB1-Locus Unacceptable 
Antigen is reported: 
All of the following HLA values are considered equivalent to the 
unacceptable antigen reported and to all the values within the 
row: 
04:01 
04:01P, 04:01, 126:01, 350:01, 415:01, 459:01, 464:01, 534:01, 
615:01, 618:01, 670:01, 677:01, 699:01, 702:01, 755:01, 757:01, 
765:01, 767:01, 784:01, 804:01, 806:01, 813:01, 820:01, 824:01, 
826:01, 849:01, 850:01, 859:01, 880:01, 882:01, 926:01, 932:01, 
939:01, 978:01, 988:01, 989:01, 992:01, 997:01, 1001:01, 
1002:01, 1003:01, 1004:01, 1010:01, 1011:01, 1023:01, 1033:01, 
1074:01, 1086:01, 1091:01, 1100:01, 1129:01, 1132:01, 1144:01, 
1146:01, 1148:01, 1152:01, 1155:01, 1161:01, 1164:01, 1173:01, 
1181:01, 1184:01, 1196:01, 1206:01, 1207:01, 1217:01, 1225:01, 
1226:01, 1231:01, 1237:01, 1238:01, 1241:01, 1242:01, 1244:01, 
1249:01, 1268:01, 1271:01, 1284:01, 1297:01, 1300:01, 1304:01, 
1308:01, 1316:01, 1317:01, 1321:01, 1322:01, 1327:01, 1328:01, 
1345:01, 1362:01, 1374:01, 1377:01, 1379:01, 1387:01, 1390:01, 
1391:01, 1409:01, 1412:01, 1413:01, 1436:01, 1444:01, 1446:01, 
1450:01, 1459:01, 1465:01, 1472:01, 1476:01 
04:02 
04:02P, 04:02, 105:01, 463:01, 571:01, 647:01, 665:01, 674:01, 
701:01, 725:01, 726:01, 730:01, 731:01, 734:01, 735:01, 763:01, 
809:01, 818:01, 823:01, 858:01, 881:01, 927:01, 933:01, 954:01, 
958:01, 981:01, 1005:01, 1013:01, 1020:01, 1025:01, 1031:01, 
1035:01, 1037:01, 1072:01, 1075:01, 1083:01, 1085:01, 1124:01, 
1153:01, 1171:01, 1194:01, 1197:01, 1235:01, 1239:01, 1267:01, 
1270:01, 1283:01, 1331:01, 1346:01, 1380:01, 1404:01, 1424:01, 
1425:01, 1460:01 
05:01 
05:01P, 05:01, 135:01, 668:01, 729:01, 744:01, 764:01, 790:01, 
847:01, 848:01, 851:01, 860:01, 923:01, 951:01, 1015:01, 
1018:01, 1117:01, 1118:01, 1119:01, 1120:01, 1143:01, 1172:01, 
1199:01, 1213:01, 1273:01, 1289:01, 1318:01, 1438:01, 1457:01, 
1462:01, 1473:01 
06:01 
06:01P, 06:01,737:01, 906:01, 914:01, 1022:01, 1087:01, 
1111:01, 1259:01, 1471:01 
08:01 
08:01 
09:01 
09:01P, 09:01, 797:01, 899:01, 1149:01, 1258:01, 1303:01, 
1313:01, 1378:01 
10:01 
10:01P, 10:01, 650:01, 673:01, 902:01, 1126:01, 1261:01, 
1470:01 
11:01 
11:01P, 11:01, 649:01, 654:01, 672:01, 707:01, 907:01, 937:01, 
1063:01 
13:01 
13:01P, 13:01, 107:01, 133:01, 518:01, 519:01, 888:01, 924:01, 
947:01, 996:01, 1065:01, 1069:01, 1105:01, 1123:01, 1131:01, 
1185:01, 1232:01, 1294:01, 1451:01 

If this DPB1-Locus Unacceptable 
Antigen is reported: 
All of the following HLA values are considered equivalent to the 
unacceptable antigen reported and to all the values within the 
row: 
14:01 
14:01P, 14:01, 498:01, 572:01, 651:01, 671:01, 705:01, 834:01, 
854:01, 949:01, 1187:01, 1348:01, 1354:01, 1384:01, 1395:01, 
1414:01 
15:01 
15:01P, 15:01, 585:01, 896:01, 910:01, 1054:01, 1192:01, 
1250:01, 1336:01, 1434:01 
16:01 
16:01P, 16:01, 652:01, 653:01, 864:01, 886:01, 940:01, 968:01, 
1386:01 
17:01 
17:01P, 17:01, 131:01, 168:01, 460:01, 846:01, 956:01, 1032:01, 
1052:01, 1233:01, 1265:01, 1367:01, 1394:01, 1397:01, 1431:01, 
1435:01, 1475:01 
18:01 
18:01P, 18:01, 897:01, 942:01, 1165:01 
19:01 
19:01P, 19:01, 106:01, 533:01, 535:01, 785:01, 965:01, 1101:01, 
1255:01, 1282:01 
20:01 
20:01P, 20:01, 905:01, 1389:01, 1426:01 
21:01 
21:01P, 21:01, 1019:01, 1186:01, 1190:01 
22:01 
22:01P, 22:01, 1026:01 
23:01 
23:01P, 23:01, 138:01 
24:01 
24:01 
25:01 
25:01P, 25:01, 1469:01 
26:01 
26:01P, 26:01, 1088:01 
27:01 
27:01 
28:01 
28:01P, 28:01, 296:01, 1286:01, 1324:01 
29:01 
29:01P, 29:01, 909:01 
30:01 
30:01 
31:01 
31:01P, 31:01, 945:01 
34:01 
34:01P, 34:01, 835:01, 913:01 
35:01 
35:01 
38:01 
38:01P, 38:01, 1099:01 
39:01 
39:01P, 39:01, 584:01 
40:01 
40:01P, 40:01, 745:01 
45:01 
45:01P, 45:01, 832:01 
51:01 
51:01P, 51:01, 736:01 
55:01 
55:01P, 55:01, 1353:01 
57:01 
57:01P, 57:01, 648:01 
59:01 
59:01P, 59:01,782:01 

If this DPB1-Locus Unacceptable 
Antigen is reported: 
All of the following HLA values are considered equivalent to the 
unacceptable antigen reported and to all the values within the 
row: 
80:01 
80:01P, 80:01, 762:01 
81:01 
81:01P, 81:01, 1383:01 
85:01 
85:01P, 85:01, 713:01, 901:01, 1034:01, 1441:01 
90:01 
90:01P, 90:01, 1012:01 
100:01 
100:01P, 100:01, 1483:01 
104:01 
104:01 
105:01 
105:01 
106:01 
106:01 
107:01 
107:01 
124:01 
124:01 
126:01 
126:01 
130:01 
130:01P, 130:01, 1211:01 
131:01 
131:01 
132:01 
132:01P, 132:01, 1027:01 
135:01 
135:01 
137:01 
137:01P, 137:01, 791:01 
152:01 
152:01P, 152:01, 944:01 
184:01 
184:01P, 184:01, 1224:01 
233:01 
233:01P, 233:01, 1428:01 
398:01 
398:01P, 398:01, 922:01 
1096:01 
1096:01P, 1096:01, 1133:01 
1371:01 
1371:01P, 1371:01, 1445:01

---

## 4.11 — Reference Tables of HLA Antigen Values and Split Equivalences (Part 6)

<!-- Policy: 4 | Section: 4.11 | Category: Histocompatibility -->

Table 4-16: Epitope based Unacceptable Antigen Assignment for DPB1 
If this 
Candidate 
Unacceptable 
Epitope is 
reported: 
The following HLA values are considered equivalent to the reported unacceptable 
epitope: 
55AAE 
01:01, 04:01, 11:01, 13:01, 15:01, 23:01, 26:01, 27:01, 31:01, 33:01, 34:01, 39:01, 
40:01, 52:01, 55:01, 56:01, 58:01, 62:01, 63:01, 65:01, 66:01, 67:01, 71:01, 72:01, 
74:01, 85:01, 87:01, 89:01, 90:01, 95:01, 96:01, 99:01, 102:01, 103:01, 107:01, 110:01, 
112:01, 117:01, 118:01, 121:01, 125:01, 126:01, 127:01, 128:01, 133:01, 134:01, 
138:01, 142:01, 147:01, 149:01, 150:01, 158:01, 160:01, 162:01, 169:01, 173:01, 
174:01, 175:01, 176:01, 177:01, 178:01, 179:01, 180:01, 181:01, 192:01, 193:01, 
194:01, 195:01, 199:01, 201:01, 202:01, 206:01, 207:01, 209:01, 212:01, 213:01, 
220:01, 224:01, 225:01, 227:01, 228:01, 230:01, 231:01, 232:01, 240:01, 244:01, 
246:01, 247:01, 250:01, 253:01, 255:01, 262:01, 264:01, 267:01, 268:01, 272:01, 
275:01, 276:01, 278:01, 279:01, 280:01, 281:01, 282:01, 283:01, 290:01, 294:01, 
295:01, 298:01, 299:01, 303:01, 304:01, 305:01, 306:01, 314:01, 318:01, 319:01, 
320:01, 322:01, 323:01, 325:01, 326:01, 327:01, 333:01, 334:01, 335:01, 336:01, 
340:01, 341:01, 345:01, 346:01, 348:01, 350:01, 353:01, 354:01, 356:01, 360:01, 
362:01, 370:01, 371:01, 372:01, 375:01, 376:01, 377:01, 378:01, 387:01, 388:01, 
389:01, 392:01, 393:01, 396:01, 397:01, 398:01, 399:01, 411:01, 412:01, 415:01, 
417:01, 418:01, 425:01, 426:01, 428:01, 434:01, 435:01, 436:01, 437:01, 438:01, 
440:01, 449:01, 451:01, 453:01, 454:01, 456:01, 458:01, 459:01, 462:01, 464:01, 
465:01, 468:01, 471:01, 474:01, 475:01, 476:01, 479:01, 480:01, 481:01, 482:01, 
483:01, 485:01, 486:01, 487:01, 490:01, 493:01, 497:01, 500:01, 503:01, 512:01, 
516:01, 517:01, 518:01, 519:01, 520:01, 521:01, 522:01, 523:01, 524:01, 529:01, 
531:01, 534:01, 538:01, 542:01, 543:01, 544:01, 553:01, 554:01, 556:01, 559:01, 
561:01, 562:01, 563:01, 564:01, 565:01, 569:01, 575:01, 576:01, 578:01, 580:01, 
583:01, 584:01, 585:01, 591:01, 592:01, 593:01, 597:01, 599:01, 600:01, 607:01, 
609:01, 612:01, 614:01, 615:01, 616:01, 618:01, 623:01, 625:01, 626:01, 631:01, 
632:01, 634:01, 635:01, 636:01, 643:01, 644:01, 649:01, 654:01, 658:01, 666:01, 
667:01, 670:01, 672:01, 677:01, 679:01, 682:01, 683:01, 686:01, 687:01, 694:01, 
695:01, 699:01, 702:01, 703:01, 707:01, 708:01, 709:01, 713:01, 716:01, 722:01, 
733:01, 739:01, 742:01, 745:01, 747:01, 749:01, 750:01, 753:01, 755:01, 757:01, 
758:01, 761:01, 765:01, 767:01, 768:01, 769:01, 772:01, 773:01, 784:01, 787:01, 
788:01, 789:01, 795:01, 803:01, 804:01, 806:01, 807:01, 808:01, 810:01, 811:01, 
812:01, 813:01, 814:01, 820:01, 822:01, 824:01, 826:01, 828:01, 830:01, 835:01, 
837:01, 840:01, 842:01, 849:01, 850:01, 852:01, 853:01, 856:01, 859:01, 879:01, 

If this 
Candidate 
Unacceptable 
Epitope is 
reported: 
The following HLA values are considered equivalent to the reported unacceptable 
epitope: 
880:01, 882:01, 888:01, 893:01, 895:01, 896:01, 901:01, 904:01, 907:01, 908:01, 
910:01, 912:01, 913:01, 915:01, 916:01, 921:01, 922:01, 924:01, 926:01, 930:01, 
931:01, 932:01, 934:01, 937:01, 945:01, 947:01, 953:01, 957:01, 966:01, 969:01, 
972:01, 976:01, 978: 01, 979:01, 988:01, 989:01, 991:01, 992:01, 993:01, 996:01, 
997:01, 998:01, 999:01, 1001:01, 1002:01, 1003:01, 1004:01, 1010:01, 1011:01, 
1012:01, 1016:01, 1023:01, 1024:01, 1033:01, 1034:01, 1038:01, 1040:01, 1042:01, 
1046:01, 1048:01, 1050:01, 1054:01, 1057:01, 1060:01, 1062:01, 1063:01, 1064:01, 
1065:01, 1066:01, 1068:01, 1069:01, 1073:01, 1074:01, 1076:01, 1078:01, 1080:01, 
1081:01, 1086:01, 1088:01, 1091:01, 1097:01, 1100:01, 1105:01, 1108:01, 1109:01, 
1113:01, 1122:01, 1123:01, 1129:01, 1131:01, 1132:01, 1137:01, 1138:01, 1139:01, 
1141:01, 1144:01, 1145:01, 1146:01, 1147:01, 1148:01, 1151:01, 1152:01, 1155:01, 
1161:01, 1162:01, 1164:01, 1166:01, 1167:01, 1170:01, 1173:01, 1177:01, 1181:01, 
1183:01, 1184:01, 1185:01, 1192:01, 1195:01, 1196:01, 1204:01, 1205:01, 1206:01, 
1207:01, 1208:01, 1212:01, 1214:01, 1215:01, 1216:01, 1217:01, 1218:01, 1220:01, 
1221:01, 1222:01, 1225:01, 1226:01, 1231:01, 1232:01, 1234:01, 1237:01, 1238:01, 
1241:01, 1242:01, 1244:01, 1249:01, 1250:01, 1252:01, 1262:01, 1264:01, 1268:01, 
1271:01, 1274:01, 1277:01, 1284:01, 1287:01, 1292:01, 1294:01, 1297:01, 1300:01, 
1301:01, 1304:01, 1306:01, 1308:01, 1309:01, 1310:01, 1314:01, 1316:01, 1317:01, 
1321:01, 1322:01, 1327:01, 1328:01, 1329:01, 1333:01, 1336:01, 1337:01, 1341:01, 
1342:01, 1343:01, 1345:01, 1353:01, 1356:01, 1358:01, 1361:01, 1362:01, 1370:01, 
1374:01, 1377:01, 1379:01, 1385:01, 1387:01, 1390:01, 1391:01, 1392:01, 1399:01, 
1406:01, 1409:01, 1412:01, 1413:01, 1420:01, 1421:01, 1427:01, 1433:01, 1434:01, 
1436:01, 1441:01, 1443:01, 1444:01, 1446:01, 1447:01, 1450:01, 1451:01, 1453:01, 
1454:01, 1459:01, 1464:01, 1465:01, 1472:01, 1476:01, 01:01P, 04:01P, 11:01P, 13:01P, 
15:01P, 23:01P, 26:01P, 31:01P, 34:01P, 39:01P, 40:01P, 55:01P, 85:01P, 90:01P, 398:01P 
55DED 
03:01, 06:01, 09:01, 14:01, 17:01, 20:01, 29:01, 35:01, 44:01, 46:01, 50:01, 57:01, 
69:01, 70:01, 76:01, 78:01, 80:01, 86:01, 88:01, 91:01, 92:01, 98:01, 104:01, 108:01, 
111:01, 119:01, 124:01, 130:01, 131:01, 132:01, 152:01, 156:01, 157:01, 164:01, 
166:01, 168:01, 182:01, 197:01, 203:01, 205:01, 208:01, 214:01, 221:01, 222:01, 
234:01, 235:01, 241:01, 242:01, 243:01, 245:01, 248:01, 249:01, 251:01, 259:01, 
266:01, 270:01, 287:01, 288:01, 289:01, 292:01, 293:01, 329:01, 332:01, 343:01, 
351:01, 355:01, 361:01, 363:01, 379:01, 383:01, 384:01, 385:01, 386:01, 391:01, 
394:01, 404:01, 405:01, 407:01, 409:01, 413:01, 439:01, 442:01, 445:01, 446:01, 
447:01, 460:01, 472:01, 484:01, 491:01, 492:01, 498:01, 504:01, 505:01, 506:01, 
55AAE

---

## 4.11 — Reference Tables of HLA Antigen Values and Split Equivalences (Part 7)

<!-- Policy: 4 | Section: 4.11 | Category: Histocompatibility -->

If this 
Candidate 
Unacceptable 
Epitope is 
reported: 
The following HLA values are considered equivalent to the reported unacceptable 
epitope: 
508:01, 509:01, 530:01, 536:01, 540:01, 541:01, 545:01, 546:01, 548:01, 555:01, 
566:01, 567:01, 568:01, 572:01, 581:01, 601:01, 610:01, 613:01, 620:01, 621:01, 
629:01, 630:01, 645:01, 648:01, 651:01, 662:01, 664:01, 669:01, 671:01, 675:01, 
676:01, 684:01, 688:01, 689:01, 698:01, 704:01, 705:01, 706:01, 714:01, 719:01, 
727:01, 728:01, 737:01, 760:01, 762:01, 797:01, 801:01, 815:01, 829:01, 833:01, 
834:01, 839:01, 846:01, 854:01, 855:01, 883:01, 899:01, 905:01, 906:01, 909:01, 
914:01, 920:01, 935:01, 938:01, 944:01, 946:01, 948:01, 949:01, 952:01, 956:01, 
970:01, 977:01, 983:01, 987:01, 990:01, 994:01, 1000:01, 1009:01, 1014:01, 1017:01, 
1021:01, 1022:01, 1027:01, 1030:01, 1032:01, 1043:01, 1047:01, 1049:01, 1052:01, 
1067:01, 1071:01, 1087:01, 1090:01, 1093:01, 1103:01, 1104:01, 1111:01, 1114:01, 
1116:01, 1125:01, 1127:01, 1128:01, 1130:01, 1134:01, 1149:01, 1157:01, 1158:01, 
1174:01, 1178:01, 1182:01, 1187:01, 1203:01, 1211:01, 1233:01, 1245:01, 1246:01, 
1251:01, 1254:01, 1258:01, 1259:01, 1263:01, 1265:01, 1278:01, 1295:01, 1303:01, 
1311:01, 1313:01, 1330:01, 1339:01, 1340:01, 1348:01, 1354:01, 1355:01, 1359:01, 
1365:01, 1366:01, 1367:01, 1373:01, 1378:01, 1382:01, 1384:01, 1388:01, 1389:01, 
1394:01, 1395:01, 1396:01, 1397:01, 1401:01, 1407:01, 1411:01, 1414:01, 1418:01, 
1422:01, 1426:01, 1429:01, 1431:01, 1432:01, 1435:01, 1448:01, 1452:01, 1458:01, 
1466:01, 1467:01, 1471:01, 1474:01, 1475:01, 1480:01, 03:01P, 06:01P, 09:01P, 14:01P, 
17:01P, 20:01P, 29:01P, 57:01P, 80:01P, 130:01P, 132:01P, 152:01P 
55DEE 
02:01, 04:02, 08:01, 10:01, 16:01, 18:01, 25:01, 28:01, 37:01, 41:01, 45:01, 48:01, 
49:01, 51:01, 53:01, 59:01, 60:01, 68:01, 73:01, 75:01, 77:01, 79:01, 81:01, 82:01, 
83:01, 93:01, 94:01, 105:01, 109:01, 113:01, 115:01, 116:01, 122:01, 123:01, 129:01, 
136:01, 137:01, 141:01, 143:01, 144:01, 145:01, 146:01, 151:01, 153:01, 155:01, 
163:01, 165:01, 167:01, 172:01, 183:01, 184:01, 185:01, 186:01, 187:01, 188:01, 
189:01, 191:01, 196:01, 198:01, 200:01, 204:01, 210:01, 211:01, 217:01, 219:01, 
229:01, 236:01, 237:01, 238:01, 239:01, 252:01, 256:01, 257:01, 258:01, 260:01, 
261:01, 263:01, 265:01, 269:01, 271:01, 273:01, 274:01, 277:01, 285:01, 286:01, 
296:01, 297:01, 307:01, 308:01, 309:01, 310:01, 311:01, 312:01, 313:01, 316:01, 
321:01, 324:01, 338:01, 339:01, 342:01, 344:01, 347:01, 349:01, 352:01, 359:01, 
364:01, 365:01, 366:01, 367:01, 368:01, 369:01, 373:01, 374:01, 380:01, 381:01, 
402:01, 410:01, 414:01, 416:01, 419:01, 420:01, 421:01, 422:01, 423:01, 424:01, 
429:01, 430:01, 431:01, 432:01, 433:01, 441:01, 443:01, 444:01, 448:01, 452:01, 
457:01, 461:01, 463:01, 466:01, 467:01, 469:01, 470:01, 477:01, 488:01, 489:01, 
494:01, 499:01, 501:01, 502:01, 510:01, 511:01, 513:01, 514:01, 515:01, 525:01, 
55DED 

If this 
Candidate 
Unacceptable 
Epitope is 
reported: 
The following HLA values are considered equivalent to the reported unacceptable 
epitope: 
526:01, 528:01, 532:01, 537:01, 539:01, 549:01, 552:01, 557:01, 571:01, 574:01, 
577:01, 579:01, 582:01, 586:01, 594:01, 595:01, 596:01, 602:01, 603:01, 604:01, 
606:01, 608:01, 617:01, 622:01, 624:01, 627:01, 628:01, 633:01, 637:01, 639:01, 
640:01, 641:01, 646:01, 647:01, 650:01, 652:01, 653:01, 655:01, 656:01, 659:01, 
660:01, 663:01, 665:01, 673:01, 674:01, 678:01, 680:01, 681:01, 685:01, 690:01, 
692:01, 701:01, 711:01, 723:01, 725:01, 726:01, 730:01, 731:01, 734:01, 735:01, 
736:01, 740:01, 741:01, 751:01, 752:01, 759:01, 763:01, 770:01, 771:01, 774:01, 
775:01, 776:01, 780:01, 781:01, 782:01, 783:01, 791:01, 799:01, 805:01, 809:01, 
816:01, 817:01, 818:01, 819:01, 823:01, 827:01, 832:01, 836:01, 841:01, 843:01, 
845:01, 857:01, 858:01, 861:01, 863:01, 864:01, 881:01, 884:01, 885:01, 886:01, 
887:01, 889:01, 890:01, 891:01, 892:01, 897:01, 898:01, 900:01, 902:01, 903:01, 
918:01, 927:01, 933:01, 936:01, 940:01, 942:01, 943:01, 954:01, 955:01, 958:01, 
963:01, 964:01, 967:01, 968:01, 973:01, 975:01, 981:01, 1005:01, 1006:01, 1007:01, 
1013:01, 1020:01, 1025:01, 1028:01, 1031:01, 1035:01, 1036:01, 1037:01, 1039:01, 
1051:01, 1053:01, 1055:01, 1056:01, 1059:01, 1072:01, 1075:01, 1077:01, 1082:01, 
1083:01, 1085:01, 1089:01, 1092:01, 1094:01, 1102:01, 1106:01, 1107:01, 1110:01, 
1115:01, 1124:01, 1126:01, 1136:01, 1140:01, 1142:01, 1150:01, 1153:01, 1159:01, 
1160:01, 1163:01, 1165:01, 1168:01, 1171:01, 1175:01, 1176:01, 1179:01, 1194:01, 
1197:01, 1198:01, 1200:01, 1201:01, 1210:01, 1219:01, 1224:01, 1227:01, 1230:01, 
1235:01, 1236:01, 1239:01, 1243:01, 1247:01, 1248:01, 1253:01, 1261:01, 1266:01, 
1267:01, 1270:01, 1276:01, 1280:01, 1281:01, 1283:01, 1286:01, 1290:01, 1296:01, 
1298:01, 1307:01, 1312:01, 1315:01, 1319:01, 1320:01, 1323:01, 1324:01, 1326:01, 
1331:01, 1335:01, 1344:01, 1346:01, 1347:01, 1352:01, 1360:01, 1363:01, 1368:01, 
1369:01, 1371:01, 1372:01, 1380:01, 1381:01, 1383:01, 1386:01, 1393:01, 1402:01, 
1404:01, 1405:01, 1408:01, 1410:01, 1417:01, 1419:01, 1424:01, 1425:01, 1445:01, 
1456:01, 1460:01, 1461:01, 1468:01, 1469:01, 1470:01, 1479:01, 02:01P, 04:02P, 
10:01P, 16:01P, 18:01P, 25:01P, 28:01P, 45:01P, 51:01P, 59:01P, 81:01P, 137:01P, 
184:01P, 1371:01P 
55EAE 
02:02, 05:01, 19:01, 21:01, 22:01, 24:01, 30:01, 36:01, 38:01, 47:01, 54:01, 97:01, 
100:01, 106:01, 114:01, 135:01, 139:01, 140:01, 170:01, 171:01, 223:01, 233:01, 
284:01, 291:01, 300:01, 301:01, 302:01, 317:01, 330:01, 337:01, 358:01, 390:01, 
395:01, 400:01, 406:01, 408:01, 473:01, 495:01, 496:01, 527:01, 533:01, 535:01, 
547:01, 550:01, 558:01, 573:01, 587:01, 588:01, 589:01, 590:01, 611:01, 619:01, 
638:01, 746:01, 697:01, 715:01, 717:01, 718:01, 720:01, 721:01, 729:01, 744:01, 
55DEE

---

## 4.11 — Reference Tables of HLA Antigen Values and Split Equivalences (Part 8)

<!-- Policy: 4 | Section: 4.11 | Category: Histocompatibility -->

If this 
Candidate 
Unacceptable 
Epitope is 
reported: 
The following HLA values are considered equivalent to the reported unacceptable 
epitope: 
847:01, 764:01, 766:01, 778:01, 779:01, 785:01, 790:01, 798:01, 802:01, 962:01, 
848:01, 851:01, 860:01, 923:01, 928:01, 929:01, 951:01, 961:01, 1026:01, 965:01, 
971:01, 980:01, 982:01, 1008:01, 1015:01, 1018:01, 1019:01, 1143:01, 1061:01, 
1095:01, 1099:01, 1101:01, 1117:01, 1118:01, 1119:01, 1120:01, 1209:01, 1156:01, 
1172:01, 1180:01, 1186:01, 1188:01, 1189:01, 1190:01, 1199:01, 1289:01, 1213:01, 
1229:01, 1240:01, 1255:01, 1257:01, 1272:01, 1273:01, 1282:01, 1293:01, 1302:01, 
1318:01, 1349:01, 1376:01, 1400:01, 1403:01, 1428:01, 1437:01, 1438:01, 1457:01, 
1462:01, 1473:01, 1477:01, 1481:01, 1483:01, 02:02P, 05:01P, 19:01P, 21:01P, 22:01P, 
38:01P, 100:01P, 233:01P 
84DEAV 
01:01, 03:01, 05:01, 06:01, 08:01, 09:01, 10:01, 11:01, 13:01, 14:01, 16:01, 17:01, 
19:01, 20:01, 21:01, 22:01, 25:01, 26:01, 27:01, 29:01, 30:01, 31:01, 35:01, 36:01, 
37:01, 38:01, 44:01, 45:01, 50:01, 52:01, 54:01, 55:01, 56:01, 57:01, 58:01, 63:01, 
65:01, 67:01, 68:01, 69:01, 70:01, 76:01, 78:01, 79:01, 84:01, 85:01, 87:01, 88:01, 
89:01, 90:01, 91:01, 92:01, 93:01, 97:01, 98:01, 102:01, 103:01, 104:01, 106:01, 
107:01, 110:01, 111:01, 114:01, 118:01, 122:01, 124:01, 125:01, 127:01, 130:01, 
131:01, 132:01, 133:01, 135:01, 136:01, 137:01, 140:01, 142:01, 147:01, 150:01, 
152:01, 156:01, 157:01, 162:01, 165:01, 166:01, 167:01, 168:01, 170:01, 171:01, 
173:01, 182:01, 184:01, 197:01, 201:01, 202:01, 203:01, 204:01, 205:01, 206:01, 
207:01, 208:01, 209:01, 220:01, 221:01, 222:01, 223:01, 226:01, 234:01, 241:01, 
243:01, 244:01, 245:01, 246:01, 247:01, 248:01, 249:01, 250:01, 251:01, 259:01, 
264:01, 265:01, 266:01, 267:01, 268:01, 269:01, 270:01, 277:01, 284:01, 285:01, 
287:01, 288:01, 289:01, 291:01, 293:01, 295:01, 300:01, 301:01, 304:01, 305:01, 
312:01, 313:01, 314:01, 315:01, 316:01, 317:01, 324:01, 325:01, 326:01, 327:01, 
329:01, 331:01, 337:01, 340:01, 343:01, 346:01, 348:01, 349:01, 351:01, 353:01, 
358:01, 361:01, 362:01, 363:01, 370:01, 371:01, 379:01, 383:01, 384:01, 385:01, 
386:01, 388:01, 389:01, 390:01, 391:01, 393:01, 394:01, 395:01, 398:01, 400:01, 
404:01, 405:01, 407:01, 408:01, 409:01, 410:01, 411:01, 412:01, 413:01, 417:01, 
422:01, 437:01, 438:01, 439:01, 442:01, 445:01, 446:01, 447:01, 448:01, 449:01, 
458:01, 460:01, 462:01, 466:01, 470:01, 472:01, 473:01, 481:01, 483:01, 490:01, 
491:01, 492:01, 495:01, 498:01, 503:01, 504:01, 505:01, 506:01, 509:01, 514:01, 
515:01, 516:01, 517:01, 518:01, 519:01, 527:01, 530:01, 532:01, 533:01, 535:01, 
536:01, 538:01, 541:01, 542:01, 543:01, 545:01, 548:01, 550:01, 552:01, 558:01, 
560:01, 562:01, 563:01, 564:01, 565:01, 566:01, 567:01, 568:01, 572:01, 573:01, 
587:01, 588:01, 597:01, 599:01, 600:01, 608:01, 609:01, 610:01, 611:01, 612:01, 
55EAE 

If this 
Candidate 
Unacceptable 
Epitope is 
reported: 
The following HLA values are considered equivalent to the reported unacceptable 
epitope: 
613:01, 616:01, 619:01, 621:01, 623:01, 629:01, 630:01, 631:01, 632:01, 633:01, 
634:01, 635:01, 636:01, 638:01, 645:01, 648:01, 649:01, 650:01, 651:01, 652:01, 
653:01, 654:01, 662:01, 664:01, 667:01, 668:01, 669:01, 671:01, 672:01, 673:01, 
675:01, 676:01, 684:01, 688:01, 689:01, 698:01, 703:01, 704:01, 705:01, 706:01, 
707:01, 708:01, 709:01, 710:01, 711:01, 713:01, 714:01, 715:01, 716:01, 717:01, 
718:01, 720:01, 727:01, 728:01, 729:01, 733:01, 737:01, 744:01, 746:01, 749:01, 
760:01, 764:01, 778:01, 785:01, 789:01, 790:01, 791:01, 797:01, 798:01, 801:01, 
802:01, 807:01, 810:01, 815:01, 822:01, 825:01, 829:01, 832:01, 833:01, 834:01, 
839:01, 846:01, 847:01, 848:01, 851:01, 853:01, 854:01, 855:01, 856:01, 860:01, 
864:01, 879:01, 883:01, 886:01, 888:01, 891:01, 892:01, 893:01, 898:01, 899:01, 
901:01, 902:01, 904:01, 905:01, 906:01, 907:01, 908:01, 909:01, 912:01, 914:01, 
920:01, 922:01, 923:01, 924:01, 929:01, 930:01, 931:01, 935:01, 937:01, 938:01, 
940:01, 944:01, 945:01, 946:01, 947:01, 948:01, 949:01, 951:01, 952:01, 953:01, 
956:01, 965:01, 968:01, 969:01, 970:01, 971:01, 976:01, 977:01, 979:01, 980:01, 
982:01, 983:01, 990:01, 991:01, 994:01, 996:01, 998:01, 999:01, 1000:01, 1006:01, 
1007:01, 1008:01, 1009:01, 1012:01, 1014:01, 1015:01, 1017:01, 1018:01, 1019:01, 
1021:01, 1022:01, 1024:01, 1026:01, 1027:01, 1030:01, 1032:01, 1034:01, 1038:01, 
1043:01, 1047:01, 1049:01, 1050:01, 1052:01, 1057:01, 1058:01, 1061:01, 1063:01, 
1065:01, 1067:01, 1068:01, 1069:01, 1071:01, 1073:01, 1076:01, 1087:01, 1088:01, 
1090:01, 1093:01, 1095:01, 1096:01, 1099:01, 1101:01, 1103:01, 1105:01, 1111:01, 
1114:01, 1116:01, 1117:01, 1118:01, 1119:01, 1120:01, 1123:01, 1125:01, 1126:01, 
1127:01, 1128:01, 1130:01, 1131:01, 1133:01, 1134:01, 1137:01, 1140:01, 1141:01, 
1143:01, 1145:01, 1147:01, 1149:01, 1150:01, 1151:01, 1156:01, 1157:01, 1158:01, 
1162:01, 1166:01, 1168:01, 1170:01, 1172:01, 1178:01, 1180:01, 1182:01, 1183:01, 
1185:01, 1186:01, 1187:01, 1189:01, 1190:01, 1199:01, 1203:01, 1204:01, 1205:01, 
1211:01, 1213:01, 1224:01, 1229:01, 1232:01, 1233:01, 1234:01, 1240:01, 1245:01, 
1246:01, 1251:01, 1254:01, 1255:01, 1257:01, 1258:01, 1259:01, 1261:01, 1263:01, 
1264:01, 1265:01, 1272:01, 1273:01, 1278:01, 1281:01, 1282:01, 1287:01, 1289:01, 
1293:01, 1294:01, 1295:01, 1302:01, 1303:01, 1305:01, 1306:01, 1310:01, 1311:01, 
1313:01, 1314:01, 1318:01, 1329:01, 1330:01, 1333:01, 1339:01, 1340:01, 1341:01, 
1342:01, 1348:01, 1349:01, 1353:01, 1354:01, 1355:01, 1359:01, 1361:01, 1365:01, 
1366:01, 1367:01, 1370:01, 1378:01, 1382:01, 1384:01, 1386:01, 1388:01, 1389:01, 
1392:01, 1394:01, 1395:01, 1396:01, 1397:01, 1400:01, 1401:01, 1406:01, 1407:01, 
1411:01, 1414:01, 1418:01, 1421:01, 1426:01, 1429:01, 1431:01, 1432:01, 1435:01, 
1438:01, 1441:01, 1443:01, 1448:01, 1451:01, 1452:01, 1457:01, 1458:01, 1462:01, 
84DEAV

---

## 4.11 — Reference Tables of HLA Antigen Values and Split Equivalences (Part 9)

<!-- Policy: 4 | Section: 4.11 | Category: Histocompatibility -->

If this 
Candidate 
Unacceptable 
Epitope is 
reported: 
The following HLA values are considered equivalent to the reported unacceptable 
epitope: 
1464:01, 1466:01, 1467:01, 1469:01, 1470:01, 1471:01, 1473:01, 1475:01, 1477:01, 
1480:01, 1481:01, 01:01P, 03:01P, 05:01P, 06:01P, 09:01P, 10:01P, 11:01P, 13:01P, 
14:01P, 16:01P, 17:01P, 19:01P, 20:01P, 21:01P, 22:01P, 25:01P, 26:01P, 29:01P, 31:01P, 
38:01P, 45:01P, 55:01P, 57:01P, 85:01P, 90:01P, 130:01P, 132:01P, 137:01P, 152:01P, 
184:01P, 398:01P, 1096:01P 
84GGPM 
02:01, 02:02, 04:01, 04:02, 23:01, 24:01, 32:01, 33:01, 39:01, 41:01, 46:01, 47:01, 
48:01, 49:01, 51:01, 59:01, 60:01, 66:01, 71:01, 72:01, 73:01, 75:01, 77:01, 80:01, 
81:01, 82:01, 83:01, 86:01, 94:01, 95:01, 96:01, 99:01, 100:01, 101:01, 105:01, 108:01, 
109:01, 112:01, 113:01, 115:01, 116:01, 117:01, 121:01, 123:01, 126:01, 128:01, 
129:01, 134:01, 138:01, 141:01, 143:01, 144:01, 145:01, 146:01, 148:01, 149:01, 
151:01, 153:01, 155:01, 158:01, 163:01, 164:01, 169:01, 172:01, 174:01, 175:01, 
176:01, 179:01, 180:01, 181:01, 183:01, 185:01, 186:01, 187:01, 188:01, 189:01, 
190:01, 191:01, 192:01, 193:01, 194:01, 195:01, 196:01, 199:01, 200:01, 210:01, 
211:01, 212:01, 213:01, 214:01, 215:01, 217:01, 219:01, 224:01, 225:01, 227:01, 
228:01, 229:01, 231:01, 232:01, 233:01, 235:01, 236:01, 237:01, 238:01, 239:01, 
240:01, 252:01, 253:01, 254:01, 255:01, 256:01, 257:01, 258:01, 260:01, 261:01, 
262:01, 263:01, 271:01, 272:01, 273:01, 274:01, 275:01, 276:01, 278:01, 281:01, 
282:01, 283:01, 286:01, 294:01, 297:01, 298:01, 302:01, 303:01, 306:01, 307:01, 
308:01, 309:01, 310:01, 311:01, 318:01, 319:01, 320:01, 321:01, 322:01, 323:01, 
332:01, 334:01, 335:01, 336:01, 338:01, 339:01, 341:01, 342:01, 344:01, 350:01, 
352:01, 354:01, 355:01, 356:01, 359:01, 360:01, 375:01, 376:01, 377:01, 378:01, 
380:01, 381:01, 392:01, 396:01, 397:01, 399:01, 402:01, 406:01, 414:01, 415:01, 
416:01, 418:01, 419:01, 420:01, 421:01, 423:01, 424:01, 425:01, 426:01, 427:01, 
428:01, 429:01, 430:01, 432:01, 433:01, 434:01, 435:01, 440:01, 441:01, 443:01, 
444:01, 451:01, 452:01, 453:01, 456:01, 457:01, 459:01, 461:01, 463:01, 464:01, 
465:01, 468:01, 469:01, 474:01, 475:01, 476:01, 477:01, 478:01, 479:01, 480:01, 
485:01, 486:01, 487:01, 488:01, 494:01, 496:01, 497:01, 500:01, 501:01, 502:01, 
508:01, 510:01, 511:01, 520:01, 521:01, 522:01, 523:01, 524:01, 525:01, 528:01, 
529:01, 531:01, 534:01, 537:01, 539:01, 540:01, 547:01, 549:01, 553:01, 554:01, 
555:01, 556:01, 557:01, 559:01, 561:01, 569:01, 571:01, 574:01, 575:01, 576:01, 
577:01, 578:01, 579:01, 581:01, 582:01, 583:01, 584:01, 586:01, 591:01, 593:01, 
594:01, 595:01, 596:01, 601:01, 602:01, 603:01, 604:01, 605:01, 606:01, 607:01, 
614:01, 615:01, 617:01, 618:01, 620:01, 622:01, 624:01, 625:01, 626:01, 627:01, 
628:01, 637:01, 639:01, 640:01, 641:01, 642:01, 643:01, 646:01, 647:01, 655:01, 
84DEAV 

If this 
Candidate 
Unacceptable 
Epitope is 
reported: 
The following HLA values are considered equivalent to the reported unacceptable 
epitope: 
656:01, 658:01, 659:01, 660:01, 663:01, 665:01, 666:01, 670:01, 674:01, 677:01, 
678:01, 679:01, 680:01, 681:01, 682:01, 683:01, 685:01, 686:01, 687:01, 690:01, 
692:01, 694:01, 699:01, 701:01, 702:01, 721:01, 722:01, 723:01, 725:01, 726:01, 
730:01, 731:01, 734:01, 735:01, 736:01, 739:01, 741:01, 742:01, 747:01, 750:01, 
751:01, 753:01, 755:01, 757:01, 758:01, 759:01, 761:01, 762:01, 763:01, 765:01, 
766:01, 767:01, 769:01, 770:01, 771:01, 772:01, 773:01, 774:01, 775:01, 776:01, 
779:01, 780:01, 781:01, 782:01, 783:01, 784:01, 787:01, 788:01, 795:01, 796:01, 
799:01, 803:01, 804:01, 805:01, 806:01, 808:01, 809:01, 811:01, 812:01, 813:01, 
814:01, 816:01, 817:01, 818:01, 819:01, 820:01, 823:01, 824:01, 826:01, 827:01, 
828:01, 830:01, 836:01, 837:01, 840:01, 841:01, 842:01, 843:01, 845:01, 849:01, 
850:01, 852:01, 857:01, 858:01, 859:01, 861:01, 863:01, 880:01, 881:01, 882:01, 
884:01, 885:01, 887:01, 889:01, 890:01, 895:01, 915:01, 916:01, 921:01, 926:01, 
927:01, 928:01, 932:01, 933:01, 934:01, 936:01, 943:01, 954:01, 955:01, 957:01, 
958:01, 961:01, 962:01, 963:01, 964:01, 966:01, 967:01, 972:01, 973:01, 975:01, 
978:01, 981:01, 987:01, 988:01, 989:01, 992:01, 993:01, 997:01, 1001:01, 1002:01, 
1003:01, 1004:01, 1005:01, 1010:01, 1011:01, 1013:01, 1016:01, 1020:01, 1023:01, 
1025:01, 1028:01, 1031:01, 1033:01, 1035:01, 1036:01, 1037:01, 1039:01, 1040:01, 
1042:01, 1046:01, 1048:01, 1051:01, 1053:01, 1055:01, 1056:01, 1059:01, 1060:01, 
1062:01, 1064:01, 1066:01, 1072:01, 1074:01, 1075:01, 1077:01, 1080:01, 1081:01, 
1082:01, 1083:01, 1085:01, 1086:01, 1089:01, 1091:01, 1094:01, 1097:01, 1100:01, 
1102:01, 1104:01, 1106:01, 1108:01, 1110:01, 1113:01, 1115:01, 1122:01, 1124:01, 
1129:01, 1132:01, 1138:01, 1139:01, 1144:01, 1146:01, 1148:01, 1152:01, 1153:01, 
1155:01, 1159:01, 1160:01, 1161:01, 1163:01, 1164:01, 1167:01, 1171:01, 1173:01, 
1174:01, 1175:01, 1176:01, 1177:01, 1179:01, 1181:01, 1184:01, 1188:01, 1194:01, 
1195:01, 1196:01, 1197:01, 1198:01, 1200:01, 1206:01, 1207:01, 1208:01, 1209:01, 
1210:01, 1212:01, 1214:01, 1215:01, 1216:01, 1217:01, 1218:01, 1220:01, 1221:01, 
1222:01, 1223:01, 1225:01, 1226:01, 1227:01, 1230:01, 1231:01, 1235:01, 1237:01, 
1238:01, 1239:01, 1241:01, 1242:01, 1243:01, 1244:01, 1247:01, 1248:01, 1249:01, 
1253:01, 1262:01, 1266:01, 1267:01, 1268:01, 1270:01, 1271:01, 1274:01, 1276:01, 
1280:01, 1283:01, 1284:01, 1290:01, 1292:01, 1297:01, 1298:01, 1300:01, 1301:01, 
1304:01, 1307:01, 1308:01, 1309:01, 1312:01, 1315:01, 1316:01, 1317:01, 1320:01, 
1321:01, 1322:01, 1323:01, 1326:01, 1327:01, 1328:01, 1331:01, 1335:01, 1337:01, 
1343:01, 1344:01, 1345:01, 1346:01, 1347:01, 1352:01, 1356:01, 1358:01, 1360:01, 
1362:01, 1363:01, 1368:01, 1369:01, 1371:01, 1372:01, 1374:01, 1376:01, 1377:01, 
1379:01, 1380:01, 1381:01, 1383:01, 1385:01, 1387:01, 1390:01, 1391:01, 1393:01, 
84GGPM

---

## 4.11 — Reference Tables of HLA Antigen Values and Split Equivalences (Part 10)

<!-- Policy: 4 | Section: 4.11 | Category: Histocompatibility -->

If this 
Candidate 
Unacceptable 
Epitope is 
reported: 
The following HLA values are considered equivalent to the reported unacceptable 
epitope: 
1399:01, 1402:01, 1403:01, 1404:01, 1405:01, 1408:01, 1409:01, 1410:01, 1412:01, 
1413:01, 1417:01, 1419:01, 1420:01, 1424:01, 1425:01, 1428:01, 1433:01, 1436:01, 
1437:01, 1444:01, 1445:01, 1446:01, 1447:01, 1450:01, 1453:01, 1454:01, 1456:01, 
1459:01, 1460:01, 1461:01, 1465:01, 1468:01, 1472:01, 1474:01, 1476:01, 1479:01, 
1483:01, 02:01P, 02:02P, 04:01P, 04:02P, 23:01P, 39:01P, 51:01P, 59:01P, 80:01P, 81:01P, 
100:01P, 233:01P, 1371:01P 
84VGPM 
15:01, 18:01, 28:01, 34:01, 40:01, 53:01, 62:01, 74:01, 139:01, 198:01, 290:01, 292:01, 
296:01, 299:01, 333:01, 345:01, 347:01, 387:01, 471:01, 482:01, 484:01, 493:01, 
499:01, 512:01, 526:01, 580:01, 585:01, 644:01, 695:01, 745:01, 752:01, 768:01, 
835:01, 896:01, 897:01, 900:01, 903:01, 910:01, 913:01, 918:01, 942:01, 1054:01, 
1109:01, 1136:01, 1142:01, 1165:01, 1192:01, 1201:01, 1219:01, 1250:01, 1252:01, 
1286:01, 1324:01, 1336:01, 1422:01, 1427:01, 1434:01, 15:01P, 18:01P, 28:01P, 34:01P, 
40:01P 
84GGPM 

5.1 
Minimum Acceptance Criteria 
88 
5.2 
Maximum Mismatched Antigens 
88 
5.3 
Additional Acceptance and Screening Criteria 
88 
5.4 
Organ Offers 
91 
5.5 
Re-Execution of the Match Run Due to New Information 
94 
5.6 
Receiving and Accepting Organ Offers 
96 
5.7 
Organ Check-In 
97 
5.8 
Pre-Transplant Verification 
97 
5.9 
Released Organs 
100 
5.10 Allocation of Multi-Organ Combinations 
100

---
