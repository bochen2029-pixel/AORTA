# OPTN Policy 20: Travel Expense and Reimbursement

**Source:** OPTN Policies | **Effective:** 12/10/2025 | **Category:** Travel Reimbursement
**Confidence:** HIGH — Official OPTN policy language

---

## 20.1.A — General Eligibility Requirements

<!-- Policy: 20 | Section: 20.1.A | Category: Travel Reimbursement -->

The OPTN will reimburse approved travel costs for members, contractors, invited guests, and 
OPTN Contractor staff who are traveling for OPTN business. OPTN Contractor employees and 
contractors must receive authorization from their director or person who approves travel before 
confirming travel arrangements. OPTN Contractor staff will approve a member’s travel to OPTN 
sponsored events.

---

## 20.1.B — Multiple Meetings in the Same City

<!-- Policy: 20 | Section: 20.1.B | Category: Travel Reimbursement -->

If the OPTN holds a meeting in a city where the traveler will attend another organization's 
meeting, the OPTN will pay only for the traveler's additional expenses incurred as a direct result 
of attending the OPTN meeting.

---

## 20.2.A — Booking Travel

<!-- Policy: 20 | Section: 20.2.A | Category: Travel Reimbursement -->

OPTN Contractor staff and members must use the approved OPTN Contractor travel agency to 
arrange all OPTN related travel and obtain a low-cost coach fare that will accommodate the 
traveler’s needs. If the traveler chooses not to accept those flight arrangements, the OPTN will 
reimburse only up to the amount the approved OPTN travel agency would have paid.

---

## 20.2.B — Air Travel

<!-- Policy: 20 | Section: 20.2.B | Category: Travel Reimbursement -->

If the traveler has an unused airline ticket, the OPTN Contractor will attempt to use the ticket 
credit on a flight that meets the needs of the traveler. 
 
The OPTN will pay for additional fees resulting from airline ticket changes if the changes result 
from OPTN business. Travelers who request ticket changes for reasons unrelated to OPTN 
business will be responsible for all fees incurred. Changes in airline ticketing due to emergencies 
will be handled on a case-by-case basis. 

 
 
 
 
 
If a traveler requests to leave an OPTN event early and “standby” is available, then the traveler 
should go “standby.” If the traveler chooses to book a confirmed seat on an earlier flight, the 
traveler will be responsible for all fees incurred. Leaving early due to emergencies will be 
handled on a case by case basis. 
 
The approved OPTN Contractor travel agency will not book back-to-back tickets or round-trip 
airfares for a one-way trip. 
 
The OPTN will not reimburse first class airfare unless it is the same price as the low-cost coach 
fare. If the traveler chooses to fly first class, the traveler must pay the entire cost of the first 
class ticket and the OPTN would only reimburse the amount of the low cost coach fare.

---

## 20.2.C — International Travel

<!-- Policy: 20 | Section: 20.2.C | Category: Travel Reimbursement -->

The OPTN will approve international travel on a case-by-case basis.

---

## 20.3 — Hotel Reimbursement

<!-- Policy: 20 | Section: 20.3 | Category: Travel Reimbursement -->

The OPTN will reimburse overnight accommodations for the number of nights necessary to conduct 
OPTN business. When making this decision, the OPTN Contractor will take into account the distance 
between the departing and destination cities, time zones crossed, and the flights available to and from 
those cities.

---

## 20.4.A — Mileage

<!-- Policy: 20 | Section: 20.4.A | Category: Travel Reimbursement -->

The OPTN will reimburse mileage at the applicable IRS rate based on the dates travelled.

---

## 20.4.B — Transportation To and From the Airport

<!-- Policy: 20 | Section: 20.4.B | Category: Travel Reimbursement -->

The OPTN will reimburse all of the following costs: 
 
1. Transportation between the airport and the traveler’s home. 
2. Transportation between the airport and the meeting location. 
3. Parking fees at the airport from which the traveler departs. 
 
Travelers must use the least expensive, convenient option to travel to and from airports. The 
OPTN will not reimburse limousines unless the cost is shared with another traveler and the total 
cost to the OPTN is no more expensive than cab fare.

---

## 20.4.C — Rental Cars

<!-- Policy: 20 | Section: 20.4.C | Category: Travel Reimbursement -->

The OPTN will not reimburse rental cars if less expensive modes of travel are available. The 
traveler must elect rental car insurance coverage and must minimize additional rental car fees. If 
the traveler elects to rent a car when less expensive modes of travel are available, the OPTN will 
reimburse up to the amount of the estimated cab fare needed for the duration of the stay.

---

## 20.4.D — Provided Ground Transportation

<!-- Policy: 20 | Section: 20.4.D | Category: Travel Reimbursement -->

The OPTN will not reimburse the cost of any other ground transportation if the OPTN provides 
ground transportation between an airport and a meeting site and the person traveling could 
reasonably take advantage of this transportation.

---

## 20.5.A — Meal Cost

<!-- Policy: 20 | Section: 20.5.A | Category: Travel Reimbursement -->

The OPTN will reimburse individual meal costs during travel except when the traveler is present 
at the meeting location and a group breakfast, luncheon, or dinner is available at the same time 
as the individual meal. Individual breakfast and lunch costs must be reasonable.

---

## 20.5.B — Evening Meal Limitations

<!-- Policy: 20 | Section: 20.5.B | Category: Travel Reimbursement -->

The OPTN will reimburse evening meal costs up to $45. This limit includes the cost of the meal 
and gratuities. The OPTN will not reimburse costs exceeding this limit unless approved by the 
Assistant Executive Director level or above.

---

## 20.5.C — Alcoholic Beverages

<!-- Policy: 20 | Section: 20.5.C | Category: Travel Reimbursement -->

The OPTN will not reimburse any charges for alcoholic beverages. However, nothing in this 
Policy prohibits the OPTN Contractor from using private resources to pay for alcohol.

---

## 20.6.A — Telecommunication Charges

<!-- Policy: 20 | Section: 20.6.A | Category: Travel Reimbursement -->

The OPTN will reimburse OPTN business and personal phone calls of a reasonable length. The 
OPTN will reimburse Internet connection charges if the traveler is conducting OPTN business.

---

## 20.6.B — Other Reasonable Expenses

<!-- Policy: 20 | Section: 20.6.B | Category: Travel Reimbursement -->

The OPTN will reimburse reasonable, out-of-pocket expenses incurred as a direct result of 
traveling for OPTN business.

---

## 20.7 — Non-Reimbursable Expenses

<!-- Policy: 20 | Section: 20.7 | Category: Travel Reimbursement -->

The OPTN will not reimburse costs for in-room movies, valet parking, fitness center, dry 
cleaning, laundering, or any other personal charges. The OPTN will not reimburse charges 
incurred for personal travel days.

---

## 20.8.A — Expense Reimbursement Form

<!-- Policy: 20 | Section: 20.8.A | Category: Travel Reimbursement -->

To request reimbursement from the OPTN, the traveler must complete and submit an OPTN 
expense reimbursement form with original receipts. Off-site OPTN members may submit 
scanned copies of the original receipts. The traveler must sign the expense reimbursement form 
and must include all of the following information:  
 
1. Dates of travel 
2. Reason for travel 
3. Meeting location and name of event 
4. To whom the reimbursement check will be made payable 
5. The address to which the reimbursement will be sent 
6. The traveler’s phone number

---

## 20.8.B — Receipts

<!-- Policy: 20 | Section: 20.8.B | Category: Travel Reimbursement | Cross-ref: Policy 21 -->

The expense report must have original receipts for expenses attached. Off-site OPTN members 
may submit scanned copies of the original receipts. If one traveler has a meal receipt that 
includes other OPTN Contractor travelers, the receipt must include the names of all travelers. 

 
 
 
Policy 21: Composite Allocation Score Reference 
21.1 Formulas 
343 
21.2 Reference Values 
345

---
