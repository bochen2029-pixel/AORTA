# OPTN Policy 14: Living Donation

**Source:** OPTN Policies | **Effective:** 12/10/2025 | **Category:** Living Donation
**Confidence:** HIGH — Official OPTN policy language

---

## 14.1.A — Living Donor Psychosocial Evaluation Requirements

<!-- Policy: 14 | Section: 14.1.A | Category: Living Donation -->

The living donor psychosocial evaluation must be performed by a psychiatrist, psychologist, 
masters prepared social worker, or licensed clinical social worker prior to organ recovery. 
Documentation of the psychosocial evaluation must be maintained in the living donor medical 
record and include all of the following components: 
 
1. An evaluation for any psychosocial issues, including mental health issues, that might 
complicate the living donor’s recovery and could be identified as risks for poor psychosocial 
outcome. 
2. An assessment of risk criteria for acute HIV, HBV, and HCV infection according to the U.S. 
Public Health Service (PHS) Guideline. 
3. A review of the living donor’s history of smoking, alcohol, and drug use, including past or 
present substance abuse disorder. 
4. The identification of factors that warrant educational or therapeutic intervention prior to 
the final donation decision. 
5. The determination that the living donor understands the short and long-term medical and 
psychosocial risks for both the living donor and recipient associated with living donation. 
6. An assessment of whether the decision to donate is free of inducement, coercion, and other 
undue pressure by exploring the reasons for donating and the nature of the relationship, if 
any, to the transplant candidate. 
7. An assessment of the living donor’s ability to make an informed decision and the ability to 
cope with the major surgery and related stress. This includes evaluating whether the donor 
has a realistic plan for donation and recovery, with social, emotional and financial support 
available as recommended. 

 
 
 
8. A review of the living donor’s occupation, employment status, health insurance status, living 
arrangements, and social support. 
9. The determination that the living donor understands the potential financial implications of 
living donation.

---

## 14.2.A — ILDA Requirements for Living Donor Recovery Hospitals

<!-- Policy: 14 | Section: 14.2.A | Category: Living Donation -->

For any living donor who is undergoing evaluation for donation, the living donor recovery 
hospital must designate and provide each living donor with an ILDA who is not involved with the 
potential recipient evaluation and is independent of the decision to transplant the potential 
recipient. The ILDA may be one person or an ILDA team with multiple members. An ILDA team 
must designate one person from the team as the key contact for each living donor. All ILDA 
requirements must be completed prior to organ recovery. 
 
The ILDA must: 
 
1. Function independently from the transplant candidate’s team. 
2. Advocate for the rights of the living donor. 
3. Fulfill the qualification and training requirements specified in the recovery hospital’s 
protocols regarding knowledge of living organ donation, transplantation, medical ethics, 
informed consent, and the potential impact of family or other external pressure on the living 
donor’s decision about whether to donate.  
4. Review and document whether the living donor has received information on each of the 
following areas and assist the donor in obtaining additional information from other 
professionals as needed about the: 
a. 
Informed consent process as described in OPTN Policy 14.3: Informed Consent 
Requirements  
b. 
Evaluation process according to OPTN Policies 14.1.A: Living Donor Psychosocial 
Evaluation Requirements and 14.4.A: Living Donor Medical Evaluation Requirements 
c. 
Surgical procedure 
d. 
Follow-up requirements, and the benefit and need for participating in recovery 
hospital’s requirements according to OPTN Policies 18.1: Data Submission 
Requirements, 18.4: Living Donor Data Submission Requirements, and 18.5.B: 
Reporting of Living Donor Events by Recovery Hospitals

---

## 14.2.B — ILDA Protocols for Living Donor Recovery Hospitals

<!-- Policy: 14 | Section: 14.2.B | Category: Living Donation -->

The living donor recovery hospital must develop, and once developed must comply with, written 
protocols for:  
 
1. The composition of the ILDA team, if the hospital uses a team. 
2. The qualifications and training (both initial and ongoing) required for the ILDA. Minimum 
qualifications must include knowledge of living organ donation, transplantation, medical 
ethics, informed consent, and the potential impact of family or other external pressures on 
the potential living donor’s donation decision. Document that each requirement has been 
met. 
3. The duties and responsibilities of the ILDA, which must include at least the functions and 

 
 
 
duties according to OPTN Policy 14.2.A: ILDA Requirements for Living Donor Recovery 
Hospitals. 
4. The process the living donor recovery hospital will provide for the ILDA to file a grievance 
when necessary to protect the rights or best interests of the living donor.  
5. The process the living donor recovery hospital will use to address any grievance raised by 
the ILDA concerning the rights or best interests of the living donor.

---

## 14.3 — Informed Consent Requirements (Part 1)

<!-- Policy: 14 | Section: 14.3 | Category: Living Donation | Cross-ref: Policy 18 -->

The living donor recovery hospital is responsible for obtaining and documenting informed consent prior 
to organ recovery. Informed consent requirements must include all of the components in Tables 14-1 
through 14-5. Documentation of informed consent must be maintained in the living donor medical 
record. 

Table 14-1: Requirements for Living Donor Informed Consent 
The recovery 
hospital 
must:  
These elements of informed consent : 
Obtain from 
living donors 
The living donor’s signature on a document that confirms that the donor: 
1. Is willing to donate 
2. Is free from inducement and coercion  
3. Has been informed that he or she may decline to donate at any time 
Provide to 
living donors 
1. An opportunity to discontinue the living donor consent or evaluation process in a 
way that is protected and confidential. 
2. The ILDA must be available to assist the living donor during the consent process, 
according to OPTN Policy 14.2: Independent Living Donor Advocate (ILDA) 
Requirements. 
3. Instruction about all phases of the living donation process, which includes: 
• 
Consent 
• 
Medical and psychosocial evaluations 
• 
Pre- and post-operative care 
• 
Required post-operative follow-up according to OPTN Policy 18.4: Living Donor 
Data Submission Requirements. 

Teaching or instructional material can include any media, one-on-one or small group 
interaction. Teaching or instruction must be provided in a language in which the living 
donor is able to engage in meaningful dialogue with recovery hospital’s staff. 
Disclose to 
living donors 
1. It is a federal crime for any person to knowingly acquire, obtain or otherwise 
transfer any human organ for anything of value including, but not limited, to cash, 
property, and vacations. 
2. The recovery hospital must provide an ILDA. 
3. Alternate procedures or courses of treatment for the recipient, including 
deceased donor transplantation. 
4. A deceased donor organ may become available for the candidate before the 
recovery hospital completes the living donor’s evaluation or the living donor 
transplant occurs. 

The recovery 
hospital 
must:  
These elements of informed consent : 
5. Transplant hospitals determine candidacy for transplantation based on existing 
hospital specific guidelines or practices and clinical judgment.  
6. The recovery hospital will take all reasonable precautions to provide 
confidentiality for the living donor and recipient. 
7. Any transplant candidate may have an increased likelihood of adverse outcomes 
(including but not limited to graft failure, complications, and mortality) that: 
• 
Exceed local or national averages  
• 
Do not necessarily prohibit transplantation  
• 
Are not disclosed to the living donor 
8. The recovery hospital can disclose to the living donor certain information about 
candidates only with permission of the candidate, including:  
• 
The reasons for a transplant candidate’s increased likelihood of adverse 
outcomes 
• 
Personal health information collected during the transplant candidate’s 
evaluation, which is confidential and protected under privacy law 
9. Health information obtained during the living donor evaluation is subject to the 
same regulations as all medical records and could reveal conditions that must be 
reported to local, state, or federal public health authorities. 
10. The recovery hospital is required to: 
a. Report living donor follow-up information, at the time intervals specified in 
OPTN Policy 18.4: Living Donor Data Submission Requirements 
b. Have the donor commit to post donation follow-up testing coordinated by 
the recovery hospital. 
c. Obtain and store a living donor blood specimen for ten years, only to be used 
for investigation of potential donor-derived disease. 
11. Any infectious disease or malignancy that is pertinent to acute recipient care 
discovered during the donor’s first two years of follow-up care: 
a. May need to be reported to local, state or federal public health authorities 
b. Will be disclosed to their recipient’s transplant hospital 
c. Will be reported through the OPTN Improving Patient Safety Portal 
12. A living donor must undergo a medical evaluation according to OPTN Policy 14.4: 
Medical Evaluation Requirements for Living Donors and a psychosocial evaluation 
as required by OPTN Policy 14.1: Psychosocial Evaluation Requirements for Living 
Donors. 
13. The hospital may refuse the living donor. In such cases, the recovery hospital 
must inform the living donor that a different recovery hospital may evaluate the 
living donor using different selection criteria 
14. The following are inherent risks associated with evaluation for living donation: 
a. Allergic reactions to contrast 
b. Discovery of reportable infections 
c. Discovery of serious medical conditions 
d. Discovery of adverse genetic findings unknown to the living donor

---

## 14.3 — Informed Consent Requirements (Part 2)

<!-- Policy: 14 | Section: 14.3 | Category: Living Donation | Cross-ref: Policy 8 -->

The recovery 
hospital 
must:  
These elements of informed consent : 
e. Discovery of certain abnormalities that will require more testing at the living 
donor’s expense or create the need for unexpected decisions on the part of 
the transplant team 
15. There are surgical, medical, psychosocial, and financial risks associated with 
living donation, which may be temporary or permanent and include, but are 
not limited to, all of the following: 
a. Potential medical or surgical risks: 
i. Death 
ii. Scars, hernia, wound infection, blood clots, pneumonia, nerve injury, 
pain, fatigue, and other consequences typical of any surgical procedure 
iii. Abdominal symptoms such as bloating, nausea, and developing bowel 
obstruction 
iv. That the morbidity and mortality of the living donor may be impacted 
by age, obesity, hypertension, or other donor-specific pre-existing 
conditions 
b. Potential psychosocial risks: 
i. Problems with body image 
ii. Post-surgery depression or anxiety 
iii. Feelings of emotional distress or grief if the transplant recipient 
experiences any recurrent disease or if the transplant recipient dies 
iv. Changes to the living donor’s lifestyle from donation 
c. Potential financial impacts: 
i. Personal expenses of travel, housing, child care costs, and lost wages 
related to donation might not be reimbursed; however, resources 
might be available to defray some donation-related costs 
ii. Need for life-long follow up at the living donor’s expense 
iii. Loss of employment or income 
iv. Negative impact on the ability to obtain future employment 
v. Negative impact on the ability to obtain, maintain, or afford health 
insurance, disability insurance, and life insurance 
vi. Future health problems experienced by living donors following 
donation may not be covered by the recipient’s insurance 

Table 14-2: Additional Requirements for the Informed Consent of Living Kidney Donors 
The recovery 
hospital must: 
These additional elements as components of informed consent for living 
kidney donors: 
Provide to all 
living kidney 
donors 
Education about expected post-donation kidney function, and how chronic kidney 
disease (CKD) and end-stage renal disease (ESRD) might potentially impact the 
living donor in the future, to include: 
a. On average, living donors will have a 25-35% permanent loss of kidney 
function after donation. 

The recovery 
hospital must: 
These additional elements as components of informed consent for living 
kidney donors: 
b. Although risk of ESRD for living kidney donors does not exceed that of the 
general population with the same demographic profile, risk of ESRD for living 
kidney donors may exceed that of healthy non-donors with medical 
characteristics similar to living kidney donors. 
c. Living donor risks must be interpreted in light of the known epidemiology of 
both CKD and ESRD. When CKD or ESRD occurs, CKD generally develops in mid-
life (40-50 years old) and ESRD generally develops after age 60. The medical 
evaluation of a young living donor cannot predict lifetime risk of CKD or ESRD. 
d. Living donors may be at a higher risk for CKD if they sustain damage to the 
remaining kidney. The development of CKD and subsequent progression to 
ESRD may be faster with only one kidney. 
e. Dialysis is required if the living donor develops ESRD. 
f. 
Current practice is to prioritize prior living kidney donors who become kidney 
transplant candidates according to OPTN Policy 8.2: Kidney Allocation Score. 
Disclose to all 
living kidney 
donors 
Surgical risks may be transient or permanent and include but are not limited to: 
• Decreased kidney function 
• Acute kidney failure and the need for dialysis or kidney transplant for the living 
donor in the immediate post-operative period 
Disclose to all 
female living 
kidney donors 
Risks of preeclampsia or gestational hypertension are increased in pregnancies 
after donation 
Disclose to all 
living kidney 
donors with HIV 
The potential impact on their health and the long-term outcomes associated with 
donating an organ while living with HIV is unknown 

Table 14-3: Additional Requirements for the Informed Consent of Living Liver Donors 
The recovery hospital 
must: 
These additional elements as components of informed consent for living 
liver donors: 
Disclose to all living 
liver donors 
Surgical risks may be transient or permanent and include but are not limited 
to: 
• 
Acute liver failure with need for liver transplant. 
• 
Transient liver dysfunction with recovery. The potential for transient liver 
dysfunction depends upon the amount of the total liver removed for 
donation. 
• 
Risk of red cell transfusions or other blood products. 
• 
Biliary complications, including leak or stricture that may require 
additional intervention. 
• 
Post-donation laboratory tests may result in abnormal or false positive 
results that may trigger additional tests that have associated risks. 
Disclose to all living 
liver donors with HIV 
The potential impact on their health and the long-term outcomes associated 
with donating an organ while living with HIV is unknown

---

## 14.3 — Informed Consent Requirements (Part 3)

<!-- Policy: 14 | Section: 14.3 | Category: Living Donation -->

Table 14-4: Additional Requirements for the Informed Consent of Living Donors of Covered 
VCAs 
The recovery 
hospital must: 
These additional elements as components of informed consent for living 
VCA donors: 
Disclose to all 
living donors of 
covered VCAs 
other than 
covered 
genitourinary 
organ VCAs 
There are surgical, psychosocial, and financial risks associated with living 
donation of covered non-genitourinary VCAs, which may be temporary or 
permanent and include, but are not limited to, all of the following: 
• 
Potential surgical risks: 
• 
Loss of function 
• 
Physical disability 
• 
Physical disfigurement 
• 
Potential psychosocial risk: Feelings of emotional distress or grief if the 
transplant recipient does not experience a successful functional or 
cosmetic outcome 
• 
Potential financial impacts: Procedure may not be covered by health 
insurance 
Disclose to all 
living donors of 
covered 
genitourinary 
organ VCAs 
There are surgical, psychosocial, and financial risks associated with living 
donation of covered genitourinary VCAs, which may be temporary or 
permanent and include, but are not limited to, all of the following: 
• 
Potential surgical risks: 
• 
Bowel injury 
• 
Need for hormonal replacement therapy 
• 
Pain or discomfort with intercourse 
• 
Partial or complete loss of organ-specific function including 
reproductive function 
• 
Physical disfigurement 
• 
Urinary tract injury or dysfunction 
• 
Potential psychosocial risk: Feelings of emotional distress or grief if the 
transplant recipient does not experience a successful functional, cosmetic, 
or reproductive outcome 
• 
Potential financial impacts: Procedure may not be covered by health 
insurance 

As part of the informed consent process, recovery hospitals must also provide transplant recipient 
outcome and transplanted organ survival data to living donors according to Table 14-5. The 
requirements in Table 14-5 do not apply to donors of covered VCAs. 

Table 14-5: Required Recipient Outcome and Transplanted Organ Survival Data 
If the recovery 
hospital and the 
recipient 
hospital: 
Then the recovery hospital 
must provide the living donor 
with: 
Including all the following information: 
Are the same 
Both national and that 
hospital’s program-specific 
transplant recipient outcomes 
from the most recent Scientific 
Registry of Transplant 
Recipients (SRTR) program-
specific reports. 
• 
National 1-year patient and transplanted 
organ survival 
• 
The 
hospital’s 
1-year 
patient 
and 
transplanted organ survival 
• 
Notification about all Centers for Medicare 
and Medicaid Services (CMS) outcome 
requirements not being met by the transplant 
hospital 
Will not be the 
same and the 
recipient hospital 
is known 
Both national and the recipient 
hospital’s program-specific 
transplant recipient outcomes 
from the most recent SRTR 
program-specific reports. 
• 
National 1-year patient and transplanted 
organ survival 
• 
The recipient hospital’s 1-year patient and 
transplanted organ survival 
• 
Notification 
about 
all 
CMS 
outcome 
requirements not being met by the recipient 
hospital 
Will not be the 
same and the 
recipient hospital 
is not known 
National transplant recipient 
outcomes from the most recent 
SRTR reports. 
• 
National 1-year patient and transplanted 
organ survival

---

## 14.4.A — Living Donor Medical Evaluation Requirements

<!-- Policy: 14 | Section: 14.4.A | Category: Living Donation -->

A medical evaluation of the living donor must be performed by the recovery hospital and by a 
physician or surgeon experienced in living donation. Documentation of the medical evaluation 
must be maintained in the donor medical record.  
 
The medical evaluation must include all of the components in Tables 14-6 through 14-10 below. 
 

 
 
 
Table 14-6: Requirements for Living Donor Medical Evaluations 
This 
evaluation 
must be 
completed: 
Including evaluation for and assessment of this information: 
General donor history 
1. A personal history of significant medical conditions which include but are 
not limited to:  
a. Hypertension 
b. Diabetes 
c. Lung disease 
d. Heart disease 
e. Gastrointestinal disease 
f. Autoimmune disease 
g. Neurologic disease 
h. Genitourinary disease 
i. 
Hematologic disorders 
j. 
Bleeding or clotting disorders 
k. History of cancer including melanoma 
2. History of infections 
3. Active and past medications with special consideration for known 
nephrotoxic and hepatotoxic medications or chronic use of pain 
medication 
4. Allergies 
5. An evaluation for coronary artery disease 
General 
family 
history 
• 
Coronary artery disease 
• 
Cancer 
Social history 
• 
Occupation 
• 
Employment status 
• 
Health insurance status 
• 
Living arrangements 
• 
Social support 
• 
Smoking, alcohol and drug use and abuse  
• 
Psychiatric illness, depression, suicide attempts  
• 
Risk criteria for acute HIV, HBV, and HCV infection according to the U.S. 
Public Health Services (PHS) Guideline 
Physical Exam 
• 
Height 
• 
Weight 
• 
BMI 
• 
Vital signs 
• 
Examination of all major organ systems 

 
 
 
This 
evaluation 
must be 
completed: 
Including evaluation for and assessment of this information: 
General laboratory and imaging 
tests 
• 
Complete blood count (CBC) with platelet count 
• 
Blood type and subtype as specified in OPTN Policy 14.5: Living Donor 
Blood Type Determination and Reporting and its subsections  
• 
Prothrombin Time (PT) or International Normalized Ratio (INR) 
• 
Partial Thromboplastin Time (PTT) 
• 
Metabolic testing (to include electrolytes, BUN, creatinine, 
transaminase levels, albumin, calcium, phosphorus, alkaline 
phosphatase, bilirubin) 
• 
HCG quantitative pregnancy test for premenopausal women without 
surgical sterilization 
• 
Chest X-Ray 
• 
Electrocardiogram (ECG) 
Transmissible disease screening 
Infectious disease testing must be performed in a CLIA-certified laboratory 
or in a laboratory meeting equivalent requirements as determined by 
Centers for Medicare and Medicaid Services (CMS) using FDA-licensed, 
approved, or cleared tests. Testing must include all the following:  
 
1. CMV (Cytomegalovirus) antibody 
2. EBV (Epstein Barr Virus) antibody 
3. HIV antibody (anti-HIV) testing or HIV antigen/antibody (Ag/Ab) 
combination test as close as possible, but within 28 days prior to organ 
recovery 
4. HIV ribonucleic acid (RNA) by nucleic acid test (NAT) as close as possible, 
but within 28 days prior to organ recovery 
5. Hepatitis B surface antigen (HBsAg) testing as close as possible, but 
within 28 days prior to organ recovery 
6. Hepatitis B core antibody (total anti-HBc) testing as close as possible, but 
within 28 days prior to organ recovery 
7. HBV deoxyribonucleic acid (DNA) by nucleic acid test (NAT) as close as 
possible, but within 28 days prior to organ recovery 
8. Hepatitis C antibody (anti-HCV) testing as close as possible, but within 28 
days prior to organ recovery 
9. HCV ribonucleic acid (RNA) by nucleic acid test (NAT) as close as possible, 
but within 28 days prior to organ recovery 
10. Syphilis testing 
 
For tuberculosis (TB), living donor recovery hospitals must determine if the 
donor is at increased risk for this infection. If TB risk is suspected, testing 
must include screening for latent infection using either: 
 
• 
Intradermal PPD  
• 
Interferon Gamma Release Assay (IGRA) 

 
 
 
This 
evaluation 
must be 
completed: 
Including evaluation for and assessment of this information: 
Endemic 
transmissible 
diseases 
Each living donor hospital must develop and follow a written protocol for 
identifying and testing donors at risk for transmissible seasonal or 
geographically defined endemic disease as part of its medical evaluation. 
Cancer screening 
Recovery hospitals must develop and comply with protocols consistent with 
the American Cancer Society (ACS) or the U.S. Preventive Services Task 
Force to screen for:  
 
• 
Cervical cancer  
• 
Breast cancer  
• 
Prostate cancer  
• 
Colon cancer  
• 
Lung cancer

---

## 14.4.B — Additional Requirements for the Medical Evaluation of Living Kidney

<!-- Policy: 14 | Section: 14.4.B | Category: Living Donation -->

Donors  
Table 14-7: Additional Requirements for the Medical Evaluation of Living Kidney Donors 
This evaluation must 
be completed: 
Including evaluation for and assessment of this information: 
Kidney - specific donor 
history 
A personal history of significant medical conditions which include, 
but are not limited to, kidney-specific personal history including: 
a. Genetic renal diseases 
b. Kidney disease, proteinuria, hematuria 
c. Kidney injury 
d. Diabetes including gestational diabetes 
e. Nephrolithiasis 
f. Recurrent urinary tract infections 
Kidney-
specific 
family 
history 
• 
Kidney disease 
• 
Diabetes 
• 
Hypertension 
• 
Kidney Cancer 
Physical 
Exam 
• 
Blood pressure taken on at least two different occasions or 24-
hour or overnight blood pressure monitoring 

 
 
 
This evaluation must 
be completed: 
Including evaluation for and assessment of this information: 
Other 
metabolic 
testing 
• 
Fasting blood glucose 
• 
Fasting lipid profile (cholesterol, triglycerides, HDL cholesterol, 
and LDL cholesterol) 
• 
Glucose tolerance test or glycosylated hemoglobin in first 
degree relatives of diabetics and in high risk individuals 
Kidney-specific tests 
• 
Urinalysis or urine microscopy 
• 
Urine culture if clinically indicated 
• 
Measurement of urinary protein and albumin excretion 
• 
Measurement of glomerular filtration rate by isotopic methods 
or a creatinine clearance calculated from a 24-hour urine 
collection 
• 
Hospitals must develop and comply with a written protocol for 
polycystic kidney disease or other inherited renal disease as 
indicated by family history 
• 
Patients with a history of nephrolithiasis or nephrolithiasis (>3 
mm) identified on radiographic imaging must have a 24-hour 
urine stone panel measuring: 
o Calcium 
o Oxalate 
o Uric acid 
o Citric acid 
o Creatinine 
o Sodium 
Anatomic 
assessment 
Determine: 
• 
Whether the kidneys are of equal size 
• 
If the kidneys have masses, cysts, or stones 
• 
If the kidneys have other anatomical defects 
• 
Which kidney is more anatomically suited for transplant

---

## 14.4.C — Additional Requirements for the Medical Evaluation of Living Liver Donors

<!-- Policy: 14 | Section: 14.4.C | Category: Living Donation -->

Table 14-8: Additional Requirements for the Medical Evaluation of Living Liver Donors 
This evaluation must be 
completed: 
Including evaluation for and assessment of this information: 
Liver- specific 
family history 
• 
Liver diseases 
• 
Bleeding or clotting disorders 

 
 
 
This evaluation must be 
completed: 
Including evaluation for and assessment of this information: 
General 
laboratory and 
imaging tests 
• 
Hospitals must develop and follow a written protocol for 
hypercoagulable state evaluation 
Liver-specific tests 
• 
Hepatic function panel 
• 
Ceruloplasmin in a donor with a family history of Wilson’s 
Disease 
• 
Iron, iron binding capacity, ferritin 
• 
Alpha-1-antitrypsin level: those with a low alpha-1-antitrypsin 
levels should have a phenotype 
• 
must develop and follow a written protocol for testing for 
genetic diseases 
• 
Hospitals must develop and follow a written protocol for 
screening for autoimmune disease 
• 
Hospitals must develop and follow a written protocol for pre-
donation liver biopsy 
Anatomic assessment 
A radiological assessment must be performed to determine if the 
liver is anatomically suitable for transplantation, and to assess 
safety of resection for the donor. 
The evaluation must include at least all of the following: 
• 
Assessment of projected graft volume 
• 
Donor’s remnant volume, 
• 
Vascular anatomy 
• 
Presence of steatosis

---

## 14.4.D — Additional Requirements for the Medical Evaluation of Living Donors of

<!-- Policy: 14 | Section: 14.4.D | Category: Living Donation -->

Covered VCAs 
Table 14-9: Additional Requirements for the Medical Evaluation of Living Donors of Covered VCAs  
This evaluation must be 
completed: 
For living donors 
of these organs: 
Including evaluation for and assessment of this 
information: 
Transmissible disease 
screening 
All covered VCAs 
Infectious disease testing must be performed in a 
CLIA-certified laboratory or in a laboratory meeting 
equivalent requirements as determined by CMS using 
FDA-licensed, approved, or cleared tests. Testing must 
include all of the following: 
• 
Toxoplasma Immunoglobulin G (IgG) antibody 
test 
Additional specific 
medical history 
Uterus 
• 
Gynecological and obstetric history including prior 
childbirth 

 
 
 
This evaluation must be 
completed: 
For living donors 
of these organs: 
Including evaluation for and assessment of this 
information: 
Additional specific 
tests 
Uterus 
• 
Pap smear 
Additional anatomic 
assessment 
Uterus 
• 
Pelvic exam 
• 
A radiological assessment must be performed to 
determine if the uterus is anatomically suitable for 
transplantation 
Additional 
transmissible disease 
screening 
Uterus 
Infectious disease testing must be performed in a 
CLIA-certified laboratory or in a laboratory meeting 
equivalent requirements as determined by CMS using 
FDA-licensed, approved, or cleared tests. Testing must 
include all of the following: 
• 
Bacterial Vaginosis (Gardnerella Vaginalis) 
• 
Chlamydia by nucleic acid test (NAT) 
• 
Gonorrhea by nucleic acid test (NAT) 
• 
Herpes Simplex Virus (HSV) 1/2 
Immunoglobulin G (IgG) antibody test 
• 
Human Papilloma Virus (HPV) cervical 
specimen only by DNA or mRNA 
• 
Trichomoniasis 
• 
Fungal screening to include Vaginal 
Candidiasis (at evaluation and time of 
donation)

---

## 14.4.E — Living Donor Exclusion Criteria

<!-- Policy: 14 | Section: 14.4.E | Category: Living Donation | Cross-ref: Policy 15 -->

Table 14-10: Living Donor Exclusion Criteria 
Exclusion criteria for all Living Donors 
Living donor recovery hospitals may exclude a donor with any condition that, in 
the hospital’s medical judgment, causes the donor to be unsuitable for organ 
donation. 
 
Living donor recovery hospitals must exclude all donors who meet any of the 
following exclusion criteria: 
• 
Is both less than 18 years old and mentally incapable of making an informed 
decision 
• 
Living with HIV, and 
o the living donor is donating a non-kidney or non-liver organ and 
o the requirements for a variance are not met, according to Policy 
15.7: Open Variance for the Recovery and Transplantation of Organs 
from Donors with HIV 
• 
Active malignancy, or incompletely treated malignancy that either 
o requires treatment other than surveillance or 
o has more than minimal known risk of transmission 
• 
High suspicion of donor inducement, coercion, or other undue pressure 
• 
High suspicion of knowingly and unlawfully acquiring, receiving, or otherwise 
transferring anything of value in exchange for any human organ 
• 
Evidence of acute symptomatic infection (until resolved) 
• 
Uncontrolled diagnosable psychiatric conditions requiring treatment before 
donation, including any evidence of suicidality 
Additional Exclusion 
Criteria for Living Kidney 
Donors 
Kidney recovery hospitals must exclude all donors who meet any of the 
following additional exclusion criteria: 
• 
Uncontrollable hypertension or history of hypertension with evidence of 
end organ damage 
• 
Type 1 diabetes 
• 
Type 2 diabetes where an individualized assessment of donor demographics 
or comorbidities reveals either 
o evidence of end organ damage or 
o unacceptable lifetime risk of complications 
Additional Exclusion  
Criteria for Living  
Liver Donors 
Liver recovery hospitals must exclude all donors who meet any of the following 
additional exclusion criteria: 
• 
HCV RNA positive 
• 
HBsAg positive 
• 
Donors with ZZ, Z-null, null-null and S-null alpha-1-antitrypsinphenotypes 
and untype-able phenotypes 
• 
Expected donor remnant volume less than 30% of native liver volume 
• 
Prior living liver donor

---

## 14.5 — Living Donor Blood Type Determination and Reporting

<!-- Policy: 14 | Section: 14.5 | Category: Living Donation -->

Recovery hospitals must develop and comply with a written protocol for blood type determination and 
reporting that includes all of the requirements below.

---

## 14.5.A — Living Donor Blood Type Determination

<!-- Policy: 14 | Section: 14.5.A | Category: Living Donation -->

The recovery hospital must ensure that each living donor’s blood type is determined by testing 
at least two donor blood samples prior to generation of the living donor ID. 
 
Living donor blood samples must: 
 
1. Be drawn on two separate occasions 
2. Have different collection times 
3. Be submitted as separate samples 
 
The recovery hospital must include a process to address conflicting or indeterminate primary 
blood type results in their written protocol. 
 
The recovery hospital must document that blood type determination was conducted according 
to the hospital’s protocol and the above requirements.

---

## 14.5.B — Living Donor Blood Subtype Determination

<!-- Policy: 14 | Section: 14.5.B | Category: Living Donation -->

Subtyping is optional for living donors. 
 
If the recovery hospital chooses to subtype and pre-red blood cell transfusion samples are 
available, then subtyping must be completed according to Table 14-11. 
 
Table 14-11: Subtyping Requirements by First Subtype Result 
If the donor’s primary 
blood type is: 
A second subtyping must be completed if the first subtype 
result is:  
A 
Blood type A, non-A1  
AB 
Blood type AB, non-A1B 
 
Living donor blood samples for subtyping must: 
 
1. Be tested using pre-red blood cell transfusion samples 
2. Be drawn on two separate occasions 
3. Have different collection times 
4. Be submitted as separate samples 
 
 

 
 
 
All subtype results reported to the OPTN must be from two separate tests indicating the same 
result. If there are conflicting or indeterminate subtype results, the subtype results must not be 
reported to the OPTN and living donor transplant compatibility or allocation must be based on 
the primary blood type. 
If subtype is determined and reported, the recovery hospital must document that subtyping was 
conducted according to the above requirements.

---

## 14.5.C — Reporting of Living Donor Blood Type and Subtype

<!-- Policy: 14 | Section: 14.5.C | Category: Living Donation -->

The recovery hospital must report and verify the living donor blood type prior to registration 
with the OPTN using the Living Donor Feedback Form as required below: 
 
1. Two different qualified health care professionals, as defined in the recovery hospital’s 
protocol, must each make an independent report to the OPTN for blood type. 
2. If blood subtype is used for ensuring transplant compatibility or allocation, a qualified health 
care professional must report blood subtype to the OPTN. This report must be verified by a 
different qualified health care professional according to the recovery hospital’s protocol. 
3. Both qualified health care professionals must use all known available blood type and 
subtype determination source documents to verify they: 
a. Contain blood type and subtype (if used for ensuring transplant compatibility or 
allocation) results for the donor 
b. Indicate the same blood type and subtype (if used for ensuring transplant compatibility 
or allocation) on the test results. If the results are conflicting or indeterminate, the 
recovery hospital must refer to their written protocol as outlined in OPTN Policy 14.5.A: 
Living Donor Blood Type Determination. 
c. Match the result reported to the OPTN 
 
The recovery hospital must document that reporting was completed according to the hospital’s 
protocol and the above requirements.

---

## 14.6.A — Prospective Crossmatching prior to Kidney Placement

<!-- Policy: 14 | Section: 14.6.A | Category: Living Donation | Cross-ref: Policy 4 -->

A prospective crossmatch is mandatory for all potential kidney living donor recipients. 
Guidelines for policy development, including assigning risk and timing of crossmatch testing, are 
outlined in Policy 4: Histocompatibility.

---

## 14.6.B — Placement of Non-directed Living Donor Organs

<!-- Policy: 14 | Section: 14.6.B | Category: Living Donation -->

Prior to determining the placement of a non-directed living donor organ, including non-directed 
organs from domino donors and non-domino therapeutic organ donors, the recovery hospital 
must obtain the match run of its waiting list candidates from its local OPO or the Organ Center. 
When a non-directed living donor organ is placed, the recovery hospital must document how the 
organ is placed and the rationale for placement. 
 
This requirement does not apply to non-directed living kidney donors who donate a kidney 
through a Kidney Paired Donation (KPD) arrangement.

---

## 14.6.C — Transplant Hospital Acceptance of Living Donor Organs

<!-- Policy: 14 | Section: 14.6.C | Category: Living Donation -->

A transplant hospital must only accept and transplant living donor organs according to Table 14-
12 below. 
 
Table 14-12: Transplant Hospital Requirements for Accepting and Transplanting  
Living Donor Organs 
If this type of living donor organ is 
being recovered: 
Then the recovery hospital must: 
Kidney 
Meet the requirements according to the OPTN 
Management and Membership Policy E.6: Kidney 
Transplant Programs that Perform Living Donor 
Recovery 
Liver 
Meet the requirements according to the OPTN 
Management and Membership Policy F.8: Liver 
Transplant Programs that Perform Living Donor 
Recovery 
Other organ types, excluding kidney or 
liver 
Have current designated transplant program 
approval for that organ type

---

## 14.7 — Living Donor Pre-Recovery Verification

<!-- Policy: 14 | Section: 14.7 | Category: Living Donation -->

Recovery hospitals must develop and comply with a written protocol to perform pre-recovery 
verifications as required below. 
 
The recovery hospital must conduct a pre-recovery verification that meets all of the following 
requirements: 
 
1. The verification must occur prior to the induction of general anesthesia on the day of the living 
donor recovery.  
2. Recovery hospitals must use at least one of the acceptable sources during the pre-recovery 
verification to verify all of the following information according to Table 14-13 below. Recovery 
hospitals may use the OPTN organ tracking system for assistance in completing these verifications. 
 
 

 
 
 
Table 14-13: Pre-Recovery Verification Requirements 
The recovery hospital must 
verify all of the following 
information: 
Using at least one of the 
following: 
By both of the following 
individuals: 
Donor ID 
• Donor identification band 
containing the donor ID 
• Donor identification band and 
OPTN computer system 
1. Recovery surgeon 
2. Licensed health care 
professional 
Organ type and laterality (if 
applicable) 
• OPTN computer system 
1. Recovery surgeon 
2. Licensed health care 
professional 
Donor blood type and subtype 
(if used for ensuring transplant 
compatibility or allocation) 
• Donor blood type and subtype 
source documents 
1. Recovery surgeon 
2. Licensed health care 
professional 
Intended recipient unique 
identifier 
• Recipient medical record 
• OPTN computer system 
1. Recovery surgeon 
2. Licensed health care 
professional 
Intended recipient blood type 
• Recipient medical record 
• OPTN computer system 
1. Recovery surgeon 
2. Licensed health care 
professional 
Donor and intended recipient 
are blood type compatible (or 
intended incompatible). 
• OPTN computer system 
• Recipient medical record 
• Attestation following 
verification of donor and 
recipient blood types 
1. Recovery surgeon 
2. Licensed health care 
professional 
Correct donor organ has been 
identified for the correct 
intended recipient 
• Donor medical record 
• OPTN computer system 
• Attestation following 
verification of donor ID, organ, 
and recipient unique identifier 
1. Recovery surgeon 
2. Licensed health care 
professional 
 
The recovery hospital must document that the verification was completed according to the hospital’s 
protocol and the above requirements.

---

## 14.8 — Packaging, Labeling, and Transporting of Living Donor Organs,

<!-- Policy: 14 | Section: 14.8 | Category: Living Donation | Cross-ref: Policy 16 -->

Extra Vessels, and Tissue Typing Materials  
Recovery hospitals are responsible for packaging and labeling any living donor organs or tissue typing 
specimens that are recovered from living donors according to OPTN Policy 16: Organ and Extra Vessels 
Packaging, Labeling, Shipping, and Storage when either of the following occurs: 
• 
Living donor organs or tissue typing specimens are recovered and must be transported outside the 
recovery hospital 
• 
Living donor organs or tissue typing specimens require repackaging by a transplant hospital for 
transport outside the transplant hospital

---

## 14.8.A — Living Donor Extra Vessels Recovery and Storage

<!-- Policy: 14 | Section: 14.8.A | Category: Living Donation | Cross-ref: Policy 16 -->

A recovery hospital must only recover extra vessels for transplant if the living donor consents 
to the removal of extra vessels for transplant. The extra vessels from a living donor must only 
be used for the implantation or modification of a solid organ transplant for the original intended 
recipient.  
 
Any extra vessels recovered from living donors must be stored according to OPTN Policy 16.6.B: 
Extra Vessels Storage.

---

## 14.8.B — Living Donor Specimen Collection and Storage

<!-- Policy: 14 | Section: 14.8.B | Category: Living Donation -->

The recovery hospital must obtain specimens appropriate for serological and NAT testing within 
24 hours prior to organ recovery. The recovery hospital is responsible for arranging storage of 
these specimens for at least 10 years after the date of transplant and ensuring these samples 
are available for retrospective testing. The recovery hospital must document the type of sample 
in the living donor medical record.

---

## 14.9 — Requirements for Domino Donors and Non-Domino Therapeutic

<!-- Policy: 14 | Section: 14.9 | Category: Living Donation -->

Donors  
Although domino donors and non-domino therapeutic donors are considered living donors, the 
requirements in OPTN Policy 14: Living Donation are limited only to Policies 14.9 A through 14.9 E below 
for domino donors and non-domino therapeutic donors.

---

## 14.9.A — Informed Consent Requirements for Domino Donors and Non-Domino

<!-- Policy: 14 | Section: 14.9.A | Category: Living Donation -->

Therapeutic Donors 
Recovery hospitals must obtain the donor’s signature on a document that confirms that the 
donor: 
 
1. Is willing to donate 
1. Is free from inducement and coercion 
2. Has been informed that the donor may decline to donate at any time 
3. Has received information on treatment options that would not involve organ donation 
 

 
 
 
Recovery hospitals must also provide all of the following to domino donors and non-domino 
therapeutic donors: 
 
1. The disclosure that the recovery hospital will take all reasonable precautions to provide 
confidentiality for the donor and recipient 
2. The disclosure that it is a federal crime for any person to knowingly acquire, obtain, or 
otherwise transfer any human organ for anything of value including, but not limited to, cash, 
property, and vacations. 
3. The disclosure that health information obtained during the evaluation for donation is 
subject to the same regulations as all health records and could reveal conditions that must 
be reported to local, state, or federal public health authorities. 
4. The disclosure that any new information discovered during the domino donor’s or non-
domino therapeutic donor’s first two years of post-donation care that indicates risk of 
potential transmission of infectious disease or malignancy to the recipient of the domino 
donor’s or non-domino therapeutic donor’s native organ: 
a. May need to be reported to local, state, or federal public health authorities 
b. Will be disclosed to the recipient’s transplant hospital 
c. Will be reported through the OPTN Improving Patient Safety Portal 
5. Information on treatment options that would not involve organ donation. 
6. An opportunity to discontinue the donor consent or evaluation process in a way that is 
protected and confidential. 
 
Documentation of the informed consent must be maintained in the donor medical record.

---

## 14.9.B — Psychosocial and Medical Evaluation Requirements for Domino and Non-

<!-- Policy: 14 | Section: 14.9.B | Category: Living Donation -->

Domino Therapeutic Donors  
Recovery hospitals must evaluate domino donors and non-domino therapeutic donors according 
to all of the following requirements: 
 
1. Perform an assessment for risk criteria for acute HIV, HBV, and HCV infection according to 
the U.S. Public Health Service (PHS) Guideline 
2. Screen the domino donor or non-domino therapeutic donor for all of the following 
according to OPTN Policy 14.4: Medical Evaluation Requirements for Living Donors, Table 14-
6: Requirements for Living Donor Medical Evaluations: 
a. Transmissible diseases screening 
b. Endemic transmissible diseases 
c. Cancer screening 
3. Develop and comply with written protocols for the domino donor and non-domino 
therapeutic donor exclusion criteria considering incorporating as appropriate the elements 
of Table 14-10: Living Donor Exclusion Criteria 
 
4. Register and verify the blood type of the domino donor or non-domino therapeutic donor 
according to OPTN Policy 14.5: Living Donor Blood Type Determination and Reporting 
 
Documentation of the psychosocial and medical evaluation must be maintained in the donor 
medical record.

---

## 14.9.C — Recovery of Domino Donor and Non-Domino Therapeutic Donor Organs

<!-- Policy: 14 | Section: 14.9.C | Category: Living Donation -->

Transplant hospitals can recover domino donor and non-domino therapeutic donor organs if the 
hospital has current designated transplant program approval for that organ type.

---

## 14.9.D — Acceptance of Domino Donor and Non-Domino Therapeutic Donor Organs

<!-- Policy: 14 | Section: 14.9.D | Category: Living Donation -->

Transplant hospitals must only accept domino donor and non-domino therapeutic donor organs 
recovered at transplant hospitals that have a current designated transplant program approval 
for that organ type.

---

## 14.9.E — Reporting and Data Submission Requirements for Domino Donors and Non-

<!-- Policy: 14 | Section: 14.9.E | Category: Living Donation | Cross-ref: Policy 18 -->

Domino Therapeutic Donors  
Recovery hospitals must submit the living donor feedback and living donor registration (LDR) 
forms for the domino donor and non-domino therapeutic donor according to OPTN Policy 18.1: 
Data Submission Requirements.

---

## 14.10 — Living Donor Organ Check-In

<!-- Policy: 14 | Section: 14.10 | Category: Living Donation | Cross-ref: Policy 5 -->

Transplant hospitals must perform organ check-ins as required by OPTN Policy 5.7: Organ Check-In.

---

## 14.11 — Living Donor Pre-Transplant Verification

<!-- Policy: 14 | Section: 14.11 | Category: Living Donation | Cross-ref: Policy 5 -->

Transplant hospitals must perform pre-transplant verifications as required by OPTN Policy 5.8: Pre-
Transplant Verification.

---

## 14.12 — Reporting Requirements

<!-- Policy: 14 | Section: 14.12 | Category: Living Donation | Cross-ref: Policy 15, Policy 18 -->

Members are responsible for submitting living donor forms according to OPTN Policy 18.4: Living Donor 
Data Submission Requirements. 
 

OPTN Policies                                                                                                              Policy 15: Identification of Transmissible Diseases 
 
 
Policy 15:  Identification of Transmissible Diseases  
15.1 Patient Safety Contact 
305 
15.2 Candidate Pre-Transplant Infectious Disease Reporting and Testing Requirements 
305 
15.3 Informed Consent of Transmissible Disease Risk 
306 
15.4 Host OPO Requirements for Reporting Post-Procurement Test Results and Discovery of Potential 
Disease Transmissions 
308 
15.5 Transplant Program Requirements for Communicating  Discovery of Potential Transmission of 
Unexpected Pathogen, Disease or Malignancy 
310 
15.6 Living Donor Recovery Hospital Requirements for Reporting Post-Donation Discovery of Disease or 
Malignancy 
312 
15.7 Recovery and Transplantation of Organs from  Donors with HIV 
313

---
