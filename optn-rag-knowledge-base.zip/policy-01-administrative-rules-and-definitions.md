# OPTN Policy 1: Administrative Rules and Definitions

**Source:** OPTN Policies | **Effective:** 12/10/2025 | **Category:** Administrative
**Confidence:** HIGH — Official OPTN policy language

---

## 1.1 — Rules of Construction

<!-- Policy: 1 | Section: 1.1 | Category: Administrative -->

The rules and definitions set forth in this Policy apply to all OPTN Policies. 
 
1.1.A 
Time 
A day ends at midnight Eastern Standard Time (EST).

---

## 1.1.B — Headings, Notes, and History

<!-- Policy: 1 | Section: 1.1.B | Category: Administrative -->

All headings, notes, and history sections of these Policies are intended only as guidance and to 
supplement the OPTN Policies and are not part of the Policies. These sections and headings are 
nonbinding to members and should not be treated as policy or used to infer the intent of the 
Policies.

---

## 1.1.C — Reporting of Information to the OPTN

<!-- Policy: 1 | Section: 1.1.C | Category: Administrative -->

Members must report requested information to the OPTN to fulfill membership requirements 
and to ensure compliance with OPTN Policies, Bylaws, and Management and Membership 
Policies. The OPTN will determine the required method and format for reporting any 
information required by OPTN Policies, Bylaws, and Management and Membership Policies, 
including the requirement to submit specific forms at defined times.

---

## 1.1.D — Signature

<!-- Policy: 1 | Section: 1.1.D | Category: Administrative -->

Signatures necessary to meet OPTN Obligations may be handwritten or electronically produced, 
including digital or electronically imaged signatures.

---

## 1.2 — Definitions (Part 1)

<!-- Policy: 1 | Section: 1.2 | Category: Administrative -->

The definitions that follow are used to define terms specific to the OPTN Policies. 
A 
Active candidate 
A candidate on the waiting list who is currently suitable for transplantation and eligible to receive organ 
offers. 

Agent 
A person legally authorized to act on behalf of another person. 

Allocation MELD or PELD Score 
The highest exception or calculated MELD or PELD score, including liver-intestine points, available to the 
candidate at the time of the match run for a liver or liver-intestine according to Policy. 

Alternative allocation system 
A type of variance that allows members who are permitted to join the variance to allocate organs 
differently than the OPTN Policies. 

Alternative local unit (ALU) 
A type of variance that creates a distinct geographic area for organ procurement and distribution. 

Alternative point assignment system 
A type of variance that allows members who are permitted to join the variance to assign points for 
organ allocation differently than required by the OPTN Policies. 

Antigen mismatch 
An antigen mismatch occurs when an identified deceased or living donor antigen is not recognized as 
equivalent to the recipient’s own antigens. In cases where a donor or candidate only has one antigen 
identified at a human leukocyte antigen (HLA) locus (A, B, or DR), the antigens are considered to be 
identical at that locus. 

Approved MELD or PELD Exception 
A MELD or PELD exception or exception extension that met standardized criteria in OPTN policy or was 
reviewed and approved by the NLRB. 

Assigned MELD or PELD Exception 
A MELD or PELD exception or exception extension where the NLRB failed to make a decision within 21 
days of the date of submission of the request and the candidate was assigned the requested score. 

Authorization 
The act of granting permission for a specific act. This is sometimes called consent, which is not to be 
confused with informed consent. 

B 
Backup offer 
An organ offer made to a lower ranked candidate on a deceased donor match run after a transplant 
hospital accepts an organ on behalf of a higher ranked candidate, but before the organ is transplanted. 

Bridge donor 
A Kidney Paired Donation (KPD) donor at the end of a KPD Chain who chooses to participate in future 
KPD match runs. 

Business days 
Calendar days excluding Saturdays, Sundays, and federal holidays. 
C 
Calculated MELD or PELD Score 
The highest non-exception MELD or PELD score available to the candidate according to Policy. 
Calculated MELD or PELD score excludes liver-intestine points. 

Calculated Panel Reactive Antibody (CPRA)  
The percentage of deceased donors expected to have one or more of the unacceptable antigens 
indicated on the waiting list for the candidate. The CPRA is derived from HLA antigen, allele, and epitope 
genotype frequencies for the different populations in proportion to their representation in the national 
deceased donor population. 

Candidate 
A person registered on the organ transplant waiting list. When a candidate appears on the match run, 
the candidate is then referred to as a potential transplant recipient (PTR). 

Chain 
A set of KPD matches that begins with a donation from a non-directed living donor to that KPD donor’s 
matched candidate. This candidate’s paired living donor then donates to the KPD donor’s matched 
candidate. A chain continues until a living donor donates to an orphan candidate, a waiting list 
candidate or is a bridge donor. 

Classification 
A collection of potential transplant recipients grouped by similar characteristics and within a given 
geographical area. Classifications are used to rank potential recipients of deceased or living donor 
organs. A collection of ranked classifications of potential transplant recipients is also known as an organ 
allocation algorithm.  

Closed variance 
A variance that is not open for other members to join it. 

Composite allocation score (CAS)  
The scoring system used to prioritize candidates on the match run. It ranges from 0-100 and is an 
aggregate of separate goal level scores. 

Covered Vascularized Composite Allograft body parts (covered VCAs) 
Covered VCAs are VCAs that are subject to OPTN Policies, Bylaws, and Management and Membership 
Policies. Covered VCAs are categorized by type as follows: 

Covered VCA(s) 
Type:  
Any group of vascularized body parts from 
the upper limb 
Upper limb 
Face, larynx, vascularized parathyroid gland, 
scalp, trachea, vascularized thyroid, and any 
other vascularized body parts from the head 
and neck 
Head and neck 
Abdominal wall, symphysis pubis, and any 
group of vascularized skeletal elements of 
the pelvis 
Abdominal wall 
Uterus, cervix, and vagina 
Uterus 
Penis and scrotum 
External male genitalia 
Internal male genitalia; external and internal 
female genitalia other than uterus, cervix, 
and vagina; and urinary bladder 
Other genitourinary organ 
Adrenal and thymus 
Vascularized gland 
Pelvic structures that are attached to the 
lower limb and transplanted intact, gluteal 
region, vascularized bone transfers from the 
lower extremity, toe transfers, and any group 
of vascularized body parts from the lower 
limb 
Lower limb 
Spine axis, chest wall, and other composite 
graft of vascularized muscle, bone, nerve, or 
skin 
Musculoskeletal composite graft segment 
Spleen 
Spleen 

D 
Day 
Calendar day. 

Deceased donor 
An individual from whom at least one organ is recovered for the purpose of transplantation after 
declaration of death. 

Directed donation 
The allocation of a deceased or living donor organ to a specific candidate named by the person who 
authorized the donation. 

Domino donor  
An individual who has an organ removed as a component of medical treatment and who receives a 
replacement organ. The organ that was removed is transplanted into another person.

---

## 1.2 — Definitions (Part 2)

<!-- Policy: 1 | Section: 1.2 | Category: Administrative | Cross-ref: Policy 15 -->

Donation after Circulatory Death (DCD) 
Donation after Circulatory Death (DCD) describes the organ recovery process that may occur following 
death by irreversible cessation of circulatory and respiratory functions. A DCD donor may also be called 
a non-heart beating, asystolic, or donation after cardiac death donor. 

Donation Service Area (DSA)  
The geographic area designated by the Centers for Medicare and Medicaid Services (CMS) that is served 
by one organ procurement organization (OPO), one or more transplant hospitals, and one or more 
donor hospitals. 

Donor hospital  
The hospital where the deceased or living donor is admitted. 

Donor ID  
A unique identification assigned to each deceased and living donor by the OPTN. 

Donor record 
The record maintained by the OPO regarding an individual deceased donor. 

E 
Eligible death 
For reporting purposes of DSA performance assessments, an eligible death for deceased organ donation 
is defined as the death of a patient who meets all the following characteristics: 

• 
Is 75 years old or less  
• 
Is legally declared dead by neurologic criteria according to state or local law 
• 
Has body weight of 5 kg or greater 
• 
Has a body mass index (BMI) of 50 kg/m2 or less 
• 
Has at least one kidney, liver, heart or lung that is deemed to meet the eligible data definition as 
defined below: 
o The kidney would initially meet the eligible data definition unless the donor meets any of the 
following criteria: 
• 
Greater than 70 years old 
• 
Age 50-69 years with history of type 1 diabetes for more than 20 years 
• 
Polycystic kidney disease 
• 
Glomerulosclerosis greater than or equal to 20% by kidney biopsy  
• 
Terminal serum creatinine greater than 4.0 mg/dL 
• 
Chronic renal failure 
• 
No urine output for 24 hours or longer 

o The liver would initially meet the eligible data definition unless the donor meets any of the 
following criteria: 
• 
Cirrhosis 
• 
Terminal total bilirubin greater than or equal to 4 mg/dL  
• 
Portal hypertension 
• 
Macrosteatosis greater than or equal to 50% or fibrosis greater than or equal to stage II 
• 
Fulminant hepatic failure  
• 
Terminal AST/ALT greater than 700 U/L 
o The heart would initially meet the eligible data definition unless the donor meets any of the 
following criteria: 
• 
Greater than 60 years old 
• 
45 years old or older with a history of 10 or more years of HTN or 10 or more years of type 1 
diabetes 
• 
History of coronary artery bypass graft (CABG) 
• 
History of coronary stent/intervention 
• 
Current or past medical history of myocardial infarction (MI) 
• 
Severe vessel diagnosis as supported by cardiac catheterization (that is more than 50 
percent occlusion or 2+ vessel disease) 
• 
Acute myocarditis or endocarditis, or both 
• 
Heart failure due to cardiomyopathy 
• 
Internal defibrillator or pacemaker 
• 
Moderate to severe single valve or 2-valve disease documented by echo or cardiac 
catheterization, or previous valve repair  
• 
Serial echo results showing severe global hypokinesis 
• 
Myxoma 
• 
Congenital defects (surgically corrected or not) 
o The lung would initially meet the eligible data definition unless the donor meets any of the 
following criteria: 
• 
Greater than 65 years old 
• 
Diagnosed with COPD 
• 
Terminal PaO2/FiO2 less than 250 mmHg 
• 
Asthma (with daily prescription) 
• 
Asthma is the cause of death 
• 
Pulmonary fibrosis 
• 
Previous lobectomy 
• 
Multiple blebs documented on computed axial tomography (CAT) scan 
• 
Pneumonia as indicated on computed tomography (CT), X-ray, bronchoscopy, or cultures 
• 
Bilateral severe pulmonary contusions as per CT 

If a deceased patient meets the above criteria they would be classified as an eligible death unless the 
donor meets any of the following criteria: 

• 
The donor goes to the operating room with intent to recover organs for transplant and all organs are 
deemed not medically suitable for transplant 
• 
The donor exhibits any of the following active infections (with a specific diagnosis): 
o Bacterial: tuberculosis, gangrenous bowel or perforated bowel or intra-abdominal sepsis 

o Viral: HIV infection by serologic or molecular detection, rabies, reactive hepatitis B surface 
antigen, retroviral infections including viral encephalitis or meningitis, active herpes simplex, 
varicella zoster, or cytomegalovirus viremia or pneumonia, acute Epstein Barr virus 
(mononucleosis), West Nile virus infection, or SARS. However, an organ procured from a donor 
with HIV for transplantation into a recipient living with HIV at a transplant hospital that meets 
the requirements in Policy 15.7: Recovery and Transplantation of Organs from Donors with HIV 
would still meet the requirements of an eligible death. 
o Fungal: active infection with cryptococcus, aspergillus, histoplasma, coccidioides, active 
candidemia or invasive yeast infection 
o Parasites: active infection with trypanosoma cruzi (Chagas'), Leishmania, strongyloides, or 
malaria (plasmodium sp.) 
o Prion: Creutzfeldt-Jacob disease 

The following are general exclusions: 

• 
Aplastic anemia, agranulocytosis 
• 
Current malignant neoplasms, except non-melanoma skin cancers such as basal cell and squamous 
cell cancer and primary CNS tumors without evident metastatic disease 
• 
Previous malignant neoplasms with current evident metastatic disease 
• 
A history of melanoma 
• 
Hematologic malignancies: leukemia, Hodgkin's disease, lymphoma, multiple myeloma 
• 
Active fungal, parasitic, viral, or bacterial meningitis or encephalitis  
• 
No discernible cause of death 

Emergency  
Any situation that compromises telecommunications, transportation, function of or access to the OPTN 
computer match system. 

Exchange 
A set of KPD matches that form a chain, a two-way exchange, or a three-way exchange.

---

## 1.2 — Definitions (Part 3)

<!-- Policy: 1 | Section: 1.2 | Category: Administrative -->

Extra vessels 
Vessels taken during recovery of deceased or living donor organs with the intent to be used in organ 
transplantation only. Extra vessels are not connected to the organ. Extra vessels are subject to the same 
member requirements applying to the organ unless otherwise specified. 
F 
Final Rule 
42 CFR § 121 et seq. 
G 
Geographical Area 
A physical area used to group potential transplant recipients in a classification.  

Glomerular Filtration Rate (GFR) 
A measure of filtering capacity of the kidneys. GFR can be measured directly or estimated (eGFR) using 
various formulae. Formulae used to calculate an eGFR must not use a race-based variable. 

Graft failure  
For all organs except pancreas and covered VCAs, graft failure occurs when any of the following occurs: 

• 
A recipient’s transplanted organ is removed 
• 
A recipient dies 
• 
A recipient is placed on a chronic allograft support system 

Pancreas graft failure occurs when any of the following occurs: 

• 
A recipient’s transplanted pancreas is removed 
• 
A recipient re-registers for a pancreas 
• 
A recipient registers for an islet transplant after receiving a pancreas transplant 
• 
A recipient’s total insulin use is greater than or equal to 0.5 units/kg/day for a consecutive 90 days 
• 
A recipient dies 

Covered VCA graft failure occurs when any of the following occurs: 

• 
A recipient re-registers for the same covered VCA 
• 
A recipient dies 
• 
An unplanned removal of a covered VCA 
H 
Hepatitis B Virus (HBV) 
Hepatitis B is a vaccine-preventable liver infection caused by the hepatitis B virus (HBV). 

Hepatitis C Virus (HCV) 
Hepatitis C is a liver infection caused by the hepatitis C virus (HCV). 

Histocompatibility Laboratory 
A histocompatibility laboratory is a member of the OPTN. A histocompatibility laboratory member is any 
histocompatibility laboratory that performs histocompatibility testing, including but not limited to, 
Human Leukocyte Antigen (HLA) typing, antibody screening, compatibility testing, or crossmatching, and 
serves at least one transplant hospital member or OPO. Histocompatibility laboratory members are 
either independent or hospital-based. See also Independent Histocompatibility Laboratory and Hospital-
based Histocompatibility Laboratory definitions in the OPTN Management and Membership Policies 
Appendix M: Definitions. 

Host Organ Procurement Organization (Host OPO) 
The OPO responding to a deceased organ donor referral from a hospital. 

Human Immunodeficiency Virus (HIV) 
Human Immunodeficiency Virus (HIV) is a virus that attacks the body’s immune system. If HIV is not 
treated, it can lead to Acquired Immunodeficiency Syndrome (AIDS). 
I 
Imminent neurological death 
Imminent Neurological Death is defined as the death of a patient who meets both of the following 
criteria: 

• 
Meets the eligible death definition with the exception that the patient has not been declared legally 
dead by neurologic criteria according to current standards of accepted medical practice and state or 
local law. 
• 
Has a severe neurological injury requiring ventilator support who, upon clinical evaluation 
documented in the OPO record or donor hospital chart, has no observed spontaneous breathing and 
is lacking at least two of the additional brain stem reflexes that follow: 

o Pupillary reaction 
o Response to iced caloric 
o Gag Reflex 
o Cough Reflex 
o Corneal Reflex 
o Doll's eyes reflex 
o Response to painful stimuli 

A patient who is unable to be assessed neurologically due to administration of sedation or 
hypothermia protocol does not meet the definition of an imminent neurological death. 

Inactive candidate 
A candidate that is temporarily unavailable or unsuitable for transplantation, and appears as inactive on 
the waiting list. 

Independent living donor advocate (ILDA) 
A person available to assist potential living donors in the living donation process. 

Intended incompatible  
Donor and candidate primary blood types that are biologically incompatible, but transplantation is 
permissible according to OPTN policy.  

Intestine  
Stomach, small intestine, large intestine, or any portion of the gastro-intestinal tract as determined by 
the medical needs of individual candidates. 

Islet infusion 
An infusion of islets from a single deceased donor. If a recipient receives islets from multiple donors 
simultaneously, then each donor’s islets must be counted as a separate infusion. 

K 
Kidney Paired Donation (KPD)  
The donation and receipt of human kidneys under the following circumstances: 

• 
An individual (the first living donor) desires to make a living donation of a kidney specifically to a 
particular patient (the first patient), but the first living donor is biologically incompatible as a donor 
for the first patient. 
• 
A second individual (the second living donor) desires to make a living donation of a kidney 
specifically to a second particular patient (the second patient), but the second living donor is 
biologically incompatible as a donor for the second patient. 
• 
The first living donor is biologically compatible as a donor of a kidney for the second patient, and the 
second living donor is biologically compatible as a donor of a kidney for the first patient. If there is 
any additional donor-patient pair as described above, each living donor in the group of donor-
patient pairs is biologically compatible as a living donor of a kidney for a patient in the group. 
• 
All donors and patients in the group of donor-patient pairs enter into a single agreement to donate 
and receive the kidneys, respectively, according to biological compatibility within the group. 

Other than described as above, no valuable consideration is knowingly acquired, received, or otherwise 
transferred for the donation of the kidneys. 

L 
Living donor  
A living individual from whom at least one organ is recovered for transplantation.

---

## 1.2 — Definitions (Part 4)

<!-- Policy: 1 | Section: 1.2 | Category: Administrative | Cross-ref: Policy 10, Policy 11, Policy 12, Policy 6, Policy 7, Policy 8, Policy 9 -->

Living donor recipient  
A transplant recipient that receives a living donor organ. 

Living donor organ 
An organ from a living donor. 

Lower respiratory specimen 
A sample taken from the respiratory system within the trachea or below. Sputum, tracheal aspirate, 
bronchial suction, bronchial wash, bronchoalveolar lavage (BAL), and lung biopsy are considered lower 
respiratory specimens.  
M 
Match 
A donor and the donor’s matched candidate. This includes deceased, living, and KPD donors. 

Match run 
A process that filters and ranks waiting list candidates based on deceased or non-directed living donor 
and candidate medical compatibility and organ-specific allocation criteria. A match run is also used to 
generate a set of potential exchanges for a KPD donor and candidate. 

Match system 
The computerized algorithm used to prioritize patients waiting for organs. 

Matched candidate 
The candidate that a KPD match run identifies as a potential transplant recipient of a living donor’s 
kidney. 

Matched donor  
 A living donor identified by a KPD match run as a potential donor for a candidate. 

Matched recipient 
A matched KPD candidate that has received a transplant. 

Medical record 
A chronological account of a patient's examination and treatment that includes the patient's medical 
history and complaints, the physician's physical findings, the results of diagnostic tests and procedures, 
and medications and therapeutic procedures. 

Model for End Stage Liver Disease (MELD)  
The scoring system used to measure illness severity in the allocation of livers to transplant candidates at 
least 12 years old. 

Model-identified offer filter   
A recommended offer filter generated based on a transplant program’s previous organ offer acceptance.   

Member  
The OPTN membership categories are transplant hospital members, OPO members, histocompatibility 
laboratory members, medical/scientific members, public organization members, business members, and 
individual members. 

Month 
Calendar month. 

Multi-organ candidate  
A candidate registered on the waiting lists for more than one organ type. 

N 
National Organ Transplantation Act (NOTA) 
42 U.S.C. § 273 et seq. 

Non-Directed Donor (NDD)  
A KPD donor that enters KPD without a paired candidate or a living donor who donates an organ and 
does not specify an intended recipient. 

Non-domino therapeutic donor  
An individual who has an organ removed as a component of medical treatment and whose organ is 
transplanted into another person. The donor does not receive a replacement organ. 

Non-US citizen/Non-US resident  
A non-citizen of the United States for whom the United States is not the primary place of residence. 

Non-US citizen/US resident  
A non-citizen of the United States for whom the United States is the primary place of residence. 

O 
Open variance  
A variance that allows members other than the members that applied for the variance to join it. 

OPTN computer match program  
A set of computer-based instructions that compares data on a deceased organ donor with data on 
transplant candidates on the waiting list and ranks the candidates according to OPTN Policies to 
determine the priority for allocating the deceased donor organs. 

OPTN Computer System 
The software platform operated by the OPTN Contractor in performance of the OPTN Contract. This 
platform includes, but is not limited to, the OPTN Data System, the OPTN Waiting List, the OPTN Donor 
Data and Matching System, the OPTN Organ Labeling, Packaging, and Tracking system, the OPTN Patient 
Safety Reporting Portal, and OPTN Kidney Paired Donation Pilot Program (KPDPP). 

OPTN Contractor 
The corporation currently operating the Organ Procurement and Transplantation Network (OPTN) under 
contract with HHS. In 1984 NOTA directed the Secretary of HHS to establish by contract the OPTN which 
shall be a private, non-profit entity that has an expertise in organ procurement and transplantation. The 
United Network for Organ Sharing (UNOS) is the current OPTN Contractor. 

OPTN obligations 
Members agree to comply with all OPTN obligations. OPTN obligations include all the applicable 
provisions of NOTA, OPTN Final Rule, OPTN Charter, OPTN Bylaws,OPTN Policies, and OPTN 
Management and Membership Policies. 

OPTN organ tracking system 
A software application developed and distributed by the OPTN Contractor that uses barcode technology 
to generate printed labels for organ packaging and tracking. 

Organ 
A human kidney, liver, heart, lung, pancreas, intestine (including the esophagus, stomach, small or large 
intestine, or any portion of the gastrointestinal tract), or vascularized composite allograft. Blood vessels, 

including extra vessels, recovered from an organ donor during the recovery of such organ(s) are 
considered part of an organ with which they are procured for purposes of these Policies if the vessels 
are intended for use in organ transplantation and labeled ‘‘For use in organ transplantation only.’’ 

Organ allocation policies 
OPTN Policies: Policy 6: Allocation of Hearts and Heart-Lungs, Policy 7: Allocation of Intestines, Policy 8: 
Allocation of Kidneys, Policy 9: Allocation of Livers and Liver-Intestines, Policy 10: Allocation of Lungs, and 
Policy 11: Allocation of Pancreas, Kidney-Pancreas, and Islets, and Policy 12: Allocation of Covered 
Vascularized Composite Allografts.

---

## 1.2 — Definitions (Part 5)

<!-- Policy: 1 | Section: 1.2 | Category: Administrative -->

Organ Center 
The Organ Center is responsible for facilitating organ sharing among transplant centers, organ 
procurement organizations and histocompatibility laboratories across the U.S. The primary functions of 
the Organ Center are to: assist in placing donated organs for transplantation, assist organ procurement 
organizations with running the donor/recipient computer matching process, assist with transportation 
of organs and associated tissues for the purposes of transplantation, act as a resource to the transplant 
community regarding organ sharing policies. The Organ Center operates 24 hours a day, 365 days a year. 

Organ offer acceptance  
When the transplant hospital notifies the host OPO that it accepts the organ offer for an intended 
recipient, pending review of organ anatomy. For kidney, acceptance is also pending final crossmatch. 

Organ offer refusal  
When the transplant hospital notifies the OPTN or the host OPO that they are declining the organ offer. 

Organ procurement organization (OPO) 
An organization authorized by the Centers for Medicare and Medicaid Services, under Section 1138(b) of 
the Social Security Act, to procure organs for transplantation. 

Organ Procurement and Transplantation Network (OPTN) 
The network established according to Section 372 of the Social Security Act. 

Organ transplant 
Organ transplants include solid organ transplants and islet infusions. An organ transplant begins at the 
start of organ anastomosis or the start of an islet infusion. 

An organ transplant procedure is complete when any of the following occurs: 

• 
The chest or abdominal cavity is closed and the final skin stitch or staple is applied. 
• 
The transplant recipient leaves the operating room, even if the chest or abdominal cavity cannot be 
closed. 
• 
The islet infusion is complete. 

Orphan candidate 
A KPD candidate who does not receive a kidney transplant from the matched donor for any reason after 
the candidate’s paired donor has donated. 

Other antibody specificities 
Antigens specified for a KPD candidate that may result in a positive or negative crossmatch. The rate of 
positive crossmatches would be expected to be higher against KPD donors who express these antigens. 

P 
Pair  
A KPD donor and the KPD donor’s paired KPD candidate. 

Paired candidate  
The KPD candidate to whom a KPD donor intended to donate his organ before entering into KPD. 

Paired donor  
A living donor who intended to donate his organ to his paired candidate before entering into KPD. 

Paired donor’s transplant hospital  
The transplant hospital that enters the donor in a KPD program. 

Paired recipient 
A paired KPD candidate that has received a transplant. 

Patient 
Includes all of the following: 

1. Potential deceased donors undergoing an OPO’s potential donor evaluation, donor management 
and procurement processes 
2. Potential candidates and potential living donors undergoing a transplant program’s evaluation 
process 
3. Candidates 
4. Living donors being followed by a transplant program 
5. Recipients being followed by a transplant program 

Pediatric End Stage Liver Disease (PELD)  
The scoring system used to measure illness severity in the allocation of livers to pediatric candidates 
under the age of 12.   

PHS Guideline, see United States Public Health Service (PHS) Guideline. 

Planned Removal of a Uterus 
A planned removal of a uterus occurs when the graft is removed with the intent of removal recorded 
either pre-transplant or at time of transplant. 

Potential transplant recipient (PTR) 
A candidate who appears on a match run. 

Primary potential transplant recipient 
The first candidate according to match run sequence for whom an organ has been accepted. 

Primary waiting time 
The longest time period a candidate registered on the waiting list has been waiting for a specific organ 
transplant procedure, after having met qualifying criteria to accrue waiting time for that organ. Primary 
waiting time is based on the candidate’s qualifying date, registration date, and waiting time accrued. 

Privacy Incident 
A suspected or confirmed incident involving the loss of control, compromise, unauthorized disclosure, 
unauthorized acquisition, or any similar occurrence where (1) a person other than an authorized user 
accesses or potentially accesses Personally Identifiable Information (PII) or (2) an authorized user 
accesses PII for an other than authorized purpose. 

Provisional yes  
When the transplant hospital notifies the OPTN or the host OPO that they have evaluated the offer and 
are interested in accepting the organ or receiving more information about the organ. 

Q 
Qualified health care professional 
A person who is qualified to perform blood type reporting or verification requirements as defined in the 
OPO, transplant hospital, or recovery hospital written protocol. 

Qualified specimen 
A blood specimen without evidence of hemodilution. 

Qualifying date 
The date that a candidate began accruing waiting time. 

Quality Assurance and Performance Improvement (QAPI) 
Any quality assessment and improvement activities consistent with the definition of health care 
operations in the Health Insurance Portability and Accountability Act (HIPAA). 

R 
Receiving transplant program  
The transplant program that receives a deceased or living donor organ from an OPO, transplant hospital, 
or recovery hospital. 

Recipient 
A candidate that has received an organ transplant. 

Recovery hospital  
A healthcare facility that recovers living donor organs. 

Region 
For administrative purposes, OPTN membership is divided into 11 geographic regions. Members belong 
to the Region in which they are located. The Regions are as follows:

---

## 1.2 — Definitions (Part 6)

<!-- Policy: 1 | Section: 1.2 | Category: Administrative -->

Region 1:  Connecticut, Maine, Massachusetts, New Hampshire, Rhode Island, and Eastern Vermont 
Region 2:  Delaware, District of Columbia, Maryland, New Jersey, Pennsylvania, West Virginia, and the 
part of Northern Virginia in the Donation Service Area served by the Infinite Legacy (MDPC) 
OPO. 
Region 3:  Alabama, Arkansas, Florida, Georgia, Louisiana, Mississippi, and Puerto Rico 
Region 4:  Oklahoma and Texas 
Region 5: 
Arizona, California, Nevada, New Mexico, and Utah 
Region 6: 
Alaska, Hawaii, Idaho, Montana, Oregon, and Washington 
Region 7: 
Illinois, Minnesota, North Dakota, South Dakota, and Wisconsin 
Region 8: 
Colorado, Iowa, Kansas, Missouri, Nebraska, and Wyoming 
Region 9: 
New York and Western Vermont 
Region 10: Indiana, Michigan, and Ohio 
Region 11: Kentucky, North Carolina, South Carolina, Tennessee, and Virginia 

Registration date 
The date that the candidate registers on the waiting list. 

S 
Security incident 
An event that is declared as jeopardizing the confidentiality, integrity, or availability of an information 
system or the information the system processes, stores, or transmits. 

Sharing arrangements  
A type of variance that permits two or more OPOs to share organs. 

Source document  
An original record of results, or a photocopy or digital copy of the original record. 

T 
Therapeutic donor  
An individual who has an organ removed as a component of medical treatment and who receives a 
replacement organ. The organ that was removed is transplanted into another person. 

Three-way exchange 
A set of KPD matches that includes three living donor-candidate pairs where each living donor donates a 
kidney to a candidate in one of the other pairs. 

Time-out 
A period of time when action stops until some information is verified, or action is completed. 

Transplant date 
Determined by the start of the organ anastomosis during transplant or the start of the islet infusion.  

Transplant hospital 
A health care facility in which transplants of organs are performed. 

Transplant program 
A component within a transplant hospital that provides transplantation of a particular type of organ. 

Two-way exchange  
A set of matches that includes two living donor-candidate pairs where each living donor donates a 
kidney to the candidate in the other pair. 

U 
Unacceptable antigens 
Antigens to which the patient is sensitized and would preclude transplantation with a deceased or living 
donor having any one of those antigens. 

United States (U.S.) Public Health Service (PHS) Guideline 
The Guideline issued by the U.S. Public Health Service in 2020 that provides recommendations for organ 
transplantation related to Human Immunodeficiency Virus (HIV), Hepatitis B Virus (HBV), and Hepatitis C 
Virus (HCV) transmission. 

V 
Variance  
An experimental policy that tests methods of improving allocation. 

Vascularized Composite Allograft (VCA)  
A body part meeting all nine of the following criteria: 

1. That is vascularized and requires blood flow by surgical connection of blood vessels to function after 
transplantation. 
2. Containing multiple tissue types. 
3. Recovered from a human donor as an anatomical/structural unit. 
4. Transplanted into a human recipient as an anatomical/structural unit. 
5. Minimally manipulated (i.e., processing that does not alter the original relevant characteristics of 
the organ relating to the organ's utility for reconstruction, repair, or replacement). 
6. For homologous use (the replacement or supplementation of a recipient's organ with an organ that 
performs the same basic function or functions in the recipient as in the donor). 

7. Not combined with another article such as a device. 
8. Susceptible to ischemia and, therefore, only stored temporarily and not cryopreserved. 
9. Susceptible to allograft rejection, generally requiring immunosuppression that may increase 
infectious disease risk to the recipient. 

Refer to “Covered Vascularized Composite Allograft body parts (covered VCAs)” for the list of body parts 
covered by OPTN Policies, Bylaws, and Management and Membership Policies. 

W 
Waiting list 
A computerized list of candidates who are waiting to be matched with specific deceased donor organs 
for transplant. 

Y 
Year 
Calendar year. 

Z 
0-ABDR mismatch 
A candidate is considered a 0-ABDR mismatch with a deceased or living donor if all of the following 
conditions are met: 
1. At least one donor antigen is identified for each of the A, B, and DR loci  
2. At least one candidate antigen is identified for each of the A, B, and DR loci 
3. The donor has zero non-equivalent A, B, or DR antigens with the candidate’s antigens 
4. The donor and the candidate have compatible or permissible blood types 

In cases where a candidate or donor has only one antigen identified at an HLA locus (A, B, or DR), the 
antigens are considered to be identical at that locus. A 0-ABDR mismatch may also be referred to as a 
zero mismatch or zero-antigen mismatch.

---

## 1.3.A — Acceptable Variances

<!-- Policy: 1 | Section: 1.3.A | Category: Administrative -->

Permissible variances include, but are not limited to: 
 
• 
Alternative allocation systems 
• 
Alternative local units 
• 
Sharing arrangements 
• 
Alternative point assignment systems 
The following principles apply to all variances: 
 

 
 
1. Variances must comply with the NOTA and the Final Rule. 
2. Members participating in a variance must follow all rules and requirements of the OPTN 
Policies, Bylaws, and Management and Membership Policies.  
3. If the Board later amends an OPTN Policy to contradict with a variance, the Policy 
amendment will not affect the existing variance. 
4. If a member’s application to create, amend, or join a variance will require other members to 
join the variance, the applicant must solicit their support.  
5. The Board of Directors may extend, amend, or terminate a variance at any time.

---

## 1.3.B — Creation of a Variance

<!-- Policy: 1 | Section: 1.3.B | Category: Administrative -->

Members wishing to create or amend a variance must submit an application to the OPTN. 
Completed applications will be considered through the policy development process described in 
OPTN Management and Membership Policy E: Adoption of New Policies. OPTN committees may 
also propose new variances without a member application. 
 
Proposed new variances must address all of the following: 
 
1. The purpose for the proposed variance and how the variance will further this purpose. 
2. A defined expiration date or period of time when the variance will end, the participating 
members will report results, and the sponsoring Committee will evaluate the impact of the 
variance. 
3. An evaluation plan with objective criteria to measure the variance’s success achieving the 
variance’s stated purpose. 
4. Any anticipated difficulties in demonstrating whether the variance is achieving its stated 
purpose. 
5. Whether this is an open variance or closed variance and, if this is an open variance, any 
additional conditions for members to join this variance.

---

## 1.3.C — Joining an Open Variance

<!-- Policy: 1 | Section: 1.3.C | Category: Administrative -->

Members wishing to join an existing open variance must submit an application as dictated by 
the specific variance. When an open variance is created, it may set conditions for the OPTN 
Contractor to approve certain applications.

---

## 1.3.D — Reporting Requirements for Variances

<!-- Policy: 1 | Section: 1.3.D | Category: Administrative -->

Members participating in a variance must submit data and status reports to the sponsoring 
Committee at the frequency defined by the variance, at least annually that does all of the 
following: 
 
1. Evaluate whether the variance is achieving its stated purpose 
2. Provide data for the performance measures in the variance application 
3. Address any organ allocation problems caused by the variance 
 
The sponsoring Committee must actively monitor and evaluate these reports to determine if the 
variance achieved of its stated purpose.

---

## 1.3.E — Final Evaluation of Variances

<!-- Policy: 1 | Section: 1.3.E | Category: Administrative -->

Prior to the variance’s expiration date, the sponsoring Committee must evaluate whether the 
variance achieved its stated purpose and make a final recommendation to the Board of 
Directors. The Board of Directors may take any of the following actions: 
 
1. Direct the sponsoring Committee to develop a policy proposal based on the results of the 
variance 
2. Amend the variance 
3. Extend the variance for a set period of time 
4. Terminate the variance

---

## 1.3.F — Terminating Variances

<!-- Policy: 1 | Section: 1.3.F | Category: Administrative -->

Members participating in a variance may apply to the sponsoring Committee to withdraw from 
or terminate a variance. The applicant must solicit feedback from all other members 
participating in the variance. The sponsoring Committee must recommend to the Board of 
Directors whether to approve or deny the request. The Board of Directors may approve, modify, 
or deny the request.

---

## 1.3.G — Appeals of Variance Decisions

<!-- Policy: 1 | Section: 1.3.G | Category: Administrative -->

Members participating in a variance or seeking to join an open variance may appeal a 
Committee or Board of Directors’ decision on an existing variance. To appeal a decision of a 
Committee, the member must submit a written appeal to the sponsoring Committee within 
thirty days of notice of the decision and submit any new evidence not previously provided. The 
sponsoring Committee may request additional information from the member. The sponsoring 
Committee will then meet to consider the appeal. The member submitting the appeal may 
participate in this meeting. After this meeting, the sponsoring Committee will recommend 
action on the appeal to the Board of Directors. 
 
Once the sponsoring Committee recommends action to the Board of Directors, a member 
cannot appeal again until the Policy Oversight Committee (POC) and Board of Directors decide 
on the variance. While evaluating the appeal, the POC may request additional information from 
the member. The sponsoring Committee must submit any information received from the 
member to the POC. The POC will recommend action on the variance to the Board of Directors. 
 
The Board of Directors will consider the variance including the recommendations of the 
sponsoring Committee and the POC. The member may participate in this meeting of the Board 
of Directors.

---

## 1.4.A — Regional and National Emergencies

<!-- Policy: 1 | Section: 1.4.A | Category: Administrative -->

During a regional or national emergency, the OPTN Contractor will attempt to distribute 
instructions to all transplant hospitals and OPOs that describe the impact and how to proceed 
with organ allocation, distribution, and transplantation. 
 
When the OPTN registers a candidate or modifies a candidate’s registration due to an 
emergency, the transplant hospital must submit to the OPTN a statement explaining the event.

---

## 1.4.B — Transportation Disruptions

<!-- Policy: 1 | Section: 1.4.B | Category: Administrative -->

If the transportation of organs is either not possible or severely impaired, affected members 
must contact the OPTN to determine proper operating procedures.

---

## 1.4.C — Internet Outages

<!-- Policy: 1 | Section: 1.4.C | Category: Administrative -->

If the OPTN and members cannot communicate through the internet, affected members must 
contact the OPTN to determine the proper operating procedures.

---

## 1.4.D — Telecommunications Outage

<!-- Policy: 1 | Section: 1.4.D | Category: Administrative -->

If the OPTN and members cannot communicate through telephone, affected members: 
 
1. Must contact the OPTN by e-mail to determine operating procedures and to obtain 
assistance. 
2. Must continue to use the OPTN computer match program for organ allocation and 
distribution. 
3. Must document and report to the OPTN any variations in allocation or distribution during 
the telecommunications problems.

---

## 1.4.E — OPTN Computer Match Program Outages

<!-- Policy: 1 | Section: 1.4.E | Category: Administrative -->

If the OPTN and members cannot communicate by any method and the OPTN computer match 
program is either not accessible or not operational, affected OPOs: 
 
1. Must refer to recent matches of similar blood type and body size for ranking transplant 
candidates. 
2. Must use transplant program waiting lists to match the best organ with waiting transplant 
candidates. 
3. Must document and report to the OPTN their process for allocation during the outage.

---

## 1.5 — Department of Defense Directive

<!-- Policy: 1 | Section: 1.5 | Category: Administrative | Cross-ref: Policy 2 -->

Members may cooperate with U.S. military facilities that are bound by United States 
Department of Defense (DOD) organ allocation directives that conflict with OPTN Policies. 
 
 

 
 
 
Policy 2: Deceased Donor Organ Procurement 
2.1 
OPO Organ Acceptance Criteria 
23 
2.2 
OPO Responsibilities 
23 
2.3 
Evaluating and Screening Potential Deceased Donors 
24 
2.4 
Deceased Donor Medical and Behavioral History 
25 
2.5 
Hemodilution Assessment 
25 
2.6 
Deceased Donor Blood Type Determination and Reporting 
25 
2.7 
HIV Screening of Potential Deceased Donors 
27 
2.8 
Required Deceased Donor General Risk Assessment 
28 
2.9 
Required Deceased Donor Infectious Disease Testing 
28 
2.10 Additional Deceased Donor Testing 
29 
2.11 Required Deceased Donor Information 
29 
2.12 Post Procurement Follow Up and Reporting 
32 
2.13 Deceased Donor Management 
32 
2.14 Organ Procurement 
33 
2.15 Requirements for Controlled Donation after Circulatory Death (DCD)  Protocols 
35

---
