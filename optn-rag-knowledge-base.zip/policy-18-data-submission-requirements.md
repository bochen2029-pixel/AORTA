# OPTN Policy 18: Data Submission Requirements

**Source:** OPTN Policies | **Effective:** 12/10/2025 | **Category:** Data Submission
**Confidence:** HIGH — Official OPTN policy language

---

## 18.1.A — Accurate Submission of Data

<!-- Policy: 18 | Section: 18.1.A | Category: Data Submission -->

OPTN members must submit accurate data to the OPTN. Members must maintain 
documentation demonstrating the accuracy of all data submitted to the OPTN.

---

## 18.1.B — Timely Submission of Certain Data

<!-- Policy: 18 | Section: 18.1.B | Category: Data Submission -->

Members must submit data to the OPTN according to Table 18-1. 

OPTN Policies                                                                                                                                    Policy 18: Data Submission Requirement 
 
 
Table 18-1: Data Submission Requirements 
The following 
member: 
Must submit the 
following instruments 
to the OPTN: 
Within: 
For: 
Histocompatibility 
Laboratory 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
Donor 
Histocompatibility 
(DHS) 
60 days after the DHS 
record is generated  
Each living and 
deceased donor 

OPTN Policies                                                                                                                                    Policy 18: Data Submission Requirement 
 
 
The following 
member: 
Must submit the 
following instruments 
to the OPTN: 
Within: 
For: 
Histocompatibility 
Laboratory 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
Recipient 
Histocompatibility 
(RHS) 
60 days after the 
transplant hospital 
removes the candidate 
from the waiting list 
because of transplant 
 
Each heart, intestine, 
kidney, liver, lung, or 
pancreas, or covered 
VCA transplant 
recipient typed by the 
laboratory 
OPOs 
 
 
 
 
 
 
 
 
 
 
Death Notification 
Registration (DNR) 
30 days after the end 
of the month in which 
a donor hospital 
reports a death to the 
OPO or the OPO 
identifies the death 
through a death record 
review 
All imminent 
neurological deaths 
and eligible deaths in 
its DSA 
OPOs 
Monthly Donation Data 
Report: Reported 
Deaths  
30 days after the end 
of the month in which 
a donor hospital 
reports a death to the 
OPO  
All deaths reported by 
a hospital to the OPO 
Allocating OPO 
Potential Transplant 
Recipient (PTR) 
30 days after the 
match run date by the 
OPO or the OPTN 
Each deceased donor 
heart, intestine, kidney, 
liver, lung, pancreas, or 
covered VCA that is 
offered to a potential 
recipient 

OPTN Policies                                                                                                                                    Policy 18: Data Submission Requirement 
 
 
The following 
member: 
Must submit the 
following instruments 
to the OPTN: 
Within: 
For: 
Host OPO 
Donor Organ 
Disposition (Feedback) 
5 business days after 
the procurement date 
Individuals, except 
living donors, from 
whom at least one 
organ is recovered 
Host OPO 
Deceased Donor 
Registration (DDR) 
60 days after the donor 
organ disposition 
(feedback) form is 
submitted and 
disposition is reported 
for all organs 
All deceased donors  
Recovery Hospitals  
Living Donor Feedback 
The time prior to 
donation surgery 
Each potential living 
donor organ recovered 
at the hospital 
Recovery Hospitals 
Living Donor Feedback 
72 hours after the 
donor organ recovery 
procedure 
Any potential living 
donor who received 
anesthesia but did not 
donate an organ or 
whose organ is 
recovered but not 
transplanted into any 
recipient 
Recovery Hospitals  
Living Donor 
Registration (LDR) 
90 days after the 
recovery hospital 
submits the living 
donor feedback form  
Each living donor organ 
recovered at the 
hospital 
 
Recovery Hospitals  
Living Donor Follow-up 
(LDF) 
90 days after the six-
month, 1-year, and 2-
year anniversary of the 
donation date  
 
Each living donor organ 
recovered at the 
hospital 
 
This does not apply 
to domino 
donor and non-domino 
therapeutic 
donor organs. 
 
 

OPTN Policies                                                                                                                                    Policy 18: Data Submission Requirement 
 
 
The following 
member: 
Must submit the 
following instruments 
to the OPTN: 
Within: 
For: 
Transplant hospitals  
Organ Specific 
Transplant Recipient 
Follow-up (TRF) 
Either of the following: 
• 
90 days after the 
six-month and 
annual anniversary 
of the transplant 
date until the 
recipient’s death, 
graft failure, or 
planned graft 
removal of a uterus 
• 
14 days from 
notification of the 
recipient's death or 
graft failure 
Each recipient followed 
by the hospital 
 
 
Transplant hospitals  
Organ Specific 
Transplant Recipient 
Registration (TRR) 
90 days after 
transplant hospital 
removes the recipient 
from the waiting list 
Each recipient 
transplanted by the 
hospital 
Transplant hospitals 
Liver Post-Transplant 
Explant Pathology 
60 days after 
transplant hospital 
removes candidate 
from waiting list  
Each liver recipient 
transplanted by the 
hospital 
Transplant hospitals  
Waiting List Removal 
for Transplant 
1 day after the 
transplant 
Each heart, intestine, 
kidney, liver, lung, 
pancreas, or covered 
VCA recipient 
transplanted by the 
hospital 
Transplant hospitals  
Recipient Malignancy 
(PTM) 
30 days after the 
transplant hospital 
reports the malignancy 
on the transplant 
recipient follow-up 
form 
Each heart, intestine, 
kidney, liver, lung, or 
pancreas recipient with 
a reported malignancy 
that is followed by the 
hospital. 
Transplant hospitals  
Transplant Candidate 
Registration (TCR) 
90 days after the 
transplant hospital 
registers the candidate 
on the waiting list 
Each heart, intestine, 
kidney, liver, lung, 
pancreas or covered 
VCA candidate on the 
waiting list or recipient 
transplanted by the 
hospital 
 

OPTN Policies                                                                                                                                    Policy 18: Data Submission Requirement

---

## 18.1.C — Retrospective Data Collection during COVID-19 Emergency

<!-- Policy: 18 | Section: 18.1.C | Category: Data Submission -->

The following 
member 
Must submit the 
following instruments 
to the OPTN 
For the following 
By 
Recovery Hospitals  
Living Donor Follow-up 
(LDF) 
Living donors with forms 
due during the period of 
March 13, 2020 through 
March 31, 2021. 
July 1, 2021 
Transplant 
hospitals  
Organ Specific 
Transplant Recipient 
Follow-up (TRF) 
Recipients with forms due 
during the period of 
March 13, 2020 through 
March 31, 2021. 
July 1, 2021 
Transplant 
hospitals  
Recipient Malignancy 
(PTM) 
Recipients with forms due 
during the period of 
March 13, 2020 through 
March 31, 2021. 
July 1, 2021

---

## 18.1.D — Changes to Submitted Data

<!-- Policy: 18 | Section: 18.1.D | Category: Data Submission -->

Upon expiration of the corresponding timeframe listed in Table 18-1, data submitted using the 
following instruments are considered final: 
 
• 
Deceased Donor Registration (DDR) 
• 
Donor Histocompatibility (DHS) 
• 
Recipient Histocompatibility (RHS) 
• 
Transplant Candidate Registration (TCR) 
• 
Transplant Recipient Registration (TRR) 
• 
Living Donor Registration (LDR) 
• 
Transplant Recipient Follow-up (TRF) 
• 
Living Donor Follow-up (LDF) 
 
Changes to final data will not be permitted unless the member reports, within the data 
collection system prior to making the changes, both the approval of the member’s official OPTN 
Representative (or designee) and the reason for the changes.

---

## 18.1.E — Reporting

<!-- Policy: 18 | Section: 18.1.E | Category: Data Submission -->

The Data Advisory Committee must report to the Board of Directors at least annually all of the 
following 
 
• 
Data submission compliance rates; 
• 
The frequencies of data change following submission and reasons reported; and 
• 
Other relevant information identified by the Committee 
 

OPTN Policies                                                                                                                                    Policy 18: Data Submission Requirement

---

## 18.2 — Timely Collection of Data

<!-- Policy: 18 | Section: 18.2 | Category: Data Submission -->

Members must collect and submit timely information to the OPTN. Timely data on recipients and living 
donors is based on recipient or living donor status at a time as close as possible to the specified 
transplant event anniversary. Table 18-2: Timely Data Collection sets standards for when the member 
must collect the data from the patient.  
 
Table 18-2: Timely Data Collection 
Information is timely if this 
Member: 
Collects this information for 
this form: 
Within this time period: 
Transplant hospital 
Organ specific transplant 
recipient registration (TRR) 
When the transplant recipient 
is discharged from the 
hospital or 42 days following 
the transplant date, 
whichever is first 
Recovery hospital 
Living donor registration (LDR) 
When the living donor is 
discharged from the hospital 
or 42 days following the 
transplant date, whichever is 
first 
Recovery hospital 
Living donor follow-up (LDF) 
60 days before or after the 
six-month, 1-year, and 2-year 
anniversary of the donation 
date

---

## 18.3 — Recording and Reporting the Outcomes of Organ Offers

<!-- Policy: 18 | Section: 18.3 | Category: Data Submission -->

The allocating OPO and the transplant hospitals that received organ offers share responsibility for 
reporting the outcomes of all organ offers. OPOs are responsible for reporting the outcomes of organ 
offers to the OPTN within 30 days of the match run date. OPOs, transplant hospitals, and the OPTN may 
report this information. The OPO or the OPTN must obtain PTR refusal codes directly from the physician, 
surgeon, or their designee involved with the potential recipient and not from other personnel. 
 
If the OPO reports the refusal code, then the transplant hospital has 45 days from the match run date, to 
validate the refusal code by either confirming or amending the refusal code. If the OPO and transplant 
hospital report different refusal codes, then the OPTN will use the transplant hospital’s refusal code for 
data analysis purposes.  
 
If the OPTN reports the refusal code, then the transplant hospital will not be required to validate the 
refusal code.

---

## 18.4 — Living Donor Data Submission Requirements

<!-- Policy: 18 | Section: 18.4 | Category: Data Submission -->

The follow up period for living donors will be a minimum of two years. 
 
The OPTN will calculate follow-up rates separately, and at least annually, for the submission of the six-
month, one-year, and two-year LDF forms. 

OPTN Policies                                                                                                                                    Policy 18: Data Submission Requirement 
 
 
 
Living donor follow-up reporting requirements do not apply to any transplant recipient whose replaced 
or explanted organ is donated to another candidate.

---

## 18.4.A — Reporting Requirements after Living Kidney Donation

<!-- Policy: 18 | Section: 18.4.A | Category: Data Submission -->

LDF forms due between March 13, 2020 and March 31, 2021 are exempt from the requirements 
in this section. 
 
The recovery hospital must report accurate, complete, and timely follow up data for donor 
status and clinical information using the LDF form for at least: 
 
• 
60% of their living kidney donors who donate between February 1, 2013 and December 31, 
2013 
• 
70% of their living kidney donors who donate between January 1, 2014 and December 31, 
2014 
• 
80% of their living kidney donors who donate after December 31, 2014 
 
The recovery hospital must report accurate, complete, and timely follow up kidney laboratory 
data using the LDF form for at least: 
 
• 
50% of their living kidney donors who donate between February 1, 2013 and December 31, 
2013 
• 
60% of their living kidney donors who donate between January 1, 2014 and December 31, 
2014 
• 
70% of their living kidney donors who donate after December 31, 2014 
 
Required kidney donor status and clinical information includes all of the following: 
 
1. Patient status  
2. Working for income, and if not working, reason for not working  
3. Loss of medical (health, life) insurance due to donation 
4. Has the donor been readmitted since last LDR or LDF form was submitted?  
5. Kidney complications  
6. Regularly administered dialysis as an ESRD patient 
7. Donor developed hypertension requiring medication  
8. Diabetes  
9. Cause of death, if applicable and known  
 
Required kidney laboratory data includes all of the following: 
 
1. Serum creatinine  
2. Urine protein

---

## 18.4.B — Reporting Requirements after Living Liver Donation

<!-- Policy: 18 | Section: 18.4.B | Category: Data Submission -->

LDF forms due between March 13, 2020 and March 31, 2021 are exempt from the requirements 
in this section. 

OPTN Policies                                                                                                                                    Policy 18: Data Submission Requirement 
 
 
  
The recovery hospital must report accurate, complete, and timely follow-up data using the LDF 
form for living liver donors who donate after September 1, 2014, as follows: 
 
1. Donor status and clinical information for 80% of their living liver donors. 
2. Liver laboratory data for at least: 
• 
75% of their living liver donors on the 6 month LDF 
• 
70% of their living liver donors on the one year LDF 
 
Required liver donor status and clinical information includes all of the following: 
 
1. Patient status 
2. Cause of death, if applicable and known 
3. Working for income, and if not working, reason for not working 
4. Loss of medical (health, life) insurance due to donation 
5. Hospital readmission since last LDR or LDF was submitted 
6. Liver complications, including the specific complications 
• 
Abscess 
• 
Bile leak 
• 
Hepatic resection 
• 
Incisional hernias due to donation surgery 
• 
Liver failure 
• 
Registered on the liver candidate waiting list 
 
 

OPTN Policies                                                                                                                                    Policy 18: Data Submission Requirement 
 
 
Required liver laboratory data includes all of the following: 
 
1. Alanine aminotransferase 
2. Alkaline phosphatase 
3. Platelet count 
4. Total bilirubin

---

## 18.5.A — Required Reporting by Transplant Hospitals

<!-- Policy: 18 | Section: 18.5.A | Category: Data Submission | Cross-ref: Policy 5 -->

Transplant hospitals must report the following events to the OPTN according to Table 18-3 
below. 
 
Table 18-3: Required Reporting by Transplant Hospitals 
Transplant hospitals must report if: 
To the: 
Within 72 hours after: 
A transplant of the incorrect organ 
into an organ recipient occurs 
OPTN Patient Safety 
Reporting Portal  
The transplant hospital 
becomes aware 
A transplant of an organ into the 
incorrect organ recipient occurs 
OPTN Patient Safety 
Reporting Portal 
The transplant hospital 
becomes aware 
A donor organ is identified as 
incorrect during pre-transplant 
processes conducted according to 
either OPTN Policy 5.8.A: Pre-
Transplant Verification Prior to Organ 
Receipt or OPTN Policy 5.8.B: Pre-
Transplant Verification Upon Organ 
Receipt 
OPTN Patient Safety 
Reporting Portal 
The transplant hospital 
becomes aware 
The potential transplant recipient is 
identified as incorrect during pre-
transplant processes conducted 
according to either OPTN Policy 
5.8.A: Pre-Transplant Verification 
Prior to Organ Receipt or OPTN Policy 
5.8.B: Pre-Transplant Verification 
Upon Organ Receipt 
OPTN Patient Safety 
Reporting Portal 
The transplant hospital 
becomes aware 
An organ was delivered to the 
incorrect transplant hospital and 
resulted in non-use of the organ 
OPTN Patient Safety 
Reporting Portal 
The transplant hospital 
becomes aware 
The incorrect organ was delivered to 
the transplant hospital and resulted 
in non-use of the organ 
OPTN Patient Safety 
Reporting Portal 
The transplant hospital 
becomes aware 

OPTN Policies                                                                                                                                    Policy 18: Data Submission Requirement 
 
 
Transplant hospitals must report if: 
To the: 
Within 72 hours after: 
An ABO typing error or discrepancy is 
caught before or during pre-
transplant processes conducted 
according to either OPTN Policy 
5.8.A: Pre-Transplant Verification 
Prior to Organ Receipt or OPTN Policy 
5.8.B: Pre-Transplant Verification 
Upon Organ Receipt 
OPTN Patient Safety 
Reporting Portal 
The transplant hospital 
becomes aware

---

## 18.5.B — Required Reporting of Living Donor Events by Recovery Hospitals

<!-- Policy: 18 | Section: 18.5.B | Category: Data Submission -->

Recovery hospitals must report living donor events through the OPTN Patient Safety Reporting Portal or 
the OPTN according to Table 18-4 below. 
 
Table 18-4: Living Donor Event Reporting 
Recovery hospitals must report if: 
To the: 
Within 72 hours after: 
A living donor organ recovery 
procedure is aborted after the donor 
has begun to receive general 
anesthesia. 
OPTN Patient Safety 
Reporting Portal and the 
OPTN 
The aborted organ recovery 
procedure 
A living donor dies within 2 years 
after organ donation 
OPTN Patient Safety 
Reporting Portal 
The hospital becomes aware 
A living donor is listed on the  wait 
list within 2 years after organ 
donation 
OPTN Patient Safety 
Reporting Portal 
The hospital becomes aware 
A living kidney donor begins regularly 
administered dialysis as an ESRD 
patient within 2 years after organ 
donation 
OPTN Patient Safety 
Reporting Portal 
The hospital becomes aware 
A living donor organ is recovered but 
not transplanted into any recipient 
OPTN Patient Safety 
Reporting Portal and the 
OPTN 
Organ recovery 
A living donor organ is recovered and 
transplanted into someone other 
than the intended recipient 
OPTN Patient Safety 
Reporting Portal 
Organ recovery 
 
 
 
 
 

OPTN Policies                                                                                                                                    Policy 18: Data Submission Requirement

---

## 18.5.C — Required Reporting by OPOs

<!-- Policy: 18 | Section: 18.5.C | Category: Data Submission | Cross-ref: Policy 2 -->

OPOs must report the following events to the OPTN according to Table 18-5 below. 
 
Table 18-5: Required Reporting by OPOs 
Host OPOs must report if: 
To the: 
Within 72 hours after: 
Transplant hospital procurement 
staff leave the operating room 
without allowing the host OPO to 
package and label deceased donor 
organs and tissue typing specimens 
as required 
OPTN Patient Safety 
Reporting Portal  
The OPO becomes aware 
An ABO typing error or discrepancy is 
caught after the OPO’s deceased 
donor blood type and subtype 
verification process, as outlined in 
Policy 2.6.C: Reporting of Deceased 
Donor Blood Type and Subtype, and 
after the OPO has executed a match 
run 
OPTN Patient Safety 
Reporting Portal 
The OPO becomes aware

---

## 18.5.D — Required Reporting by Histocompatibility Laboratories

<!-- Policy: 18 | Section: 18.5.D | Category: Data Submission | Cross-ref: Policy 19, Policy 20, Policy 4 -->

Histocompatibility laboratories must report the following events to the OPTN according to Table 
18-6 below. 
 
Table 18-6: Required Reporting by Histocompatibility Laboratories 
 
Discovering laboratories must 
report if: 
To the: 
Within 72 hours after: 
A donor, candidate, or 
recipient HLA typing critical 
discrepancy occurs, as 
defined by the OPTN Policy 
4.4: Critical HLA Discrepancies 
in Candidate, Donor, and 
Recipient HLA Typing Results 
OPTN Patient Safety 
Reporting Portal 
The laboratory becomes 
aware 
An incorrect donor or 
candidate sample was used 
for a physical crossmatch 
OPTN Patient Safety 
Reporting Portal 
The laboratory becomes 
aware 
An incorrect candidate HLA 
antibody sample was 
analyzed for a virtual 
crossmatch per program 
testing agreement 
OPTN Patient Safety 
Reporting Portal 
The laboratory becomes 
aware 

OPTN Policies                                                                                                                                     Policy 19: Data Release 
 
 
Policy 19: Data Release  
 
The OPTN will release OPTN data according to the Final Rule and other applicable federal and state laws 
and regulations. The OPTN will release all OPTN data requested by the Secretary of the Department of 
Health and Human Services (HHS). 

 
 
 
 
Policy 20: Travel Expense and Reimbursement  
20.1 Eligibility for Reimbursement 
339 
20.2 Airfare and Rail Reimbursement 
339 
20.3 Hotel Reimbursement 
340 
20.4 Other Transportation 
340 
20.5 Meals 
341 
20.6 Miscellaneous Expenses 
341 
20.7 Non-Reimbursable Expenses 
341 
20.8 Filing Expense Reports 
342

---
