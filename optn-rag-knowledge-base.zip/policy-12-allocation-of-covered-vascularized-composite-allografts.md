# OPTN Policy 12: Allocation of Covered Vascularized Composite Allografts

**Source:** OPTN Policies | **Effective:** 12/10/2025 | **Category:** VCA Allocation
**Confidence:** HIGH — Official OPTN policy language

---

## 12.1 — Waiting Time

<!-- Policy: 12 | Section: 12.1 | Category: VCA Allocation -->

Waiting time for candidates registered for a covered VCA begins when the candidate is registered on the 
waiting list. Candidates are registered by covered VCA type: upper limb, head and neck, abdominal wall, 
uterus, external male genitalia, other genitourinary organ, vascularized gland, lower limb, 
musculoskeletal composite graft segment, or spleen.

---

## 12.2 — Covered VCA Allocation

<!-- Policy: 12 | Section: 12.2 | Category: VCA Allocation | Cross-ref: Policy 13 -->

A covered VCA from a deceased donor is allocated to candidates registered for that covered VCA 
according to Table 12-1 below. 
 
Table 12-1: Allocation of Covered VCAs from Deceased Donors 
Classification 
Candidates registered for the 
covered VCA at a transplant 
hospital that is at or within this 
distance from a donor hospital: 
And are: 
1 
500 NM  
Blood type compatible with the 
donor 
2 
Nation 
Blood type compatible with the 
donor 
 
Within each classification, candidates are sorted by waiting time (longest to shortest). 
 
 
 

OPTN Policies                                                                                                                                       Policy 13: Kidney Paired Donation (KPD) 
 
 
Policy 13: Kidney Paired Donation (KPD)  
13.1 Candidate Requirements for Participation 
261 
13.2 Potential KPD Donor Requirements for Participation 
261 
13.3 Informed Consent for KPD Candidates 
261 
13.4 Informed Consent for KPD Donors 
262 
13.5 OPTN KPD Histocompatibility Testing 
264 
13.6 Matching within the OPTN KPD Program 
266 
13.7 Re-Evaluation Requirements for OPTN KPD Donors 
269 
13.8 OPTN KPD Screening Criteria 
273 
13.9 Two- and Three-Way Matches 
277 
13.10 Donor Chains 
277 
13.11 OPTN KPD Crossmatching Requirements 
279 
13.12 KPD Match Offer and Transplant Timing Requirements 
279 
13.13 Transportation of Kidneys 
281 
13.14 Communication between KPD Donors and Recipients 
281

---
